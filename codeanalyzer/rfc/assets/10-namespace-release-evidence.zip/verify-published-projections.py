from pathlib import Path
import os,sys,json,subprocess,time,signal
from importlib.metadata import version
import cldk,codeanalyzer_typescript,codeanalyzer_java,codeanalyzer_go
root=Path('/Users/rkrsn/workspace/codellm-devkit');work=Path('/private/tmp/namespace-minor-releases')
assert str(Path(cldk.__file__).resolve()).startswith(str(work/'sdk-wheel-env'))
expected={'cldk':'2.1.0','codeanalyzer-python':'1.7.0','codeanalyzer-typescript':'1.7.0','codeanalyzer-java':'3.4.0','codeanalyzer-go':'0.3.0'}
for name,value in expected.items():assert version(name)==value,(name,version(name));print(name,value,flush=True)
services=[('currencyservice','javascript'),('paymentservice','javascript'),('checkoutservice','go'),('frontend','go'),('productcatalogservice','go'),('shippingservice','go'),('emailservice','python'),('loadgenerator','python'),('recommendationservice','python'),('shoppingassistantservice','python'),('adservice','java')]
results=[]
for service,language in services:
 source=root/'online-boutique/src'/service
 if language=='javascript':cmd=[str(codeanalyzer_typescript.bin_path()),'--eager']
 elif language=='go':cmd=[str(codeanalyzer_go.bin_path()),'--eager','--strict']
 elif language=='python':cmd=[sys.executable,'-m','codeanalyzer','--no-ray']
 else:cmd=[str(codeanalyzer_java.java_path()),'-Xmx2g','-jar',str(codeanalyzer_java.jar_path()),'--schema','v2','--strict','-f',str(source)]
 cmd+=['-i',str(source),'-o',str(work/'projection-output'/service),'--namespace','online-boutique','--app-name',service,'--emit','neo4j','--neo4j-uri','bolt://127.0.0.1:17687','--neo4j-database','neo4j']
 print('START',service,flush=True);start=time.monotonic()
 with (work/f'published-{service}.log').open('w') as log:
  proc=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:exit=proc.wait(timeout=600)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGTERM);exit=124
 row={'service':service,'language':language,'exit':exit,'seconds':round(time.monotonic()-start,2),'command':cmd};results.append(row);(work/'published-projections.json').write_text(json.dumps(results,indent=2)+'\n');print('RESULT',service,exit,row['seconds'],flush=True)
 if exit:raise SystemExit(f'Published projection failed: {service}; inspect log')
print('ALL PUBLISHED PROJECTIONS PASSED',flush=True)
