### Task 8: Coordinated verification, PR delivery, and user handoff

**Files:**
- Update: `architecture/codeanalyzer/rfc/10-application-identity-namespaces.md` implementation links and this plan's checkboxes/evidence.
- Update each changed repo's README usage examples; update SDK dependency pins/lock files through the existing package workflow once compatible producer artifacts are available.
- Create: `architecture/codeanalyzer/rfc/assets/10-namespace-verification.md` for reproducible commands, artifact versions, and remaining integration dependencies.

**Interfaces:**
- Consumes: Passing producer and SDK task results and the tracking map from Task 1.
- Produces: Updated existing analyzer PRs, companion Go/SDK PRs, and concrete integration handoff. No merge, release, production regeneration, or private-repo modification is included.

- [ ] **Step 1: Run a cross-repository smoke test from local producer outputs.** Emit representative Python/Java/JS/TS/Go outputs into temporary directories with the same namespace and explicit service names. Verify every application-owned reference uses the right root, marker 2 is present, all graph endpoints correspond to emitted entities, and SDK local reads preserve IDs. Exercise default monolith roots too. Do not download an unrelated released analyzer and mistake it for the modified local producer.
- [ ] **Step 2: Run available isolated Neo4j checks.** Project the small fixtures into a temporary database/container; verify exact application binding, distinct same-name modules, and equality joins. If Docker/Neo4j is unavailable, state that limitation and retain fake-driver evidence without claiming a live pass. Verify selected SDK attachment is read-only and unrelated fixture data survives regeneration/cleanup.
- [ ] **Step 3: Reconcile packaging and validation.** Pin released compatible versions only when they exist. Until then, use editable/local producer artifacts for SDK validation and mark companion PRs coordinated/blocking; do not fabricate version pins or claim released-package compatibility. Confirm fixture copies remain byte-identical and run `git diff --check` in each changed repository.
- [ ] **Step 4: Review and deliver PRs.** Obtain independent review of the combined identity contract, scope checks, and deduplication behavior. Push commits to George's existing three PR branches without force pushes. Rewrite their titles/bodies around the actual namespace implementation and validation, preserving relevant unrelated fixes. Open Go/SDK PRs from the companion branches. Link issues/PRs across repositories and record any unresolved integration-level joins in their tracking issues.
- [ ] **Step 5: Leave the requested user verification note.** After implementation, the user will clone Online Boutique, project all analyzer outputs into one Neo4j database, confirm `online-boutique` namespace grouping, and run a Python SDK script checking service-specific resolution. Supply the actual built versions and a small script/command example; this user-run check supplements the automated fixture tests and must not be reported as already performed.

## Self-review checklist

- [x] Every first-iteration RFC requirement maps to Tasks 1–8; deferred ADR work stays deferred.
- [x] Every new interface has a definition above; task consumers use those exact names/types.
- [x] All five Review Focus risks have concrete assertions in their owning tasks.
- [x] Existing PR fixes survive removal of workspace-relative identity; no branch resets or force pushes.
- [x] External integration deduplication is tracked separately from the SDK implementation.
- [x] Product code starts after plan review; implementation claims require recorded command results.

## Execution choice

:::question
Which execution approach should implement this reviewed plan?

The four producer tasks can be implemented independently against the frozen contract, followed by SDK and regression work. Subagent-driven execution gives each component a separate implementation and review pass; native execution keeps all work in this session with a final independent review.

- [x] Subagent-driven — separate implementer/reviewer passes for each task
- [ ] Native — implementation in this session, then one independent final review

Recommended: Subagent-driven
:::
