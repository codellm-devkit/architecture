f62c3ec fix: validate output scope and preserve graph edge facts
 README.md                           |  6 ++++
 internal/core/analyzer.go           |  3 ++
 internal/core/analyzer_test.go      | 37 +++++++++++++++++++++
 internal/neo4j/bolt.go              |  6 ++--
 internal/neo4j/bolt_session_test.go | 65 +++++++++++++++++++++++++++++++++++++
 internal/neo4j/cypher.go            | 12 +++----
 internal/neo4j/ddl.go               | 42 ++++++++++++------------
 internal/neo4j/rows.go              |  9 +++++
 internal/neo4j/schema.go            | 11 +++++--
 internal/neo4j/schema_test.go       |  7 ++++
 10 files changed, 166 insertions(+), 32 deletions(-)
diff --git a/README.md b/README.md
index 8481ee6..0d61c82 100644
--- a/README.md
+++ b/README.md
@@ -787,10 +787,16 @@ The version is injected into the binary at build time via `-ldflags "-X main.ver
 Apache 2.0 — see [LICENSE](./LICENSE).
 
 Application identity uses `--namespace` (default: resolved application name) and
 `--app-name` (default: input directory basename). Both segments are always present,
 for example `can://team/inventory` or `can://inventory/inventory`. Names are raw,
 case-sensitive Unicode strings; reserved UTF-8 bytes are percent encoded. Empty,
 whitespace-only, control-containing names, slashes, backslashes, `.` and `..` are
 rejected. Explicit empty flags are errors. Outputs and graph anchors carry integer
 `identity_version: 2`; regenerate legacy outputs from source. The graph writer
 rejects incompatible selected anchors before any DDL or graph write.
+
+Graph relationships retain existing `_k` values and additionally use private
+`_fact` identity (declared as `relationship_fact_property` by `--emit schema`).
+Both snapshot and Bolt writers derive it from SHA-256 of the canonical JSON of
+the existing pruned relationship properties. Equal endpoint/type/key facts with
+different site, context, or evidence properties therefore remain distinct.
diff --git a/internal/core/analyzer.go b/internal/core/analyzer.go
index 9618e27..a82ac2c 100644
--- a/internal/core/analyzer.go
+++ b/internal/core/analyzer.go
@@ -336,20 +336,23 @@ func StreamJSON(w io.Writer, app *schema.GoApplication, l3 map[dataflow.L3Key]da
 	if err := v2emit.EmitTo(bw, app, identity, opts.InputPath, int(opts.Level), opts.AnalyzerVersion, KLimit(opts), l3, l4); err != nil {
 		return err
 	}
 	return bw.Flush()
 }
 
 // WriteOutput streams the analysis to outputDir/analysis.json, or to stdout
 // when outputDir is empty. The file is written beside its destination and
 // renamed into place, so a failed run never leaves a truncated analysis.json.
 func WriteOutput(app *schema.GoApplication, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result, opts options.AnalysisOptions) error {
+	if _, err := resolveIdentity(opts); err != nil {
+		return err
+	}
 	if err := checkFormat(opts); err != nil {
 		return err
 	}
 	if opts.OutputDir == "" {
 		return StreamJSON(os.Stdout, app, l3, l4, opts)
 	}
 	if err := utils.EnsureDir(opts.OutputDir); err != nil {
 		return err
 	}
 	dst := filepath.Join(opts.OutputDir, "analysis.json")
diff --git a/internal/core/analyzer_test.go b/internal/core/analyzer_test.go
index 52330ec..8df7513 100644
--- a/internal/core/analyzer_test.go
+++ b/internal/core/analyzer_test.go
@@ -418,10 +418,47 @@ func TestAnalyzeInvalidNamespaceReadOnly(t *testing.T) {
 	dir := t.TempDir()
 	opts := options.AnalysisOptions{InputPath: greeterDir(t), AppName: "greeter", Namespace: &ns, Level: options.LevelSymbolTable, CacheDir: dir}
 	if _, err := core.New(opts).Analyze(); err == nil {
 		t.Fatal("accepted empty namespace")
 	}
 	entries, err := os.ReadDir(dir)
 	if err != nil || len(entries) != 0 {
 		t.Fatalf("cache changed: %v %v", entries, err)
 	}
 }
+
+func TestWriteOutputInvalidIdentityPreservesFilesystem(t *testing.T) {
+	for _, existing := range []bool{false, true} {
+		t.Run(fmt.Sprint(existing), func(t *testing.T) {
+			root := t.TempDir()
+			dst := filepath.Join(root, "missing", "output")
+			if existing {
+				if err := os.MkdirAll(dst, 0700); err != nil {
+					t.Fatal(err)
+				}
+				if err := os.WriteFile(filepath.Join(dst, "analysis.json"), []byte("protected"), 0600); err != nil {
+					t.Fatal(err)
+				}
+			}
+			ns := ""
+			opts := options.AnalysisOptions{InputPath: greeterDir(t), AppName: "greeter", Namespace: &ns, OutputDir: dst}
+			if err := core.WriteOutput(&schema.GoApplication{}, nil, nil, opts); err == nil {
+				t.Fatal("accepted invalid identity")
+			}
+			if !existing {
+				entries, err := os.ReadDir(root)
+				if err != nil || len(entries) != 0 {
+					t.Fatalf("created destination: %v %v", entries, err)
+				}
+			} else {
+				entries, err := os.ReadDir(dst)
+				if err != nil || len(entries) != 1 {
+					t.Fatalf("changed destination: %v %v", entries, err)
+				}
+				b, err := os.ReadFile(filepath.Join(dst, "analysis.json"))
+				if err != nil || string(b) != "protected" {
+					t.Fatalf("changed output: %q %v", b, err)
+				}
+			}
+		})
+	}
+}
diff --git a/internal/neo4j/bolt.go b/internal/neo4j/bolt.go
index 201df06..baaf0e2 100644
--- a/internal/neo4j/bolt.go
+++ b/internal/neo4j/bolt.go
@@ -385,23 +385,23 @@ func (w *boltWriter) upsertEdges(edges []EdgeRow) error {
 	groups := map[string][]EdgeRow{}
 	for _, e := range edges {
 		groups[edgeGroupKey(e)] = append(groups[edgeGroupKey(e)], e)
 	}
 	for _, gk := range sortedEdgeKeys(groups) {
 		g := groups[gk]
 		e0 := g[0]
 		keyed := e0.Key != ""
 		var mergeClause string
 		if keyed {
-			mergeClause = fmt.Sprintf("MERGE (a)-[r:%s {_k: row.k}]->(b)", e0.Type)
+			mergeClause = fmt.Sprintf("MERGE (a)-[r:%s {_k: row.k, %s: row.f}]->(b)", e0.Type, RelationshipFactProperty)
 		} else {
-			mergeClause = fmt.Sprintf("MERGE (a)-[r:%s]->(b)", e0.Type)
+			mergeClause = fmt.Sprintf("MERGE (a)-[r:%s {%s: row.f}]->(b)", e0.Type, RelationshipFactProperty)
 		}
 		q := fmt.Sprintf("UNWIND $rows AS row MATCH (a:%s {%s: row.a}) MATCH (b:%s {%s: row.b}) %s SET r += row.p",
 			e0.From.Label, e0.From.KeyProp, e0.To.Label, e0.To.KeyProp, mergeClause)
 		params := map[string]any{"rows": edgeParams(g, keyed)}
 		if err := w.write(func(tx neo4j.ManagedTransaction) error {
 			_, err := tx.Run(w.ctx, q, params)
 			return err
 		}); err != nil {
 			return err
 		}
@@ -459,21 +459,21 @@ func nodeParams(g []NodeRow) []map[string]any {
 			}
 		}
 		out[i] = map[string]any{"k": n.Value, "p": p}
 	}
 	return out
 }
 
 func edgeParams(g []EdgeRow, keyed bool) []map[string]any {
 	out := make([]map[string]any, len(g))
 	for i, e := range g {
-		m := map[string]any{"a": e.From.Value, "b": e.To.Value, "p": propsToAny(e.Props)}
+		m := map[string]any{"a": e.From.Value, "b": e.To.Value, "p": propsToAny(e.Props), "f": edgeFactID(e)}
 		if keyed {
 			m["k"] = e.Key
 		}
 		out[i] = m
 	}
 	return out
 }
 
 func propsToAny(p Props) map[string]any {
 	if len(p) == 0 {
diff --git a/internal/neo4j/bolt_session_test.go b/internal/neo4j/bolt_session_test.go
index 3e51d31..db37f0c 100644
--- a/internal/neo4j/bolt_session_test.go
+++ b/internal/neo4j/bolt_session_test.go
@@ -1,14 +1,15 @@
 package neo4j
 
 import (
 	"context"
+	"reflect"
 	"strings"
 	"testing"
 
 	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
 )
 
 // recordingSession is a DB-free SessionWithContext: it records which path a
 // statement takes (implicit Run vs an explicit ExecuteWrite transaction).
 // Methods it does not override panic through the nil embedded interface.
 type recordingSession struct {
@@ -412,10 +413,74 @@ func TestIncompatibleIdentityReadOnly(t *testing.T) {
 func TestMissingStoredIdentityReadOnly(t *testing.T) {
 	db := &fakeDB{missingIdentity: true}
 	w := &boltWriter{ctx: context.Background(), session: db, appID: "can://team/app"}
 	if err := w.run(); err == nil {
 		t.Fatal("accepted legacy anchor")
 	}
 	if len(db.writes) != 0 {
 		t.Fatal("wrote before rejecting legacy anchor")
 	}
 }
+
+func TestWritersPreserveDistinctEdgeFacts(t *testing.T) {
+	for _, key := range []string{"", "original-key"} {
+		for _, field := range []string{"site", "context"} {
+			t.Run(key+"/"+field, func(t *testing.T) {
+				build := func(reverse bool) GraphRows {
+					b := NewRowBuilder()
+					n := b.Node([]string{LabelCallable}, "id", "can://team/app/go/a", nil, "")
+					sites := []string{"one", "two"}
+					if reverse {
+						sites[0], sites[1] = sites[1], sites[0]
+					}
+					for _, site := range sites {
+						props := Props{"site": "shared", "context": "shared"}
+						props[field] = site
+						b.Edge(RelCalls, n, n, props, key)
+					}
+					return b.Finish()
+				}
+				var scripts []string
+				var batches [][]map[string]any
+				for _, reverse := range []bool{false, true} {
+					rows := build(reverse)
+					var script strings.Builder
+					writeEdgeBatches(&script, rows.Edges)
+					scripts = append(scripts, script.String())
+					db := &fakeDB{}
+					w := &boltWriter{ctx: context.Background(), session: db}
+					if err := w.upsertEdges(rows.Edges); err != nil {
+						t.Fatal(err)
+					}
+					if len(db.writes) != 1 {
+						t.Fatalf("writes %d", len(db.writes))
+					}
+					q := db.writes[0].q
+					if !strings.Contains(q, "_fact: row.f") || !strings.Contains(script.String(), "_fact: row.f") {
+						t.Fatalf("fact identity missing:\n%s\n%s", q, script.String())
+					}
+					batch := db.writes[0].params["rows"].([]map[string]any)
+					batches = append(batches, batch)
+					if len(batch) != 2 || batch[0]["f"] == nil || batch[0]["f"] == batch[1]["f"] {
+						t.Fatalf("collapsed facts: %+v", batch)
+					}
+					for _, row := range batch {
+						f, ok := row["f"].(string)
+						if !ok || !strings.Contains(script.String(), "f: "+cypherString(f)) {
+							t.Fatalf("writer identity differs: %+v", row)
+						}
+						if key != "" {
+							if row["k"] != key || !strings.Contains(q, "_k: row.k") || !strings.Contains(script.String(), "k: "+cypherString(key)) {
+								t.Fatal("original key lost")
+							}
+						} else if _, ok := row["k"]; ok {
+							t.Fatal("invented original key")
+						}
+					}
+				}
+				if scripts[0] != scripts[1] || !reflect.DeepEqual(batches[0], batches[1]) {
+					t.Fatal("input order changes writer identities")
+				}
+			})
+		}
+	}
+}
diff --git a/internal/neo4j/cypher.go b/internal/neo4j/cypher.go
index 8370558..3b883b3 100644
--- a/internal/neo4j/cypher.go
+++ b/internal/neo4j/cypher.go
@@ -172,34 +172,34 @@ func writeEdgeBatches(b *strings.Builder, edges []EdgeRow) {
 		keyed := e0.Key != ""
 
 		for _, chunk := range chunkEdges(g, batchSize) {
 			b.WriteString("UNWIND [\n")
 			for i, e := range chunk {
 				sep := ","
 				if i == len(chunk)-1 {
 					sep = ""
 				}
 				if keyed {
-					fmt.Fprintf(b, "  {a: %s, b: %s, k: %s, p: %s}%s\n",
-						cypherString(e.From.Value), cypherString(e.To.Value), cypherString(e.Key), cypherMap(e.Props), sep)
+					fmt.Fprintf(b, "  {a: %s, b: %s, k: %s, f: %s, p: %s}%s\n",
+						cypherString(e.From.Value), cypherString(e.To.Value), cypherString(e.Key), cypherString(edgeFactID(e)), cypherMap(e.Props), sep)
 				} else {
-					fmt.Fprintf(b, "  {a: %s, b: %s, p: %s}%s\n",
-						cypherString(e.From.Value), cypherString(e.To.Value), cypherMap(e.Props), sep)
+					fmt.Fprintf(b, "  {a: %s, b: %s, f: %s, p: %s}%s\n",
+						cypherString(e.From.Value), cypherString(e.To.Value), cypherString(edgeFactID(e)), cypherMap(e.Props), sep)
 				}
 			}
 			b.WriteString("] AS row\n")
 			fmt.Fprintf(b, "MATCH (a:%s {%s: row.a})\n", e0.From.Label, e0.From.KeyProp)
 			fmt.Fprintf(b, "MATCH (b:%s {%s: row.b})\n", e0.To.Label, e0.To.KeyProp)
 			if keyed {
-				fmt.Fprintf(b, "MERGE (a)-[r:%s {_k: row.k}]->(b)\n", e0.Type)
+				fmt.Fprintf(b, "MERGE (a)-[r:%s {_k: row.k, %s: row.f}]->(b)\n", e0.Type, RelationshipFactProperty)
 			} else {
-				fmt.Fprintf(b, "MERGE (a)-[r:%s]->(b)\n", e0.Type)
+				fmt.Fprintf(b, "MERGE (a)-[r:%s {%s: row.f}]->(b)\n", e0.Type, RelationshipFactProperty)
 			}
 			b.WriteString("SET r += row.p;\n")
 		}
 	}
 	b.WriteByte('\n')
 }
 
 // ─── grouping keys & chunking ─────────────────────────────────────────────────
 
 func nodeGroupKey(n NodeRow) string {
diff --git a/internal/neo4j/ddl.go b/internal/neo4j/ddl.go
index eb1e30c..b35632a 100644
--- a/internal/neo4j/ddl.go
+++ b/internal/neo4j/ddl.go
@@ -78,30 +78,31 @@ func Indexes() []Index {
 func constraintName(label, prop string) string {
 	return fmt.Sprintf("%s_%s_unique", lower(label), prop)
 }
 
 // ─── --emit schema document ──────────────────────────────────────────────────
 
 // SchemaDocument is the machine-readable graph contract, serialized by
 // --emit schema to schema.neo4j.json. It is the graph-side sibling of the
 // keystone JSON schema and what the SDK's Neo4j backend reconstructs against.
 type SchemaDocument struct {
-	SchemaVersion string       `json:"schema_version"`
-	Language      string       `json:"language"`
-	NodePrefix    string       `json:"node_prefix"`
-	RelPrefix     string       `json:"rel_prefix"`
-	MarkerLabel   string       `json:"marker_label"`
-	SymbolLabel   string       `json:"symbol_label"`
-	Nodes         []NodeDoc    `json:"nodes"`
-	Relationships []RelDoc     `json:"relationships"`
-	Constraints   []Constraint `json:"constraints"`
-	Indexes       []Index      `json:"indexes"`
+	RelationshipFactProperty string       `json:"relationship_fact_property"`
+	SchemaVersion            string       `json:"schema_version"`
+	Language                 string       `json:"language"`
+	NodePrefix               string       `json:"node_prefix"`
+	RelPrefix                string       `json:"rel_prefix"`
+	MarkerLabel              string       `json:"marker_label"`
+	SymbolLabel              string       `json:"symbol_label"`
+	Nodes                    []NodeDoc    `json:"nodes"`
+	Relationships            []RelDoc     `json:"relationships"`
+	Constraints              []Constraint `json:"constraints"`
+	Indexes                  []Index      `json:"indexes"`
 }
 
 // NodeDoc / RelDoc are the serialized (JSON-stable) views of NodeSpec / RelSpec.
 type NodeDoc struct {
 	Label      string   `json:"label"`
 	MergeLabel string   `json:"merge_label"`
 	Key        string   `json:"key"`
 	Props      []string `json:"props"`
 	CanNode    bool     `json:"can_node"`
 }
@@ -121,30 +122,31 @@ type RelDoc struct {
 func BuildSchemaDocument() SchemaDocument {
 	nodes := make([]NodeDoc, 0, len(Nodes))
 	for _, n := range Nodes {
 		nodes = append(nodes, NodeDoc(n))
 	}
 	rels := make([]RelDoc, 0, len(Rels))
 	for _, r := range Rels {
 		rels = append(rels, RelDoc(r))
 	}
 	return SchemaDocument{
-		SchemaVersion: SchemaVersion,
-		Language:      v2.Language,
-		NodePrefix:    NodePrefix,
-		RelPrefix:     RelPrefix,
-		MarkerLabel:   MarkerLabel,
-		SymbolLabel:   SymbolLabel,
-		Nodes:         nodes,
-		Relationships: rels,
-		Constraints:   UniquenessConstraints(),
-		Indexes:       Indexes(),
+		RelationshipFactProperty: RelationshipFactProperty,
+		SchemaVersion:            SchemaVersion,
+		Language:                 v2.Language,
+		NodePrefix:               NodePrefix,
+		RelPrefix:                RelPrefix,
+		MarkerLabel:              MarkerLabel,
+		SymbolLabel:              SymbolLabel,
+		Nodes:                    nodes,
+		Relationships:            rels,
+		Constraints:              UniquenessConstraints(),
+		Indexes:                  Indexes(),
 	}
 }
 
 // lower is a tiny ASCII-lowercase for constraint names (labels are ASCII).
 func lower(s string) string {
 	b := []byte(s)
 	for i, c := range b {
 		if c >= 'A' && c <= 'Z' {
 			b[i] = c + ('a' - 'A')
 		}
diff --git a/internal/neo4j/rows.go b/internal/neo4j/rows.go
index fc96985..ea0ad8b 100644
--- a/internal/neo4j/rows.go
+++ b/internal/neo4j/rows.go
@@ -1,13 +1,14 @@
 package neo4j
 
 import (
+	"crypto/sha256"
 	"encoding/json"
 	"fmt"
 	"sort"
 	"strings"
 )
 
 // Milestone M2: the output-agnostic row IR and the RowBuilder. GraphRows is a
 // deterministic, deduped bag of nodes and edges with NO I/O and NO driver; both
 // writers (cypher.go, bolt.go) consume the identical bag. The RowBuilder is the
 // in-memory analog of Neo4j MERGE semantics — it mirrors MERGE … SET += props
@@ -328,10 +329,18 @@ func unionLabels(a, b []string) []string {
 		}
 	}
 	for _, l := range b {
 		if !seen[l] {
 			seen[l] = true
 			out = append(out, l)
 		}
 	}
 	return out
 }
+
+// edgeFactID retains distinct site/context/evidence facts through relationship
+// MERGE. Endpoints, type and original Key remain separate identity components.
+// JSON orders map keys, so equivalent property bags produce the same digest.
+func edgeFactID(e EdgeRow) string {
+	data, _ := json.Marshal(prune(e.Props))
+	return fmt.Sprintf("%x", sha256.Sum256(data))
+}
diff --git a/internal/neo4j/schema.go b/internal/neo4j/schema.go
index f9acac0..18853b4 100644
--- a/internal/neo4j/schema.go
+++ b/internal/neo4j/schema.go
@@ -28,20 +28,25 @@
 // targets, never a renamed shared name.
 package neo4j
 
 import v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 
 // SchemaVersion is the graph contract version, stamped onto the :GoApplication
 // node so a consumer can detect a producer/consumer mismatch at runtime. It
 // moves in lockstep with the JSON schema major (v2.SchemaVersion). The
 // additive-MINOR rule is suspended for the 2.0.0 line (parity with the sibling
 // ruling); consumers gate on the analyzer-version floor instead.
+// RelationshipFactProperty is the private SHA-256 discriminator every writer
+// includes in relationship MERGE, in addition to endpoints/type and any _k.
+// It hashes the canonical JSON of the existing pruned fact properties.
+const RelationshipFactProperty = "_fact"
+
 const SchemaVersion = v2.SchemaVersion // "2.0.0"
 
 // ─── namespacing (parity: Python PY_/Py, TS TS_/TS) ─────────────────────────
 
 // NodePrefix / RelPrefix are the node-label and relationship-type prefixes for
 // Go's code vocabulary. The SDK's AnalysisBackend ABC reads these as its N / P
 // ClassVars, so GoAnalysisBackend sets N="Go", P="GO_" — the graph vocabulary
 // and the backend's N/P must agree letter-for-letter.
 const (
 	NodePrefix = "Go"
@@ -157,27 +162,27 @@ type NodeSpec struct {
 
 // RelSpec declares one relationship type: its endpoints (by the labels it may
 // connect) and the property names it may carry. Discriminant records the _k
 // property used to keep legitimately-parallel edges from collapsing under MERGE.
 type RelSpec struct {
 	Type string
 	// From / To are the label sets the endpoints may take. Used by the
 	// conformance test to reject an edge wired to an undeclared endpoint.
 	From []string
 	To   []string
-	// Props are the property names the edge may carry (excluding the _k
-	// discriminant, which is Discriminant).
+	// Props are fact property names, excluding writer identity properties:
+	// _k (Discriminant) and the private RelationshipFactProperty.
 	Props []string
 	// Discriminant names the _k key when parallel edges per (endpoint pair) are
 	// legitimate (e.g. "kind" for GO_CFG_NEXT). A composite is written
 	// "a|b" and means _k = a + "|" + strings.Join(b, ","), b being an array
-	// prop (GO_DDG: "var|prov"). Empty = plain endpoint-pair MERGE.
+	// prop (GO_DDG: "var|prov"). Empty omits _k; all relationships also MERGE on RelationshipFactProperty.
 	Discriminant string
 	// Deferred marks an edge whose target may be library/external code not
 	// present in the graph: it is emitted via the RowBuilder's edge-only-when-
 	// resolved path and kept at finish() only if the target was emitted.
 	Deferred bool
 	// Reserved marks an edge declared ahead of the level that fills it: it
 	// emits zero rows. None is Reserved today (the L4 overlay is live).
 	Reserved bool
 }
 
diff --git a/internal/neo4j/schema_test.go b/internal/neo4j/schema_test.go
index 4069038..a7c295b 100644
--- a/internal/neo4j/schema_test.go
+++ b/internal/neo4j/schema_test.go
@@ -316,10 +316,17 @@ func TestContract_L4RelsCarryVar(t *testing.T) {
 		}
 		found := false
 		for _, p := range n.Props {
 			found = found || p == "degraded_json"
 		}
 		if !found {
 			t.Errorf(":GoApplication props %v lack degraded_json", n.Props)
 		}
 	}
 }
+
+func TestSchemaDeclaresRelationshipFactIdentity(t *testing.T) {
+	doc := BuildSchemaDocument()
+	if doc.RelationshipFactProperty != "_fact" {
+		t.Fatalf("private fact identity property: %q", doc.RelationshipFactProperty)
+	}
+}
# codeanalyzer-go: 8fabbf69a11c2c3a338ee60577ca300c52280165..f62c3ec5df679858add19694c3c37d88c8037e30
