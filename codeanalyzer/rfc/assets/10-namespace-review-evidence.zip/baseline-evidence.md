# Pre-implementation baseline evidence

Toolchains were absent initially and installed into /private/tmp/namespace-toolchains (no user-system runtime replacement). Source env.sh there for command paths/cache settings.

- Python: `.venv/bin/python -m pytest test/test_v2_ids.py test/test_v2_schema.py test/test_neo4j_scope.py -q` -> 18 passed, 40 existing pytest_cov/scalpel deprecation warnings, 3.15s; coverage46.86% meets existing40% threshold.
- TypeScript: `bun test test/ids.test.ts test/body-ids.test.ts test/neo4j-prefix-scope.test.ts` ->25 passed,0 failed,1502 assertions,2.02s.
- Go: `go test ./internal/schema/v2` ->passed,0.442s.
- Java: `./gradlew test --tests 'com.ibm.cldk.schema.CanIdTest' --console=plain` ->BUILD SUCCESSFUL,46s; existing unchecked/deprecation notes. Gradle formatting produced no tracked changes.
- SDK: `.venv/bin/python -m pytest tests/analysis/commons tests/analysis/python/test_neo4j_multi_application_scope.py tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py tests/analysis/java/test_java_neo4j_multi_application_scope.py -q -o addopts=''` ->354 passed,2 skipped,7.11s.

Versions: Python3.12.16, Bun1.4.4, Go1.26.10, Temurin17.0.21. Python analyzer editable at its PR branch; SDK baseline uses released producer pins until its implementation task installs local modified artifacts.
