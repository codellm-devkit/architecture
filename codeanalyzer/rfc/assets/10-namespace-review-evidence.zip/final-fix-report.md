# Final combined fixwave report

Read `global-constraints.md`, `contract-decisions.md`, and the completed `final-review.md`. Addressed all established Important/Minor findings in one wave. No subagents, broad re-review, push, PR mutation, producer pin change, or lifecycle redesign.

## Findings addressed

1. Python streaming and nonstreaming Bolt now read only the exact selected application anchor before any DDL/hash read/upsert. Existing anchors require integer 2 and matching raw application/namespace; genuinely absent anchors remain allowed. Fake-driver tests assert the only query on rejection is the anchor read, including missing metadata, float/bool markers and contradictory owners.
2. Go's existing selected-anchor query now reads both raw owner fields and validates that their resolved identity equals the requested canonical root, before DDL/writes. Tests cover missing and contradictory fields, wrong types, matching metadata and absent fresh anchors; rejection records zero writes.
3. SDK-owned Go/TS/Java model markers validate raw integer type before Literal coercion. SDK-reexported Python PyApplication also now validates before normalization (its raw Analysis envelope was already strict). Fresh complete models and raw cache parity tests cover float markers; the local Python model regression rejects float 2.0.
4. Removed repeated CLI identity option pairs from Python handoff regeneration commands.
5. Removed duplicate Python SDK scope fixture identity setup.
6. SDK PR body references issue #435 without closing downstream work. Go PR body no longer claims a prior workspace-root option. Updated local provenance, verification/ruling annex and prepared PR validation evidence.
7. Java minor risk ruling: preserve strict property-conflict behavior; corrected stale class documentation and added ordinary display-property rejection contract coverage. No runtime behavior changed or speculative Java repair made. Existing native artifact is behavior-identical; no Java rebuild.

## RED/GREEN evidence

Environment: `source /private/tmp/namespace-toolchains/sdk-env.sh`; direct venv Python, no uv re-resolution.

- Python RED: `codeanalyzer-python/.venv/bin/python -m pytest codeanalyzer-python/test/test_neo4j_bolt_streaming.py -q`: 11 failed, 1 passed on original behavior (guard ordering / absent helper). Log `/private/tmp/final-python-red.log`.
- Go RED on original bolt.go with new tests: `go test ./internal/neo4j -run TestStoredOwnerMismatchReadOnly`: failed, accepted contradictory stored owner. Log `/private/tmp/final-go-red.log`.
- SDK RED in SDK cwd, original model files: `.venv/bin/python -m pytest tests/analysis/commons/test_identity.py -k fresh_models --no-cov -q`: 5 failed, 10 passed, 34 deselected; float accepted by all five affected fields. Log `/private/tmp/final-sdk-red.log`.
- Python reexport RED in SDK cwd: `.venv/bin/python -m pytest tests/analysis/commons/test_identity.py -k python_reexport --no-cov -q`: 1 failed, 57 deselected; float accepted before field validator. Log `/private/tmp/final-python-model-red.log`.
- Python GREEN: direct producer venv pytest for `test_neo4j_bolt_streaming.py`, `test_neo4j_scope.py`, `test_neo4j_artifacts.py`, `test_neo4j_streamed_nodes.py`, `test_v2_schema.py`: **34 passed**, 46 warnings, 4.34s, coverage 58.70%. Log `/private/tmp/final-python-green.log`.
- Go GREEN: `go test ./internal/neo4j`: **passed**, 7.314s. Log `/private/tmp/final-go-green.log`.
- SDK focused GREEN: `.venv/bin/python -m pytest tests/analysis/commons/test_identity.py tests/analysis/python/test_neo4j_multi_application_scope.py --no-cov -q`: **142 passed, 1 skipped**, 1.63s. Skip explicitly represents Java's absence of an application-level marker. Log `/private/tmp/final-sdk-focused.log`.
- Java contract: `./gradlew test --tests com.ibm.cldk.neo4j.CanonicalIdentityRowsTest --console=plain`: **BUILD SUCCESSFUL**, 3 tests, zero failures/errors/skips, 7s. Log `/private/tmp/final-java-contract.log`.
- Final bounded SDK: `CLDK_SKIP_JAVA_E2E=1 .venv/bin/python -m pytest tests -q` from SDK cwd via subprocess timeout 240s: **1949 passed, 422 skipped, 10 warnings**, coverage **85.34%**, 74.60s pytest / 75.22s runner, **exit 0**. Log `/private/tmp/final-sdk-full.log`.
- Rebuilt Go from its committed final HEAD: `go build -o /private/tmp/namespace-toolchains/cango ./cmd/codeanalyzer`. Then workspace-root `PYTHONPATH=python-sdk python-sdk/.venv/bin/python architecture/codeanalyzer/rfc/assets/10-namespace-smoke.py`: **20 cases / 60 canonical endpoints passed**, all five language views at native L2. Log `/private/tmp/final-native-smoke.log`.

A few initial command setup attempts were corrected before evidence was accepted: SDK tests launched from workspace root missed relative fixtures; Go test source import insertion briefly malformed a string literal; two guessed Python test filenames did not exist; Maven was attempted in a Gradle repository. The RED/GREEN results above are the corrected commands, except the valid initial Python RED. No setup error is counted as a regression or passing verification.

## Exact final commits and worktree state

| Repository | HEAD | Worktree | Check |
|---|---|---|---|
| python-sdk | `d2256fb728f19bb456d1226a1ba1d5ff4afe19a8` | clean | diff check exit 0 |
| codeanalyzer-python | `b6599662ee17947bedc4231fa1b0875c2d172999` | clean | diff check exit 0 |
| codeanalyzer-typescript | `9658f895e3e75d683a0c00c87069934ddf2966fa` | clean | diff check exit 0 |
| codeanalyzer-java | `89b95237ee2623dfdf84ddd6e71f07ab2472699b` | clean | diff check exit 0 |
| codeanalyzer-go | `f66a589c1e2f4dc0ed373f4811a0dbe8f22b3d13` | clean | diff check exit 0 |

Commits remain on the existing local branches. Python's new missing-field coverage was included by amending its unpushed wave commit; no reset/force was used. SDK SDD files and workspace-parent architecture docs are local artifacts outside the tracked product changes. All five product worktrees are clean.

## Provenance and limits

`local-artifacts.json` contains final Go source/hash/path, editable Python source HEAD/path, unchanged TS artifact and unchanged Java artifact build source plus reviewed docs/test HEAD. Go SHA-256: `881307dd51a1068bee53bbf5a91b4ff4c5984080ea0a5704634861acdf04c867`.

Docker/Neo4j remains absent: fake-driver no-mutation ordering is verified, live database semantics and equality joins are not. Java ordinary property refinement callers may need a targeted follow-up if a real trigger is found; no demonstrated source-level regression is claimed. Private integration indexes/finding joins remain external and issue #435 stays open. Published producer pins/lock are untouched; SDK delivery remains Draft/release blocked until real compatible releases and installed-package validation. Root owns scoped fix review, push and PR delivery.
