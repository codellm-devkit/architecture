# Task 2 independent review

Spec compliance: PASS within the disclosed integration gates.
Quality: PASS WITH NIT. No blocking correctness finding identified.

## Scope and evidence

Reviewed the binding task brief, global constraints and contract decisions, the committed review package for `94b331e9..d644a1c8`, and the task report. The review package was the primary changed-code view. Targeted current-source inspection addressed concrete risks in cache reuse, raw-name helper propagation, canonical endpoint forwarding, and graph deduplication/ownership. No Git mutation or test-suite rerun was performed. This review relies on the report for executed test outcomes, rather than asserting independently reproduced results.

Reported evidence includes initial RED (18 failed / 7 passed with missing interfaces, not dependency imports), subsequent scope-rejection and marker RED cases, and focused GREEN (77 passed / 25 skipped). The final broad run reports 548 passed / 27 skipped / 5 deselected. The five heavy CLI cases and 25 container tests remain gates; neither they nor live shared-artifact behavior are claimed independently verified. Inherited warnings and unsuccessful intermediate runs are explicitly disclosed.

## Finding

- **P3 / documentation:** `codeanalyzer-python/docs/handoff/README.md:140` (also lines 141–144) repeats `--app-name sample-app --namespace sample-app` three times in each sample command. The identical repeated options do not change the intended identity, but make the documented reproduction commands unnecessarily confusing. Keep one pair per invocation. This is nonblocking.

## Contract assessment

- Root construction retains both namespace/application segments, preserves raw metadata and suffix grammar, and distinguishes omission from explicit empty strings. Validation rejects controls, surrogate code points, separators, whole-name dot segments, and whitespace-only names; UTF-8 quoting uses ASCII unreserved characters and uppercase escapes without trimming/normalization.
- CLI and options replace workspace-root; ordinary source keys and resolved-module references remain input-relative. The narrowly scoped resolver correction handles absolute builder keys and application-relative core keys, without broadening import search scope.
- Application metadata and envelope markers are stamped. Raw envelope validation rejects missing application markers and coercible/noninteger envelope/application markers. Internal builder defaults permit construction before ID assignment; external raw loading performs the explicit validation.
- Cache reuse compares selected raw application and namespace in addition to existing schema/level/analyzer checks. Scope changes rebuild from source. Neo4j emission checks ownership before opening output or dispatching Bolt; same-scope assignment does not translate ownership.
- All raw-name production helper call sites inspected propagate namespace through projection, streaming Cypher, streaming Bolt, nonstreaming Bolt and artifact reconciliation. `call_graph_ids.py` correctly remains unchanged: it maps endpoints through the canonical signature map and takes no raw application name.
- Module/class/callable/body/parameter, external, artifact/config, dependency provenance, and cross-function references retain their existing ownership derivation. Package identities stay outside application ownership. Existing canonical row merging and relationship discriminators are preserved.
- Destructive graph prefixes include the complete encoded namespace/application plus separator. Legacy-root artifact cleanup was removed rather than expanded beyond selected ownership. Shared-artifact claim/release checks remain intact; their live-container verification remains outstanding as disclosed.
- Source-regenerated handoff JSON/graph and catalog snapshot changes are consistent with the new marker and root contract. Their generation/repeatability evidence is recorded in the report.

No new fallback, aliasing, namespace-wide lookup, in-place ID migration, package-release model, or producer lifecycle redesign was found. Optional low-level helper arguments still require callers to forward the selected namespace; production callers inspected do so. Existing low-level project/build APIs are not substitutes for the checked emission entrypoint.
