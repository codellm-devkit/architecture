### Task 2: Repurpose Python PR #235

**Files:**
- Modify: `codeanalyzer-python/codeanalyzer/__main__.py`, `options/options.py`, `core.py` (all under `codeanalyzer-python/codeanalyzer/`).
- Modify: `codeanalyzer-python/codeanalyzer/schema/{ids.py,assign_ids.py,py_schema.py,call_graph_ids.py}` and `codeanalyzer-python/codeanalyzer/neo4j/{emit.py,project.py,rows.py,schema.py,bolt.py}`.
- Modify where namespace is forwarded: `codeanalyzer-python/codeanalyzer/artifacts/discovery.py`.
- Replace: `codeanalyzer-python/test/test_workspace_root.py` with `test/test_namespace.py`.
- Extend: `test/test_v2_ids.py`, `test/test_v2_schema.py`, `test/test_neo4j_scope.py`, `test/test_neo4j_bolt.py`, and `README.md` in that repo.

**Interfaces:**
- Consumes: Task 1 fixture and Python helper signatures above.
- Produces: `AnalysisOptions.namespace: str | None`, `--namespace`, namespace-qualified JSON/Cypher/Bolt IDs, `identity_version: 2`, and raw identity metadata.

- [ ] **Step 1: Write failing ID/CLI/emission tests.** Parameterize the golden roots; assert namespace omission repeats the resolved app name and explicit empty namespace fails. Analyze a small source with a callable, body node, import, and config artifact. Assert every application-owned ID/reference has the selected root, local file keys remain input-relative, and known suffixes are unchanged.
- [ ] **Step 2: Verify failure.** From `codeanalyzer-python`, run `uv run --group test pytest test/test_v2_ids.py test/test_namespace.py -q`. Expect missing namespace interface/wrong-root assertions, not dependency/import failures.
- [ ] **Step 3: Implement the Python contract.** Replace `workspace_root` with `namespace`, remove emission-time workspace re-keying, and thread the pair through existing helpers and all callers. Preserve artifact reconciliation from the PR. Stamp/validate `identity_version: 2`; retain application name and identity namespace on the application model/graph anchor. Include namespace in cache validation and test repeated emission under a changed scope.
- [ ] **Step 4: Verify focused suites then full Python tests.** Run `uv run --group test pytest test/test_v2_ids.py test/test_namespace.py test/test_v2_schema.py test/test_neo4j_scope.py test/test_neo4j_bolt.py -q`, then `uv run --group test pytest test -q`. Container/live tests remain explicit integration gates when prerequisites are unavailable; report skips.
- [ ] **Step 5: Commit on the existing PR branch.** Use `feat: qualify Python analysis identities by namespace`. Do not push until Task 8 verifies the coordinated result.

