## Contract decisions for this plan

These are implementation choices proposed for review, resolving the RFC's version question without changing the entity suffix grammar:

- Add required integer `identity_version: 2` to the **existing** analysis envelope and application-anchor properties. Unversioned outputs are legacy and unsupported by the updated SDK. Keep `schema_version: "2.0.0"` and existing schema-family selectors: this marker versions URI ownership, not the model hierarchy. Update published validators to require the marker.
- On existing application records, retain raw `application_name` and `identity_namespace`. Canonical entity IDs carry ownership; do not repeat those properties on every entity.
- Python root helper: `application_id(app_name: str, namespace: str | None = None) -> str`; module/artifact helpers gain the same optional namespace after existing positional arguments.
- TypeScript root helper: `applicationIdOf(appName: string, namespace?: string): string`; module/artifact helpers gain a final optional namespace. `assignIds(app, appName, namespace?)` replaces the PR's workspace-key-prefix argument.
- Java: add `CanId.applicationId(String appName, String namespace)`; the one-argument overload delegates with omitted namespace. App-name-based artifact/external helpers gain equivalent overloads. Helpers already accepting a canonical parent ID keep that input.
- Go: add `ResolveIdentity(appName string, namespace *string) (Identity, error)` with `Namespace`, `ApplicationName`, and `ApplicationID` fields. `nil` means omitted; a pointer to empty string is invalid. `AppID(appName, namespace string) string` receives resolved validated names. CLI flag presence distinguishes omitted and explicit empty values.
- SDK: `resolve_identity(application_name: str | None, namespace: str | None, *, project_root: Path | None = None) -> ApplicationIdentity`, a frozen value with `namespace`, `application_name`, and `application_id` fields. Missing graph application selection raises the existing configuration exception.

