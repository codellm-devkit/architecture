9658f89 fix: reject explicit empty CLI application names
 src/cli.ts             |  2 +-
 test/namespace.test.ts | 30 ++++++++++++++++++++++++++++++
 2 files changed, 31 insertions(+), 1 deletion(-)
diff --git a/src/cli.ts b/src/cli.ts
index 9a7d108..cbc55ed 100644
--- a/src/cli.ts
+++ b/src/cli.ts
@@ -139,21 +139,21 @@ export function parseArgs(argv: string[]): AnalysisOptions {
     jobs = j;
   }
   // --emit schema is a static artifact and needs no project; every other target requires -i.
   if (emit !== "schema" && !o.input) program.error("required option '-i, --input <path>' not specified");
   const targets: string[] | null =
     Array.isArray(o.targetFiles) && o.targetFiles.length ? o.targetFiles.map(String) : null;
   return {
     input: o.input ? path.resolve(String(o.input)) : "",
     output: o.output ? path.resolve(String(o.output)) : null,
     emit,
-    appName: o.appName ? String(o.appName) : null,
+    appName: o.appName === undefined ? null : String(o.appName),
     namespace: o.namespace === undefined ? undefined : String(o.namespace),
     neo4jUri: o.neo4jUri ? String(o.neo4jUri) : null,
     neo4jUser: String(o.neo4jUser),
     neo4jPassword: String(o.neo4jPassword),
     neo4jDatabase: o.neo4jDatabase ? String(o.neo4jDatabase) : null,
     analysisLevel: level,
     graphs,
     graphFieldDepth: k,
     jobs,
     targetFiles: targets,
diff --git a/test/namespace.test.ts b/test/namespace.test.ts
index 86fda18..477fdf3 100644
--- a/test/namespace.test.ts
+++ b/test/namespace.test.ts
@@ -63,10 +63,40 @@ test('cache rejects legacy and noninteger markers without rewriting the input',
    expect(loadCache(cacheDir,'can://first/a%25b')).toBeNull();
    expect(fs.readFileSync(file,'utf8')).toBe(bytes);
   }
  } finally { fs.writeFileSync(file,original); }
 });
 test('application metadata is required even for the default namespace', async () => {
  const wire = (await analyze({...options,appName:'app',namespace:undefined})).application;
  delete (wire.application as any).identity_namespace;
  expect(()=>project(wire)).toThrow();
 });
+
+for (const namespaceArgs of [[], ['--namespace', 'team']]) {
+ test(`CLI rejects explicit empty application name ${namespaceArgs.join(' ')}`, () => {
+  const input = fs.mkdtempSync(path.join(os.tmpdir(), 'cants-empty-name-'));
+  const output = path.join(input, 'out');
+  try {
+   const result = Bun.spawnSync(['bun', 'run', path.join(import.meta.dir, '../src/index.ts'),
+    '--input', input, '--output', output, '--no-build', '--app-name', '', ...namespaceArgs],
+    { stdout: 'pipe', stderr: 'pipe' });
+   expect(result.exitCode).not.toBe(0);
+   expect(result.stderr.toString()).toContain('Invalid application identity segment');
+   expect(fs.existsSync(path.join(output, 'analysis.json'))).toBe(false);
+  } finally { fs.rmSync(input, {recursive:true,force:true}); }
+ });
+ test(`CLI omitted application name uses input basename ${namespaceArgs.join(' ')}`, () => {
+  const input = fs.mkdtempSync(path.join(os.tmpdir(), 'cants-default-name-'));
+  const output = path.join(input, 'out');
+  try {
+   const result = Bun.spawnSync(['bun', 'run', path.join(import.meta.dir, '../src/index.ts'),
+    '--input', input, '--output', output, '--no-build', ...namespaceArgs],
+    { stdout: 'pipe', stderr: 'pipe' });
+   expect(result.exitCode).toBe(0);
+   const wire = JSON.parse(fs.readFileSync(path.join(output,'analysis.json'),'utf8'));
+   const name = path.basename(input);
+   expect(wire.application.application_name).toBe(name);
+   expect(wire.application.identity_namespace).toBe(namespaceArgs.length ? 'team' : name);
+   expect(wire.application.id).toBe(applicationIdOf(name, namespaceArgs.length ? 'team' : undefined));
+  } finally { fs.rmSync(input, {recursive:true,force:true}); }
+ });
+}
# codeanalyzer-typescript: fcc9529a932bc40a6be426fb85298237e19ffe65..9658f895e3e75d683a0c00c87069934ddf2966fa
