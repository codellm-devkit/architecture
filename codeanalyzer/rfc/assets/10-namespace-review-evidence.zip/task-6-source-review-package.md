315eeae feat: bind SDK URI resolution to namespace and application
 cldk/analysis/commons/backend_config.py            |  20 +-
 cldk/analysis/commons/identity.py                  |  84 ++++++++
 cldk/analysis/commons/keys.py                      |  68 +++---
 cldk/analysis/go/codeanalyzer/codeanalyzer.py      |  27 +--
 cldk/analysis/go/go_analysis.py                    |   8 +-
 cldk/analysis/go/neo4j/neo4j_backend.py            |  80 ++++---
 cldk/analysis/java/backend.py                      |  21 +-
 cldk/analysis/java/codeanalyzer/codeanalyzer.py    |  23 +-
 cldk/analysis/java/java_analysis.py                |  25 +--
 cldk/analysis/java/neo4j/neo4j_backend.py          |  38 +++-
 cldk/analysis/python/codeanalyzer/codeanalyzer.py  |  51 ++---
 cldk/analysis/python/neo4j/neo4j_backend.py        | 110 ++++++----
 cldk/analysis/python/python_analysis.py            |  54 ++---
 .../typescript/codeanalyzer/codeanalyzer.py        |  32 +--
 cldk/analysis/typescript/neo4j/neo4j_backend.py    |  60 ++++--
 cldk/analysis/typescript/typescript_analysis.py    |  10 +-
 cldk/core.py                                       |   2 +
 cldk/models/go/models.py                           |   6 +-
 cldk/models/java/models.py                         |   3 +
 cldk/models/typescript/models.py                   |   5 +
 tests/analysis/commons/test_identity.py            | 239 +++++++++++++++++++++
 .../commons/test_identity_local_producers.py       |  42 ++++
 tests/analysis/commons/test_lifted_helpers.py      |  50 ++++-
 tests/analysis/go/test_go_analysis.py              |  39 ++--
 tests/analysis/go/test_go_e2e.py                   |   2 +-
 .../go/test_go_neo4j_multi_application_scope.py    |  84 ++++++++
 tests/analysis/java/conftest.py                    |   8 +-
 tests/analysis/java/test_java_addressing.py        |  20 +-
 tests/analysis/java/test_java_analysis.py          |  10 +-
 tests/analysis/java/test_java_dataflow.py          |  24 ++-
 tests/analysis/java/test_java_degradation.py       |  12 +-
 tests/analysis/java/test_java_e2e.py               |   2 +-
 tests/analysis/java/test_java_entrypoints.py       |  14 +-
 tests/analysis/java/test_java_neo4j_lookup_miss.py |   3 +
 .../test_java_neo4j_multi_application_scope.py     |  80 +++++--
 tests/analysis/java/test_java_public_surface.py    |  12 +-
 tests/analysis/java/test_java_schema_probe.py      |   2 +-
 tests/analysis/java/test_java_v1_accessors.py      |   8 +-
 tests/analysis/java/test_java_view_dispatches.py   |  23 +-
 tests/analysis/java/test_jcodeanalyzer.py          |  75 +++++--
 tests/analysis/python/conftest.py                  |  13 +-
 tests/analysis/python/test_artifacts.py            |  33 +--
 tests/analysis/python/test_bodies.py               |   2 +-
 tests/analysis/python/test_entrypoints.py          |  24 +--
 tests/analysis/python/test_external_symbols.py     |  20 +-
 tests/analysis/python/test_locate.py               |  12 +-
 tests/analysis/python/test_module_key_of.py        |  21 +-
 .../python/test_neo4j_multi_application_scope.py   |  67 ++++--
 tests/analysis/python/test_python_analysis.py      |   4 +-
 tests/analysis/python/test_python_method_lookup.py |  12 ++
 .../analysis/python/test_python_neo4j_selection.py |   2 +-
 tests/analysis/python/test_python_taint.py         |   8 +-
 tests/analysis/python/test_resolution_probe.py     |   2 +-
 tests/analysis/python/test_resolve.py              |   2 +-
 tests/analysis/python/test_scoping_keywords.py     |  33 ++-
 tests/analysis/typescript/conftest.py              |   6 +
 .../typescript/test_typescript_addressing.py       |   8 +-
 .../typescript/test_typescript_analysis.py         |  46 ++--
 .../typescript/test_typescript_bulk_accessors.py   |   2 +-
 .../typescript/test_typescript_dataflow.py         |   4 +-
 tests/analysis/typescript/test_typescript_e2e.py   |   2 +-
 .../typescript/test_typescript_e2e_neo4j_live.py   |  16 +-
 .../typescript/test_typescript_entrypoints.py      |   4 +-
 .../test_typescript_external_reconstruct.py        |   7 +-
 .../test_typescript_get_method_functions.py        |  21 +-
 .../typescript/test_typescript_neo4j_backend.py    |   2 +-
 .../typescript/test_typescript_neo4j_bulk.py       |   5 +-
 ...est_typescript_neo4j_multi_application_scope.py |  50 ++---
 .../typescript/test_typescript_neo4j_selection.py  |   2 +-
 tests/analysis/typescript/test_typescript_taint.py |  20 +-
 tests/models/go/test_go_models.py                  |   6 +-
 tests/models/java/test_java_models.py              |   4 +-
 tests/models/python/test_python_models.py          |  45 +++-
 tests/models/typescript/test_ts_v2_models.py       |  12 +-
 tests/resources/go/analysis.json                   |   2 +-
 tests/resources/go/analysis_json/v2/README.md      |  19 ++
 tests/resources/java/analysis_json/v2/README.md    |  21 ++
 .../java/analysis_json/v2/a1/analysis.json.gz      | Bin 924438 -> 926009 bytes
 .../java/analysis_json/v2/a4/analysis.json.gz      | Bin 353246 -> 354831 bytes
 tests/resources/regenerate_identity_fixtures.py    | 125 +++++++++++
 .../typescript/analysis_json/v2/README.md          |  19 ++
 .../typescript/analysis_json/v2/a1/analysis.json   |   2 +-
 .../typescript/analysis_json/v2/a2/analysis.json   |   2 +-
 .../typescript/analysis_json/v2/a3/analysis.json   |   2 +-
 .../typescript/analysis_json/v2/a4/analysis.json   |   2 +-
 85 files changed, 1642 insertions(+), 545 deletions(-)
diff --git a/cldk/analysis/commons/backend_config.py b/cldk/analysis/commons/backend_config.py
index f2a3b83..3c0b2ca 100644
--- a/cldk/analysis/commons/backend_config.py
+++ b/cldk/analysis/commons/backend_config.py
@@ -27,44 +27,51 @@ Two backend families exist:
   codeanalyzer backend, which runs the packaged ``codeanalyzer-*`` binary and caches its
   ``analysis.json`` under a language-keyed cache directory.
 * :class:`Neo4jConnectionConfig` selects the read-only Neo4j/Cypher backend, which answers the
   same queries over a graph populated out of band.
 
 The per-language ``*Backend`` unions below are the discriminated unions the facades match on.
 """
 
 from __future__ import annotations
 
-from dataclasses import dataclass
+from dataclasses import dataclass, field
+import hashlib
 from pathlib import Path
 from typing import Union
 
+from cldk.analysis.commons.identity import ApplicationIdentity
+
 # The canonical sub-directory name each language's artifacts live under inside the shared cache
 # root. Keyed so that a polyglot repository analyzed under more than one language does not have its
 # backends overwrite a single shared ``analysis.json``.
 _CACHE_KEYS = {"java": "java", "python": "python", "typescript": "typescript", "go": "go"}
 
 
 @dataclass
 class CodeAnalyzerConfig:
     """Select the in-process codeanalyzer backend.
 
     The backend binary is sourced from the packaged ``codeanalyzer-*`` dependency, so the only
     knob is where analysis artifacts are cached.
 
     Attributes:
         cache_dir: Root directory for analysis artifacts. When ``None`` the facade defaults it to
             ``<project>/.codeanalyzer``. Each backend writes under a language-keyed subdirectory of
-            this root (see :func:`cache_subdir`), so the same root can be shared across languages.
+            this root (see :func:`cache_subdir`), with a separate digest for each application identity.
+        namespace: Raw namespace; defaults to the resolved application name.
+        application_name: Raw application name; defaults to the normalized project-root basename.
     """
 
     cache_dir: Union[str, Path, None] = None
+    namespace: str | None = field(default=None, kw_only=True)
+    application_name: str | None = field(default=None, kw_only=True)
 
 
 @dataclass
 class PyCodeAnalyzerConfig(CodeAnalyzerConfig):
     """Select the in-process codeanalyzer backend for Python.
 
     Adds the Python-only call-graph knobs on top of :class:`CodeAnalyzerConfig`.
 
     Attributes:
         use_ray: If ``True``, enable Ray-based parallel processing for large projects.
@@ -105,43 +112,48 @@ class Neo4jConnectionConfig:
         database: Database name (``None`` => server default).
         application_name: The application anchor name to scope queries to. Matches the
             ``--app-name`` the graph was loaded with (defaults to the project directory name).
     """
 
     uri: str
     username: str = "neo4j"
     password: str = "neo4j"
     database: str | None = None
     application_name: str | None = None
+    namespace: str | None = field(default=None, kw_only=True)
 
 
 # Per-language discriminated unions the facades match on.
 JavaBackend = Union[CodeAnalyzerConfig, Neo4jConnectionConfig]
 PyBackend = Union[PyCodeAnalyzerConfig, Neo4jConnectionConfig]
 TSBackend = Union[TSCodeAnalyzerConfig, CodeAnalyzerConfig, Neo4jConnectionConfig]
 # Go's cango has no backend-only knob today, so it reuses the base CodeAnalyzerConfig rather than a
 # GoCodeAnalyzerConfig subclass -- the same shape as JavaBackend. Add a subclass only if cango later
 # grows a knob.
 GoBackend = Union[CodeAnalyzerConfig, Neo4jConnectionConfig]
 
 
-def cache_subdir(cache_dir: Union[str, Path, None], project_dir: Union[str, Path, None], language: str) -> Path | None:
+def cache_subdir(cache_dir: Union[str, Path, None], project_dir: Union[str, Path, None], language: str, *, identity: ApplicationIdentity | None = None) -> Path | None:
     """Resolve the language-keyed cache directory for a backend.
 
     Args:
         cache_dir: The cache root from the backend config. When ``None``, defaults to
             ``<project_dir>/.codeanalyzer``.
         project_dir: The project directory, used to derive the default root.
+        identity: Bound application identity; when supplied its digest isolates cached outputs.
         language: The canonical language key (``"java"``, ``"python"``, ``"typescript"``, ``"go"``).
 
     Returns:
-        ``<root>/<language>`` as an absolute path, or ``None`` if no root can be determined
+        ``<root>/<language>/<identity digest>`` (or the language directory when unbound)
+        as an absolute path, or ``None`` if no root can be determined
         (no ``cache_dir`` and no ``project_dir``).
     """
     key = _CACHE_KEYS.get(language, language)
     if cache_dir is not None:
         root = Path(cache_dir).expanduser().resolve()
     elif project_dir is not None:
         root = Path(project_dir).expanduser().resolve() / ".codeanalyzer"
     else:
         return None
+    if identity is not None:
+        return root / key / hashlib.sha256(identity.application_id.encode()).hexdigest()
     return root / key
diff --git a/cldk/analysis/commons/identity.py b/cldk/analysis/commons/identity.py
new file mode 100644
index 0000000..f60d84b
--- /dev/null
+++ b/cldk/analysis/commons/identity.py
@@ -0,0 +1,84 @@
+################################################################################
+# Copyright IBM Corporation 2026
+#
+# Licensed under the Apache License, Version 2.0 (the "License");
+# you may not use this file except in compliance with the License.
+# You may obtain a copy of the License at
+#
+#       http://www.apache.org/licenses/LICENSE-2.0
+#
+# Unless required by applicable law or agreed to in writing, software
+# distributed under the License is distributed on an "AS IS" BASIS,
+# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
+# See the License for the specific language governing permissions and
+# limitations under the License.
+################################################################################
+
+"""Validated raw application identity and canonical URI ownership."""
+
+import json
+import unicodedata
+from dataclasses import dataclass
+from pathlib import Path
+from urllib.parse import quote
+
+from cldk.utils.exceptions import CodeanalyzerExecutionException
+
+
+@dataclass(frozen=True)
+class ApplicationIdentity:
+    namespace: str
+    application_name: str
+    application_id: str
+
+
+def _segment(value: str) -> str:
+    if not isinstance(value, str) or not value.strip() or value in {".", ".."} or any(c in "/\\" or unicodedata.category(c) in {"Cc", "Cs"} for c in value):
+        raise ValueError("identity names must be nonempty raw names without separators or control characters")
+    return quote(value, safe="-._~", encoding="utf-8", errors="strict")
+
+
+def resolve_identity(application_name: str | None, namespace: str | None, *, project_root: Path | None = None) -> ApplicationIdentity:
+    if application_name is None:
+        if project_root is None:
+            raise CodeanalyzerExecutionException("application_name is required to scope queries to an application.")
+        application_name = Path(project_root).expanduser().resolve().name
+    namespace = application_name if namespace is None else namespace
+    return ApplicationIdentity(namespace, application_name, f"can://{_segment(namespace)}/{_segment(application_name)}")
+
+
+def validate_identity(payload, identity: ApplicationIdentity, *, envelope: bool = True):
+    """Reject legacy or foreign persisted data without synthesizing metadata."""
+    if envelope and hasattr(payload, "application"):
+        app_model = payload.application
+        if hasattr(app_model, "identity_version") and "identity_version" not in app_model.model_fields_set:
+            raise CodeanalyzerExecutionException("Analysis identity marker is missing from the application.")
+    raw = (
+        payload.model_dump(include={"identity_version": True, "language": True, "application": {"identity_version", "id", "application_name", "identity_namespace"}})
+        if envelope and hasattr(payload, "model_dump")
+        else payload
+    )
+    if not isinstance(raw, dict):
+        raise CodeanalyzerExecutionException("Analysis identity metadata must be an object.")
+    app = raw.get("application", {}) if envelope else raw
+    if not isinstance(app, dict):
+        raise CodeanalyzerExecutionException("Application identity metadata must be an object.")
+    if envelope and raw.get("language") != "java" and (type(app.get("identity_version")) is not int or app.get("identity_version") != 2):
+        raise CodeanalyzerExecutionException("Analysis identity marker is missing from the application.")
+    if (
+        type(raw.get("identity_version")) is not int
+        or raw.get("identity_version") != 2
+        or app.get("application_name") != identity.application_name
+        or app.get("identity_namespace") != identity.namespace
+        or app.get("id") != identity.application_id
+    ):
+        raise CodeanalyzerExecutionException("Analysis identity metadata is missing, incompatible, or outside the requested application scope.")
+    return payload
+
+
+def cache_matches(path: Path, identity: ApplicationIdentity) -> bool:
+    try:
+        validate_identity(json.loads(path.read_text(encoding="utf-8")), identity)
+        return True
+    except (OSError, ValueError, CodeanalyzerExecutionException):
+        return False
diff --git a/cldk/analysis/commons/keys.py b/cldk/analysis/commons/keys.py
index 518616a..4642343 100644
--- a/cldk/analysis/commons/keys.py
+++ b/cldk/analysis/commons/keys.py
@@ -19,78 +19,84 @@
 Lifted out of the Python backend and its Neo4j reconstruction (leg 2.5a, G4) unchanged except
 that :func:`module_dotted` takes the language's source extensions as a parameter. Keys are the
 repo-relative paths the analyzer saw; every ruling here is about matching a caller's spelling of
 one to the key that exists, or refusing.
 """
 
 from __future__ import annotations
 
 import os
 import posixpath
-from typing import Collection, Iterable, List, Sequence
+from typing import Collection, Iterable, List, Sequence, Mapping
+from pathlib import Path
 
 from cldk.analysis.commons.bounds import check_depth, check_selector, reject_bare_string
 
 
-def resolve_module_key(path: str, keys: Iterable[str]) -> str:
-    """The symbol-table / graph ``file_key`` naming ``path``, or ``path`` unchanged if none does.
-
-    A caller of :meth:`PythonAnalysisBackend.locate` hands over whatever its scanner printed —
-    ``./src/app.py``, ``src/../src/app.py``, or an absolute path from the machine the scan ran on —
-    while both backends are keyed by the project-relative path the analyzer saw. Exact key first,
-    then the normalised form, then the longest known key the normalised path *ends on a segment
-    boundary* of (which is what an absolute path is). Returning ``path`` unchanged when nothing
-    matches is deliberate: the caller then gets ``file_not_in_graph`` naming the path it asked
-    about, not a silently substituted neighbour.
-    """
-    keys = list(keys)
-    if path in keys:
+def resolve_module_key(
+    path: str, keys: Iterable[str], *, application_id: str | None = None, module_ids: Mapping[str, str] | None = None, source_root: str | Path | None = None
+) -> str:
+    """Resolve only within the bound application's verified module IDs and source root."""
+    path = str(path)
+    known = list(keys)
+    if path.startswith("can:") or "://" in path:
+        if application_id is None or not path.startswith(application_id + "/") or module_ids is None:
+            raise ValueError("Module URI is outside the bound application scope")
+        matches = [key for key, value in module_ids.items() if value == path and key in known]
+        if len(matches) != 1:
+            raise ValueError("Module URI is not a module in the selected language view")
+        return matches[0]
+    if Path(path).is_absolute():
+        if source_root is None or not Path(source_root).is_dir():
+            raise ValueError("Absolute module paths require a bound source root")
+        try:
+            path = Path(path).resolve().relative_to(Path(source_root).resolve()).as_posix()
+        except ValueError as exc:
+            raise ValueError("Absolute module path is outside the bound source root") from exc
+    if path in known:
         return path
-    norm = posixpath.normpath(str(path).replace(os.sep, "/"))
-    if norm in keys:
-        return norm
-    suffix_matches = [k for k in keys if norm.endswith("/" + k)]
-    return max(suffix_matches, key=len) if suffix_matches else path
+    norm = posixpath.normpath(path.replace(os.sep, "/"))
+    return norm if norm in known else path
 
 
-def scope_paths(paths: Sequence[str] | None, keys: Iterable[str], kind: str = "paths") -> List[str] | None:
+def scope_paths(paths: Sequence[str] | None, keys: Iterable[str], kind: str = "paths", **scope) -> List[str] | None:
     """Resolve requested module paths to symbol-table keys, or ``None`` for "the whole application".
 
     Both backends route their ``paths=`` / ``module=`` keywords through here, so the lenient
-    resolution (:func:`resolve_module_key` — an absolute path or one with native separators finds
-    its module) and the strictness (:func:`check_selector` — a path naming no module raises) cannot
+    resolution (:func:`resolve_module_key` — relative keys, verified module URIs, or absolute
+    paths under the existing bound source root) and the strictness (:func:`check_selector` — a path naming no module raises) cannot
     drift apart between them.
 
     Args:
         paths: What the caller named, or ``None`` for the unscoped call.
         keys: The symbol-table keys that exist — ``symbol_table.keys()`` locally, the
             application's module ``file_key``s over Neo4j.
         kind: The keyword's name for the error message; ``"module"`` for ``get_classes``, whose
             single-valued keyword routes through here as a one-element sequence.
 
     **Resolution is many-to-one, and the result is de-duplicated.** Leniency is the whole point of
-    :func:`resolve_module_key` — ``"pkg/a.py"`` and ``"/abs/pkg/a.py"`` are two spellings a scanner
-    may plausibly hand over for the *same* module — so two requested paths legitimately collapse to
+    :func:`resolve_module_key` — a relative key and an absolute path under the bound root may
+    name the *same* module — so two requested paths legitimately collapse to
     one key and the caller gets one entry back. Raising on the collapse would punish the very
     caller the leniency exists for; de-duplicating explicitly is what keeps the returned list from
     naming the same module twice and asking both backends to fetch it twice.
 
     Raises:
         TypeError: ``paths`` is a bare string (see :func:`reject_bare_string`).
         ValueError: ``paths`` is an empty sequence.
         SelectorNotInGraph: a path names no module in this application.
     """
     reject_bare_string(kind, paths)
     if paths is None:
         return None
     known = list(keys)
-    resolved = [resolve_module_key(p, known) for p in paths]
+    resolved = [resolve_module_key(p, known, **scope) for p in paths]
     check_selector(kind, list(paths), [p for p, r in zip(paths, resolved) if r not in known])
     return list(dict.fromkeys(resolved))
 
 
 def call_graph_scope(roots: Sequence[str] | None, depth: int | None) -> List[str] | None:
     """Normalise :meth:`PythonAnalysisBackend.get_call_graph`'s scoping keywords.
 
     Returns the roots as a list, or ``None`` for "the whole application" — the unscoped call,
     which must keep behaving exactly as it did before the keywords existed.
 
@@ -175,10 +181,22 @@ def body_key_column(key: str) -> int:
     carry no span and are filtered out before ranking; in TypeScript they span the whole callable,
     so they lose on width to anything nested inside them and reach this only in a one-line callable,
     where ranking last is the right answer -- a statement inside the callable is the more precise
     position.
 
     Lifted out of ``cldk/analysis/python/backend.py`` unchanged (leg 2.5b): it reads a key grammar
     both analyzers emit, and a second copy is a second thing to keep in step.
     """
     _, _, col = key.split("/", 1)[0].partition(":")
     return int(col) if col.isdigit() else -1
+
+
+def module_scope(backend) -> dict:
+    """Carry the backend's selected owner and existing source root into path resolution."""
+    identity = backend.identity
+    if hasattr(backend, "_module_ids"):
+        ids = backend._module_ids
+    elif hasattr(backend, "_module_props"):
+        ids = {key: props["id"] for key, props in backend._module_props.items()}
+    else:
+        ids = {key: value.id for key, value in backend.get_application_view().symbol_table.items()}
+    return dict(application_id=identity.application_id, module_ids=ids, source_root=getattr(backend, "source_root", getattr(backend, "project_dir", None)))
diff --git a/cldk/analysis/go/codeanalyzer/codeanalyzer.py b/cldk/analysis/go/codeanalyzer/codeanalyzer.py
index fd14e97..bb85ab0 100644
--- a/cldk/analysis/go/codeanalyzer/codeanalyzer.py
+++ b/cldk/analysis/go/codeanalyzer/codeanalyzer.py
@@ -27,68 +27,76 @@ from __future__ import annotations
 import json
 import os
 import shlex
 import subprocess
 from pathlib import Path
 from subprocess import CompletedProcess
 from typing import Dict, List, Union
 
 import networkx as nx
 
+from cldk.analysis.commons.identity import resolve_identity, validate_identity, cache_matches
 from cldk.analysis.commons.backend_config import cache_subdir
 from cldk.analysis.commons.levels import analyzer_level
 from cldk.analysis.go.backend import ARTIFACT_LAYER_UNAVAILABLE, GoAnalysisBackend
 from cldk.models.go import (
     GoAnalysis,
     GoApplication,
     GoCallable,
     GoCallGraphEdge,
     GoField,
     GoModule,
     GoParam,
     GoType,
 )
 from cldk.models.python import PyArtifact, PyConfigKey, PyConfigRead, PyConfigUseEdge, PyDependency
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
+
 class GoCodeanalyzer(GoAnalysisBackend):
     """Run ``cango`` and answer queries over the parsed ``analysis.json``.
 
     Attributes:
         analysis: The whole ``analysis.json`` v2 envelope (``schema_version``, ``max_level``,
             ``analyzer``, ``application``).
         application: The application root — symbol table + call graph.
         application_name: The ``--app-name`` anchor the analyzer stamped into every id, read back
             off the ``can://<app>`` root id. Spelled the same as the Neo4j backend's
             ``application_name`` so a raised message names the application identically whichever
             backend raised it.
     """
 
     def __init__(
         self,
         project_dir: Union[str, Path],
         cache_dir: Union[str, Path, None],
         analysis_level: str,
         eager_analysis: bool,
         target_files: List[str] | None,
+        *,
+        application_name: str | None = None,
+        namespace: str | None = None,
     ) -> None:
+        self.identity = resolve_identity(application_name, namespace, project_root=Path(project_dir) if project_dir is not None else None)
+
         self.project_dir = project_dir
         self.cache_dir = cache_dir
         self.analysis_level = analysis_level
         self.eager_analysis = eager_analysis
         self.target_files = target_files
         # analyzer_level maps the AnalysisLevel enum/name/value to its integer, raising on an
         # unknown level rather than silently defaulting to 1 (the bug a hand-rolled dict caused).
         # cango has no L3/L4, so _argv caps the result at 2.
         self.analysis: GoAnalysis = self._init_codeanalyzer(analyzer_level(analysis_level))
+        validate_identity(self.analysis, self.identity)
         self.application: GoApplication = self.analysis.application
-        self.application_name: str = self.application.id.removeprefix("can://")
+        self.application_name: str = self.identity.application_name
         self._call_graph: nx.DiGraph | None = None
         self._index()
 
     # -----[ binary resolution ]-----
     def _get_codeanalyzer_exec(self) -> List[str]:
         """Resolve the ``cango`` executable command.
 
         ``$CODEANALYZER_GO_BIN`` is the out-of-band override (a locally built binary); otherwise the
         binary ships inside the ``codeanalyzer-go`` PyPI package (platform wheel), mirroring the TS
         backend. The wheel arm lights up once the analyzer release is pinned.
@@ -110,22 +118,22 @@ class GoCodeanalyzer(GoAnalysisBackend):
     def _argv(self, analysis_level: int, output_dir: Path | None) -> List[str]:
         """The cango command line: ``-i <project> --app-name <project.name> -a <1|2>
         [-o <dir> --cache-dir <dir>] --skip-tests [--eager] [-t <file>]...``.
 
         . The level is capped at 2 — cango produces no L3/L4.
         """
         project = Path(self.project_dir)
         args = self._get_codeanalyzer_exec() + [
             "-i",
             str(project),
-            "--app-name",
-            project.name,
+            f"--app-name={self.identity.application_name}",
+            f"--namespace={self.identity.namespace}",
             "-a",
             str(min(analysis_level, 2)),
         ]
         if output_dir is not None:
             args += ["-o", str(output_dir), "--cache-dir", str(output_dir)]
         args += ["--skip-tests"]
         if self.eager_analysis:
             args += ["--eager"]
         for tf in self.target_files or []:
             args += ["-t", str(tf).strip()]
@@ -144,36 +152,36 @@ class GoCodeanalyzer(GoAnalysisBackend):
 
     def _init_codeanalyzer(self, analysis_level: int) -> GoAnalysis:
         """Run cango and return the validated v2 envelope.
 
         With no cache directory the output is read from the subprocess stdout pipe; with one, the
         analysis.json is persisted under ``<cache>/go`` and reused unless ``eager_analysis``,
         ``target_files``, or a cache **shallower than the requested level** force a re-run. A cache
         at or above the requested level is reused as-is: the schema is additive (``L1 ⊆ L2``), so a
         deeper cache already contains everything a shallower request needs.
         """
-        output_dir = cache_subdir(self.cache_dir, self.project_dir, "go")
+        output_dir = cache_subdir(self.cache_dir, self.project_dir, "go", identity=self.identity)
         if output_dir is None:
             args = self._argv(analysis_level, None)
             try:
                 proc: CompletedProcess[str] = subprocess.run(args, capture_output=True, text=True, check=True)
             except subprocess.CalledProcessError as e:
                 raise CodeanalyzerExecutionException(f"cango failed: {e.stderr or e}") from e
             return GoAnalysis.model_validate_json(proc.stdout)
 
         output_dir.mkdir(parents=True, exist_ok=True)
         analysis_json_file = output_dir / "analysis.json"
         # cango caps at 2, so a request above 2 is satisfied by a level-2 cache (never re-runs for a
         # level it cannot produce). Compare the requested level, capped, against the cached level.
         requested = min(analysis_level, 2)
         cached_level = self._cached_level(analysis_json_file) if analysis_json_file.exists() else None
-        stale = cached_level is None or cached_level < requested
+        stale = cached_level is None or cached_level < requested or not cache_matches(analysis_json_file, self.identity)
         needs_run = self.eager_analysis or bool(self.target_files) or stale
         if needs_run:
             args = self._argv(analysis_level, output_dir)
             try:
                 subprocess.run(args, capture_output=True, text=True, check=True)
             except subprocess.CalledProcessError as e:
                 raise CodeanalyzerExecutionException(f"cango failed: {e.stderr or e}") from e
             if not analysis_json_file.exists():
                 raise CodeanalyzerExecutionException("cango did not generate analysis.json.")
         return GoAnalysis.model_validate_json(analysis_json_file.read_text(encoding="utf-8"))
@@ -284,43 +292,38 @@ class GoCodeanalyzer(GoAnalysisBackend):
         """The source text of ``node_id`` — ``module.source`` sliced by ``node.span.bytes`` — for a
         durable-id node (type, callable, field).
 
         ``span.bytes`` are **UTF-8 byte** offsets, so a non-ASCII module is sliced on the encoded
         bytes and decoded back (an ASCII module is indexed directly, paying nothing), the same way
         the TS ``_Spanned.code`` property does. Slicing the ``str`` by character index would drift
         on any file with a multibyte character before the span.
         """
         entry = self._source_of.get(node_id)
         if entry is None:
-            raise CodeanalyzerExecutionException(
-                f"no source for {node_id!r}: not a type, callable or field of application "
-                f"{self.application_name!r}"
-            )
+            raise CodeanalyzerExecutionException(f"no source for {node_id!r}: not a type, callable or field of application " f"{self.application_name!r}")
         mod, node = entry
         if node.span is None:
             raise CodeanalyzerExecutionException(f"node {node_id!r} carries no span, so it has no source text")
         b0, b1 = node.span.bytes
         if mod.source.isascii():
             return mod.source[b0:b1]
         encoded = self._module_bytes.get(mod.id)
         if encoded is None:
             encoded = mod.source.encode("utf-8")
             self._module_bytes[mod.id] = encoded
         return encoded[b0:b1].decode("utf-8")
 
     # -----[ artifact / dependency / config layer — not emitted by a local L1/L2 analysis ]-----
     def get_artifacts(self) -> Dict[str, PyArtifact]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
-    def get_dependencies(
-        self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None
-    ) -> List[PyDependency]:
+    def get_dependencies(self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None) -> List[PyDependency]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
     def get_config_keys(self) -> Dict[str, PyConfigKey]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
     def get_config_uses(self, key: str | None = None) -> List[PyConfigUseEdge]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
     def get_unresolved_config_reads(self) -> List[PyConfigRead]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
diff --git a/cldk/analysis/go/go_analysis.py b/cldk/analysis/go/go_analysis.py
index 5575be9..903368b 100644
--- a/cldk/analysis/go/go_analysis.py
+++ b/cldk/analysis/go/go_analysis.py
@@ -29,20 +29,21 @@ are addressed by the type's durable ``can://`` id (a Go type has no unique short
 packages); callers/callees by the callable's ``can://`` id.
 """
 
 from __future__ import annotations
 
 from pathlib import Path
 from typing import Dict, List
 
 import networkx as nx
 
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig, GoBackend, Neo4jConnectionConfig
 from cldk.analysis.go.backend import GoAnalysisBackend
 from cldk.analysis.go.codeanalyzer import GoCodeanalyzer
 from cldk.analysis.go.neo4j import GoNeo4jBackend
 from cldk.models.go import GoApplication, GoCallable, GoCallGraphEdge, GoField, GoModule, GoParam, GoType
 
 
 class GoAnalysis:
     """Analysis facade for Go projects.
 
@@ -64,33 +65,38 @@ class GoAnalysis:
         eager_analysis: bool,
         backend: GoBackend | None = None,
     ) -> None:
         self.project_dir = project_dir
         self.analysis_level = analysis_level
         self.target_files = target_files
         self.eager_analysis = eager_analysis
         # The backend is selected by the *type* of the config: Neo4jConnectionConfig picks the
         # read-only Cypher backend, CodeAnalyzerConfig (the default) the in-process cango.
         self.backend_config: GoBackend = backend if backend is not None else CodeAnalyzerConfig()
+        self.identity = resolve_identity(self.backend_config.application_name, self.backend_config.namespace, project_root=Path(project_dir) if project_dir is not None else None)
         self.backend: GoAnalysisBackend
         if isinstance(self.backend_config, Neo4jConnectionConfig):
             cfg = self.backend_config
-            application_name = cfg.application_name or (Path(project_dir).name if project_dir else None)
+            application_name = self.identity.application_name
             self.backend = GoNeo4jBackend(
                 neo4j_uri=cfg.uri,
                 neo4j_username=cfg.username,
                 neo4j_password=cfg.password,
                 neo4j_database=cfg.database,
                 application_name=application_name,
+                namespace=self.identity.namespace,
+                source_root=project_dir,
             )
         else:
             self.backend = GoCodeanalyzer(
+                application_name=self.identity.application_name,
+                namespace=self.identity.namespace,
                 project_dir=project_dir,
                 cache_dir=self.backend_config.cache_dir,
                 analysis_level=analysis_level,
                 eager_analysis=eager_analysis,
                 target_files=target_files,
             )
         self.application: GoApplication = self.backend.get_application_view()
 
     # -----[ Tier A: lifecycle / whole-program ]-----
     def get_application_view(self) -> GoApplication:
diff --git a/cldk/analysis/go/neo4j/neo4j_backend.py b/cldk/analysis/go/neo4j/neo4j_backend.py
index 4a5068f..8c97954 100644
--- a/cldk/analysis/go/neo4j/neo4j_backend.py
+++ b/cldk/analysis/go/neo4j/neo4j_backend.py
@@ -38,134 +38,153 @@ emitting it, those six flip to querying the graph for real.
 """
 
 from __future__ import annotations
 
 import json
 from functools import cached_property
 from typing import Any, Dict, List
 
 import networkx as nx
 
+from cldk.analysis.commons.identity import resolve_identity, validate_identity
 from cldk.analysis.go.backend import ARTIFACT_LAYER_UNAVAILABLE, GoAnalysisBackend
 from cldk.analysis.go.neo4j import reconstruct as R
 from cldk.models.go import GoApplication, GoCallable, GoCallGraphEdge, GoField, GoModule, GoParam, GoType
 from cldk.models.python import PyArtifact, PyConfigKey, PyConfigRead, PyConfigUseEdge, PyDependency
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
 #: Relationship types a Go graph must carry to be a codeanalyzer-go projection at all.
 _REQUIRED_RELS = {"GO_HAS_MODULE", "GO_DECLARES", "GO_HAS_METHOD", "GO_CALLS"}
 
 
 class GoNeo4jBackend(GoAnalysisBackend):
     """Answer the Go query surface over a ``GO_``-prefixed Neo4j graph (see the module docstring)."""
 
     def __init__(
         self,
         neo4j_uri: str,
         neo4j_username: str,
         neo4j_password: str,
         neo4j_database: str | None = None,
         application_name: str | None = None,
+        namespace: str | None = None,
+        source_root=None,
     ) -> None:
         try:
             from neo4j import GraphDatabase
         except ModuleNotFoundError as e:  # pragma: no cover - import guard
-            raise CodeanalyzerExecutionException(
-                "The Neo4j backend requires the 'neo4j' driver. Install it with `pip install neo4j` "
-                "(or `pip install cldk[neo4j]`)."
-            ) from e
+            raise CodeanalyzerExecutionException("The Neo4j backend requires the 'neo4j' driver. Install it with `pip install neo4j` " "(or `pip install cldk[neo4j]`).") from e
         self._init_with_driver(
             GraphDatabase.driver(neo4j_uri, auth=(neo4j_username, neo4j_password)),
             application_name=application_name,
+            namespace=namespace,
+            source_root=source_root,
             neo4j_database=neo4j_database,
         )
 
     @classmethod
-    def _from_driver(cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None) -> "GoNeo4jBackend":
+    def _from_driver(
+        cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None, namespace: str | None = None, source_root=None
+    ) -> "GoNeo4jBackend":
         """Construct from an already-built driver — the seam tests inject a fake/real driver here."""
         self = cls.__new__(cls)
-        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database)
+        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database, namespace=namespace, source_root=source_root)
         return self
 
-    def _init_with_driver(self, driver: Any, *, application_name: str | None, neo4j_database: str | None) -> None:
-        if not application_name:
-            raise CodeanalyzerExecutionException("application_name is required to scope queries to an application.")
-        self.application_name = application_name
+    def _init_with_driver(self, driver: Any, *, application_name: str | None, neo4j_database: str | None, namespace: str | None = None, source_root=None) -> None:
+        self.identity = resolve_identity(application_name, namespace)
+        self.application_name = self.identity.application_name
+        self.source_root = source_root
         self._database = neo4j_database
         self._driver = driver
         self._session_obj: Any | None = None
         self._call_graph: nx.DiGraph | None = None
         self._probe_schema()
+        self._probe_identity()
 
     # -----[ scope + execution ]-----
     @property
     def _app_id(self) -> str:
-        """``can://<app>`` — the ``:GoApplication`` anchor id and the root of every id below it."""
-        return f"can://{self.application_name}"
+        """``can://<namespace>/<app>`` — the ``:GoApplication`` anchor id and the root of every id below it."""
+        return self.identity.application_id
 
     @property
     def _scope_prefix(self) -> str:
-        """``can://<app>/`` — the trailing slash keeps ``app`` from matching ``app-b``."""
+        """``can://<namespace>/<app>/`` — the trailing slash keeps ``app`` from matching ``app-b``."""
         return f"{self._app_id}/"
 
     def _run(self, query: str, **params: Any) -> List[Dict[str, Any]]:
         """Run one read statement over a reused session; drop the session on failure."""
+        for name in ("id", "mid", "tid"):
+            value = params.get(name)
+            if isinstance(value, str) and value.startswith("can:") and not value.startswith(self._scope_prefix + "go/"):
+                raise ValueError("Node URI is outside the bound Go application scope")
         if self._session_obj is None:
             self._session_obj = self._driver.session(database=self._database)
         try:
             return [record.data() for record in self._session_obj.run(query, **params)]
         except Exception:
             self._session_obj = None
             raise
 
     def close(self) -> None:
         if self._session_obj is not None:
             self._session_obj = None
         self._driver.close()
 
     def __enter__(self) -> "GoNeo4jBackend":
         return self
 
     def __exit__(self, *exc: Any) -> None:
         self.close()
 
+    def _probe_identity(self) -> None:
+        rows = self._run("MATCH (a:GoApplication {id: $app_id}) RETURN properties(a) AS identity", app_id=self._app_id)
+        validate_identity(rows[0].get("identity", {}) if rows else {}, self.identity, envelope=False)
+
     def _probe_schema(self) -> None:
         """Refuse a graph that is not a codeanalyzer-go projection or holds no node for this app."""
         found = {r["relationshipType"] for r in self._run("CALL db.relationshipTypes()")}
         missing = _REQUIRED_RELS - found
         if missing:
-            raise CodeanalyzerExecutionException(
-                f"the graph is not a codeanalyzer-go projection: missing relationship types {sorted(missing)}"
-            )
+            raise CodeanalyzerExecutionException(f"the graph is not a codeanalyzer-go projection: missing relationship types {sorted(missing)}")
         rows = self._run("OPTIONAL MATCH (a:GoApplication {id: $app_id}) RETURN count(a) AS n", app_id=self._app_id)
         if not (rows and rows[0].get("n")):
-            raise CodeanalyzerExecutionException(
-                f"the graph holds no :GoApplication node for {self.application_name!r} (id {self._app_id!r})"
-            )
+            raise CodeanalyzerExecutionException(f"the graph holds no :GoApplication node for {self.application_name!r} (id {self._app_id!r})")
 
     # -----[ application / whole-program ]-----
     def get_application_view(self) -> GoApplication:
         """The whole application view. Whole-program accessors touch everything by nature; this
         builds the symbol table from the containment relationships and the call graph from
         ``GO_CALLS``, cached."""
         return self._application
 
     @cached_property
     def _application(self) -> GoApplication:
-        return GoApplication(id=self._app_id, symbol_table=self._build_symbol_table(), call_graph=self._call_edges())
+        return GoApplication(
+            identity_version=2,
+            application_name=self.identity.application_name,
+            identity_namespace=self.identity.namespace,
+            id=self._app_id,
+            symbol_table=self._build_symbol_table(),
+            call_graph=self._call_edges(),
+        )
 
     def get_symbol_table(self) -> Dict[str, GoModule]:
         return self.get_application_view().symbol_table
 
     def _module_file_key(self, module_id: str) -> str:
         """``can://<app>/<file>`` → ``<file>`` (the symbol-table key the local backend uses)."""
-        return module_id[len(self._scope_prefix):]
+        prefix = self._scope_prefix + "go/"
+        if not module_id.startswith(prefix):
+            raise ValueError("Module URI is outside the bound Go application scope")
+        return module_id[len(prefix) :]
 
     def _build_symbol_table(self) -> Dict[str, GoModule]:
         """Rebuild every module with its types, functions, methods and fields from the containment
         relationships. This is the expensive whole-program path; point accessors below never call
         it."""
         modules: Dict[str, GoModule] = {}
         mod_rows = self._run(
             "MATCH (:GoApplication {id: $app_id})-[:GO_HAS_MODULE]->(m:GoModule) RETURN properties(m) AS p ORDER BY m.id",
             app_id=self._app_id,
         )
@@ -197,28 +216,24 @@ class GoNeo4jBackend(GoAnalysisBackend):
                     fld = R.field(frow["p"])
                     ty.fields[fld.id.split("/")[-1]] = fld
                 # keyed by the short name, as in the JSON types{} map
                 mod.types[ty.id.split("/")[-1]] = ty
             modules[self._module_file_key(mod.id)] = mod
         return modules
 
     # -----[ call graph ]-----
     def _call_edges(self) -> List[GoCallGraphEdge]:
         rows = self._run(
-            "MATCH (a:GoCallable)-[r:GO_CALLS]->(b) WHERE a.id STARTS WITH $pre "
-            "RETURN a.id AS src, b.id AS dst, properties(r) AS p ORDER BY a.id, b.id",
+            "MATCH (a:GoCallable)-[r:GO_CALLS]->(b) WHERE a.id STARTS WITH $pre " "RETURN a.id AS src, b.id AS dst, properties(r) AS p ORDER BY a.id, b.id",
             pre=self._scope_prefix,
         )
-        return [
-            GoCallGraphEdge(src=r["src"], dst=r["dst"], prov=list(r["p"].get("prov") or []), weight=r["p"].get("weight", 1))
-            for r in rows
-        ]
+        return [GoCallGraphEdge(src=r["src"], dst=r["dst"], prov=list(r["p"].get("prov") or []), weight=r["p"].get("weight", 1)) for r in rows]
 
     def get_call_graph(self) -> nx.DiGraph:
         if self._call_graph is not None:
             return self._call_graph
         graph = nx.DiGraph()
         for e in self._call_edges():
             graph.add_node(e.src, id=e.src)
             graph.add_node(e.dst, id=e.dst)
             graph.add_edge(e.src, e.dst, type="CALL_DEP", weight=e.weight, provenance=tuple(e.prov))
         self._call_graph = graph
@@ -283,61 +298,56 @@ class GoNeo4jBackend(GoAnalysisBackend):
         # :GoCallable does not project parameters; a reconstructed method carries none. Returning
         # [] keeps parity with "the graph does not carry this", not an invented answer.
         m = self.get_method(qualified_class_name, qualified_method_name)
         return list(m.parameters) if m else []
 
     # -----[ functions + source ]-----
     def get_functions(self) -> Dict[str, GoCallable]:
         """Every package-level function (``:GoModule``-[:GO_DECLARES]->(:GoCallable)``), keyed by
         signature."""
         rows = self._run(
-            "MATCH (m:GoModule)-[:GO_DECLARES]->(c:GoCallable) WHERE m.id STARTS WITH $pre "
-            "RETURN properties(c) AS p ORDER BY c.signature",
+            "MATCH (m:GoModule)-[:GO_DECLARES]->(c:GoCallable) WHERE m.id STARTS WITH $pre " "RETURN properties(c) AS p ORDER BY c.signature",
             pre=self._scope_prefix,
         )
         return {r["p"]["signature"]: R.callable_(r["p"]) for r in rows}
 
     def get_source(self, node_id: str) -> str:
         """The source text of ``node_id`` — ``module.source`` sliced by the node's ``span_json``
         byte offsets. The owning ``:GoModule`` carries ``source``; the node's module is the longest
         ``:GoModule.id`` the node id starts with. Byte offsets are UTF-8, as in the local backend."""
         node_rows = self._run(
             "MATCH (n:GoCanNode {id: $id}) RETURN n.span_json AS span",
             id=node_id,
         )
         if not node_rows:
-            raise CodeanalyzerExecutionException(
-                f"no node {node_id!r} in the graph for application {self.application_name!r}"
-            )
+            raise CodeanalyzerExecutionException(f"no node {node_id!r} in the graph for application {self.application_name!r}")
         span_json = node_rows[0]["span"]
         if not span_json:
             raise CodeanalyzerExecutionException(f"node {node_id!r} carries no span, so it has no source text")
         # the owning module: the :GoModule whose id is a prefix of this node's id
         mod_rows = self._run(
             "MATCH (m:GoModule) WHERE $id STARTS WITH m.id + '/' RETURN m.id AS id, m.source AS source ORDER BY size(m.id) DESC LIMIT 1",
             id=node_id,
         )
         if not mod_rows:
             raise CodeanalyzerExecutionException(f"no owning module for {node_id!r}")
         source = mod_rows[0]["source"] or ""
         b0, b1 = json.loads(span_json)["bytes"]
         if source.isascii():
             return source[b0:b1]
         return source.encode("utf-8")[b0:b1].decode("utf-8")
 
     # -----[ artifact / dependency / config layer — reserved-but-unemitted on this projection ]-----
     def get_artifacts(self) -> Dict[str, PyArtifact]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
-    def get_dependencies(
-        self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None
-    ) -> List[PyDependency]:
+    def get_dependencies(self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None) -> List[PyDependency]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
     def get_config_keys(self) -> Dict[str, PyConfigKey]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
     def get_config_uses(self, key: str | None = None) -> List[PyConfigUseEdge]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
 
     def get_unresolved_config_reads(self) -> List[PyConfigRead]:
         raise CodeanalyzerExecutionException(ARTIFACT_LAYER_UNAVAILABLE.format(app=self.application_name))
diff --git a/cldk/analysis/java/backend.py b/cldk/analysis/java/backend.py
index 2cace7b..9b0ffd2 100644
--- a/cldk/analysis/java/backend.py
+++ b/cldk/analysis/java/backend.py
@@ -47,34 +47,47 @@ nothing else.
 
 from __future__ import annotations
 
 import re
 from abc import abstractmethod
 from functools import cached_property
 from typing import ClassVar, Collection, Dict, Iterable, List, Mapping, NamedTuple, Optional, Sequence, Set, Tuple, Union
 
 import networkx as nx
 
+from cldk.analysis.commons.keys import module_scope
 from cldk.analysis.commons.backend import AnalysisBackend
 from cldk.analysis.commons.bounds import (
     DEFAULT_DEPTH,
     DEFAULT_MAX_NODES,
     DEFAULT_MAX_PATHS,
     DEFAULT_PAGE_SIZE,
     EdgeOrder,
     check_depth,
     check_distinct_endpoints,
     check_max_nodes,
     check_max_paths,
     reject_bare_string,
 )
-from cldk.analysis.commons.graphs import as_slice_node, call_reaches, cone_sinks, edge_sort_key, flow_path, sdg_rel_pattern, sdg_rels, shortest_walks, slice_resolved, taint_verdict, via_table
+from cldk.analysis.commons.graphs import (
+    as_slice_node,
+    call_reaches,
+    cone_sinks,
+    edge_sort_key,
+    flow_path,
+    sdg_rel_pattern,
+    sdg_rels,
+    shortest_walks,
+    slice_resolved,
+    taint_verdict,
+    via_table,
+)
 from cldk.analysis.commons.keys import body_key_column, resolve_module_key
 from cldk.analysis.commons.resolve import CallableCandidate, resolve_callable_signature, resolve_sanitizers, resolve_value_name, resolve_within
 from cldk.analysis.commons.results import (
     BodyRef,
     CallableRef,
     Diagnostic,
     EdgePage,
     EntrypointCoverage,
     FlowPath,
     FlowPaths,
@@ -519,21 +532,21 @@ def duplicate_type_name(qualified_name: str) -> str:
     it names only the qualified name: a ``can://`` id must not appear in a message (E6)."""
     return f"type qualified name {qualified_name!r} is declared twice: codeanalyzer-java emitted two declarations that spell one name"
 
 
 def unhomed_endpoint(node_id: str) -> str:
     """The defect message for a call-graph endpoint that is not one of the application's callables.
     Both backends raise this text, identically, and it names the endpoint by the signature and
     module key its id *spells* rather than by the id itself (E6)."""
     module, sep, rest = node_id.partition(".java/")
     signature = (rest or node_id).rpartition("/")[2]
-    where = f"{module.split('/', 4)[4]}.java" if sep and module.count("/") >= 4 else "no module of this application"
+    where = f"{module.partition('/java/')[2]}.java" if sep and "/java/" in module else "no module of this application"
     return f"call-graph endpoint {signature!r} in {where!r} is not one of its callables: codeanalyzer-java emitted an unhomed endpoint"
 
 
 class JavaAnalysisBackend(AnalysisBackend[JApplication, JCompilationUnit, JType, JCallable, JField, JCallableParameter]):
     """Abstract base every Java analysis backend implements.
 
     A backend owns all indexing and query logic for a Java application; the :class:`JavaAnalysis`
     façade delegates to it. Implementations must return the canonical ``cldk.models.java`` pydantic
     objects (or the documented NetworkX / dict / list shapes) so backends are behaviorally
     interchangeable.
@@ -648,21 +661,21 @@ class JavaAnalysisBackend(AnalysisBackend[JApplication, JCompilationUnit, JType,
         Neo4j projection carries and a rule the two backends cannot both apply is not one rule.
         Ties (a callable declared inside another on one line) break on the longer J-1 key, deeper
         first — a local class's key extends its declaring callable's — and then on the key itself,
         so the order is total and identical on both sides.
 
         A position between two callables, or at module scope, is contained by none and comes back
         ``None`` rather than snapping to a neighbour. A callable with **no span** — every implicit
         constructor (99 of daytrader8's 1,216) — is contained by nothing, which is right: it has no
         position in the file to be found at.
         """
-        key = resolve_module_key(str(path), self.get_application_view().symbol_table.keys())
+        key = resolve_module_key(str(path), self.get_application_view().symbol_table.keys(), **module_scope(self))
         rows = [r for r in self._addressing.by_path.get(key, ()) if r.callable.span is not None and r.callable.start_line <= line <= r.callable.end_line]
         if not rows:
             return key, None
         return key, min(rows, key=lambda r: (r.callable.end_line - r.callable.start_line, -len(r.key), r.key))
 
     def _locate_result(self, line: int, key: str, row: Optional[_Addressed], bodies: Mapping[str, Mapping[str, JBodyNode]]) -> LocateResult:
         unit = self.get_application_view().symbol_table.get(key)
         if unit is None:
             return LocateResult(
                 body=None,
@@ -1641,21 +1654,21 @@ class JavaAnalysisBackend(AnalysisBackend[JApplication, JCompilationUnit, JType,
     # to the statement graph from 3.0.3, and on such output all five answer with no change here.
     # See :data:`PORTS_DISCONNECTED`.
     # =====================================================================================
     @property
     def _application_name(self) -> str:
         """The ``--app-name`` this application was analysed under, for a message to name it by.
 
         Read off the application's own id rather than stored, so the in-memory backend (which has
         no ``application_name``) and the graph backend give one answer. Only the *name* segment
         leaves this method: a ``can://`` id must not appear in a message (E6)."""
-        return self.get_application_view().id.rpartition("/")[2]
+        return self.get_application_view().application_name
 
     # -----[ the per-callable graphs ]-----
     @abstractmethod
     def get_cfg(self, callable: str, *, in_class: str | None = None, page_size: int = DEFAULT_PAGE_SIZE, cursor: str | None = None) -> EdgePage[JCfgEdge]:
         """One page of the control flow edges within one callable.
 
         Args:
             callable: The callable's name, resolved by :meth:`resolve_callable` — so an ambiguous
                 name raises listing candidates rather than being guessed at.
             in_class: Disambiguate by owning class, as in :meth:`resolve_callable`.
diff --git a/cldk/analysis/java/codeanalyzer/codeanalyzer.py b/cldk/analysis/java/codeanalyzer/codeanalyzer.py
index c31e78e..aaf1fd7 100644
--- a/cldk/analysis/java/codeanalyzer/codeanalyzer.py
+++ b/cldk/analysis/java/codeanalyzer/codeanalyzer.py
@@ -31,20 +31,21 @@ import json
 import logging
 import re
 import subprocess
 from pathlib import Path
 from subprocess import CompletedProcess
 from typing import Any, Dict, FrozenSet, Iterable, List, Mapping, Sequence, Tuple, Union
 
 import networkx as nx
 from pydantic import ValidationError
 
+from cldk.analysis.commons.identity import resolve_identity, validate_identity, cache_matches
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.commons.bounds import DEFAULT_PAGE_SIZE, check_page_size, edge_page
 from cldk.analysis.commons.graphs import flow_path, shortest_walks, slice_resolved, under_callable
 from cldk.analysis.commons.levels import ANALYZER_LEVELS, LEVEL_NAMES, analyzer_level
 from cldk.analysis.commons.results import Diagnostic, EdgePage, FlowPath, FlowPaths, Slice, SliceNode
 from cldk.analysis.java.backend import (
     CDG_ORDER,
     CFG_ORDER,
     CRUD_UNAVAILABLE,
     DDG_ORDER,
@@ -199,29 +200,37 @@ class JCodeanalyzer(JavaAnalysisBackend):
         """``analyzer.version`` off the wire, as a comparable tuple; ``None`` if it is not a semver."""
         return _semver(self.analysis.analyzer.version)
 
     def __init__(
         self,
         project_dir: Union[str, Path, None],
         analysis_json_path: Union[str, Path, None],
         analysis_level: str,
         eager_analysis: bool,
         target_files: List[str] | None,
+        *,
+        application_name: str | None = None,
+        namespace: str | None = None,
     ) -> None:
+        if project_dir is None:
+            raise CodeanalyzerExecutionException("Cannot run codeanalyzer-java: no project directory.")
+        self.identity = resolve_identity(application_name, namespace, project_root=Path(project_dir))
+
         self.project_dir = project_dir
         self.analysis_json_path = analysis_json_path
         self.analysis_level = analysis_level
         self.eager_analysis = eager_analysis
         self.target_files = target_files
         self.analyzer_diagnostics: List[Diagnostic] | None = None
         self.analysis: JAnalysis = self._init_codeanalyzer(analysis_level=analyzer_level(analysis_level))
         self._report_analyzer_diagnostics(analyzer_level(analysis_level))
+        validate_identity(self.analysis, self.identity)
         self.application: JApplication = self.analysis.application
         self._call_graph: nx.DiGraph | None = None
         self._sdg_cache: Any = None
         self._index()
 
     # -----[ driving the analyzer ]-----
     def _get_codeanalyzer_exec(self) -> List[str]:
         """``codeanalyzer_java.command()`` — ``[<jdk4py java>, -jar, <the wheel's jar>]``.
 
         The ``codeanalyzer-java`` wheel is the single source of both the jar and the JVM it runs
@@ -247,21 +256,21 @@ class JCodeanalyzer(JavaAnalysisBackend):
         only place it declares that a capability it was asked for did not run (#341) — and only
         with ``-o``, since without it the payload occupies the same stdout the log would.
         """
         if self.project_dir is None:
             raise CodeanalyzerExecutionException("Cannot run codeanalyzer-java: no project directory.")
         args = self._get_codeanalyzer_exec()
         project = Path(self.project_dir)
         args += ["-i", str(project), "-a", str(analysis_level)]
         if output_dir is not None:
             args += ["-o", str(output_dir), "-c", str(output_dir / "cache"), "-v"]
-        args += ["--app-name", project.name]
+        args += [f"--app-name={self.identity.application_name}", f"--namespace={self.identity.namespace}"]
         for tf in self.target_files or []:
             args += ["-t", str(tf).strip()]
         return args
 
     @staticmethod
     def check_exisiting_analysis_file_level(analysis_json_path_file: Path, analysis_level: int) -> bool:
         """Whether a cached ``analysis.json`` can serve a request at ``analysis_level``.
 
         ``False`` (re-run) when the file is missing, unparsable, or was computed at a lower
         ``max_level`` than requested. A file without ``schema_version`` is a pre-v2 (2.x) artifact
@@ -287,21 +296,26 @@ class JCodeanalyzer(JavaAnalysisBackend):
             try:
                 logger.info(f"Running codeanalyzer-java: {' '.join(args)}")
                 console_out: CompletedProcess[str] = subprocess.run(args, capture_output=True, text=True, check=True)
                 return JAnalysis.model_validate_json(console_out.stdout)
             except Exception as e:  # noqa: BLE001
                 raise CodeanalyzerExecutionException(str(e)) from e
 
         output_dir = Path(self.analysis_json_path)
         analysis_json_file = output_dir / "analysis.json"
         verdict_file = output_dir / VERDICT_FILE
-        needs_run = self.eager_analysis or bool(self.target_files) or not self.check_exisiting_analysis_file_level(analysis_json_file, analysis_level)
+        needs_run = (
+            self.eager_analysis
+            or bool(self.target_files)
+            or not self.check_exisiting_analysis_file_level(analysis_json_file, analysis_level)
+            or not cache_matches(analysis_json_file, self.identity)
+        )
         if needs_run:
             args = self._argv(analysis_level, output_dir)
             try:
                 logger.info(f"Running codeanalyzer-java: {' '.join(args)}")
                 console_out: CompletedProcess[str] = subprocess.run(args, capture_output=True, text=True, check=True)
                 if not analysis_json_file.exists():
                     raise CodeanalyzerExecutionException("codeanalyzer-java did not generate analysis.json.")
             except Exception as e:  # noqa: BLE001
                 raise CodeanalyzerExecutionException(str(e)) from e
             # Persisted beside the payload, because the point of the cache is that the next run does
@@ -893,21 +907,24 @@ class JCodeanalyzer(JavaAnalysisBackend):
         raise CodeanalyzerExecutionException(CRUD_UNAVAILABLE)
 
     def get_all_delete_operations(self) -> List[CRUDRow]:
         raise CodeanalyzerExecutionException(CRUD_UNAVAILABLE)
 
     # -----[ repository artifacts — the shared Py* models, as the generic ABC promises ]-----
     def get_artifacts(self) -> Dict[str, PyArtifact]:
         """Every non-code artifact (see :meth:`AnalysisBackend.get_artifacts`), keyed by repo-relative
         path as the wire keys them. ``JArtifact.text_truncated`` has no home on the shared model and
         is not carried; read it off ``JApplication.artifacts`` when it matters."""
-        return {path: PyArtifact(**a.model_dump(exclude={"config_keys", "text_truncated"}), config_keys=[PyConfigKey(**ck.model_dump()) for ck in a.config_keys]) for path, a in self.application.artifacts.items()}
+        return {
+            path: PyArtifact(**a.model_dump(exclude={"config_keys", "text_truncated"}), config_keys=[PyConfigKey(**ck.model_dump()) for ck in a.config_keys])
+            for path, a in self.application.artifacts.items()
+        }
 
     def get_dependencies(self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None) -> List[PyDependency]:
         """Every declared dependency, optionally filtered (see :meth:`AnalysisBackend.get_dependencies`).
         The Maven ``group`` coordinate has no home on the shared model and is not carried; read it off
         ``JApplication.dependencies`` when ``name`` alone is ambiguous."""
         deps = [PyDependency(**d.model_dump(exclude={"group"})) for d in self.application.dependencies]
         if direct_only:
             deps = [d for d in deps if d.direct]
         if ecosystem is not None:
             deps = [d for d in deps if d.ecosystem == ecosystem]
diff --git a/cldk/analysis/java/java_analysis.py b/cldk/analysis/java/java_analysis.py
index 614d586..547a851 100644
--- a/cldk/analysis/java/java_analysis.py
+++ b/cldk/analysis/java/java_analysis.py
@@ -45,20 +45,21 @@ See Also:
 """
 
 from __future__ import annotations
 
 from pathlib import Path
 from typing import Dict, List, Sequence, Tuple, Set, Union
 import networkx as nx
 
 from tree_sitter import Tree
 
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig, JavaBackend, Neo4jConnectionConfig, cache_subdir
 from cldk.analysis.commons.bounds import DEFAULT_DEPTH, DEFAULT_MAX_NODES, DEFAULT_MAX_PATHS, DEFAULT_PAGE_SIZE
 from cldk.analysis.commons.results import EdgePage, EntrypointCoverage, FlowPaths, LocateResult, Slice, SliceNode, TaintResult
 from cldk.analysis.commons.treesitter import TreesitterJava
 from cldk.models.java import JCallable
 from cldk.models.java import JApplication
 from cldk.models.java.models import (
     JCallableParameter,
     JCallSite,
     JCdgEdge,
@@ -157,38 +158,43 @@ class JavaAnalysis:
             NotImplementedError: If the requested analysis configuration is
                 not supported by the backend.
         """
 
         self.project_dir = project_dir
         self.analysis_level = analysis_level
         self.eager_analysis = eager_analysis
         self.target_files = target_files
         self.backend_config: JavaBackend = backend if backend is not None else CodeAnalyzerConfig()
         self.treesitter_java: TreesitterJava = TreesitterJava()
+        self.identity = resolve_identity(self.backend_config.application_name, self.backend_config.namespace, project_root=Path(project_dir) if project_dir is not None else None)
         self.backend: JavaAnalysisBackend
         if isinstance(self.backend_config, Neo4jConnectionConfig):
             # Read-only: the graph is populated out of band; the SDK only polls it.
             cfg = self.backend_config
-            application_name = cfg.application_name or (Path(project_dir).name if project_dir else None)
+            application_name = self.identity.application_name
             self.backend = JNeo4jBackend(
                 neo4j_uri=cfg.uri,
                 neo4j_username=cfg.username,
                 neo4j_password=cfg.password,
                 neo4j_database=cfg.database,
                 application_name=application_name,
+                namespace=self.identity.namespace,
+                source_root=project_dir,
             )
         else:
             # The config only carries the cache root. analysis.json is cached under <cache_dir>/java.
-            cache_path = cache_subdir(self.backend_config.cache_dir, project_dir, "java")
+            cache_path = cache_subdir(self.backend_config.cache_dir, project_dir, "java", identity=self.identity)
             if cache_path is not None:
                 cache_path.mkdir(parents=True, exist_ok=True)
             self.backend = JCodeanalyzer(
+                application_name=self.identity.application_name,
+                namespace=self.identity.namespace,
                 project_dir=self.project_dir,
                 eager_analysis=self.eager_analysis,
                 analysis_level=self.analysis_level,
                 analysis_json_path=cache_path,
                 target_files=self.target_files,
             )
 
     def get_imports(self) -> List[str]:
         """Return every distinct import target of the project, sorted.
 
@@ -545,23 +551,21 @@ class JavaAnalysis:
             A dictionary mapping fully qualified class names (strings) to
             :class:`~cldk.models.java.JType` objects containing class metadata,
             methods, fields, and inheritance information.
 
         See Also:
             :meth:`get_class`: For a single class by name.
             :meth:`get_classes_by_criteria`: For filtered class retrieval.
         """
         return self.backend.get_all_classes()
 
-    def get_classes_by_criteria(
-        self, inclusions: List[str] | None = None, exclusions: List[str] | None = None
-    ) -> Dict[str, JType]:
+    def get_classes_by_criteria(self, inclusions: List[str] | None = None, exclusions: List[str] | None = None) -> Dict[str, JType]:
         """Return classes matching inclusion/exclusion filter criteria.
 
         Filters the project's classes based on substring matching against
         their qualified names. Classes are included if their name contains
         any inclusion substring AND does not contain any exclusion substring.
 
         Args:
             inclusions: List of substrings that class names must contain to
                 be included. If ``None`` or empty, no inclusion filtering is
                 applied (effectively includes nothing unless you have at least
@@ -853,47 +857,40 @@ class JavaAnalysis:
 
         Returns:
             A list of interface names (as strings) that the class implements.
             Returns empty list if the class implements no interfaces.
 
         See Also:
             :meth:`get_extended_classes`: For class inheritance.
         """
         return self.backend.get_implemented_interfaces(qualified_class_name)
 
-    def __get_class_call_graph_using_symbol_table(
-        self, qualified_class_name: str, method_signature: str | None = None
-    ) -> List[Tuple[JMethodDetail, JMethodDetail]]:
+    def __get_class_call_graph_using_symbol_table(self, qualified_class_name: str, method_signature: str | None = None) -> List[Tuple[JMethodDetail, JMethodDetail]]:
         """Return class-level call graph using the symbol table.
 
         Internal method that uses symbol table-based resolution for building
         the call graph, which is faster but may be less accurate than full
         call graph analysis.
 
         Args:
             qualified_class_name: The fully qualified name of the class.
             method_signature: Optional method signature to scope the graph
                 to calls originating from a specific method.
 
         Returns:
             A list of tuples ``(caller, callee)`` where each element is a
             :class:`~cldk.models.java.JMethodDetail` object representing
             a method in the call relationship.
         """
         return self.backend.get_class_call_graph_using_symbol_table(qualified_class_name, method_signature)
 
-    def get_class_call_graph(
-        self,
-        qualified_class_name: str,
-        method_signature: str | None = None,
-        using_symbol_table: bool = False
-    ) -> List[Tuple[JMethodDetail, JMethodDetail]]:
+    def get_class_call_graph(self, qualified_class_name: str, method_signature: str | None = None, using_symbol_table: bool = False) -> List[Tuple[JMethodDetail, JMethodDetail]]:
         """Return call graph edges reachable from a class or method.
 
         Extracts a subset of the call graph containing only edges reachable
         from the specified class (and optionally a specific method within
         that class). This is useful for understanding the call structure
         of a specific component without the noise of the full project graph.
 
         Args:
             qualified_class_name: The fully qualified name of the class to
                 start traversal from (e.g., ``"com.example.service.UserService"``).
diff --git a/cldk/analysis/java/neo4j/neo4j_backend.py b/cldk/analysis/java/neo4j/neo4j_backend.py
index 103b2cc..db9c7a6 100644
--- a/cldk/analysis/java/neo4j/neo4j_backend.py
+++ b/cldk/analysis/java/neo4j/neo4j_backend.py
@@ -112,20 +112,21 @@ from __future__ import annotations
 
 import json
 import logging
 import re
 from collections import defaultdict
 from functools import cached_property
 from typing import Any, Dict, FrozenSet, Iterable, List, Mapping, Sequence, Tuple
 
 import networkx as nx
 
+from cldk.analysis.commons.identity import resolve_identity, validate_identity
 from cldk.analysis.commons.bounds import DEFAULT_PAGE_SIZE, EdgeOrder, check_page_size, cursor_params, encode_cursor, keyset_where
 from cldk.analysis.commons.graphs import flow_path, sdg_path_query, sdg_taint_query, slice_resolved
 from cldk.analysis.commons.results import Diagnostic, EdgePage, FlowPath, FlowPaths, Slice, SliceNode
 from cldk.analysis.java.backend import (
     CDG_ORDER,
     CFG_ORDER,
     CRUD_UNAVAILABLE,
     DDG_ORDER,
     SDG_REL_PATTERN,
     VIA,
@@ -237,56 +238,67 @@ class JNeo4jBackend(JavaAnalysisBackend):
     _has_resolution_edges: bool = False
     _call_graph: nx.DiGraph | None = None
 
     def __init__(
         self,
         neo4j_uri: str,
         neo4j_username: str,
         neo4j_password: str,
         neo4j_database: str | None = None,
         application_name: str | None = None,
+        namespace: str | None = None,
+        source_root=None,
     ) -> None:
         try:
             from neo4j import GraphDatabase
         except ModuleNotFoundError as e:  # pragma: no cover - import guard
             raise CodeanalyzerExecutionException("The Neo4j backend requires the 'neo4j' driver. Install it with `pip install neo4j` (or `pip install cldk[neo4j]`).") from e
-        self._init_with_driver(GraphDatabase.driver(neo4j_uri, auth=(neo4j_username, neo4j_password)), application_name=application_name, neo4j_database=neo4j_database)
+        self._init_with_driver(
+            GraphDatabase.driver(neo4j_uri, auth=(neo4j_username, neo4j_password)),
+            application_name=application_name,
+            neo4j_database=neo4j_database,
+            namespace=namespace,
+            source_root=source_root,
+        )
 
     @classmethod
-    def _from_driver(cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None) -> "JNeo4jBackend":
+    def _from_driver(
+        cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None, namespace: str | None = None, source_root=None
+    ) -> "JNeo4jBackend":
         """Construct from an already-built driver — the seam tests inject a fake driver through."""
         self = cls.__new__(cls)
-        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database)
+        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database, namespace=namespace, source_root=source_root)
         return self
 
-    def _init_with_driver(self, driver: Any, *, application_name: str | None, neo4j_database: str | None) -> None:
-        if not application_name:
-            raise CodeanalyzerExecutionException("application_name is required to scope queries to an application.")
-        self.application_name = application_name
+    def _init_with_driver(self, driver: Any, *, application_name: str | None, neo4j_database: str | None, namespace: str | None = None, source_root=None) -> None:
+        self.identity = resolve_identity(application_name, namespace)
+        self.application_name = self.identity.application_name
+        self.source_root = source_root
         self._database = neo4j_database
         self._driver = driver
         self._session_obj: Any | None = None
         self._probe_schema()
+        self._probe_identity()
         self._has_resolution_edges = self._probe_resolution_edges()
         self._module_props: Dict[str, Dict[str, Any]] = self._load_modules()
         self._modules: List[str] = list(self._module_props)
         self._call_graph = None
 
     # -----[ scope ]-----
     @property
     def _application_id(self) -> str:
-        """``can://<app>`` — the ``:JApplication`` root's own merge key since 3.1.1."""
-        return f"can://{self.application_name}"
+        """``can://<namespace>/<app>`` — the ``:JApplication`` root's own merge key since 3.1.1."""
+        return self.identity.application_id
 
     @property
     def _scope_prefix(self) -> str:
-        """``can://<app>/`` — the trailing slash keeps ``app`` from matching ``app-b``.
+        """``can://<namespace>/<app>/`` — the trailing slash keeps ``app`` from matching ``app-b``.
 
         The *application* prefix, not the narrower ``can://<app>/java/`` code one: an ``@external``
         ghost and an artifact both sit inside the application and outside the language segment (see
         the module docstring's **Scope**), and ``_external_rows`` would return nothing at all under
         the code prefix."""
         return f"{self._application_id}/"
 
     # -----[ lifecycle ]-----
     def close(self) -> None:
         """Close the underlying Neo4j driver."""
@@ -308,20 +320,24 @@ class JNeo4jBackend(JavaAnalysisBackend):
         """Run one read statement over a reused session; drop the session on failure."""
         if self._session_obj is None:
             self._session_obj = self._driver.session(database=self._database)
         try:
             return [record.data() for record in self._session_obj.run(query, **params)]
         except Exception:
             self._session_obj = None
             raise
 
     # -----[ attach ]-----
+    def _probe_identity(self) -> None:
+        rows = self._run("MATCH (a:JApplication {id: $app_id}) RETURN properties(a) AS identity", app_id=self._application_id)
+        validate_identity(rows[0].get("identity", {}) if rows else {}, self.identity, envelope=False)
+
     def _probe_schema(self) -> None:
         """J-9: the relationship-type fingerprint, then the analyzer generation the
         ``:JApplication`` anchor stamps, against :attr:`_ANALYZER_FLOOR`.
 
         A graph built by another codeanalyzer-java generation answers every statement here with
         zero rows and no error — indistinguishable from "this application has no callables". Below
         the floor, absent, or unreadable is refused, naming what was found.
         """
         found = {r["relationshipType"] for r in self._run("CALL db.relationshipTypes()")}
         # Kept: :meth:`_probe_resolution_edges` asks whether ``J_RESOLVES_TO`` exists at all, and
@@ -568,20 +584,22 @@ class JNeo4jBackend(JavaAnalysisBackend):
             module_id = props["id"]
             types: Dict[str, JType] = {}
             for rel, p, _ in children.get(module_id, []):
                 if rel != "J_DECLARES":
                     continue
                 # A module declares types only; ``kind`` is a ``Literal`` on :class:`JType`, so a
                 # row that is not one is refused by the model.
                 types[self._child_key(module_id, p)] = self._type(p, children, sites)
             symbol_table[key] = R.compilation_unit(props, import_declarations=[i for e in imports.get(key, []) for i in R.imports(e)], types=types)
         return JApplication(
+            application_name=self.identity.application_name,
+            identity_namespace=self.identity.namespace,
             id=self._application_id,
             symbol_table=symbol_table,
             call_graph=[JCallGraphEdge(src=r["src"], dst=r["dst"], prov=list(r["prov"] or []), weight=r["weight"] or 1) for r in self._call_edge_rows()],
             # ``{}`` and never ``None``: ``--emit neo4j`` forces ``--external-calls``, so a graph
             # this backend can attach to was *always* asked, and no rows therefore means "homed
             # them, found none" -- a real answer about a project that calls nothing outside itself.
             # ``None`` is the local payload's own value, for the run that was never asked, and it is
             # the one ``get_external_symbols`` raises on (D7). Coercing an empty map to it here made
             # the ``{}`` both that method and the facade document unreachable on either backend.
             external_symbols={r["p"]["id"]: JExternalSymbol(**{k: v for k, v in r["p"].items() if k != "id"}) for r in self._external_rows()},
diff --git a/cldk/analysis/python/codeanalyzer/codeanalyzer.py b/cldk/analysis/python/codeanalyzer/codeanalyzer.py
index 776f3c5..f29a38b 100644
--- a/cldk/analysis/python/codeanalyzer/codeanalyzer.py
+++ b/cldk/analysis/python/codeanalyzer/codeanalyzer.py
@@ -45,28 +45,31 @@ Note:
 See Also:
     - :class:`~cldk.analysis.python.PythonAnalysis`: High-level facade.
     - :class:`~cldk.analysis.java.codeanalyzer.JCodeanalyzer`: Java equivalent.
 """
 
 from __future__ import annotations
 
 import logging
 from functools import partial
 from pathlib import Path
-from typing import Dict, FrozenSet, Iterator, List, Mapping, Sequence, Tuple, Union
+from typing import Dict, FrozenSet, Iterable, Iterator, List, Mapping, Sequence, Tuple, Union
 
 import networkx as nx
 
 from codeanalyzer.core import Codeanalyzer
 from codeanalyzer.options import AnalysisOptions, EmitTarget
 from codeanalyzer.schema import Analysis, model_dump_json
 
+from dataclasses import replace
+from cldk.analysis.commons.keys import module_scope
+from cldk.analysis.commons.identity import resolve_identity, validate_identity
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.commons.graphs import call_reaches, under_callable
 from cldk.analysis.commons.levels import ANALYZER_LEVELS, LEVEL_NAMES, analyzer_level
 from cldk.analysis.commons.resolve import CallableCandidate, body_node_kind, resolve_callable_signature, resolve_value_name, resolve_within, value_candidate
 from cldk.analysis.commons.results import BodyRef, CallableRef, Diagnostic, EdgePage, EntrypointCoverage, FlowPath, FlowPaths, LocateResult, ModuleRef, Slice, SliceNode, TypeRef
 from cldk.utils.exceptions import CodeanalyzerUsageException
 from cldk.analysis.python.backend import (
     CDG_ORDER,
     CFG_ORDER,
     DDG_ORDER,
@@ -291,21 +294,21 @@ def _resolve_callee(
     A call site with neither — Jedi failed and no body-node resolution exists — keeps
     ``callee_signature`` as ``None``: genuinely unresolved, not a gap this closes.
     """
     node = body.get(f"{cs.start_line}:{cs.start_column}")
     if node is not None and node.callee:
         resolved = id_to_sig.get(node.callee, node.callee)
     elif cs.callee_signature and cs.callee_signature not in declared_sigs:
         resolved = reverse_externals.get(cs.callee_signature, cs.callee_signature)
     else:
         resolved = cs.callee_signature
-    return cs if resolved == cs.callee_signature else cs.model_copy(update={"callee_signature": resolved})
+    return cs if resolved == cs.callee_signature else replace(cs, callee_signature=resolved)
 
 
 def _decorator_covers(c: PyCallable, line: int) -> bool:
     """Whether ``line`` sits on (or between) the decorators applied to ``c`` -- at or after the first
     recorded decorator's line and above ``c.start_line``, the ``def`` line. The same predicate the
     Neo4j backend's ``PY_DECORATED_BY`` disjunct evaluates, so the two backends admit the same
     callable for a decorator position (#408).
 
     A decorator whose ``span`` was not recorded (every analysis from codeanalyzer-python 1.5.1 or
     earlier) is skipped: nothing is inferred from the decorator's mere presence, so such a position
@@ -434,20 +437,23 @@ class PyCodeanalyzer(PythonAnalysisBackend):
 
     def __init__(
         self,
         project_dir: Union[str, Path],
         analysis_level: str,
         analysis_json_path: Union[str, Path, None],
         eager_analysis: bool,
         cache_dir: Union[str, Path, None] = None,
         target_files: List[str] | None = None,
         use_ray: bool = False,
+        *,
+        application_name: str | None = None,
+        namespace: str | None = None,
     ) -> None:
         """Initialize the Python code analyzer and run analysis.
 
         Creates a new analyzer instance for the specified project. Analysis
         is performed immediately during initialization, with results cached
         for subsequent method calls.
 
         Args:
             project_dir: Absolute or relative path to the Python project root
                 directory. This directory should contain Python source files
@@ -475,20 +481,22 @@ class PyCodeanalyzer(PythonAnalysisBackend):
                 would otherwise be slow. Requires Ray to be installed.
                 Defaults to ``False``.
 
         Raises:
             ValueError: If ``project_dir`` is ``None``.
 
         Note:
             Analysis is performed synchronously during initialization.
             For large projects, this may take significant time.
         """
+
+        self.identity = resolve_identity(application_name, namespace, project_root=Path(project_dir) if project_dir is not None else None)
         if project_dir is None:
             raise ValueError("project_dir is required for Python analysis.")
         # Expand ~ and resolve to absolute path for robustness
         self.project_dir = Path(project_dir).expanduser().resolve()
         if not self.project_dir.is_dir():
             raise ValueError(f"project_dir does not exist or is not a directory: {self.project_dir}")
         self.analysis_level = analysis_level
         self.eager_analysis = eager_analysis
         self.target_files = target_files
         self.use_ray = use_ray
@@ -499,20 +507,21 @@ class PyCodeanalyzer(PythonAnalysisBackend):
         self.cache_dir = Path(cache_dir).expanduser().resolve() if cache_dir else None
         self.analysis_json_path = Path(analysis_json_path).expanduser().resolve() if analysis_json_path else None
 
         # codeanalyzer-python 1.4.0's analyze() returns the v2 envelope (schema_version,
         # max_level, analyzer, application) rather than a bare application. Unwrap it here, once,
         # so every downstream `self.application.xxx` read below keeps working unchanged; the
         # envelope itself is kept on `self.analysis` rather than discarded, since schema_version /
         # max_level are facts a later, interprocedural-aware facade needs to tell "no result"
         # apart from "unanswerable at this analysis level".
         self.analysis: Analysis = self._run_analyzer()
+        validate_identity(self.analysis, self.identity)
         self.application: PyApplication = self.analysis.application
         # Class-signature → file path lookup, built once.
         # Built on first use by ``_sdg()``: the whole application's SDG adjacency, which every
         # slice reads and nothing else needs, so it is not paid for by a caller who never slices.
         self._sdg_cache: "Tuple[Dict[str, Dict[str, set]], Dict[str, Tuple[PyCallable, str, str]]] | None" = None
         self._class_to_file: Dict[str, str] = {}
         for file_path, module in self.application.symbol_table.items():
             for class_sig in module.types:
                 self._class_to_file[class_sig] = file_path
 
@@ -543,20 +552,22 @@ class PyCodeanalyzer(PythonAnalysisBackend):
             supports single-file targeting only.
         """
         target_file = None
         if self.target_files:
             if len(self.target_files) > 1:
                 logger.warning("codeanalyzer-python supports only a single target file; using the first.")
             target_file = Path(self.target_files[0])
 
         options = AnalysisOptions(
             input=self.project_dir,
+            app_name=self.identity.application_name,
+            namespace=self.identity.namespace,
             output=self.analysis_json_path,
             emit=EmitTarget.JSON,
             # Without this the analyzer ran at its own default (1) whatever the caller
             # asked for, so ``cfg``/``cdg``/``ddg`` were always empty and no ``formal_in`` vertex
             # ever existed. ``graphs`` / ``graph_field_depth`` stay at their defaults — see
             # :func:`analyzer_level`.
             analysis_level=analyzer_level(self.analysis_level),
             using_ray=self.use_ray,
             rebuild_analysis=self.eager_analysis,
             skip_tests=True,
@@ -660,21 +671,21 @@ class PyCodeanalyzer(PythonAnalysisBackend):
         Returns:
             A dictionary where keys are file paths (strings) and values
             are :class:`~cldk.models.python.PyModule` objects.
 
         Raises:
             ValueError: ``paths`` is an empty sequence — omit it to enumerate everything.
             SelectorNotInGraph: a path names no module in this application
                 (see :func:`~cldk.analysis.python.backend.scope_paths`).
         """
         table = self.application.symbol_table
-        keys = scope_paths(paths, table.keys())
+        keys = scope_paths(paths, table.keys(), **module_scope(self))
         return table if keys is None else {k: table[k] for k in keys}
 
     def get_modules(self) -> List[PyModule]:
         """Return all analyzed modules as a list.
 
         Returns:
             A list of :class:`~cldk.models.python.PyModule` objects,
             one for each analyzed Python file.
         """
         return list(self.application.symbol_table.values())
@@ -759,21 +770,21 @@ class PyCodeanalyzer(PythonAnalysisBackend):
         Returns:
             A dictionary mapping qualified class names to
             :class:`~cldk.models.python.PyClass` objects.
 
         Raises:
             SelectorNotInGraph: ``module`` names no module in this application. It resolves
                 through the same :func:`~cldk.analysis.python.backend.scope_paths` as ``paths=``
                 but reports itself as ``module``, so the error names the keyword the caller wrote.
         """
         table = self.application.symbol_table
-        keys = scope_paths(None if module is None else [module], table.keys(), kind="module")
+        keys = scope_paths(None if module is None else [module], table.keys(), kind="module", **module_scope(self))
         result: Dict[str, PyClass] = {}
         for mod in table.values() if keys is None else (table[k] for k in keys):
             result.update(mod.types)
         return result
 
     def get_class(self, qualified_class_name: str) -> PyClass | None:
         """Return a specific class by its qualified name.
 
         Args:
             qualified_class_name: The fully qualified class name
@@ -1285,21 +1296,21 @@ class PyCodeanalyzer(PythonAnalysisBackend):
         if self._sdg_cache is None:
             forward: Dict[str, Dict[str, list]] = {}
             backward: Dict[str, Dict[str, list]] = {}
             nodes: Dict[str, Tuple[PyCallable, str, str]] = {}
 
             def link(src: str, dst: str, label: tuple) -> None:
                 forward.setdefault(src, {}).setdefault(dst, []).append(label)
                 backward.setdefault(dst, {}).setdefault(src, []).append(label)
 
             for c, _, _, path, _ in self._iter_callables():
-                for key in (c.body or {}):
+                for key in c.body or {}:
                     nodes[body_node_id(c.id, key)] = (c, key, path)
                 # The relationship name each list is projected as, so a hop reports the same
                 # ``via`` here as it does over the graph -- ``cldk.analysis.python.backend.VIA``
                 # is the single translation table and neither backend has its own.
                 for rel, edges in (("PY_DDG", c.ddg), ("PY_CDG", c.cdg), ("PY_SUMMARY", c.summary)):
                     for e in edges or []:
                         link(
                             body_node_id(c.id, e.src),
                             body_node_id(c.id, e.dst),
                             (rel, getattr(e, "var", None), tuple(getattr(e, "prov", None) or ())),
@@ -1677,47 +1688,42 @@ class PyCodeanalyzer(PythonAnalysisBackend):
         analysis levels."""
         return True
 
     def get_callsites_for(self, signatures: List[str]) -> Dict[str, List[PyCallsite]]:
         """Return ``{signature: call_sites}`` for the requested signatures that exist, with each
         call site's ``callee_signature`` resolved (see :meth:`PythonAnalysisBackend.get_callsites_for`
         and :func:`_resolve_callee`)."""
         wanted = set(signatures)
         id_to_sig = self._id_to_signature()
         declared_sigs = set(id_to_sig.values())
-        reverse_externals = {
-            (f"{ext.module}.{ext.name}" if ext.module else ext.name): ext.id
-            for ext in self.application.external_symbols.values()
-        }
+        reverse_externals = {(f"{ext.module}.{ext.name}" if ext.module else ext.name): ext.id for ext in self.application.external_symbols.values()}
         return {
             c.signature: [_resolve_callee(cs, c.body, id_to_sig, declared_sigs, reverse_externals) for cs in c.call_sites]
             for c, _, _, _, _ in self._iter_callables()
             if c.signature in wanted
         }
 
     def get_external_symbols(self) -> Dict[str, PyExternalSymbol]:
         """Return every ``@external`` ghost symbol the application's call graph homed (see
         :meth:`PythonAnalysisBackend.get_external_symbols`) — a direct passthrough of
         ``PyApplication.external_symbols``, which the local backend has in full."""
         return dict(self.application.external_symbols)
 
     # ----------------------------------------------------------- repository artifacts
     def get_artifacts(self) -> Dict[str, PyArtifact]:
         """Return every non-code artifact (see :meth:`AnalysisBackend.get_artifacts`).
 
         ``PyApplication.artifacts`` is already keyed by repo-relative path (the analyzer's own
         ``project.py`` iterates it the same way), so this is a direct passthrough."""
         return dict(self.application.artifacts)
 
-    def get_dependencies(
-        self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None
-    ) -> List[PyDependency]:
+    def get_dependencies(self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None) -> List[PyDependency]:
         """Return every declared dependency, optionally filtered (see
         :meth:`AnalysisBackend.get_dependencies`)."""
         deps = self.application.dependencies
         if direct_only:
             deps = [d for d in deps if d.direct]
         if ecosystem is not None:
             deps = [d for d in deps if d.ecosystem == ecosystem]
         if declared_in is not None:
             deps = [d for d in deps if d.declared_in == declared_in]
         return list(deps)
@@ -1775,21 +1781,21 @@ class PyCodeanalyzer(PythonAnalysisBackend):
             type=None,
             module=ModuleRef(path=str(path)),
             source="",
             span=Span(start=(line, 0), end=(line, 0), bytes=(0, 0)),
             diagnostics=[Diagnostic(code="file_not_in_graph", message=f"{path} is not covered by any analysed module ({why}).")],
         )
 
     def _locate_one(self, path: str, line: int) -> LocateResult:
         # Whatever the caller's scanner printed ("./src/app.py", an absolute path) is normalised to
         # the symbol-table key first; an unnormalised path would otherwise read as file_not_in_graph.
-        key = resolve_module_key(str(path), self.application.symbol_table.keys())
+        key = resolve_module_key(str(path), self.application.symbol_table.keys(), **module_scope(self))
         module = self.application.symbol_table.get(key)
         if module is None:
             return self._not_analysed(key, line)
         # ``key``, never ``module.file_path``: the latter is the absolute path on the analysing
         # machine, which joins to nothing -- ``LocateResult.module.path`` shares its vocabulary with
         # the symbol table's keys, ``PyCallableOverview.path`` and ``SliceNode.file``, and the
         # Neo4j backend answers with the same repo-relative key.
         module_ref = ModuleRef(path=key, module_name=module.module_name)
         found = _find_innermost(module, line)
         if found is None:
@@ -1864,24 +1870,21 @@ class PyCodeanalyzer(PythonAnalysisBackend):
                     ]
                 }
 
             Returns ``{"caller_details": []}`` if the method is not found
             or has no callers.
         """
         graph = self.get_call_graph()
         method = self.get_method(target_class_name, target_method_declaration)
         if method is None or method.signature not in graph:
             return {"caller_details": []}
-        callers = [
-            {"caller_signature": src, "edge": graph.get_edge_data(src, method.signature)}
-            for src in graph.predecessors(method.signature)
-        ]
+        callers = [{"caller_signature": src, "edge": graph.get_edge_data(src, method.signature)} for src in graph.predecessors(method.signature)]
         return {"target_method": method.signature, "caller_details": callers}
 
     def get_all_callees(self, source_class_name: str, source_method_declaration: str) -> Dict:
         """Return all methods called by a specific source method.
 
         Queries the call graph to find all successor nodes (callees)
         of the specified method.
 
         Args:
             source_class_name: The fully qualified class name containing
@@ -1903,29 +1906,24 @@ class PyCodeanalyzer(PythonAnalysisBackend):
                     ]
                 }
 
             Returns ``{"callee_details": []}`` if the method is not found
             or has no callees.
         """
         graph = self.get_call_graph()
         method = self.get_method(source_class_name, source_method_declaration)
         if method is None or method.signature not in graph:
             return {"callee_details": []}
-        callees = [
-            {"callee_signature": tgt, "edge": graph.get_edge_data(method.signature, tgt)}
-            for tgt in graph.successors(method.signature)
-        ]
+        callees = [{"callee_signature": tgt, "edge": graph.get_edge_data(method.signature, tgt)} for tgt in graph.successors(method.signature)]
         return {"source_method": method.signature, "callee_details": callees}
 
-    def get_class_call_graph(
-        self, qualified_class_name: str, method_signature: str | None = None
-    ) -> List[Tuple[str, str]]:
+    def get_class_call_graph(self, qualified_class_name: str, method_signature: str | None = None) -> List[Tuple[str, str]]:
         """Return call graph edges reachable from a class or method.
 
         Performs a depth-first traversal of the call graph starting from
         the specified class's methods (or a specific method).
 
         Args:
             qualified_class_name: The fully qualified class name to start from.
             method_signature: Optional specific method to start from. If
                 ``None``, traversal starts from all methods in the class.
 
@@ -2005,14 +2003,11 @@ class PyCodeanalyzer(PythonAnalysisBackend):
         """Return all docstrings in the project grouped by file.
 
         Filters comments to include only those marked as docstrings
         (comments at the beginning of modules, classes, or functions).
 
         Returns:
             A dictionary mapping file paths to lists of
             :class:`~cldk.models.python.PyComment` objects where
             ``is_docstring`` is ``True``.
         """
-        return {
-            fp: [c for c in module.comments if c.is_docstring]
-            for fp, module in self.application.symbol_table.items()
-        }
+        return {fp: [c for c in module.comments if c.is_docstring] for fp, module in self.application.symbol_table.items()}
diff --git a/cldk/analysis/python/neo4j/neo4j_backend.py b/cldk/analysis/python/neo4j/neo4j_backend.py
index 75ac0fd..12bbbda 100644
--- a/cldk/analysis/python/neo4j/neo4j_backend.py
+++ b/cldk/analysis/python/neo4j/neo4j_backend.py
@@ -90,28 +90,43 @@ Everything else round-trips identically to ``PyCodeanalyzer``.
 from __future__ import annotations
 
 import logging
 from collections import defaultdict
 from contextlib import contextmanager
 from functools import cached_property
 from typing import Any, Callable, Dict, FrozenSet, List, Mapping, Sequence, Tuple
 
 import networkx as nx
 from codeanalyzer.schema import model_dump_json
-from codeanalyzer.schema.ids import application_id, module_id
+from codeanalyzer.schema.ids import module_id
 from codeanalyzer.schema.py_schema import PyEntrypointReport
 
+from cldk.analysis.commons.keys import module_scope
+from cldk.analysis.commons.identity import resolve_identity, validate_identity
 from cldk.analysis.commons.backend import semver as _semver
 from cldk.analysis.commons.graphs import path_order, sdg_path_query, sdg_taint_query
 from cldk.analysis.commons.keys import module_key_of
 from cldk.analysis.commons.resolve import CallableCandidate, body_node_kind, resolve_callable_signature, resolve_value_name, resolve_within, value_candidate
-from cldk.analysis.commons.results import BodyRef, CallableRef, Diagnostic, EdgePage, EntrypointCoverage, FlowPath, FlowPaths, LocateResult, ModuleRef, PathHop, Slice, SliceNode, TypeRef
+from cldk.analysis.commons.results import (
+    BodyRef,
+    CallableRef,
+    Diagnostic,
+    EdgePage,
+    EntrypointCoverage,
+    FlowPath,
+    FlowPaths,
+    LocateResult,
+    ModuleRef,
+    Slice,
+    SliceNode,
+    TypeRef,
+)
 from cldk.analysis.python.backend import (
     CDG_ORDER,
     CFG_ORDER,
     DDG_ORDER,
     DEFAULT_DEPTH,
     DEFAULT_MAX_NODES,
     DEFAULT_MAX_PATHS,
     DEFAULT_PAGE_SIZE,
     SDG_REL_PATTERN,
     VIA,
@@ -155,21 +170,20 @@ from cldk.models.python import (
     PyDependency,
     PyExternalSymbol,
     PyModule,
     Span,
 )
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException, GraphSchemaMismatch
 
 logger = logging.getLogger(__name__)
 
 
-
 # One statement per parent->child collection, each fetching that whole collection for the *entire*
 # application in a single round trip and returning the parent's key as ``pk``. These are the bulk
 # twins of the per-parent statements inlined in ``PyNeo4jBackend._callable_full`` / ``_class_full``
 # / ``_module_full``, and reproduce those statements' row shapes exactly so either source can feed
 # the same reconstruction code (see ``PyNeo4jBackend._children``).
 #
 # Scoping: the module-level buckets key on ``m.file_key IN $mods`` plus the application prefix on
 # the module's id; the signature-keyed buckets on the parent's id prefix -- the application's when
 # the whole application is read, the per-module prefixes when a scoped accessor narrows the fetch
 # (``$prefixes``, see ``PyNeo4jBackend._module_prefixes``). Both confine the result to this
@@ -294,55 +308,57 @@ class PyNeo4jBackend(PythonAnalysisBackend):
     #: begin with -- the wrong kind of "absence is never null".
     _REQUIRED_RELATIONSHIP_TYPES: frozenset[str] = frozenset({"PY_HAS_MODULE", "PY_HAS_METHOD", "PY_HAS_BODY_NODE", "PY_CALLS"})
 
     def __init__(
         self,
         neo4j_uri: str,
         neo4j_username: str | None = None,
         neo4j_password: str | None = None,
         neo4j_database: str | None = None,
         application_name: str | None = None,
+        namespace: str | None = None,
+        source_root=None,
     ) -> None:
         try:
             from neo4j import GraphDatabase
         except ModuleNotFoundError as e:  # pragma: no cover - import guard
-            raise CodeanalyzerExecutionException(
-                "The Neo4j backend requires the 'neo4j' driver. Install it with "
-                "`pip install neo4j` (or `pip install cldk[neo4j]`)."
-            ) from e
+            raise CodeanalyzerExecutionException("The Neo4j backend requires the 'neo4j' driver. Install it with " "`pip install neo4j` (or `pip install cldk[neo4j]`).") from e
         driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_username, neo4j_password))
-        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database)
+        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database, namespace=namespace, source_root=source_root)
 
     @classmethod
-    def _from_driver(cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None) -> "PyNeo4jBackend":
+    def _from_driver(
+        cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None, namespace: str | None = None, source_root=None
+    ) -> "PyNeo4jBackend":
         """Construct directly from an already-built driver — exists for tests injecting a fake driver."""
         self = cls.__new__(cls)
-        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database)
+        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database, namespace=namespace, source_root=source_root)
         return self
 
-    def _init_with_driver(self, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None) -> None:
-        if not application_name:
-            raise CodeanalyzerExecutionException("application_name is required to scope queries to an application.")
-        self.application_name = application_name
+    def _init_with_driver(self, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None, namespace: str | None = None, source_root=None) -> None:
+        self.identity = resolve_identity(application_name, namespace)
+        self.application_name = self.identity.application_name
+        self.source_root = source_root
         self._database = neo4j_database
         self._driver = driver
         # One long-lived read session reused across queries (see _run). Reconstruction is an N+1
         # fan-out, so reopening a session per query added real per-call overhead. Created lazily.
         self._session_obj: Any | None = None
 
         # The attached server's version, filled in by _probe_schema; None means "not readable",
         # which blocks nothing (see _read_server_version).
         self._server_version: Tuple[int, ...] | None = None
 
         # Fail fast if the attached graph doesn't speak this backend's vocabulary — one round
         # trip, run once per connection, before any query can silently come back empty.
         self._probe_schema()
+        self._probe_identity()
 
         # The application's module file_keys, used to scope every query to this app.
         self._modules: List[str] = self._load_module_keys()
         # Whether this application's graph carries any per-callsite resolution data at all --
         # probed once here, same pattern as _probe_schema (see _probe_resolution_edges).
         self._has_resolution_edges: bool = self._probe_resolution_edges()
         # Lazily-built call graph cache (mirrors PyCodeanalyzer.call_graph).
         self._call_graph: nx.DiGraph | None = None
 
     # The Cypher generation the bounded call graph needs. A quantified path pattern —
@@ -353,20 +369,24 @@ class PyNeo4jBackend(PythonAnalysisBackend):
 
     #: The oldest codeanalyzer-python whose graph this backend serves. **1.5.0 exactly**, not
     #: "1.4.0 or newer": 1.5.0 moved the application to the outermost segment of the ``can://``
     #: grammar every statement here scopes on, and 1.4.1 -- which is in the wild -- emits the old
     #: ``can://python/<app>/…`` one. A 1.4.1 graph carries every relationship type
     #: :meth:`_probe_schema` looks for and the ``:PySymbol(id)`` index the point lookups seek, so
     #: it attaches cleanly and then answers every scoped statement with zero rows. Refusing it by
     #: version is the only thing between a caller and that silent empty.
     _ANALYZER_FLOOR = (1, 5, 0)
 
+    def _probe_identity(self) -> None:
+        rows = self._run("MATCH (a:PyApplication {id: $app_id}) RETURN properties(a) AS identity", app_id=self._application_id)
+        validate_identity(rows[0].get("identity", {}) if rows else {}, self.identity, envelope=False)
+
     def _probe_schema(self) -> None:
         """Verify the connected graph's vocabulary once, at connection time, and record the
         server's version while the connection is already open.
 
         A graph built by a different ``codeanalyzer-python`` generation (or an empty/asset-only
         database) answers every one of this backend's Cypher queries with zero rows — no error,
         nothing to distinguish it from "this codebase has no callables". This runs
         ``CALL db.relationshipTypes()`` (one round trip, read-only) and compares the result
         against :attr:`_REQUIRED_RELATIONSHIP_TYPES`, raising :class:`GraphSchemaMismatch` if any
         are absent.
@@ -384,21 +404,25 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         # The analyzer generation that emitted *this application*, from the property it stamps on
         # its :PyApplication node. Below the floor the id grammar the scoping relies on does not
         # exist and every statement would come back empty; refusing here is what keeps that from
         # reading as "no callables". An absent application has no version either, and is refused
         # for the same reason.
         rows = self._run("MATCH (a:PyApplication {id: $app_id}) RETURN a.analyzer_version AS v", app_id=self._application_id)
         raw = rows[0].get("v") if rows else None
         version = _semver(raw)
         floor = ".".join(map(str, self._ANALYZER_FLOOR))
         if version is None or version < self._ANALYZER_FLOOR:
-            what = f"was emitted by codeanalyzer-python {raw}" if version else (f"reports analyzer_version {raw!r}" if raw else "carries no analyzer_version (no :PyApplication with that id, or one emitted before the property existed)")
+            what = (
+                f"was emitted by codeanalyzer-python {raw}"
+                if version
+                else (f"reports analyzer_version {raw!r}" if raw else "carries no analyzer_version (no :PyApplication with that id, or one emitted before the property existed)")
+            )
             raise GraphSchemaMismatch(
                 expected=set(self._REQUIRED_RELATIONSHIP_TYPES),
                 found=found,
                 missing=set(),
                 message=f"The graph for application {self.application_name!r} {what}; this backend needs a graph emitted by codeanalyzer-python {floor} or newer.",
             )
         self._analyzer_version = version
 
     def _read_server_version(self) -> Tuple[int, ...] | None:
         """The attached server's version as an int tuple, or ``None`` when it cannot be read.
@@ -470,23 +494,23 @@ class PyNeo4jBackend(PythonAnalysisBackend):
     #: (``get_symbol_table(paths=...)``, ``get_all_classes(module=...)``) narrows it, so asking for
     #: one module does not prefetch the application's other 77,000 call sites to answer.
     _prefetch_scope: List[str] | None = None
 
     #: ``_prefetch_scope`` as id prefixes -- what the seven signature-keyed bulk statements scope on
     #: (see :meth:`_module_prefixes`). Set alongside it by :meth:`_bulk`.
     _prefetch_prefixes: List[str] | None = None
 
     @property
     def _application_id(self) -> str:
-        """``can://<app>`` -- the ``:PyApplication`` root's own merge key since 1.5.0 (it used to
+        """``can://<namespace>/<app>`` -- the ``:PyApplication`` root's own merge key since 1.5.0 (it used to
         merge on ``name``, which carries no uniqueness constraint any more)."""
-        return application_id(self.application_name)
+        return self.identity.application_id
 
     @property
     def _scope_prefix(self) -> str:
         """The application scope every statement carries: ``can://<app>/``.
 
         Every node the analyzer emits for this application -- module, class, callable, body node,
         ``@external`` ghost and artifact alike -- has an id under this prefix, and nothing from any
         other application does. The trailing slash is load-bearing: without it ``odoo-slim-19``
         would also match ``odoo-slim-19-b``. Derived, not stored, so a backend built through the
         ``object.__new__`` seam the unit tests use has it too.
@@ -503,21 +527,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
     @property
     def _code_prefix(self) -> str:
         """``can://<app>/python/`` -- what a *declared* node's id carries before its file key.
 
         The one place the language segment matters. :meth:`_module_key` strips this to recover the
         repo-relative module key, so it cannot use :attr:`_scope_prefix`: that would leave
         ``python/odoo/tools/mail.py`` to match against a key set spelling ``odoo/tools/mail.py``,
         and every row would raise. Built from the analyzer's own :func:`module_id` (with an empty
         file key) so the segment is never spelled twice.
         """
-        return module_id(self.application_name, "")
+        return module_id(self.application_name, "", self.identity.namespace)
 
     #: The codeanalyzer-python generation that emitted this application, set by
     #: :meth:`_probe_schema` (which refuses anything below :attr:`_ANALYZER_FLOOR`). The class-level
     #: ``None`` is for the ``object.__new__`` seam the unit tests build backends through.
     _analyzer_version: Tuple[int, ...] | None = None
 
     @cached_property
     def _module_set(self) -> FrozenSet[str]:
         """:attr:`_modules` as a set -- the membership side of :func:`~cldk.analysis.commons.keys.module_key_of`.
         The list stays the Cypher parameter (the driver does not pack a set); this is the view every
@@ -554,21 +578,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         """A projected callable row (``_OVERVIEW_PROJECTION``'s shape) with its ``path`` derived."""
         return R.overview({**row, "path": self._module_key(row["id"])})
 
     def _module_prefixes(self, keys: Sequence[str] | None) -> List[str]:
         """Per-module id prefixes for **narrowing** a bulk fetch to a subset of the application's
         modules (``get_symbol_table(paths=...)``, ``get_all_classes(module=...)``); ``None`` is the
         whole application, i.e. the one prefix :attr:`_scope_prefix`. Scope answers "which
         application", narrowing "which of its modules" -- a single application prefix cannot
         express the second, and a list of 1,626 module prefixes is a measurably slower way to
         express the first."""
-        return [self._scope_prefix] if keys is None else [module_id(self.application_name, k) + "/" for k in keys]
+        return [self._scope_prefix] if keys is None else [self._module_ids[k] + "/" for k in keys]
 
     def close(self) -> None:
         """Close the reused session (if any) and the underlying Neo4j driver."""
         self._close_session()
         self._driver.close()
 
     def _close_session(self) -> None:
         if self._session_obj is not None:
             try:
                 self._session_obj.close()
@@ -596,24 +620,25 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         """
         try:
             return [record.data() for record in self._session().run(query, **params)]
         except Exception:
             self._close_session()
             raise
 
     def _load_module_keys(self) -> List[str]:
         """The application's module ``file_key``s — the scope key for every other query."""
         rows = self._run(
-            "MATCH (:PyApplication {id: $app_id})-[:PY_HAS_MODULE]->(m:PyModule) RETURN m.file_key AS k",
+            "MATCH (:PyApplication {id: $app_id})-[:PY_HAS_MODULE]->(m:PyModule) RETURN m.file_key AS k, m.id AS id",
             app_id=self._application_id,
         )
-        return [r["k"] for r in rows]
+        self._module_ids = {r["k"]: r["id"] for r in rows}
+        return list(self._module_ids)
 
     # =====================================================================================
     # Reconstruction helpers — fetch a node's children over Cypher, then assemble via R.
     #
     # Rebuilding a module walks module → class → method → nested-anything, and each child
     # collection below used to cost one round trip **per parent node**: 73,669 of them to rebuild
     # a 1,626-module application (45.3 per module at ~4.9 ms each, ~363 s wall clock) — a textbook
     # N+1 against a database answering every individual query in five milliseconds. Inside
     # :meth:`_bulk` each collection is instead fetched **once for the whole application** and
     # served from a by-parent index (:data:`_BULK_CHILD_QUERIES`), so a bulk accessor pays one
@@ -942,49 +967,55 @@ class PyNeo4jBackend(PythonAnalysisBackend):
             "OPTIONAL MATCH (s)-[r:PY_CALLS]->(t) WHERE t IN ns AND s:PyCallable AND s.id STARTS WITH $prefix "
             "RETURN coalesce(s.signature, s.id) AS src, coalesce(t.signature, t.id) AS tgt, properties(r) AS p",
             roots=list(roots),
             prefix=self._scope_prefix,
         )
 
     # =====================================================================================
     # PythonAnalysisBackend — application / whole-program
     # =====================================================================================
     def get_application_view(self) -> PyApplication:
-        return PyApplication(symbol_table=self.get_symbol_table(), call_graph=self._call_edges())
+        return PyApplication(
+            id=self.identity.application_id,
+            identity_version=2,
+            application_name=self.identity.application_name,
+            identity_namespace=self.identity.namespace,
+            symbol_table=self.get_symbol_table(),
+            call_graph=self._call_edges(),
+        )
 
     def get_symbol_table(self, *, paths: Sequence[str] | None = None) -> Dict[str, PyModule]:
         # ``paths`` narrows in Cypher (the WHERE below) *and* narrows the prefetch scope, which is
         # where the saving actually is: without the second the eleven bulk statements would still
         # drag the whole application's children back to describe one module.
         keys = self._resolve_paths(paths)
         result: Dict[str, PyModule] = {}
         with self._bulk(keys):  # every module's children in eleven queries, not 45 per module
             for r in self._run(
-                "MATCH (:PyApplication {id: $app_id})-[:PY_HAS_MODULE]->(m:PyModule) "
-                "WHERE $paths IS NULL OR m.file_key IN $paths RETURN properties(m) AS p",
+                "MATCH (:PyApplication {id: $app_id})-[:PY_HAS_MODULE]->(m:PyModule) " "WHERE $paths IS NULL OR m.file_key IN $paths RETURN properties(m) AS p",
                 app_id=self._application_id,
                 paths=keys,
             ):
                 mod = self._module_full(r["p"])
                 result[mod.file_path] = mod  # symbol_table keyed by file_path (== file_key)
         return result
 
     def _resolve_paths(self, paths: Sequence[str] | None, kind: str = "paths") -> List[str] | None:
         """Requested module paths as graph ``file_key``s — ``None`` passes through as "everything".
 
         Delegates to :func:`~cldk.analysis.python.backend.scope_paths`, which is also what the
         local backend calls, so the lenient resolution (an absolute path or one with native
         separators finds its module) and the strictness (a path naming no module raises
         :class:`~cldk.utils.exceptions.SelectorNotInGraph` rather than quietly selecting no rows)
         are the same on both.
         """
-        return scope_paths(paths, self._modules, kind)
+        return scope_paths(paths, self._modules, kind, **module_scope(self))
 
     def get_modules(self) -> List[PyModule]:
         return list(self.get_symbol_table().values())
 
     def get_python_module(self, file_path: str) -> PyModule | None:
         rows = self._run(
             "MATCH (:PyApplication {id: $app_id})-[:PY_HAS_MODULE]->(m:PyModule {file_key: $fk}) RETURN properties(m) AS p LIMIT 1",
             app_id=self._application_id,
             fk=str(file_path),
         )
@@ -1160,22 +1191,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         cls = self.get_class(qualified_class_name)
         return dict(cls.callables) if cls else {}
 
     def _get_module_functions(self, module_name: str) -> Dict[str, PyCallable]:
         """Fetch a module's top-level functions by ``module_name`` (not ``file_key``) — the scope
         key ``get_method`` accepts for module-level lookups, mirroring
         ``get_all_methods_in_application``'s module outer key. A single scoped query, so it stays
         as cheap as the class path instead of paying the whole-symbol-table fan-out.
         """
         rows = self._run(
-            "MATCH (m:PyModule {module_name: $name})-[:PY_DECLARES]->(f:PyCallable) "
-            "WHERE m.file_key IN $mods AND m.id STARTS WITH $prefix RETURN properties(f) AS p",
+            "MATCH (m:PyModule {module_name: $name})-[:PY_DECLARES]->(f:PyCallable) " "WHERE m.file_key IN $mods AND m.id STARTS WITH $prefix RETURN properties(f) AS p",
             name=module_name,
             mods=self._modules,
             prefix=self._scope_prefix,
         )
         return {fn.name: fn for fn in (self._callable_full(r["p"]) for r in rows)}
 
     def get_method(self, qualified_class_name: str, qualified_method_name: str) -> PyCallable | None:
         """Return a specific method or module-level function by scope and name (see
         :meth:`PythonAnalysisBackend.get_method`).
 
@@ -1234,22 +1264,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
 
     def get_callables_overview(self) -> List[PyCallableOverview]:
         rows = self._run(
             "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix " + self._OVERVIEW_PROJECTION,
             prefix=self._scope_prefix,
         )
         return [self._overview(r) for r in rows]
 
     def get_method_bodies(self, signatures: List[str]) -> Dict[str, str]:
         rows = self._run(
-            "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix AND c.signature IN $sigs AND c.code IS NOT NULL "
-            "RETURN c.signature AS signature, c.code AS code",
+            "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix AND c.signature IN $sigs AND c.code IS NOT NULL " "RETURN c.signature AS signature, c.code AS code",
             prefix=self._scope_prefix,
             sigs=list(signatures),
         )
         return {r["signature"]: r["code"] for r in rows}
 
     def get_source(self, node_id: str) -> str:
         """Return the source text named by ``node_id`` (see
         :meth:`PythonAnalysisBackend.get_source`).
 
         Only a callable-granularity ``node_id`` (no ``"@"``) is answerable here: ``:PyCallable.code``
@@ -1263,22 +1292,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         """
         sig, sep, _ = node_id.partition("@")
         if sep:
             raise NotImplementedError(
                 f"get_source({node_id!r}): the attached graph carries no source text below callable "
                 "granularity -- :PyBodyNode has a line span and no code/text property, and :PyModule "
                 "has no source to slice one out of. Only the local codeanalyzer backend can answer "
                 "for a statement or call site."
             )
         rows = self._run(
-            "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix AND (c.signature = $sig OR c.id = $sig) AND c.code IS NOT NULL "
-            "RETURN c.code AS code",
+            "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix AND (c.signature = $sig OR c.id = $sig) AND c.code IS NOT NULL " "RETURN c.code AS code",
             prefix=self._scope_prefix,
             sig=sig,
         )
         if not rows:
             raise KeyError(f"no callable with signature {sig!r} (or it has no code)")
         return rows[0]["code"]
 
     # -----[ addressing ]-----
     #: ``:PySymbol`` is named so the prefix seeks its unique ``id`` range index (see the note above
     #: ``_LOCATE_QUERY``): 19.2 -> 15.3 ms on the 1.4.1 graph, 17.4 -> 17.9 ms on 1.4.0 (a wash).
@@ -1558,21 +1586,23 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         "RETURN size(found) AS total, found[0..$cap] AS page"
     )
 
     def backward_cone(self, sinks: Sequence[str], *, depth: int | None = DEFAULT_DEPTH, max_nodes: int = DEFAULT_MAX_NODES) -> Slice:
         """Everything that can reach these sinks (see :meth:`PythonAnalysisBackend.backward_cone`)."""
         check_depth(depth)
         check_max_nodes(max_nodes)
         self._require_quantified_paths("backward_cone")
         roots = cone_sinks(self.resolve_callable, sinks)
         row = self._run(self._CONE.format(depth="" if depth is None else depth), sigs=[r.callable for r in roots], cap=max_nodes, prefix=self._scope_prefix)[0]
-        nodes = [SliceNode(file=self._module_key(n["ref"]), line=n["line"], callable=n["callable"], kind="callable", name=n["name"], source=None, ref=n["ref"]) for n in row["page"]]
+        nodes = [
+            SliceNode(file=self._module_key(n["ref"]), line=n["line"], callable=n["callable"], kind="callable", name=n["name"], source=None, ref=n["ref"]) for n in row["page"]
+        ]
         return Slice(nodes=nodes, roots=roots, resolved=slice_resolved(roots), total=row["total"])
 
     #: ``t`` may be a ``:PyExternal`` ghost, which carries ``module``/``name``/``id`` and no
     #: ``signature`` or ``start_line`` -- so the projection names each property
     #: explicitly and :func:`_call_neighbour` decides what a row means from whether ``signature``
     #: came back. ``(s:PyCallable)`` pins the *caller* side by label -- a ghost's id sits under
     #: the same prefix -- which is how a call originating at a ghost stays out of ``callers_of``.
     _CALLERS = "MATCH (s:PyCallable)-[:PY_CALLS]->(t:PyCallable {signature: $sig}) WHERE s.id STARTS WITH $prefix RETURN s.signature AS signature, s.name AS name, s.id AS ref, s.start_line AS line, s.module AS module"
     _CALLEES = "MATCH (s:PyCallable {signature: $sig})-[:PY_CALLS]->(t:PyCallable|PyExternal) WHERE s.id STARTS WITH $prefix RETURN t.signature AS signature, t.name AS name, t.id AS ref, t.start_line AS line, t.module AS module"
 
@@ -1817,22 +1847,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
             # A callable answers to both of its names, exactly as ``get_source`` accepts either --
             # a ``SliceNode.ref`` is the ``can://`` id, but a caller holding a signature must not
             # get "names nothing" for a callable that plainly exists.
             for name in (row["id"], row["sig"]):
                 if name in wanted:
                     found[name] = row["code"]
         return found
 
     def get_decorated_callables(self, markers: List[str]) -> List[PyCallableOverview]:
         rows = self._run(
-            "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix "
-            "AND any(d IN c.decorators WHERE d IN $markers) " + self._OVERVIEW_PROJECTION,
+            "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix " "AND any(d IN c.decorators WHERE d IN $markers) " + self._OVERVIEW_PROJECTION,
             prefix=self._scope_prefix,
             markers=list(markers),
         )
         return [self._overview(r) for r in rows]
 
     def get_entrypoints(self) -> List[PyCallableOverview]:
         rows = self._run(
             "MATCH (c:PyCallable) WHERE c.id STARTS WITH $prefix AND c.is_entrypoint = true " + self._OVERVIEW_PROJECTION,
             prefix=self._scope_prefix,
         )
@@ -1911,21 +1940,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
             sites = out.setdefault(r["owner"], [])
             if r["p"] is not None:
                 sites.append(R.callsite(r["p"], callee_signature=r["callee"]))
         return out
 
     def get_external_symbols(self) -> Dict[str, PyExternalSymbol]:
         # A ghost is owned by no module, so there is no module key to narrow on; its id embeds this
         # application's own can:// id by construction (`<app-id>/@external/<module>/<name>`), and
         # that prefix is the whole scope -- a second application in the same database mints a
         # disjoint one. (This was the one prefix-scoped statement before leg 1.6 made it the rule.)
-        prefix = f"{application_id(self.application_name)}/@external/"
+        prefix = f"{self.identity.application_id}/@external/"
         rows = self._run(
             "MATCH (e:PyExternal) WHERE e.id STARTS WITH $prefix RETURN properties(e) AS p",
             prefix=prefix,
         )
         return {r["p"]["id"]: R.external_symbol(r["p"]) for r in rows}
 
     # =====================================================================================
     # PythonAnalysisBackend — repository artifacts (Artifact/ConfigKey/Package, unprefixed —
     # see cldk/analysis/commons/backend.py's module docstring)
     # =====================================================================================
@@ -1956,22 +1985,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         query = (
             "MATCH (:PyApplication {id: $app_id})-[:HAS_ARTIFACT]->(a:Artifact)-[r:DECLARES_DEPENDENCY]->(p:Package)"
             + where
             + " RETURN properties(r) AS rel, p.name AS name, p.ecosystem AS ecosystem, a.id AS declared_in"
         )
         return [R.dependency(r["rel"], name=r["name"], ecosystem=r["ecosystem"], declared_in=r["declared_in"]) for r in self._run(query, **params)]
 
     def get_config_keys(self) -> Dict[str, PyConfigKey]:
         result: Dict[str, PyConfigKey] = {}
         for r in self._run(
-            "MATCH (:PyApplication {id: $app_id})-[:HAS_ARTIFACT]->(:Artifact)-[:DEFINES_CONFIG]->(ck:ConfigKey) "
-            "RETURN properties(ck) AS p",
+            "MATCH (:PyApplication {id: $app_id})-[:HAS_ARTIFACT]->(:Artifact)-[:DEFINES_CONFIG]->(ck:ConfigKey) " "RETURN properties(ck) AS p",
             app_id=self._application_id,
         ):
             ck = R.config_key(r["p"])
             result[ck.id] = ck
         return result
 
     def get_config_uses(self, key: str | None = None) -> List[PyConfigUseEdge]:
         # PY_USES_CONFIG (the one prefixed edge in this layer, per the leg-1 brief) connects
         # (:PyBodyNode)-->(:ConfigKey) directly, so its endpoints ARE src/dst -- no reconstruction
         # helper needed, unlike artifact()/dependency()/config_key() above. Scoped like every other
@@ -1995,22 +2023,21 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         #     with key/reason/prov as edge properties, no site. `site` comes back "" here.
         # (2) the edge's own discriminant is `_k=(key, reason)` (per project.py's comment: "does
         #     not per-site discriminate the non-literal bucket"), so several distinct call sites
         #     reading the same (callee, key, reason) collapse into ONE edge under MERGE -- a count
         #     mismatch against the local backend's one-entry-per-occurrence list is expected, not a
         #     bug. Presence/absence still agrees: any unresolved read for a (callee, key, reason)
         #     triple guarantees at least one edge, so "no rows" here still means "no unresolved
         #     reads," never a false negative -- unlike finding 1's entrypoint_report, which the
         #     graph doesn't carry at all.
         rows = self._run(
-            "MATCH (:PyApplication {id: $app_id})-[u:PY_READS_CONFIG_UNRESOLVED]->(ghost:PyExternal) "
-            "RETURN properties(u) AS p, ghost.id AS callee",
+            "MATCH (:PyApplication {id: $app_id})-[u:PY_READS_CONFIG_UNRESOLVED]->(ghost:PyExternal) " "RETURN properties(u) AS p, ghost.id AS callee",
             app_id=self._application_id,
         )
         return [R.unresolved_config_read(r["p"], callee=r["callee"]) for r in rows]
 
     def get_config_readers(self, key: str) -> List[PyCallableOverview]:
         # PyConfigUseEdge.src IS the reading call's :PyBodyNode.id (see get_config_uses's own
         # comment), and _project_program_graphs adds PY_HAS_BODY_NODE from a callable to every
         # PyBodyNode it creates in the same loop iteration that creates the node -- so any
         # PyBodyNode a PY_USES_CONFIG edge points at is guaranteed to already have that edge to its
         # owner. DISTINCT because one callable can read the same key at several call sites.
@@ -2218,25 +2245,26 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         """Resolve many positions in **one** Cypher round trip (see
         :meth:`PythonAnalysisBackend.locate_many`) — the position list travels as a single
         parameter via ``UNWIND``, never a loop over :meth:`locate`. Results come back in input
         order regardless of the order Neo4j returns rows in."""
         positions = list(positions)
         if not positions:
             return []
         # Whatever the caller's scanner printed ("./src/app.py", an absolute path) is normalised to
         # the graph's file_key before it becomes a Cypher parameter — an unnormalised path would
         # match no :PyModule and read back as file_not_in_graph.
-        keys = [resolve_module_key(path, self._modules) for path, _ in positions]
+        keys = [resolve_module_key(path, self._modules, **module_scope(self)) for path, _ in positions]
         # ``module_prefix`` is the exact inverse of ``_module_key``: ``module_id(app, key) + "/"``
         # selects the module's own callables and nothing under a longer key sharing the spelling.
         rows = self._run(
             self._LOCATE_QUERY,
             app_id=self._application_id,
             positions=[
-                {"idx": i, "path": key, "module_prefix": module_id(self.application_name, key) + "/", "line": line}
+                {"idx": i, "path": key, "module_prefix": self._module_ids[key] + "/", "line": line}
                 for i, (key, (_, line)) in enumerate(zip(keys, positions))
+                if key in self._module_ids
             ],
         )
         by_idx: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
         for r in rows:
             by_idx[r["idx"]].append(r)
         return [self._locate_result(key, line, by_idx.get(i, [])) for i, (key, (_, line)) in enumerate(zip(keys, positions))]
diff --git a/cldk/analysis/python/python_analysis.py b/cldk/analysis/python/python_analysis.py
index 834a09d..e46b1c7 100644
--- a/cldk/analysis/python/python_analysis.py
+++ b/cldk/analysis/python/python_analysis.py
@@ -45,20 +45,21 @@ See Also:
 """
 
 from __future__ import annotations
 
 from pathlib import Path
 from typing import Dict, List, Sequence, Tuple
 
 import networkx as nx
 from tree_sitter import Tree
 
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis.commons.backend_config import Neo4jConnectionConfig, PyBackend, PyCodeAnalyzerConfig, cache_subdir
 from cldk.analysis.commons.results import EdgePage, EntrypointCoverage, FlowPaths, LocateResult, Slice, SliceNode, TaintResult
 from cldk.analysis.commons.treesitter import TreesitterPython
 from cldk.analysis.python.backend import DEFAULT_DEPTH, DEFAULT_MAX_NODES, DEFAULT_MAX_PATHS, DEFAULT_PAGE_SIZE, PythonAnalysisBackend
 from cldk.analysis.python.codeanalyzer import PyCodeanalyzer
 from cldk.analysis.python.neo4j import PyNeo4jBackend
 from cldk.models.python import (
     CdgEdge,
     CfgEdge,
     DdgEdge,
@@ -166,38 +167,43 @@ class PythonAnalysis:
         self.backend_config: PyBackend = backend if backend is not None else PyCodeAnalyzerConfig()
         # With a Neo4j config the graph is read out of band, so project_dir is optional there;
         # the in-memory backend still requires it (source_code mode is not supported for Python).
         if project_dir is None and not isinstance(self.backend_config, Neo4jConnectionConfig):
             raise ValueError("project_dir is required; source_code mode is not supported for Python.")
         self.project_dir = project_dir
         self.analysis_level = analysis_level
         self.eager_analysis = eager_analysis
         self.target_files = target_files
         self.treesitter_python: TreesitterPython = TreesitterPython()
+        self.identity = resolve_identity(self.backend_config.application_name, self.backend_config.namespace, project_root=Path(project_dir) if project_dir is not None else None)
         self.backend: PythonAnalysisBackend
         if isinstance(self.backend_config, Neo4jConnectionConfig):
             # Read-only: the graph is populated out of band; the SDK only polls it.
             cfg = self.backend_config
-            application_name = cfg.application_name or (Path(project_dir).name if project_dir else None)
+            application_name = self.identity.application_name
             self.backend = PyNeo4jBackend(
                 neo4j_uri=cfg.uri,
                 neo4j_username=cfg.username,
                 neo4j_password=cfg.password,
                 neo4j_database=cfg.database,
                 application_name=application_name,
+                namespace=self.identity.namespace,
+                source_root=project_dir,
             )
         else:
             cfg = self.backend_config
-            cache_path = cache_subdir(cfg.cache_dir, project_dir, "python")
+            cache_path = cache_subdir(cfg.cache_dir, project_dir, "python", identity=self.identity)
             if cache_path is not None:
                 cache_path.mkdir(parents=True, exist_ok=True)
             self.backend = PyCodeanalyzer(
+                application_name=self.identity.application_name,
+                namespace=self.identity.namespace,
                 project_dir=project_dir,
                 analysis_level=analysis_level,
                 analysis_json_path=None,
                 eager_analysis=eager_analysis,
                 cache_dir=cache_path,
                 target_files=target_files,
                 use_ray=getattr(cfg, "use_ray", False),
             )
 
     # -----[ treesitter passthrough ]-----
@@ -377,23 +383,21 @@ class PythonAnalysis:
 
         Returns:
             A dictionary mapping file paths (strings) to lists of import
             objects. Each import object contains information about the
             imported module or symbol, including whether it's an absolute
             or relative import.
 
         See Also:
             :meth:`get_python_module`: For detailed module information.
         """
-        return {
-            fp: list(m.imports) for fp, m in self.backend.get_symbol_table().items()
-        }
+        return {fp: list(m.imports) for fp, m in self.backend.get_symbol_table().items()}
 
     # -----[ call graph ]-----
     def get_call_graph(self, *, roots: Sequence[str] | None = None, depth: int | None = None) -> nx.DiGraph:
         """Return the project call graph as a NetworkX directed graph.
 
         Constructs and returns a directed graph representing method/function
         call relationships across the entire project. Each node represents
         a callable (function or method), and each edge represents a call
         from one callable to another.
 
@@ -442,23 +446,21 @@ class PythonAnalysis:
 
         Returns:
             A JSON-formatted string containing the complete analysis data,
             including modules, classes, methods, and call relationships.
 
         See Also:
             :meth:`get_call_graph`: For the graph object directly.
         """
         return self.backend.get_call_graph_json()
 
-    def get_callers(
-        self, target_class_name: str, target_method_declaration: str
-    ) -> Dict:
+    def get_callers(self, target_class_name: str, target_method_declaration: str) -> Dict:
         """Return all methods that call the specified target method.
 
         Finds and returns information about all callables (functions and
         methods) that invoke the specified target method. This is useful
         for impact analysis and understanding how a method is used.
 
         Args:
             target_class_name: The fully qualified name of the class
                 containing the target method. Use an empty string or
                 module name for module-level functions.
@@ -468,27 +470,23 @@ class PythonAnalysis:
         Returns:
             A dictionary containing information about all callers, including:
                 - Caller method signatures
                 - Call site locations (file and line)
                 - Caller class information (if applicable)
 
         See Also:
             :meth:`get_callees`: For the reverse direction (what a method calls).
             :meth:`get_call_graph`: For the complete call relationship graph.
         """
-        return self.backend.get_all_callers(
-            target_class_name, target_method_declaration
-        )
+        return self.backend.get_all_callers(target_class_name, target_method_declaration)
 
-    def get_callees(
-        self, source_class_name: str, source_method_declaration: str
-    ) -> Dict:
+    def get_callees(self, source_class_name: str, source_method_declaration: str) -> Dict:
         """Return all methods called by the specified source method.
 
         Finds and returns information about all callables (functions and
         methods) that are invoked by the specified source method. This is
         useful for understanding method dependencies and tracing execution
         paths.
 
         Args:
             source_class_name: The fully qualified name of the class
                 containing the source method. Use an empty string or
@@ -499,27 +497,23 @@ class PythonAnalysis:
         Returns:
             A dictionary containing information about all callees, including:
                 - Callee method signatures
                 - Target class information (if applicable)
                 - Call site locations within the source method
 
         See Also:
             :meth:`get_callers`: For the reverse direction (who calls a method).
             :meth:`get_call_graph`: For the complete call relationship graph.
         """
-        return self.backend.get_all_callees(
-            source_class_name, source_method_declaration
-        )
+        return self.backend.get_all_callees(source_class_name, source_method_declaration)
 
-    def get_class_call_graph(
-        self, qualified_class_name: str, method_signature: str | None = None
-    ) -> List[Tuple[str, str]]:
+    def get_class_call_graph(self, qualified_class_name: str, method_signature: str | None = None) -> List[Tuple[str, str]]:
         """Return call graph edges reachable from a class or method.
 
         Extracts a subset of the call graph containing only edges reachable
         from the specified class (and optionally a specific method within
         that class). This is useful for understanding the call structure
         of a specific component without the noise of the full project graph.
 
         Args:
             qualified_class_name: The fully qualified name of the class
                 to start traversal from (e.g., ``"mypackage.models.User"``).
@@ -747,23 +741,21 @@ class PythonAnalysis:
             the local backend an external target keeps Jedi's raw, unaddressable dotted guess
             instead of the resolved ``@external`` can-id. Use :meth:`get_callsites_for` for the
             same call sites with resolved signatures.
 
         See Also:
             :meth:`get_method`: For a single method by name.
             :meth:`get_constructors`: For ``__init__`` methods specifically.
         """
         return self.backend.get_all_methods_in_class(qualified_class_name)
 
-    def get_method(
-        self, qualified_class_name: str, qualified_method_name: str
-    ) -> PyCallable | None:
+    def get_method(self, qualified_class_name: str, qualified_method_name: str) -> PyCallable | None:
         """Return a specific method or module-level function by scope and name.
 
         Retrieves detailed information about a single method, including
         its signature, parameters, return type, decorators, and body.
 
         ``qualified_class_name`` is looked up the same way as
         :meth:`get_all_methods_in_application`'s outer keys: a class signature resolves to that
         class's methods, and a module name (``PyModule.module_name``) resolves to that module's
         top-level functions.
 
@@ -785,23 +777,21 @@ class PythonAnalysis:
             the local backend an external target keeps Jedi's raw, unaddressable dotted guess
             instead of the resolved ``@external`` can-id. Use :meth:`get_callsites_for` for the
             same call sites with resolved signatures.
 
         See Also:
             :meth:`get_methods_in_class`: For all methods of a class.
             :meth:`get_method_parameters`: For just the parameter names.
         """
         return self.backend.get_method(qualified_class_name, qualified_method_name)
 
-    def get_method_parameters(
-        self, qualified_class_name: str, qualified_method_name: str
-    ) -> List[str]:
+    def get_method_parameters(self, qualified_class_name: str, qualified_method_name: str) -> List[str]:
         """Return the parameter names for a specific method.
 
         Retrieves the list of parameter names (excluding ``self`` for
         instance methods) defined in the method signature.
 
         Args:
             qualified_class_name: The fully qualified name of the class
                 containing the method.
             qualified_method_name: The name of the method to get parameters for.
 
@@ -810,23 +800,21 @@ class PythonAnalysis:
             in the method signature. Returns an empty list if the method
             is not found or has no parameters.
 
         Note:
             This returns only parameter names, not types or default values.
             Use :meth:`get_method` for full parameter information.
 
         See Also:
             :meth:`get_method`: For complete method information.
         """
-        return self.backend.get_method_parameters(
-            qualified_class_name, qualified_method_name
-        )
+        return self.backend.get_method_parameters(qualified_class_name, qualified_method_name)
 
     def get_constructors(self, qualified_class_name: str) -> Dict[str, PyCallable]:
         """Return the constructor(s) of a specific class.
 
         Retrieves the ``__init__`` method(s) defined in the specified class.
         In Python, a class typically has at most one ``__init__`` method,
         but this returns a dictionary for API consistency.
 
         Args:
             qualified_class_name: The fully qualified name of the class
@@ -1508,23 +1496,21 @@ class PythonAnalysis:
 
         This layer (``Artifact``/``ConfigKey``/``Package`` nodes, ``HAS_ARTIFACT``/
         ``DECLARES_DEPENDENCY``/``DEFINES_CONFIG``/``LOCKS`` edges) is the one part of the graph
         every ``codeanalyzer-<lang>`` projects identically and unprefixed.
 
         See Also:
             :meth:`get_dependencies`, :meth:`get_config_keys`, :meth:`get_config_uses`.
         """
         return self.backend.get_artifacts()
 
-    def get_dependencies(
-        self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None
-    ) -> List[PyDependency]:
+    def get_dependencies(self, *, direct_only: bool = False, ecosystem: str | None = None, declared_in: str | None = None) -> List[PyDependency]:
         """Return every declared third-party dependency, one entry per declaring manifest,
         optionally filtered.
 
         All three filters default to "don't filter" — a pure widening, so existing calls are
         unaffected.
 
         Args:
             direct_only: When ``True``, excludes lockfile-only transitive pins.
             ecosystem: When given, only dependencies from this package ecosystem (e.g. ``"pypi"``).
             declared_in: When given, only dependencies declared by this artifact id (see
@@ -1636,23 +1622,21 @@ class PythonAnalysis:
             A :class:`~cldk.models.python.PyClass` object containing all
             analyzed information about the class, or ``None`` if the class
             is not found in the analyzed project.
 
         See Also:
             :meth:`get_classes`: For all classes in the project.
             :meth:`get_python_file`: To find which file contains a class.
         """
         return self.backend.get_class(qualified_class_name)
 
-    def get_classes_by_criteria(
-        self, inclusions: List[str] | None = None, exclusions: List[str] | None = None
-    ) -> Dict[str, PyClass]:
+    def get_classes_by_criteria(self, inclusions: List[str] | None = None, exclusions: List[str] | None = None) -> Dict[str, PyClass]:
         """Return classes matching inclusion/exclusion filter criteria.
 
         Filters the project's classes based on substring matching against
         their qualified names. Classes are included if their name contains
         any inclusion substring AND does not contain any exclusion substring.
 
         Args:
             inclusions: List of substrings that class names must contain to
                 be included. If ``None`` or empty, no inclusion filtering is
                 applied (effectively includes nothing unless you have at least
diff --git a/cldk/analysis/typescript/codeanalyzer/codeanalyzer.py b/cldk/analysis/typescript/codeanalyzer/codeanalyzer.py
index 27fc099..dc623f6 100644
--- a/cldk/analysis/typescript/codeanalyzer/codeanalyzer.py
+++ b/cldk/analysis/typescript/codeanalyzer/codeanalyzer.py
@@ -32,20 +32,22 @@ import shlex
 import subprocess
 import warnings
 from collections import defaultdict
 from functools import cached_property, partial
 from pathlib import Path
 from subprocess import CompletedProcess
 from typing import Dict, FrozenSet, Iterator, List, Mapping, Sequence, Set, Tuple, Union
 
 import networkx as nx
 
+from cldk.analysis.commons.keys import module_scope
+from cldk.analysis.commons.identity import resolve_identity, validate_identity, cache_matches
 from cldk.analysis.commons.bounds import (
     DEFAULT_DEPTH,
     DEFAULT_MAX_NODES,
     DEFAULT_MAX_PATHS,
     DEFAULT_PAGE_SIZE,
     check_depth,
     check_distinct_endpoints,
     check_max_nodes,
     check_max_paths,
     check_page_size,
@@ -142,43 +144,42 @@ class TSCodeanalyzer(TSAnalysisBackend):
     """
 
     def __init__(
         self,
         project_dir: Union[str, Path],
         analysis_json_path: Union[str, Path, None],
         analysis_level: str,
         eager_analysis: bool,
         target_files: List[str] | None,
         tsc_only: bool = False,
+        *,
+        application_name: str | None = None,
+        namespace: str | None = None,
     ) -> None:
+        self.identity = resolve_identity(application_name, namespace, project_root=Path(project_dir) if project_dir is not None else None)
+
         self.project_dir = project_dir
         self.analysis_json_path = analysis_json_path
         self.analysis_level = analysis_level
         self.eager_analysis = eager_analysis
         self.target_files = target_files
         if tsc_only:
             warnings.warn(
                 f"tsc_only is a no-op: codeanalyzer-typescript removed --tsc-only in {_TSC_ONLY_REMOVED_IN}; " "every call edge now carries its resolver in `prov` instead.",
                 DeprecationWarning,
                 stacklevel=4,  # warn at the CLDK.typescript(...) call, through the facade
             )
         self.analysis: TSAnalysis = self._init_codeanalyzer(analysis_level=analyzer_level(analysis_level))
+        validate_identity(self.analysis, self.identity)
         self.application: TSApplication = self.analysis.application
-        #: The ``--app-name`` the analyzer stamped into every id, read back off the application's
-        #: own ``can://<app>`` id. Spelled the same as :attr:`TSNeo4jBackend.application_name`
-        #: so a message naming the application reads identically whichever backend raised it -- and
-        #: so no message has to embed a ``can://`` id to name it (E6).
-        #:
-        #: The scheme is *stripped*, never split off: the root id is exactly ``can://<app>`` since
-        #: 1.5.1 put the application outermost, and an application legitimately named ``typescript``
-        #: makes any positional reading of the segments a coin flip.
-        self.application_name: str = self.application.id.removeprefix("can://")
+        # Preserve the raw selected name; canonical root segments may contain percent escapes.
+        self.application_name: str = self.identity.application_name
         self._call_graph: nx.DiGraph | None = None
         self._index()
 
     # -----[ binary resolution ]-----
     def _get_codeanalyzer_exec(self) -> List[str]:
         """Resolve the codeanalyzer-typescript executable command.
 
         The binary ships with the ``codeanalyzer-typescript`` PyPI dependency. ``$CODEANALYZER_TS_BIN``
         remains the only out-of-band override (e.g. a locally built binary).
         """
@@ -197,21 +198,28 @@ class TSCodeanalyzer(TSAnalysisBackend):
                 "codeanalyzer-typescript binary not found: $CODEANALYZER_TS_BIN is unset and the "
                 f"`codeanalyzer-typescript` wheel is not importable or carries no binary for this platform ({e}). "
                 "Install it with `pip install codeanalyzer-typescript`, or set $CODEANALYZER_TS_BIN."
             ) from e
 
     def _argv(self, analysis_level: int, output_dir: Path | None) -> List[str]:
         """The 1.2.0 command line: ``-i <project> --app-name <project.name> -a <1..4> [-o <dir>
         --cache-dir <dir>] --skip-tests [--eager] [-t <file>]...``. The application name is what
         the analyzer stamps into every ``can://<app>/<lang>/...`` id."""
         project = Path(self.project_dir)
-        args = self._get_codeanalyzer_exec() + ["-i", str(project), "--app-name", project.name, "-a", str(analysis_level)]
+        args = self._get_codeanalyzer_exec() + [
+            "-i",
+            str(project),
+            f"--app-name={self.identity.application_name}",
+            f"--namespace={self.identity.namespace}",
+            "-a",
+            str(analysis_level),
+        ]
         if output_dir is not None:
             args += ["-o", str(output_dir), "--cache-dir", str(output_dir)]
         args += ["--skip-tests"]
         if self.eager_analysis:
             args += ["--eager"]
         for tf in self.target_files or []:
             args += ["-t", str(tf).strip()]
         return args
 
     def _init_codeanalyzer(self, analysis_level: int) -> TSAnalysis:
@@ -222,21 +230,21 @@ class TSCodeanalyzer(TSAnalysisBackend):
             try:
                 logger.info(f"Running codeanalyzer-typescript: {' '.join(args)}")
                 console_out: CompletedProcess[str] = subprocess.run(args, capture_output=True, text=True, check=True)
                 return TSAnalysis.model_validate_json(console_out.stdout)
             except Exception as e:  # noqa: BLE001
                 raise CodeanalyzerExecutionException(str(e)) from e
 
         # Persist to an output directory and read analysis.json back.
         output_dir = Path(self.analysis_json_path)
         analysis_json_file = output_dir / "analysis.json"
-        needs_run = self.eager_analysis or not analysis_json_file.exists() or bool(self.target_files)
+        needs_run = self.eager_analysis or not analysis_json_file.exists() or not cache_matches(analysis_json_file, self.identity) or bool(self.target_files)
         if needs_run:
             args = self._argv(analysis_level, output_dir)
             try:
                 logger.info(f"Running codeanalyzer-typescript: {' '.join(args)}")
                 subprocess.run(args, capture_output=True, text=True, check=True)
                 if not analysis_json_file.exists():
                     raise CodeanalyzerExecutionException("codeanalyzer-typescript did not generate analysis.json.")
             except Exception as e:  # noqa: BLE001
                 raise CodeanalyzerExecutionException(str(e)) from e
         return TSAnalysis.model_validate_json(analysis_json_file.read_text(encoding="utf-8"))
@@ -877,21 +885,21 @@ class TSCodeanalyzer(TSAnalysisBackend):
         if not node.id:
             raise CodeanalyzerExecutionException(
                 f"body node {key!r} of {c.signature!r} carries no id: codeanalyzer-typescript {self.analysis.analyzer.version} "
                 "emitted an unaddressable body node (ids are required from 1.3.0, cants#165)"
             )
         return BodyRef(id=node.id, kind=node.kind, span=node.span, callee=node.callee)
 
     def _locate_one(self, path: str, line: int) -> LocateResult:
         # Whatever the caller's scanner printed ("./src/app.ts", an absolute path) is normalised to
         # the symbol-table key first; an unnormalised path would otherwise read as file_not_in_graph.
-        key = resolve_module_key(str(path), self.application.symbol_table.keys())
+        key = resolve_module_key(str(path), self.application.symbol_table.keys(), **module_scope(self))
         module = self.application.symbol_table.get(key)
         if module is None:
             return self._not_analysed(key, line)
         module_ref = ModuleRef(path=key)
         # Innermost callable = narrowest line span containing the position. A position between two
         # callables, or at module scope, matches none and falls through to module_scope rather than
         # snapping to a neighbour. Equal widths (an arrow inside a one-line function) tie, and the
         # tie is broken on the longer signature, deeper first -- a nested callable's signature
         # extends its owner's -- which is the rule the Neo4j backend applies to the same rows.
         found = min(
diff --git a/cldk/analysis/typescript/neo4j/neo4j_backend.py b/cldk/analysis/typescript/neo4j/neo4j_backend.py
index 1888204..9707146 100644
--- a/cldk/analysis/typescript/neo4j/neo4j_backend.py
+++ b/cldk/analysis/typescript/neo4j/neo4j_backend.py
@@ -110,20 +110,22 @@ now that a signature is no longer unique, and they cost nothing.
 
 from __future__ import annotations
 
 import logging
 from collections import defaultdict
 from functools import cached_property
 from typing import Any, Dict, FrozenSet, List, Mapping, Sequence, Set, Tuple
 
 import networkx as nx
 
+from cldk.analysis.commons.keys import module_scope
+from cldk.analysis.commons.identity import resolve_identity, validate_identity
 from cldk.analysis.commons import artifacts as shared  # the artifact layer every analyzer projects identically
 from cldk.analysis.commons.backend import semver
 from cldk.analysis.commons.bounds import (
     DEFAULT_DEPTH,
     DEFAULT_MAX_NODES,
     DEFAULT_MAX_PATHS,
     DEFAULT_PAGE_SIZE,
     EdgeOrder,
     check_depth,
     check_distinct_endpoints,
@@ -288,56 +290,74 @@ class TSNeo4jBackend(TSAnalysisBackend):
     #: ``(a) ((x)-[:R]->(y) WHERE ...){0,n} (m)``, the only way to put a predicate on *every* hop of
     #: a walk -- arrives in Neo4j 5.9. Recorded at attach (:meth:`_read_server_version`) and
     #: enforced at the calls that need it (:meth:`_require_quantified_paths`), never at attach, so
     #: an older server keeps serving every other accessor on this class.
     _QUANTIFIED_PATH_MIN_SERVER = (5, 9)
     #: Set by :meth:`_read_server_version`; ``None`` means *unknown*, which blocks nothing.
     _server_version: Tuple[int, ...] | None = None
     _call_graph: nx.DiGraph | None = None
     _module_ids: Dict[str, str] = {}
 
-    def __init__(self, neo4j_uri: str, neo4j_username: str, neo4j_password: str, neo4j_database: str | None = None, application_name: str | None = None) -> None:
+    def __init__(
+        self,
+        neo4j_uri: str,
+        neo4j_username: str,
+        neo4j_password: str,
+        neo4j_database: str | None = None,
+        application_name: str | None = None,
+        namespace: str | None = None,
+        source_root=None,
+    ) -> None:
         try:
             from neo4j import GraphDatabase
         except ModuleNotFoundError as e:  # pragma: no cover - import guard
             raise CodeanalyzerExecutionException("The Neo4j backend requires the 'neo4j' driver. Install it with `pip install neo4j` (or `pip install cldk[neo4j]`).") from e
-        self._init_with_driver(GraphDatabase.driver(neo4j_uri, auth=(neo4j_username, neo4j_password)), application_name=application_name, neo4j_database=neo4j_database)
+        self._init_with_driver(
+            GraphDatabase.driver(neo4j_uri, auth=(neo4j_username, neo4j_password)),
+            application_name=application_name,
+            neo4j_database=neo4j_database,
+            namespace=namespace,
+            source_root=source_root,
+        )
 
     @classmethod
-    def _from_driver(cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None) -> "TSNeo4jBackend":
+    def _from_driver(
+        cls, driver: Any, *, application_name: str | None = None, neo4j_database: str | None = None, namespace: str | None = None, source_root=None
+    ) -> "TSNeo4jBackend":
         """Construct from an already-built driver -- the seam tests inject a fake driver through."""
         self = cls.__new__(cls)
-        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database)
+        self._init_with_driver(driver, application_name=application_name, neo4j_database=neo4j_database, namespace=namespace, source_root=source_root)
         return self
 
-    def _init_with_driver(self, driver: Any, *, application_name: str | None, neo4j_database: str | None) -> None:
-        if not application_name:
-            raise CodeanalyzerExecutionException("application_name is required to scope queries to an application.")
-        self.application_name = application_name
+    def _init_with_driver(self, driver: Any, *, application_name: str | None, neo4j_database: str | None, namespace: str | None = None, source_root=None) -> None:
+        self.identity = resolve_identity(application_name, namespace)
+        self.application_name = self.identity.application_name
+        self.source_root = source_root
         self._database = neo4j_database
         self._driver = driver
         self._session_obj: Any | None = None
         self._probe_schema()
+        self._probe_identity()
         self._module_ids = self._load_module_keys()
         self._modules: List[str] = list(self._module_ids)
         self._has_resolution_edges = self._probe_resolution_edges()
         self._call_graph = None
 
     # -----[ scope ]-----
     @property
     def _app_id(self) -> str:
-        """``can://<app>`` -- the ``:Application`` anchor's id, and the root of every id below it."""
-        return f"can://{self.application_name}"
+        """``can://<namespace>/<app>`` -- the ``:Application`` anchor's id, and the root of every id below it."""
+        return self.identity.application_id
 
     @property
     def _scope_prefix(self) -> str:
-        """``can://<app>/`` (TS-3): one prefix covering both language namespaces, the ``@external``
+        """``can://<namespace>/<app>/`` (TS-3): one prefix covering both language namespaces, the ``@external``
         ghosts and the artifacts. The trailing slash keeps ``app`` from matching ``app-b``."""
         return f"{self._app_id}/"
 
     @property
     def _scope_params(self) -> Dict[str, str]:
         """The parameter :func:`_scoped` binds."""
         return {"p": self._scope_prefix}
 
     @property
     def _language_prefixes(self) -> List[str]:
@@ -390,20 +410,24 @@ class TSNeo4jBackend(TSAnalysisBackend):
         """Run one read statement over a reused session; drop the session on failure."""
         if self._session_obj is None:
             self._session_obj = self._driver.session(database=self._database)
         try:
             return [record.data() for record in self._session_obj.run(query, **params)]
         except Exception:
             self._session_obj = None
             raise
 
     # -----[ attach ]-----
+    def _probe_identity(self) -> None:
+        rows = self._run("MATCH (a:Application {id: $app_id}) RETURN properties(a) AS identity", app_id=self._app_id)
+        validate_identity(rows[0].get("identity", {}) if rows else {}, self.identity, envelope=False)
+
     def _probe_schema(self) -> None:
         """G5: the relationship-type fingerprint, then the analyzer generation the ``:Application``
         anchor stamps against :attr:`_ANALYZER_FLOOR`. Below the floor, absent, or unreadable is
         refused naming what was found -- a served mismatch would read as "no callables"."""
         found = {r["relationshipType"] for r in self._run("CALL db.relationshipTypes()")}
         missing = self._REQUIRED_RELATIONSHIP_TYPES - found
         if missing:
             raise GraphSchemaMismatch(expected=set(self._REQUIRED_RELATIONSHIP_TYPES), found=found, missing=missing)
         rows = self._run("OPTIONAL MATCH (a:Application {id: $app_id}) RETURN count(a) AS n, a.analyzer_version AS v", app_id=self._app_id)
         present = bool(rows and rows[0].get("n"))
@@ -616,20 +640,23 @@ class TSNeo4jBackend(TSAnalysisBackend):
           (no ``TS_PARAM_IN``/``TS_PARAM_OUT``/``TS_DDG``/``TS_SUMMARY`` statement exists on this
           class); the whole dataflow surface, this overlay with it, is leg 2.5b.
         * ``config_reads`` -- projected since 1.4.0 and reachable through
           :meth:`get_unresolved_config_reads`, but not folded into the view: the edge carries no
           ``site``, so the entries would not be the ones the in-memory view holds.
         * ``unresolved_imports`` -- ``TS_UNRESOLVED_IMPORT`` is in the projection but no accessor
           on this surface reads it, so the view does not invent one.
         """
         externals = {e.id: e for e in self.get_external_symbols().values()}
         return TSApplication(
+            application_name=self.identity.application_name,
+            identity_namespace=self.identity.namespace,
+            identity_version=2,
             id=self._app_id,
             symbol_table=self.get_symbol_table(),
             call_graph=[TSCallGraphEdge(src=r["src"], dst=r["dst"], prov=list(r["prov"] or []), weight=r["weight"] or 1) for r in self._call_rows()],
             artifacts={a.path: TSArtifact.model_validate(a.model_dump()) for a in self.get_artifacts().values()},
             dependencies=[TSDependency.model_validate(d.model_dump(exclude={"ecosystem"})) for d in self.get_dependencies()],
             config_uses=[TSConfigUse.model_validate(u.model_dump()) for u in self.get_config_uses()],
             external_symbols=externals,
             synthesized_callables=self.get_synthesized_callables(),
         )
 
@@ -1390,21 +1417,21 @@ class TSNeo4jBackend(TSAnalysisBackend):
         """Resolve many positions in **one** Cypher round trip (see
         :meth:`TSAnalysisBackend.locate_many`) -- the position list travels as a single parameter
         via ``UNWIND``, never a loop over :meth:`locate`. Results come back in input order
         regardless of the order Neo4j returns rows in."""
         positions = list(positions)
         if not positions:
             return []
         # Whatever the caller's scanner printed ("./src/app.ts", an absolute path) is normalised to
         # the graph's module key before it becomes a Cypher parameter -- an unnormalised path would
         # match no :TSModule and read back as file_not_in_graph.
-        keys = [resolve_module_key(path, self._module_ids) for path, _ in positions]
+        keys = [resolve_module_key(path, self._module_ids, **module_scope(self)) for path, _ in positions]
         # A key the application does not hold is never sent: its ``module_prefix`` would be the raw
         # path, which is not application-stamped and could seek outside this application. It has no
         # rows either way, and no rows is exactly the ``file_not_in_graph`` outcome.
         asked = [
             {"idx": i, "path": key, "module_prefix": self._module_ids[key] + "/", "line": line}
             for i, (key, (_, line)) in enumerate(zip(keys, positions))
             if key in self._module_ids
         ]
         rows = self._run(self._LOCATE_QUERY, app_id=self._app_id, callable_kinds=sorted(CALLABLE_KINDS), owner_kinds=_OWNER_KINDS, positions=asked) if asked else []
         by_idx: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
@@ -1767,23 +1794,21 @@ class TSNeo4jBackend(TSAnalysisBackend):
     #: what keeps a declaration-merged node out of the facet it is not. Needs Neo4j 5.9+.
     #: **One endpoint per hop, not two.** Consecutive repetitions of a quantified pattern bind ``x``
     #: to the previous ``y``, so predicating both ends checks every interior node twice. The walk is
     #: still scoped in full: ``a`` by the anchor, every node it reaches as some ``x``, and the last
     #: node -- which is only ever a ``y`` -- by the trailing ``WITH``. Measured on a synthetic
     #: 5,000-node/100,000-edge cyclic graph with an unreachable target, so the search must exhaust:
     #: **623.9s predicating both ends, 3.2s predicating one**, same answer. The doctrine is intact --
     #: every node on the walk carries the predicate, once rather than twice.
     _REACHES = (
         "MATCH (a:TSCallable {{signature:$a}}) WHERE " + _scoped("a") + " AND a.kind IN $callable_kinds "
-        "MATCH (a) ((x:TSCallable)-[:TS_CALLS]->(y:TSCallable) WHERE "
-        + _scoped("x")
-        + " AND x.kind IN $callable_kinds){{1,{depth}}} (m:TSCallable) "
+        "MATCH (a) ((x:TSCallable)-[:TS_CALLS]->(y:TSCallable) WHERE " + _scoped("x") + " AND x.kind IN $callable_kinds){{1,{depth}}} (m:TSCallable) "
         "WITH DISTINCT m WHERE " + _scoped("m") + " AND m.kind IN $callable_kinds AND m.signature = $b RETURN count(m) > 0 AS ok"
     )
 
     def reaches(self, src: str, dst: str, *, depth: int | None = None) -> bool:
         """Is there a call path (see :meth:`TSAnalysisBackend.reaches`)?"""
         check_depth(depth)
         self._require_quantified_paths("reaches")
         a = self.resolve_callable(src).callable
         b = self.resolve_callable(dst).callable
         query = self._REACHES.format(depth="" if depth is None else depth)
@@ -1996,24 +2021,21 @@ class TSNeo4jBackend(TSAnalysisBackend):
         """
         rows = self._run(
             self._TAINT.format(rels=SDG_REL_PATTERN, depth="" if depth is None else depth),
             srcs=[n.ref for n in srcs],
             dsts=[n.ref for n in dsts],
             cuts=cuts,
             cut_callables=cut_callables,
             cap=max_paths + 1,
             **self._scope_params,
         )
-        return [
-            (r["src"], r["dst"], flow_path([self._slice_row(n) for n in r["ns"]], [(e["via"], e["var"], e["prov"]) for e in r["rs"]], via=VIA))
-            for r in rows
-        ], {}
+        return [(r["src"], r["dst"], flow_path([self._slice_row(n) for n in r["ns"]], [(e["via"], e["var"], e["prov"]) for e in r["rs"]], via=VIA)) for r in rows], {}
 
     def _edge_vars_in(self, callable_id: str) -> FrozenSet[str]:
         """The edge variables scoped to this callable (see :meth:`TSAnalysisBackend._edge_vars_in`).
 
         ``r.var`` is absent on ``TS_CDG`` and ``TS_SUMMARY``, so the collected list carries ``None``;
         it is dropped rather than kept, because a membership test against a set holding ``None``
         would be answering a question no caller can ask -- ``resolve_sanitizers`` refuses a blank
         variable before it gets here.
         """
         rows = self._run(self._EDGE_VARS.format(rels=SDG_REL_PATTERN), callable_prefix=callable_id)
diff --git a/cldk/analysis/typescript/typescript_analysis.py b/cldk/analysis/typescript/typescript_analysis.py
index 96c16c1..77b1b01 100644
--- a/cldk/analysis/typescript/typescript_analysis.py
+++ b/cldk/analysis/typescript/typescript_analysis.py
@@ -22,20 +22,21 @@ codeanalyzer-typescript backend. Mirrors the method vocabulary of ``JavaAnalysis
 those, delegates all indexing and query work to its backend (:class:`TSCodeanalyzer`).
 """
 
 from __future__ import annotations
 
 from pathlib import Path
 from typing import Dict, List, Sequence, Set, Tuple
 
 import networkx as nx
 
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig, Neo4jConnectionConfig, TSBackend, cache_subdir
 from cldk.models.python import PyArtifact, PyConfigKey, PyConfigRead, PyConfigUseEdge, PyDependency
 from cldk.analysis.commons.bounds import DEFAULT_DEPTH, DEFAULT_MAX_NODES, DEFAULT_MAX_PATHS, DEFAULT_PAGE_SIZE
 from cldk.analysis.commons.results import EdgePage, EntrypointCoverage, FlowPaths, LocateResult, Slice, SliceNode, TaintResult
 from cldk.analysis.typescript.backend import TSAnalysisBackend
 from cldk.analysis.typescript.codeanalyzer import TSCodeanalyzer
 from cldk.analysis.typescript.neo4j import TSNeo4jBackend
 from cldk.models.typescript import (
     TSApplication,
     TSCallable,
@@ -82,37 +83,42 @@ class TypeScriptAnalysis:
         eager_analysis: bool,
         backend: TSBackend | None = None,
     ) -> None:
         self.project_dir = project_dir
         self.analysis_level = analysis_level
         self.target_files = target_files
         self.eager_analysis = eager_analysis
         # The backend is selected by the *type* of the config: Neo4jConnectionConfig picks the
         # read-only Cypher backend, CodeAnalyzerConfig (the default) the in-process analyzer.
         self.backend_config: TSBackend = backend if backend is not None else CodeAnalyzerConfig()
+        self.identity = resolve_identity(self.backend_config.application_name, self.backend_config.namespace, project_root=Path(project_dir) if project_dir is not None else None)
         self.backend: TSAnalysisBackend
         if isinstance(self.backend_config, Neo4jConnectionConfig):
             # Read-only: the graph is populated out of band; the SDK only polls it.
             cfg = self.backend_config
-            application_name = cfg.application_name or (Path(project_dir).name if project_dir else None)
+            application_name = self.identity.application_name
             self.backend = TSNeo4jBackend(
                 neo4j_uri=cfg.uri,
                 neo4j_username=cfg.username,
                 neo4j_password=cfg.password,
                 neo4j_database=cfg.database,
                 application_name=application_name,
+                namespace=self.identity.namespace,
+                source_root=project_dir,
             )
         else:
-            cache_path = cache_subdir(self.backend_config.cache_dir, project_dir, "typescript")
+            cache_path = cache_subdir(self.backend_config.cache_dir, project_dir, "typescript", identity=self.identity)
             if cache_path is not None:
                 cache_path.mkdir(parents=True, exist_ok=True)
             self.backend = TSCodeanalyzer(
+                application_name=self.identity.application_name,
+                namespace=self.identity.namespace,
                 project_dir=project_dir,
                 analysis_json_path=cache_path,
                 analysis_level=analysis_level,
                 eager_analysis=eager_analysis,
                 target_files=target_files,
                 tsc_only=getattr(self.backend_config, "tsc_only", False),
             )
         self.application: TSApplication = self.backend.get_application_view()
 
     # -----[ Tier A: lifecycle / whole-program ]-----
diff --git a/cldk/core.py b/cldk/core.py
index 6d4534e..266c11e 100644
--- a/cldk/core.py
+++ b/cldk/core.py
@@ -137,20 +137,21 @@ class CLDK:
         Args:
             project_path: Path to the Java project directory. Optional only when ``backend`` is a
                 :class:`Neo4jConnectionConfig` (the graph is read out of band over Bolt). When
                 provided, the path is validated — it must exist and be a directory — regardless of
                 backend.
             analysis_level: Analysis depth (see :class:`~cldk.analysis.AnalysisLevel`).
             target_files: Restrict analysis to these files.
             eager: Force regeneration of cached analysis.
             backend: Backend configuration. Defaults to :class:`CodeAnalyzerConfig`; pass a
                 :class:`Neo4jConnectionConfig` to use the read-only Neo4j backend.
+                Both configurations accept raw ``namespace`` and ``application_name`` selections.
 
         Raises:
             CldkInitializationException: If ``project_path`` is missing and the backend is not
                 Neo4j. (The 1.x ``source_code`` single-file mode was removed in 2.0.)
         """
         # The read-only Neo4j backend reads a graph populated out of band, so it needs no project_path.
         if project_path is None and not isinstance(backend, Neo4jConnectionConfig):
             raise CldkInitializationException("project_path must be provided.")
         return JavaAnalysis(
             project_dir=_normalize_project_path(project_path),
@@ -174,20 +175,21 @@ class CLDK:
         Args:
             project_path: Path to the Python project directory. Optional only when ``backend`` is a
                 :class:`Neo4jConnectionConfig` (the graph is populated out of band over Bolt). When
                 provided, the path is validated — it must exist and be a directory — regardless of
                 backend.
             analysis_level: Analysis depth (see :class:`~cldk.analysis.AnalysisLevel`).
             target_files: Restrict analysis to these files.
             eager: Force regeneration of cached analysis.
             backend: Backend configuration. Defaults to :class:`PyCodeAnalyzerConfig`;
                 pass a :class:`Neo4jConnectionConfig` to use the read-only Neo4j backend.
+                Set raw ``namespace`` and ``application_name`` on that configuration to select ownership.
         """
         return PythonAnalysis(
             project_dir=_normalize_project_path(project_path),
             analysis_level=analysis_level,
             target_files=target_files,
             eager_analysis=eager,
             backend=backend,
         )
 
     @staticmethod
diff --git a/cldk/models/go/models.py b/cldk/models/go/models.py
index c0f3d80..86dacde 100644
--- a/cldk/models/go/models.py
+++ b/cldk/models/go/models.py
@@ -193,21 +193,21 @@ class GoCallable(_NullSafeBase):
 # Type — one model with a ``kind`` field (struct | interface); never a class.
 # ----------------------------------------------------------------------------------------------
 
 
 class GoType(_NullSafeBase):
     """A Go ``struct`` or ``interface``. The two kinds carry the same wire shape, so this is one
     model discriminated by ``kind`` rather than a ``Union`` of subclasses. ``base_types`` are
     embedded types; ``fields`` are the struct's data fields (empty for an interface)."""
 
     id: str
-    kind: Literal["struct", "interface"]
+    kind: Literal["struct", "interface", "defined"]
     span: Optional[GoSpan] = None
     base_types: List[str] = []
     callables: Dict[str, GoCallable] = {}
     fields: Dict[str, GoField] = {}
 
 
 # ----------------------------------------------------------------------------------------------
 # Module
 # ----------------------------------------------------------------------------------------------
 
@@ -229,34 +229,38 @@ class GoModule(_NullSafeBase):
 
 # ----------------------------------------------------------------------------------------------
 # Application + envelope
 # ----------------------------------------------------------------------------------------------
 
 
 class GoApplication(_NullSafeBase):
     """The application root: the containment tree (``symbol_table``) plus the one app-scope overlay
     the analyzer emits at L2 (``call_graph``)."""
 
+    application_name: str
+    identity_namespace: str
+    identity_version: Literal[2]
     id: str
     kind: Literal["application"] = "application"
     symbol_table: Dict[str, GoModule]
     call_graph: List[GoCallGraphEdge] = []
 
 
 class GoAnalyzer(_Base):
     name: str
     version: str
 
 
 class GoAnalysis(_Base):
     """The envelope ``analysis.json`` IS."""
 
+    identity_version: Literal[2]
     schema_version: str
     language: str
     max_level: int
     k_limit: Optional[int] = None  # L3+ (absent at L1/L2)
     analyzer: GoAnalyzer
     application: GoApplication
 
 
 # Resolve the forward reference in the self-recursive callable.
 GoCallable.model_rebuild()
diff --git a/cldk/models/java/models.py b/cldk/models/java/models.py
index 35f27b1..a4382fa 100644
--- a/cldk/models/java/models.py
+++ b/cldk/models/java/models.py
@@ -904,20 +904,22 @@ class JViewDispatchUnresolved(_Base):
 class JApplication(_Base):
     """The application root. ``call_graph``/``param_in``/``param_out`` are absent below the level
     that computes them — empty here, never ``None``.
 
     That reading is exact for ``call_graph`` on both backends. ``param_in``/``param_out`` are
     **always empty off the Neo4j projection**, at every level: ``--emit neo4j`` forces L4, so the
     dataflow overlay was computed, but this leg does not project the port lattice back out (leg 3b
     does). An empty pair there is this backend's silence, not the analyzer's.
     """
 
+    application_name: str
+    identity_namespace: str
     id: str
     kind: Literal["application"] = "application"
     symbol_table: Dict[str, JCompilationUnit]
     call_graph: List[JCallGraphEdge] = []
     external_symbols: Optional[Dict[str, JExternalSymbol]] = None
     param_in: List[JParamEdge] = []
     param_out: List[JParamEdge] = []
     artifacts: Dict[str, JArtifact] = {}
     dependencies: List[JDependency] = []
     #: The three 3.1.0 overlays, and the one place in this file where ``None`` and ``[]`` are
@@ -941,20 +943,21 @@ class JApplication(_Base):
 
 
 class JAnalyzer(_Base):
     name: str
     version: str
 
 
 class JAnalysis(_Base):
     """The envelope ``analysis.json`` IS."""
 
+    identity_version: Literal[2]
     schema_version: str
     language: str
     max_level: int
     k_limit: Optional[int] = None  # not emitted by 3.0.1 at any level
     analyzer: JAnalyzer
     application: JApplication
 
 
 # ----------------------------------------------------------------------------------------------
 # Call-graph node payload built by the backends (not on the wire)
diff --git a/cldk/models/typescript/models.py b/cldk/models/typescript/models.py
index 4d29064..33144b9 100644
--- a/cldk/models/typescript/models.py
+++ b/cldk/models/typescript/models.py
@@ -727,20 +727,24 @@ class TSConfigRead(_Base):
     site: str
     callee: str
     key: Optional[str] = None
     reason: str  # non-literal | undefined-key
     prov: List[str] = []
 
 
 class TSApplication(_Base):
     """The application root: the containment tree plus the app-scope overlays."""
 
+    name: Optional[str] = None
+    application_name: str
+    identity_namespace: str
+    identity_version: Literal[2]
     id: str
     kind: Literal["application"] = "application"
     symbol_table: Dict[str, TSModule]
     call_graph: List[TSCallGraphEdge] = []
     param_in: List[TSParamEdge] = []
     param_out: List[TSParamEdge] = []
     artifacts: Dict[str, TSArtifact] = {}
     dependencies: List[TSDependency] = []
     unresolved_imports: List[TSImportBinding] = []
     config_uses: List[TSConfigUse] = []
@@ -751,20 +755,21 @@ class TSApplication(_Base):
 
 
 class TSAnalyzer(_Base):
     name: str
     version: str
 
 
 class TSAnalysis(_Base):
     """The envelope ``analysis.json`` IS."""
 
+    identity_version: Literal[2]
     schema_version: str
     language: str
     max_level: int
     k_limit: Optional[int] = None  # L3+
     analyzer: TSAnalyzer
     application: TSApplication
 
 
 # ----------------------------------------------------------------------------------------------
 # 1.x compatibility — names kept importable; the wire no longer carries these shapes
diff --git a/tests/analysis/commons/test_identity.py b/tests/analysis/commons/test_identity.py
new file mode 100644
index 0000000..ec2b3dc
--- /dev/null
+++ b/tests/analysis/commons/test_identity.py
@@ -0,0 +1,239 @@
+from pathlib import Path
+import pytest
+from cldk.analysis.commons import identity
+from cldk.analysis.commons.backend_config import CodeAnalyzerConfig, PyCodeAnalyzerConfig, TSCodeAnalyzerConfig
+from cldk.analysis.commons.keys import resolve_module_key
+
+
+def test_identity_defaults_and_raw_encoding(tmp_path, monkeypatch):
+    monkeypatch.chdir(tmp_path)
+    resolved = identity.resolve_identity(None, None, project_root=Path("."))
+    assert resolved.application_id == f"can://{tmp_path.name}/{tmp_path.name}"
+    value = identity.resolve_identity("-svc %雪", "team%")
+    assert value.application_id == "can://team%25/-svc%20%25%E9%9B%AA"
+    assert value.application_name == "-svc %雪"
+
+
+@pytest.mark.parametrize("name", ["", " ", ".", "..", "a/b", "a\\b", "x\n", "\ud800"])
+def test_invalid_identity(name):
+    with pytest.raises(ValueError):
+        identity.resolve_identity(name, None)
+    with pytest.raises(ValueError):
+        identity.resolve_identity("app", name)
+
+
+def test_missing_graph_application():
+    with pytest.raises(Exception, match="application_name"):
+        identity.resolve_identity(None, None)
+
+
+def test_config_identity_keyword_only():
+    assert PyCodeAnalyzerConfig("cache", True, namespace="team", application_name="app").use_ray
+    assert TSCodeAnalyzerConfig("cache", True, namespace="team").tsc_only
+    assert CodeAnalyzerConfig(namespace="team").application_name is None
+
+
+def test_scoped_module_resolution(tmp_path):
+    keys = ["src/server.js", "server.js"]
+    ids = {"server.js": "can://team/svc/javascript/server.js", "src/server.js": "can://team/svc/typescript/src/server.js"}
+    kwargs = dict(application_id="can://team/svc", module_ids=ids, source_root=tmp_path)
+    assert resolve_module_key(ids["server.js"], keys, **kwargs) == "server.js"
+    assert resolve_module_key(str(tmp_path / "src/server.js"), keys, **kwargs) == "src/server.js"
+    assert resolve_module_key("./src/../server.js", keys, **kwargs) == "server.js"
+    assert resolve_module_key("other/server.js", keys, **kwargs) == "other/server.js"
+    for uri in ["can://other/svc/javascript/server.js", "can://team/svc-extra/javascript/server.js", "can://team/svc/python/server.js"]:
+        with pytest.raises(ValueError):
+            resolve_module_key(uri, keys, **kwargs)
+    with pytest.raises(ValueError):
+        resolve_module_key("/unbound/server.js", keys)
+
+
+@pytest.mark.parametrize("language,cls", [("typescript", "TSCodeanalyzer"), ("java", "JCodeanalyzer"), ("go", "GoCodeanalyzer")])
+def test_argv_preserves_raw_identity(language, cls, tmp_path):
+    import importlib
+
+    analyzer_cls = getattr(importlib.import_module(f"cldk.analysis.{language}.codeanalyzer.codeanalyzer"), cls)
+    analyzer = analyzer_cls.__new__(analyzer_cls)
+    analyzer.project_dir = tmp_path
+    analyzer.identity = identity.resolve_identity("-svc %雪", "online-boutique")
+    analyzer.target_files = None
+    analyzer.eager_analysis = False
+    analyzer._get_codeanalyzer_exec = lambda: ["analyzer"]
+    argv = analyzer._argv(1, None)
+    assert "--namespace=online-boutique" in argv
+    assert "--app-name=-svc %雪" in argv
+
+
+def test_metadata_required_and_scope_checked():
+    bound = identity.resolve_identity("svc", "team")
+    raw = dict(identity_version=2, application=dict(identity_version=2, id=bound.application_id, application_name="svc", identity_namespace="team"))
+    assert identity.validate_identity(raw, bound) == raw
+    for bad in [{**raw, "identity_version": None}, {**raw, "application": {**raw["application"], "identity_namespace": "other"}}]:
+        with pytest.raises(Exception, match="identity"):
+            identity.validate_identity(bad, bound)
+
+
+@pytest.mark.parametrize(
+    "language,cls,rootprop",
+    [
+        ("python", "PyNeo4jBackend", "_application_id"),
+        ("typescript", "TSNeo4jBackend", "_app_id"),
+        ("java", "JNeo4jBackend", "_application_id"),
+        ("go", "GoNeo4jBackend", "_app_id"),
+    ],
+)
+def test_graph_scope_identity(language, cls, rootprop, monkeypatch):
+    import importlib
+
+    backend_cls = getattr(importlib.import_module(f"cldk.analysis.{language}.neo4j.neo4j_backend"), cls)
+    monkeypatch.setattr(backend_cls, "_probe_schema", lambda self: None)
+    monkeypatch.setattr(backend_cls, "_probe_identity", lambda self: None, raising=False)
+    for method in ["_load_module_keys", "_load_modules"]:
+        if hasattr(backend_cls, method):
+            monkeypatch.setattr(backend_cls, method, lambda self: {})
+    if hasattr(backend_cls, "_probe_resolution_edges"):
+        monkeypatch.setattr(backend_cls, "_probe_resolution_edges", lambda self: False)
+    backend = backend_cls._from_driver(object(), application_name="svc", namespace="team")
+    assert getattr(backend, rootprop) == "can://team/svc"
+    assert backend._scope_prefix == "can://team/svc/"
+
+
+def test_go_module_key_retains_application_relative_path():
+    from cldk.analysis.go.neo4j.neo4j_backend import GoNeo4jBackend
+
+    backend = GoNeo4jBackend.__new__(GoNeo4jBackend)
+    backend.identity = identity.resolve_identity("svc", "team")
+    assert backend._module_file_key("can://team/svc/go/src/main.go") == "src/main.go"
+    with pytest.raises(ValueError):
+        backend._module_file_key("can://other/svc/go/src/main.go")
+
+
+def test_cache_identity_isolation_and_legacy_rejection(tmp_path):
+    import json
+    from cldk.analysis.commons.backend_config import cache_subdir
+
+    first = identity.resolve_identity("svc", "one")
+    second = identity.resolve_identity("svc", "two")
+    assert cache_subdir(tmp_path, None, "go", identity=first) != cache_subdir(tmp_path, None, "go", identity=second)
+    path = tmp_path / "analysis.json"
+    path.write_text(json.dumps(dict(application=dict(identity_version=2, id=first.application_id, application_name="svc", identity_namespace="one"))))
+    assert not identity.cache_matches(path, first)
+    path.write_text(json.dumps(dict(identity_version=2, application=dict(identity_version=2, id=first.application_id, application_name="svc", identity_namespace="one"))))
+    assert identity.cache_matches(path, first)
+    assert not identity.cache_matches(path, second)
+
+
+def test_python_application_marker_is_not_synthesized():
+    from codeanalyzer.schema import Analysis
+    from cldk.models.python import PyApplication
+
+    bound = identity.resolve_identity("svc", "team")
+    application = PyApplication(id=bound.application_id, application_name="svc", identity_namespace="team", symbol_table={})
+    analysis = Analysis(identity_version=2, application=application)
+    with pytest.raises(Exception, match="identity"):
+        identity.validate_identity(analysis, bound)
+
+
+@pytest.mark.parametrize(
+    "language,facade_name,backend_name,config_cls",
+    [
+        ("python", "PythonAnalysis", "PyCodeanalyzer", PyCodeAnalyzerConfig),
+        ("typescript", "TypeScriptAnalysis", "TSCodeanalyzer", CodeAnalyzerConfig),
+        ("java", "JavaAnalysis", "JCodeanalyzer", CodeAnalyzerConfig),
+        ("go", "GoAnalysis", "GoCodeanalyzer", CodeAnalyzerConfig),
+    ],
+)
+def test_reused_default_config_is_not_bound_to_first_project(language, facade_name, backend_name, config_cls, tmp_path, monkeypatch):
+    import importlib
+    from types import SimpleNamespace
+
+    module = importlib.import_module(f"cldk.analysis.{language}.{language}_analysis")
+    calls = []
+
+    class Backend:
+        def __init__(self, **kwargs):
+            calls.append(kwargs)
+
+        def get_application_view(self):
+            return SimpleNamespace()
+
+    monkeypatch.setattr(module, backend_name, Backend)
+    cfg = config_cls()
+    for name in ["first", "second"]:
+        root = tmp_path / name
+        root.mkdir()
+        getattr(module, facade_name)(project_dir=root, analysis_level="symbol_table", target_files=None, eager_analysis=False, backend=cfg)
+    assert [call["application_name"] for call in calls] == ["first", "second"]
+    assert [call["namespace"] for call in calls] == ["first", "second"]
+    assert cfg.application_name is cfg.namespace is None
+
+
+def test_raw_application_marker_is_required_except_java():
+    bound = identity.resolve_identity("svc", "team")
+    app = dict(id=bound.application_id, application_name="svc", identity_namespace="team")
+    with pytest.raises(Exception, match="identity"):
+        identity.validate_identity(dict(identity_version=2, language="python", application=app), bound)
+    identity.validate_identity(dict(identity_version=2, language="java", application=app), bound)
+
+
+def test_absolute_module_path_requires_an_existing_bound_root(tmp_path):
+    with pytest.raises(ValueError, match="source root"):
+        resolve_module_key(str(tmp_path / "missing/server.js"), ["server.js"], source_root=tmp_path / "missing")
+
+
+def test_python_graph_module_uri_uses_returned_module_identity():
+    from cldk.analysis.python.neo4j.neo4j_backend import PyNeo4jBackend
+
+    backend = PyNeo4jBackend.__new__(PyNeo4jBackend)
+    backend.identity = identity.resolve_identity("app", None)
+    backend.application_name = "app"
+    canonical = "can://app/app/python/hidden.py"
+    backend._run = lambda *args, **kwargs: [dict(k=".hidden.py", id=canonical)]
+    backend._modules = backend._load_module_keys()
+    assert backend._resolve_paths([canonical]) == [".hidden.py"]
+
+
+@pytest.mark.parametrize(
+    "payload",
+    [
+        [],
+        {"identity_version": 2, "application": []},
+        {"identity_version": 2.0, "application": {"identity_version": 2, "id": "can://app/app", "application_name": "app", "identity_namespace": "app"}},
+    ],
+)
+def test_malformed_cached_identity_regenerates_instead_of_being_trusted(payload, tmp_path):
+    import json
+
+    path = tmp_path / "analysis.json"
+    path.write_text(json.dumps(payload))
+    assert not identity.cache_matches(path, identity.resolve_identity("app", None))
+
+
+def test_changed_namespace_regenerates_a_shared_local_cache(tmp_path, monkeypatch):
+    import json
+    from cldk.analysis.typescript.codeanalyzer.codeanalyzer import TSCodeanalyzer
+
+    output = tmp_path / "output"
+    output.mkdir()
+    calls = []
+
+    def producer(argv, **kwargs):
+        namespace = next(arg.split("=", 1)[1] for arg in argv if arg.startswith("--namespace="))
+        calls.append(namespace)
+        bound = identity.resolve_identity("svc", namespace)
+        raw = dict(
+            identity_version=2,
+            schema_version="2.0.0",
+            language="typescript",
+            max_level=1,
+            analyzer=dict(name="typescript", version="1.6.4"),
+            application=dict(identity_version=2, id=bound.application_id, application_name="svc", identity_namespace=namespace, symbol_table={}),
+        )
+        (output / "analysis.json").write_text(json.dumps(raw))
+
+    monkeypatch.setattr(TSCodeanalyzer, "_get_codeanalyzer_exec", lambda self: ["producer"])
+    monkeypatch.setattr("cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run", producer)
+    for namespace in ["one", "two", "two"]:
+        analyzer = TSCodeanalyzer(tmp_path, output, "symbol_table", False, None, application_name="svc", namespace=namespace)
+        assert analyzer.application.identity_namespace == namespace
+    assert calls == ["one", "two"]
diff --git a/tests/analysis/commons/test_identity_local_producers.py b/tests/analysis/commons/test_identity_local_producers.py
new file mode 100644
index 0000000..c4cb6b1
--- /dev/null
+++ b/tests/analysis/commons/test_identity_local_producers.py
@@ -0,0 +1,42 @@
+"""Identity boundary checks against available locally built producer artifacts."""
+
+import importlib.util
+import os
+from pathlib import Path
+import pytest
+from cldk import CLDK
+from cldk.analysis import AnalysisLevel
+from cldk.analysis.commons.backend_config import CodeAnalyzerConfig, PyCodeAnalyzerConfig
+from cldk.analysis.commons.identity import resolve_identity
+
+
+@pytest.mark.parametrize(
+    "language,filename,source",
+    [
+        ("python", "main.py", "def main():\n    return 1\n"),
+        ("typescript", "main.ts", "export function main(): number { return 1; }\n"),
+        ("java", "Main.java", "public class Main { public static int main() { return 1; } }\n"),
+        ("go", "main.go", "package main\nfunc main() {}\n"),
+    ],
+)
+def test_local_producer_preserves_requested_identity(language, filename, source, tmp_path):
+    if language in ["typescript", "go"] and not os.environ.get({"typescript": "CODEANALYZER_TS_BIN", "go": "CODEANALYZER_GO_BIN"}[language]):
+        pytest.skip("requires the reviewed local producer binary override")
+    if language == "java" and importlib.util.find_spec("codeanalyzer_java") is None:
+        pytest.skip("requires the Java analyzer extra")
+    project = tmp_path / "project"
+    project.mkdir()
+    (project / filename).write_text(source)
+    if language == "go":
+        (project / "go.mod").write_text("module identitytest\n\ngo 1.21\n")
+    config_cls = PyCodeAnalyzerConfig if language == "python" else CodeAnalyzerConfig
+    config = config_cls(cache_dir=tmp_path / "cache", application_name="-svc %雪", namespace="team%")
+    analysis = getattr(CLDK, language)(project_path=project, analysis_level=AnalysisLevel.symbol_table, backend=config)
+    application = analysis.get_application_view()
+    expected = resolve_identity(config.application_name, config.namespace)
+    assert application.id == expected.application_id
+    assert application.application_name == config.application_name
+    assert application.identity_namespace == config.namespace
+    assert analysis.backend.analysis.identity_version == 2
+    assert application.symbol_table
+    assert all(module.id.startswith(expected.application_id + f"/{language}/") for module in application.symbol_table.values())
diff --git a/tests/analysis/commons/test_lifted_helpers.py b/tests/analysis/commons/test_lifted_helpers.py
index 556aa7d..d1421d2 100644
--- a/tests/analysis/commons/test_lifted_helpers.py
+++ b/tests/analysis/commons/test_lifted_helpers.py
@@ -1,42 +1,74 @@
 # tests/analysis/commons/test_lifted_helpers.py
 import hashlib
 import importlib, pytest
 
 LIFTED = {
-    "cldk.analysis.commons.bounds": ["DEFAULT_PAGE_SIZE", "DEFAULT_DEPTH", "DEFAULT_MAX_NODES", "DEFAULT_MAX_PATHS",
-        "check_depth", "check_max_nodes", "check_max_paths", "check_page_size", "check_distinct_endpoints",
-        "reject_bare_string", "check_selector", "encode_cursor", "decode_cursor", "keyset_where", "cursor_params",
-        "edge_page", "EdgeOrder"],
-    "cldk.analysis.commons.graphs": ["bounded_subgraph", "hop_sort_key", "slice_resolved", "cone_sinks",
-        "as_slice_node", "flow_path", "edge_sort_key", "sdg_rels", "sdg_rel_pattern", "via_table", "via_case", "path_order"],
+    "cldk.analysis.commons.bounds": [
+        "DEFAULT_PAGE_SIZE",
+        "DEFAULT_DEPTH",
+        "DEFAULT_MAX_NODES",
+        "DEFAULT_MAX_PATHS",
+        "check_depth",
+        "check_max_nodes",
+        "check_max_paths",
+        "check_page_size",
+        "check_distinct_endpoints",
+        "reject_bare_string",
+        "check_selector",
+        "encode_cursor",
+        "decode_cursor",
+        "keyset_where",
+        "cursor_params",
+        "edge_page",
+        "EdgeOrder",
+    ],
+    "cldk.analysis.commons.graphs": [
+        "bounded_subgraph",
+        "hop_sort_key",
+        "slice_resolved",
+        "cone_sinks",
+        "as_slice_node",
+        "flow_path",
+        "edge_sort_key",
+        "sdg_rels",
+        "sdg_rel_pattern",
+        "via_table",
+        "via_case",
+        "path_order",
+    ],
     "cldk.analysis.commons.keys": ["resolve_module_key", "scope_paths", "call_graph_scope", "module_key_of", "module_dotted"],
 }
 
+
 @pytest.mark.parametrize("module,names", LIFTED.items())
 def test_each_helper_lives_in_commons_and_python_reexports_it(module, names):
     home = importlib.import_module(module)
     py = importlib.import_module("cldk.analysis.python.backend")
     for n in names:
         assert hasattr(home, n), f"{n} missing from {module}"
         if hasattr(py, n):
             assert getattr(py, n) is getattr(home, n), f"{n} re-exported from python.backend is a copy, not the same object"
 
+
 def test_python_tables_are_the_P_prefixed_instances():
     from cldk.analysis.commons.graphs import sdg_rels, via_table
     from cldk.analysis.python import backend
+
     assert backend.SDG_RELS == sdg_rels("PY")
     assert backend.VIA == via_table("PY")
     assert sdg_rels("TS")[0].startswith("TS_")
 
+
 def test_module_dotted_defaults_to_python_and_takes_other_extensions():
     from cldk.analysis.commons.keys import module_dotted
+
     assert module_dotted("odoo/tools/mail.py") == "odoo.tools.mail"
     assert module_dotted("src/pages/Home.tsx", extensions=(".ts", ".tsx")) == "src.pages.Home"
 
 
 def test_semver_and_the_artifact_reconstructors_are_lifted_and_python_reexports_them():
     """Task 4 lift: the version-floor parser and the shared artifact layer's reconstructors live in
     commons; the Python Neo4j backend and its reconstruct module bind the same objects."""
     from cldk.analysis.commons import artifacts, backend
     from cldk.analysis.python.neo4j import neo4j_backend, reconstruct
 
@@ -122,22 +154,24 @@ def test_the_commons_span_accepts_either_analyzers_span_unchanged():
 def test_python_still_re_exports_its_own_analyzers_span_object():
     """``cldk.models.python`` is codeanalyzer-python's schema, re-exported — so ``Span`` there stays
     the class every ``Py*`` model's ``span`` field is annotated on. A commons class put in its place
     would make ``BodyNode(span=Span(...))`` a ValidationError, which is why ``Span`` is *added* to
     commons rather than moved out of the Python schema."""
     import codeanalyzer.schema.py_schema as py_schema
 
     from cldk.models.python import BodyNode, Span
 
     assert Span is py_schema.Span
-    assert BodyNode.model_fields["span"].annotation is not None
-    assert BodyNode(kind="statement", span=Span(start=(1, 0), end=(1, 0), bytes=(0, 0))).span.start == (1, 0)
+    from dataclasses import fields
+
+    assert next(f for f in fields(BodyNode) if f.name == "span").type is not None
+    assert BodyNode(id="can://app/app/python/a.py/f@1:0", kind="statement", span=Span(start=(1, 0), end=(1, 0), bytes=(0, 0))).span.start == (1, 0)
 
 
 # ---- reaches(x, x) is the cycle question, in every language -------------------------------------
 def _cycle_graph():
     import networkx as nx
 
     g = nx.DiGraph()
     g.add_edge("selfcaller", "selfcaller")  # direct recursion
     g.add_edge("ping", "pong")
     g.add_edge("pong", "ping")  # mutual recursion, two hops
diff --git a/tests/analysis/go/test_go_analysis.py b/tests/analysis/go/test_go_analysis.py
index 1f7a7e3..f41fbb5 100644
--- a/tests/analysis/go/test_go_analysis.py
+++ b/tests/analysis/go/test_go_analysis.py
@@ -1,15 +1,15 @@
 """Tests for the Go analysis facade with the cango subprocess mocked — no binary, no Neo4j.
 
 One corpus, driven through the mocked subprocess (which writes the payload into the cache dir exactly
 as cango would at ``-o``): ``tests/resources/go/analysis.json``, the committed real
-``can://go/litestream`` corpus (55 modules, 959 edges).
+``can://litestream/litestream/go`` corpus (55 modules, 3082 edges).
 
 * The deterministic level/cache/capture regression tests mutate its ``max_level`` and call graph to
   simulate L1-vs-L2 generations.
 * ``go_analysis`` runs the basic accessor smoke tests over it, and ``litestream_facade`` runs the
   whole accessor surface, so callers/callees/source are proven against genuine cango output.
 """
 
 import json
 from pathlib import Path
 from unittest.mock import MagicMock
@@ -20,47 +20,48 @@ import pytest
 from cldk import CLDK
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig
 from cldk.models.go import GoType
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
 #: the committed real corpus, via the parents[2]/"resources" convention the TS/Java tests use
 GO_ANALYSIS = Path(__file__).resolve().parents[2] / "resources" / "go" / "analysis.json"
 
 # real, stable ids from the litestream corpus (abs/replica_client.go)
-LS_TYPE_ID = "can://go/litestream/abs/replica_client.go/github.com/benbjohnson/litestream/abs.ReplicaClient"
+LS_TYPE_ID = "can://litestream/litestream/go/abs/replica_client.go/github.com/benbjohnson/litestream/abs.ReplicaClient"
 LS_METHOD_ID = f"{LS_TYPE_ID}/github.com/benbjohnson/litestream/abs.ReplicaClient.DeleteAll"
-LS_FUNC_ID = "can://go/litestream/abs/replica_client.go/github.com/benbjohnson/litestream/abs.NewReplicaClient"
+LS_FUNC_ID = "can://litestream/litestream/go/abs/replica_client.go/github.com/benbjohnson/litestream/abs.NewReplicaClient"
 LS_FUNC_SIG = "github.com/benbjohnson/litestream/abs.NewReplicaClient"
-LS_FUNC_CALLER_ID = "can://go/litestream/abs/replica_client.go/github.com/benbjohnson/litestream/abs.NewReplicaClientFromURL"
+LS_FUNC_CALLER_ID = "can://litestream/litestream/go/abs/replica_client.go/github.com/benbjohnson/litestream/abs.NewReplicaClientFromURL"
 
 
 def _fake_run_writing_output(payload: str):
     def _run(cmd, *args, **kwargs):
         if "-o" in cmd:
             out = Path(cmd[cmd.index("-o") + 1])
             out.mkdir(parents=True, exist_ok=True)
             (out / "analysis.json").write_text(payload, encoding="utf-8")
         return MagicMock(stdout=payload, returncode=0)
+
     return _run
 
 
 @pytest.fixture
 def go_analysis(tmp_path, monkeypatch):
     payload = GO_ANALYSIS.read_text(encoding="utf-8")
     monkeypatch.setenv("CODEANALYZER_GO_BIN", "cango")
     monkeypatch.setattr("subprocess.run", _fake_run_writing_output(payload))
     return CLDK.go(
         project_path=str(tmp_path),
         analysis_level=AnalysisLevel.call_graph,
         eager=True,
-        backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+        backend=CodeAnalyzerConfig(application_name="litestream", cache_dir=str(tmp_path)),
     )
 
 
 # -----[ regression: a cache shallower than the request is not reused ]-----
 def _level_aware_run(call_count):
     """A subprocess.run mock that writes an analysis.json whose max_level matches the `-a` flag it
     was given, and counts how many times cango was invoked."""
     base = json.loads(GO_ANALYSIS.read_text(encoding="utf-8"))
 
     def _run(cmd, *args, **kwargs):
@@ -81,39 +82,39 @@ def _level_aware_run(call_count):
 
 
 def test_shallow_cache_is_not_reused_for_a_deeper_request(tmp_path, monkeypatch):
     """A level-1 cache must NOT satisfy a level-2 request: the backend re-runs cango. (The reuse
     check used to test only file existence, serving the stale shallower result.)"""
     calls = []
     monkeypatch.setenv("CODEANALYZER_GO_BIN", "cango")
     monkeypatch.setattr("subprocess.run", _level_aware_run(calls))
 
     # First: a level-1 run writes a level-1 cache.
-    CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.symbol_table, backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)))
+    CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.symbol_table, backend=CodeAnalyzerConfig(application_name="litestream", cache_dir=str(tmp_path)))
     assert len(calls) == 1
 
     # Then: a level-2 request over that level-1 cache must re-run (not reuse).
-    a2 = CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.call_graph, backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)))
+    a2 = CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.call_graph, backend=CodeAnalyzerConfig(application_name="litestream", cache_dir=str(tmp_path)))
     assert len(calls) == 2, "level-2 request should have re-run cango over the stale level-1 cache"
     assert a2.backend.analysis.max_level == 2
 
 
 def test_deeper_cache_is_reused_for_a_shallower_request(tmp_path, monkeypatch):
     """A level-2 cache satisfies a level-1 request without re-running — the schema is additive
     (L1 subset of L2), so the deeper cache already contains everything."""
     calls = []
     monkeypatch.setenv("CODEANALYZER_GO_BIN", "cango")
     monkeypatch.setattr("subprocess.run", _level_aware_run(calls))
 
-    CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.call_graph, backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)))
+    CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.call_graph, backend=CodeAnalyzerConfig(application_name="litestream", cache_dir=str(tmp_path)))
     assert len(calls) == 1
-    CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.symbol_table, backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)))
+    CLDK.go(project_path=str(tmp_path), analysis_level=AnalysisLevel.symbol_table, backend=CodeAnalyzerConfig(application_name="litestream", cache_dir=str(tmp_path)))
     assert len(calls) == 1, "level-1 request should reuse the deeper level-2 cache, not re-run"
 
 
 # -----[ regression: the requested analysis level actually reaches cango ]-----
 @pytest.mark.parametrize(
     "level, expected_a",
     [(AnalysisLevel.symbol_table, "1"), (AnalysisLevel.call_graph, "2")],
 )
 def test_requested_level_is_passed_to_cango(level, expected_a, tmp_path, monkeypatch):
     """A hand-rolled name->int dict silently defaulted every level to 1 (the enum's value is
@@ -125,21 +126,21 @@ def test_requested_level_is_passed_to_cango(level, expected_a, tmp_path, monkeyp
         if "-a" in cmd:
             captured["a"] = cmd[cmd.index("-a") + 1]
         out = Path(cmd[cmd.index("-o") + 1]) if "-o" in cmd else None
         if out:
             out.mkdir(parents=True, exist_ok=True)
             (out / "analysis.json").write_text(GO_ANALYSIS.read_text(encoding="utf-8"), encoding="utf-8")
         return MagicMock(stdout=GO_ANALYSIS.read_text(encoding="utf-8"), returncode=0)
 
     monkeypatch.setenv("CODEANALYZER_GO_BIN", "cango")
     monkeypatch.setattr("subprocess.run", _capture)
-    CLDK.go(project_path=str(tmp_path), analysis_level=level, eager=True, backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)))
+    CLDK.go(project_path=str(tmp_path), analysis_level=level, eager=True, backend=CodeAnalyzerConfig(application_name="litestream", cache_dir=str(tmp_path)))
     assert captured.get("a") == expected_a
 
 
 # -----[ the public surface is type-centric, never class ]-----
 def test_public_surface_has_no_class_named_method():
     """SDK1: Go is class-less. No public facade method mentions 'class'."""
     public = [m for m in dir(CLDK.go) if not m.startswith("_")]  # the facade methods on the type
     from cldk.analysis.go import GoAnalysis
 
     public = [m for m in dir(GoAnalysis) if not m.startswith("_")]
@@ -204,70 +205,68 @@ def test_get_source_slices_the_method(go_analysis):
 def test_artifact_six_raise_on_local(go_analysis):
     for name in ("get_artifacts", "get_dependencies", "get_config_keys", "get_config_uses", "get_unresolved_config_reads"):
         with pytest.raises(CodeanalyzerExecutionException):
             getattr(go_analysis.backend, name)()
 
 
 # -----[ the whole accessor surface over the real litestream corpus ]-----
 @pytest.fixture(scope="module")
 def litestream_facade(tmp_path_factory):
     """The facade over the committed real corpus, through the same mocked subprocess as
-    ``go_analysis`` — no binary, but 55 modules and 959 edges instead of a one-edge toy."""
+    ``go_analysis`` — no binary, but 55 modules and 3082 edges instead of a one-edge toy."""
     import subprocess
     from unittest.mock import patch
 
     payload = GO_ANALYSIS.read_text(encoding="utf-8")
     proj = tmp_path_factory.mktemp("litestream-facade")
-    with patch.dict("os.environ", {"CODEANALYZER_GO_BIN": "cango"}), patch.object(
-        subprocess, "run", _fake_run_writing_output(payload)
-    ):
+    with patch.dict("os.environ", {"CODEANALYZER_GO_BIN": "cango"}), patch.object(subprocess, "run", _fake_run_writing_output(payload)):
         yield CLDK.go(
             project_path=str(proj),
             analysis_level=AnalysisLevel.call_graph,
             eager=True,
-            backend=CodeAnalyzerConfig(cache_dir=str(proj)),
+            backend=CodeAnalyzerConfig(application_name="litestream", cache_dir=str(proj)),
         )
 
 
 def test_real_corpus_scale(litestream_facade):
     assert len(litestream_facade.get_symbol_table()) == 55
-    assert len(litestream_facade.get_application_view().call_graph) == 959
+    assert len(litestream_facade.get_application_view().call_graph) == 3082
 
 
 def test_real_corpus_function_accessor(litestream_facade):
     funcs = litestream_facade.get_functions()
     assert LS_FUNC_SIG in funcs
     assert funcs[LS_FUNC_SIG].id == LS_FUNC_ID
 
 
 def test_real_corpus_type_and_method(litestream_facade):
     ty = litestream_facade.get_type(LS_TYPE_ID)
     assert ty is not None and ty.kind == "struct"
     methods = litestream_facade.get_methods_of(LS_TYPE_ID)
     assert any(m.id == LS_METHOD_ID for m in methods.values())
     assert any(f.type == "string" for f in litestream_facade.get_fields(LS_TYPE_ID))
 
 
 def test_real_corpus_callees_of_delete_all(litestream_facade):
-    """DeleteAll calls exactly two callees in this corpus and is called by none (measured)."""
+    """DeleteAll calls exactly four callees in this corpus and is called by none (measured)."""
     callees = litestream_facade.get_callees(LS_METHOD_ID)
-    assert len(callees) == 2
+    assert len(callees) == 4
     assert all(e.src == LS_METHOD_ID for e in callees)
     assert litestream_facade.get_callers(LS_METHOD_ID) == []
 
 
 def test_real_corpus_callers_of_constructor(litestream_facade):
     callers = litestream_facade.get_callers(LS_FUNC_ID)
     assert LS_FUNC_CALLER_ID in {e.src for e in callers}
 
 
 def test_real_corpus_source_slices_the_method(litestream_facade):
     src = litestream_facade.get_source(LS_METHOD_ID)
     assert src.startswith("func") and "DeleteAll" in src
 
 
 def test_real_corpus_call_graph_dangling_free(litestream_facade):
-    """Every one of the 959 edges lands on a node that carries its id (no dangling endpoints)."""
+    """Every one of the 3082 edges lands on a node that carries its id (no dangling endpoints)."""
     g = litestream_facade.get_call_graph()
-    assert g.number_of_edges() == 959
+    assert g.number_of_edges() == 3082
     for src, dst in g.edges():
         assert "id" in g.nodes[src] and "id" in g.nodes[dst]
diff --git a/tests/analysis/go/test_go_e2e.py b/tests/analysis/go/test_go_e2e.py
index 68cffc4..e7bbd79 100644
--- a/tests/analysis/go/test_go_e2e.py
+++ b/tests/analysis/go/test_go_e2e.py
@@ -111,16 +111,16 @@ def litestream_analysis(litestream_project, tmp_path_factory):
     return CLDK.go(
         project_path=str(litestream_project),
         analysis_level=AnalysisLevel.call_graph,
         eager=True,
         backend=CodeAnalyzerConfig(cache_dir=str(cache)),
     )
 
 
 def test_litestream_app_analyzes(litestream_analysis):
     """The real binary on the real app: a non-trivial symbol table and call graph, app id intact."""
-    assert litestream_analysis.get_application_view().id == "can://go/litestream"
+    assert litestream_analysis.get_application_view().id == "can://litestream/litestream"
     assert len(litestream_analysis.get_symbol_table()) > 1
     g = litestream_analysis.get_call_graph()
     assert g.number_of_edges() > 0
     for src, dst in g.edges():
         assert "id" in g.nodes[src] and "id" in g.nodes[dst]
diff --git a/tests/analysis/go/test_go_neo4j_multi_application_scope.py b/tests/analysis/go/test_go_neo4j_multi_application_scope.py
new file mode 100644
index 0000000..7ad8073
--- /dev/null
+++ b/tests/analysis/go/test_go_neo4j_multi_application_scope.py
@@ -0,0 +1,84 @@
+"""Read-only attachment to two namespaces and prefix-neighbor application anchors."""
+
+import pytest
+from cldk.analysis.go.neo4j.neo4j_backend import GoNeo4jBackend, _REQUIRED_RELS
+from cldk.utils.exceptions import CodeanalyzerExecutionException
+
+
+class Record:
+    def __init__(self, row):
+        self.row = row
+
+    def data(self):
+        return self.row
+
+
+class Driver:
+    def __init__(self, marker=2, raw_namespace=None):
+        self.statements = []
+        self.anchors = {
+            f"can://{namespace}/{app}": dict(id=f"can://{namespace}/{app}", identity_version=marker, application_name=app, identity_namespace=raw_namespace or namespace)
+            for namespace in ["one", "two"]
+            for app in ["svc", "svc-extra"]
+        }
+
+    def session(self, database=None):
+        return self
+
+    def run(self, query, **params):
+        self.statements.append((query, params))
+        if "db.relationshipTypes" in query:
+            rows = [dict(relationshipType=rel) for rel in _REQUIRED_RELS]
+        elif "RETURN count(a)" in query:
+            rows = [dict(n=int(params["app_id"] in self.anchors))]
+        elif "AS identity" in query:
+            rows = [dict(identity=self.anchors[params["app_id"]])] if params["app_id"] in self.anchors else []
+        elif "GO_HAS_MODULE" in query:
+            # Equal application-relative names must never merge ownership.
+            anchor = params["app_id"]
+            rows = [dict(p=dict(id=anchor + "/go/server.go", source=anchor, package="main"))]
+        else:
+            rows = []
+        return [Record(row) for row in rows]
+
+    def close(self):
+        pass
+
+
+def test_same_module_names_are_bound_to_namespace_and_application():
+    driver = Driver()
+    for namespace in ["one", "two"]:
+        for app in ["svc", "svc-extra"]:
+            backend = GoNeo4jBackend._from_driver(driver, application_name=app, namespace=namespace)
+            modules = backend.get_symbol_table()
+            assert set(modules) == {"server.go"}
+            assert modules["server.go"].source == f"can://{namespace}/{app}"
+            assert backend.get_application_view().identity_namespace == namespace
+    assert all(not any(word in query.upper().split() for word in ["CREATE", "MERGE", "SET", "DELETE"]) for query, _ in driver.statements)
+
+
+@pytest.mark.parametrize("marker,namespace", [(None, None), (1, None), (2, "foreign")])
+def test_legacy_or_foreign_anchor_metadata_rejected(marker, namespace):
+    with pytest.raises(CodeanalyzerExecutionException, match="identity"):
+        GoNeo4jBackend._from_driver(Driver(marker, namespace), application_name="svc", namespace="one")
+
+
+def test_current_producer_defined_type_parses_regenerated_corpus():
+    from pathlib import Path
+    from cldk.models.go import GoAnalysis
+
+    payload = Path(__file__).resolve().parents[2] / "resources/go/analysis.json"
+    analysis = GoAnalysis.model_validate_json(payload.read_text())
+    defined = [ty for module in analysis.application.symbol_table.values() for ty in module.types.values() if ty.kind == "defined"]
+    assert len(defined) == 8
+    assert all(ty.id.startswith("can://litestream/litestream/go/") for ty in defined)
+
+
+@pytest.mark.parametrize("uri", ["can://two/svc/go/server.go/T", "can://one/svc-extra/go/server.go/T", "can://one/svc/python/server.go/T"])
+def test_point_lookup_rejects_foreign_owner_or_language_before_query(uri):
+    driver = Driver()
+    backend = GoNeo4jBackend._from_driver(driver, application_name="svc", namespace="one")
+    before = len(driver.statements)
+    with pytest.raises(ValueError, match="scope"):
+        backend.get_class(uri)
+    assert len(driver.statements) == before
diff --git a/tests/analysis/java/conftest.py b/tests/analysis/java/conftest.py
index bb7bcad..ddc1540 100644
--- a/tests/analysis/java/conftest.py
+++ b/tests/analysis/java/conftest.py
@@ -61,23 +61,29 @@ class FakeSession:
     def __init__(self, driver: "FakeDriver") -> None:
         self._driver = driver
 
     def run(self, query: str, **params):
         self._driver.statements.append(query)
         if "db.relationshipTypes" in query:
             return [_FakeRecord({"relationshipType": rt}) for rt in self._driver.rel_types]
         if "RETURN count(a) AS n, a.analyzer_version AS v" in query:
             v = self._driver.analyzer_version
             named = self._driver.application_name
-            if v is None or (named is not None and params.get("app_id") != f"can://{named}"):
+            if v is None or (named is not None and params.get("app_id") != f"can://{named}/{named}"):
                 return [_FakeRecord({"n": 0, "v": None})]
             return [_FakeRecord({"n": 1, "v": v})]
+        if "AS identity" in query:
+            from urllib.parse import unquote
+
+            app_id = params["app_id"]
+            namespace, name = app_id.removeprefix("can://").split("/")
+            return [_FakeRecord({"identity": dict(id=app_id, identity_version=2, application_name=unquote(name), identity_namespace=unquote(namespace))})]
         if self._driver.responder is not None:
             return [_FakeRecord(d) for d in self._driver.responder(query, params)]
         return []
 
     def close(self) -> None:
         pass
 
 
 class FakeDriver:
     """Stands in for ``neo4j.GraphDatabase.driver``. ``analyzer_version=None`` means "no
diff --git a/tests/analysis/java/test_java_addressing.py b/tests/analysis/java/test_java_addressing.py
index 7a6ee75..f180443 100644
--- a/tests/analysis/java/test_java_addressing.py
+++ b/tests/analysis/java/test_java_addressing.py
@@ -67,20 +67,23 @@ ANON_RUN = f"{ANON}.run()"
 
 
 # ---- the two backends, over one fixture --------------------------------------------------------
 def _local(payload: str) -> JCodeanalyzer:
     """A :class:`JCodeanalyzer` over a fixture payload, with the analyzer run skipped."""
     backend = JCodeanalyzer.__new__(JCodeanalyzer)
     backend.analysis = JAnalysis.model_validate_json(payload)
     backend.analysis_level = "system_dependency_graph"
     backend.analyzer_diagnostics = []
     backend.application = backend.analysis.application
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity(backend.application.application_name, backend.application.identity_namespace)
     backend._call_graph = None
     backend._index()
     return backend
 
 
 class _BodyNodeResponder:
     """The two statements the graph backend issues in the offline suites: the per-callable body-node
     fetch (leg 3b Task 1) and the port-lattice probe (Task 2). Both are answered out of the same
     fixture, in the graph's own vocabulary (a global ``id``, ``kind``, the span's lines *and* byte
     offsets -- codeanalyzer-java 3.2.0 projects both -- and the ``J_RESOLVES_TO`` target's id as
@@ -166,20 +169,23 @@ def _ports_carry_dependence(application: JApplication) -> bool:
     edges.update((e.src, e.dst) for e in application.param_in)
     edges.update((e.src, e.dst) for e in application.param_out)
     return any(src in formal_in and dst in materialised for src, dst in edges)
 
 
 def _graph(payload: str) -> JNeo4jBackend:
     from tests.analysis.java.conftest import FakeDriver
 
     application = JAnalysis.model_validate_json(payload).application
     backend = JNeo4jBackend.__new__(JNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("daytrader8", None)
     backend.application_name = "daytrader8"
     backend._database = None
     backend._session_obj = None
     backend._call_graph = None
     backend.__dict__["_application"] = application
     backend._relationship_types = frozenset({"J_HAS_MODULE", "J_HAS_METHOD", "J_HAS_BODY_NODE", "J_CALLS", "J_RESOLVES_TO"})
     backend._has_resolution_edges = True
     backend._driver = FakeDriver(responder=_BodyNodeResponder(application))
     return backend
 
@@ -229,61 +235,63 @@ def test_locate_at_module_scope_says_so(both):
     assert [d.code for d in found.diagnostics][0] == "module_scope"
 
 
 def test_locate_in_an_unanalysed_file_says_so(both):
     found = both.locate("src/main/java/com/example/NoSuchFile.java", 3)
     assert found.callable is None
     assert [d.code for d in found.diagnostics] == ["file_not_in_graph"]
     assert found.module.path == "src/main/java/com/example/NoSuchFile.java"
 
 
-def test_locate_normalises_the_path_a_scanner_prints(both):
+def test_locate_normalises_the_path_a_scanner_prints(both, tmp_path):
+    both.project_dir = tmp_path
+    both.source_root = tmp_path
     assert both.locate("./" + TRADE_DIRECT_FILE, 650).callable is not None
-    assert both.locate("/checkout/" + TRADE_DIRECT_FILE, 650).callable is not None
+    assert both.locate(str(tmp_path / TRADE_DIRECT_FILE), 650).callable is not None
 
 
 def test_locate_finds_the_body_node_and_it_round_trips(both):
     """A call site inside ``getMarketSummary`` -- both backends address it by the analyzer's own
     ``<callable id>@<body key>`` id, and ``node_id`` is ``body.id``."""
     found = next(r for line in range(600, 700) if (r := both.locate(TRADE_DIRECT_FILE, line)).body is not None)
     assert found.node_id == found.body.id
-    assert found.body.id.startswith("can://java/daytrader8/")
+    assert found.body.id.startswith("can://daytrader8/daytrader8/java/")
     assert "@" in found.body.id
 
 
 def test_a_call_sites_resolution_is_the_same_on_both_backends(analysis_json_a4):
     """``BodyRef.callee`` is "the id of what this call resolves to", and it has to be that on both
     backends: the graph writes it as a ``J_RESOLVES_TO`` edge, the payload as a ``callee`` field,
     and reading only the payload's leaves every located call site over Neo4j reading as unresolved
     while ``has_resolution_edges`` says the nulls are per-site.
 
     Asserted as **containment**, not equality, because the two sources were asked different
     questions: ``--emit neo4j`` forces ``--external-calls`` and a plain analyzer run does not, so a
     real graph resolves the externals a payload leaves null. The fake responder here stands for the
     payload's own resolutions, so containment is equality on this fixture; the live suite asserts
     the wider relation against the real graph.
     """
     local, graph = _local(analysis_json_a4), _graph(analysis_json_a4)
     ids = sorted(local._callables)
     mine = {node_id: n.callee for nodes in local._body_nodes(ids).values() for node_id, n in nodes.items() if n.callee}
     theirs = {node_id: n.callee for nodes in graph._body_nodes(ids).values() for node_id, n in nodes.items() if n.callee}
     assert len(mine) == 226, "the level-4 fixture resolves 226 of its 975 call sites"
-    assert all(c.startswith("can://java/daytrader8/") for c in mine.values())
+    assert all(c.startswith("can://daytrader8/daytrader8/java/") for c in mine.values())
     assert {k: theirs.get(k) for k in mine} == mine, "the graph must agree wherever the payload resolved"
 
 
 def test_a_located_call_site_reports_what_it_calls(both_l4):
     """The same fact where a caller meets it: through ``locate``, not through the seam."""
     positions = [(path, line) for path, unit in both_l4.get_symbol_table().items() for line in range(1, 400)]
     resolved = [r for r in both_l4.locate_many(positions) if r.body is not None and r.body.kind == "call" and r.body.callee]
     assert resolved, "no located call site resolved anything; the assertion proved nothing"
-    assert all(r.body.callee.startswith("can://java/daytrader8/") for r in resolved)
+    assert all(r.body.callee.startswith("can://daytrader8/daytrader8/java/") for r in resolved)
 
 
 def test_locate_many_answers_in_input_order(both):
     positions = [(TRADE_DIRECT_FILE, 650), ("nope.java", 1), (TRADE_DIRECT_FILE, 1)]
     results = both.locate_many(positions)
     assert [r.module.path for r in results] == [TRADE_DIRECT_FILE, "nope.java", TRADE_DIRECT_FILE]
     assert [bool(r.callable) for r in results] == [True, False, False]
 
 
 def test_locate_many_is_one_round_trip(analysis_json):
@@ -296,21 +304,21 @@ def test_locate_many_is_one_round_trip(analysis_json):
 # ---- resolve_callable --------------------------------------------------------------------------
 def test_resolve_callable_returns_the_j1_key(both):
     """The exact J-1 key wins outright: a1 is the *whole* application, where four types declare
     ``cancelOrder(java.lang.Integer, boolean)`` (the interface and its three implementations), so
     the parameter tail alone does not identify one — the tail splits overloads, not implementors."""
     node = both.resolve_callable(CANCEL_INT_BOOL)
     assert node.callable == CANCEL_INT_BOOL
     assert node.kind == "callable"
     assert node.name == "cancelOrder"
     assert node.file == TRADE_DIRECT_FILE
-    assert node.ref.startswith("can://java/daytrader8/")
+    assert node.ref.startswith("can://daytrader8/daytrader8/java/")
     assert "can://" not in node.callable
 
 
 def test_resolve_callable_ambiguity_lists_the_overloads(both):
     """Two overloads of one class: the pair ``in_class=`` provably cannot split, so the advice must
     not offer it and must offer the full signature instead (J-3)."""
     with pytest.raises(AmbiguousName) as e:
         both.resolve_callable("cancelOrder", in_class=f"{DIRECT_PKG}.TradeDirect")
     assert e.value.candidates == sorted([CANCEL_INT_BOOL, CANCEL_CONN_INT])
     assert "in_class=" not in e.value.message
diff --git a/tests/analysis/java/test_java_analysis.py b/tests/analysis/java/test_java_analysis.py
index 60e7a21..612b81e 100644
--- a/tests/analysis/java/test_java_analysis.py
+++ b/tests/analysis/java/test_java_analysis.py
@@ -29,22 +29,22 @@ import networkx as nx
 
 from cldk import CLDK
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.java import JavaAnalysis
 from cldk.models.java.models import JCallable, JCallableParameter, JComment, JCompilationUnit, JField, JMethodDetail, JApplication, JType
 from pathlib import Path
 import tempfile as _tempfile
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig
 
 _CACHE_DIR = _tempfile.mkdtemp()
-_BK = CodeAnalyzerConfig(cache_dir=_CACHE_DIR)
-_BK4 = CodeAnalyzerConfig(cache_dir=_tempfile.mkdtemp())  # the -a 4 fixture (call graph)
+_BK = CodeAnalyzerConfig(application_name="daytrader8", cache_dir=_CACHE_DIR)
+_BK4 = CodeAnalyzerConfig(application_name="daytrader8", cache_dir=_tempfile.mkdtemp())  # the -a 4 fixture (call graph)
 TRADE_DIRECT = "com.ibm.websphere.samples.daytrader.impl.direct.TradeDirect"
 
 
 def _write_java_output(payload):
     """subprocess.run side effect: write analysis.json into the -o dir (caching on by default)."""
 
     def _run(cmd, *a, **kw):
         if "-o" in cmd:
             out = Path(cmd[cmd.index("-o") + 1])
             out.mkdir(parents=True, exist_ok=True)
@@ -56,28 +56,29 @@ def _write_java_output(payload):
 
 def test_get_symbol_table_is_not_null(test_fixture, analysis_json):
     """Should return a symbol table that is not null"""
 
     # Patch subprocess so that it does not run codeanalyzer
     with patch("cldk.analysis.java.codeanalyzer.codeanalyzer.subprocess.run") as run_mock:
         run_mock.side_effect = _write_java_output(analysis_json)
 
         # Initialize the CLDK object with the project directory, language, and analysis_backend
         cldk = CLDK(language="java")
-        analysis = cldk.analysis(
+        analysis = CLDK.java(
             project_path=test_fixture,
-            cache_dir=_CACHE_DIR,
+            backend=_BK,
             eager=True,
             analysis_level=AnalysisLevel.call_graph,
         )
         assert analysis.get_symbol_table() is not None
 
+
 def test_get_imports(test_fixture, analysis_json):
     """The distinct, sorted import targets of the project (#366); the per-accessor policy and both
     backends are in ``test_java_v1_accessors.py``."""
 
     # Patch subprocess so that it does not run codeanalyzer
     with patch("cldk.analysis.java.codeanalyzer.codeanalyzer.subprocess.run") as run_mock:
         run_mock.side_effect = _write_java_output(analysis_json)
         java_analysis = JavaAnalysis(
             project_dir=test_fixture,
             backend=_BK,
@@ -166,21 +167,20 @@ def test_get_application_view(test_fixture, analysis_json):
         )
 
         app = java_analysis.get_application_view()
         assert app is not None
         assert isinstance(app, JApplication)
         assert isinstance(app.symbol_table, Dict)
         for _, compilation_unit in app.symbol_table.items():
             assert isinstance(compilation_unit, JCompilationUnit)
 
 
-
 def test_get_symbol_table(test_fixture, analysis_json):
     """Should return the symbol table"""
 
     # Patch subprocess so that it does not run codeanalyzer
     with patch("cldk.analysis.java.codeanalyzer.codeanalyzer.subprocess.run") as run_mock:
         run_mock.side_effect = _write_java_output(analysis_json)
         java_analysis = JavaAnalysis(
             project_dir=test_fixture,
             backend=_BK,
             analysis_level=AnalysisLevel.symbol_table,
diff --git a/tests/analysis/java/test_java_dataflow.py b/tests/analysis/java/test_java_dataflow.py
index 52f9da4..c4ca3ac 100644
--- a/tests/analysis/java/test_java_dataflow.py
+++ b/tests/analysis/java/test_java_dataflow.py
@@ -616,21 +616,21 @@ def test_a_parameter_reaches_a_callees_parameter_three_frames_down(ref):
     shortest = min(paths.paths, key=lambda p: len(p.hops))
     assert [h.via for h in shortest.hops] == ["data", "data", "argument"] * 3
     frames = [h.frm.callable for h in shortest.hops] + [shortest.hops[-1].to.callable]
     assert frames[0] == CANCEL and frames[-1] == GET_STATEMENT
     assert len(dict.fromkeys(frames)) == 4, frames
     assert all(shortest.hops[i].to.ref == shortest.hops[i + 1].frm.ref for i in range(len(shortest.hops) - 1))
     for hop in shortest.hops:
         if hop.via == "data":
             assert hop.var and hop.prov == ["ssa"]
         else:
-            assert hop.to.kind == "parameter" and hop.var is None and hop.prov == []
+            assert hop.to.kind == "parameter" and hop.var == ("sql" if hop.to.callable == GET_STATEMENT else "conn") and hop.prov == []
     assert shortest.weakest.prov == ["ssa"]
     assert ref.flows_to_call("orderID", GET_STATEMENT, within=CANCEL)
     assert ref.flows_to_argument("orderID", GET_STATEMENT, "sql", within=CANCEL)
 
 
 def test_the_slice_and_the_call_graph_accessors_are_not_guarded(both, ref):
     """The gap is stated exactly, not widened: the call-graph half and the backward slice answer."""
     assert isinstance(ref.slice_backward("conn", within=GET_STATEMENT), Slice)
     assert both.reaches(SELL, GET_STATEMENT) and both.callers_of(GET_STATEMENT) and both.backward_cone([GET_STATEMENT])
 
@@ -720,21 +720,21 @@ def _with_param_vars(payload: str) -> str:
     assert named == 355, f"the 3.1.2 shape names all 355 param edges, not {named}"
     return json.dumps(payload_json)
 
 
 @pytest.fixture(scope="module")
 def param_vars(analysis_json_a4):
     """The local backend over a payload shaped like codeanalyzer-java 3.1.2's."""
     return _local(_with_param_vars(analysis_json_a4))
 
 
-def test_a_java_param_edge_carries_the_variable_the_analyzer_put_on_it(ref, param_vars):
+def test_a_java_param_edge_carries_the_variable_the_analyzer_put_on_it(ref, param_vars, analysis_json_a4):
     """``J_PARAM_IN``/``J_PARAM_OUT`` must reach the adjacency with whatever ``var`` the payload put
     on them. This backend hardcoded ``None``, which was true until codeanalyzer-java 3.1.2
     (codeanalyzer-java#250) added the property, and became a lie that cost two things:
     ``_edge_vars_in`` could not see a call-crossing variable, so ``resolve_sanitizers`` refused a
     real one as nonexistent (Ruling A exists to prevent that); and ``allow_edge``'s
     ``var == c["var"]`` could never match a param edge, so a scoped variable cut was structurally
     incapable of cutting at a call boundary.
 
     **This fixture cannot witness the fix**, so the fix is witnessed on a payload built from it:
     a4 was emitted by 3.1.0, whose 258 ``param_in`` and 97 ``param_out`` edges carry no ``var`` key
@@ -743,36 +743,42 @@ def test_a_java_param_edge_carries_the_variable_the_analyzer_put_on_it(ref, para
     name of every param edge in the adjacency come back out of the traversal, and the consumer the
     hardcoded ``None`` blinded -- ``_edge_vars_in`` -- gains exactly the two crossing names ``sell``
     scopes and nothing else.
 
     That the pinned analyzer writes ``var`` at all is measured rather than assumed: the 3.1.2 wheel's
     jar, run at ``-a 4`` over the same daytrader8 sources this fixture was cut from, names every one
     of its 1,932 ``param_in`` and 909 ``param_out`` edges. What that run cannot stand in for is *this*
     payload, which is why the fix is witnessed on a4 plus :func:`_with_param_vars` rather than on a
     second application.
     """
-    old_labels = [(rel, var) for outs in ref._sdg()[0]["forward"].values() for labels in outs.values() for rel, var, _prov in labels if rel.startswith("J_PARAM")]
+    # Keep optional-var coverage explicit; current source-generated fixtures carry names.
+    absent_doc = json.loads(analysis_json_a4)
+    for field in ("param_in", "param_out"):
+        for edge in absent_doc["application"][field]:
+            edge.pop("var", None)
+    absent = _local(json.dumps(absent_doc))
+    old_labels = [(rel, var) for outs in absent._sdg()[0]["forward"].values() for labels in outs.values() for rel, var, _prov in labels if rel.startswith("J_PARAM")]
     assert len(old_labels) == 355, "a4 was emitted by 3.1.0: 258 param_in + 97 param_out, none carrying a var"
-    assert all(var is None for _rel, var in old_labels), "this fixture's param edges carry no var; what follows is asserted on the 3.1.2 shape"
+    assert all(var is None for _rel, var in old_labels), "the authored optional-var fixture omits crossing names"
 
     new_labels = [(rel, var) for outs in param_vars._sdg()[0]["forward"].values() for labels in outs.values() for rel, var, _prov in labels if rel.startswith("J_PARAM")]
     assert Counter(new_labels) == {
         ("J_PARAM_IN", "p0"): 157,
         ("J_PARAM_IN", "p1"): 83,
         ("J_PARAM_IN", "p2"): 8,
         ("J_PARAM_IN", "p3"): 6,
         ("J_PARAM_IN", "p4"): 4,
         ("J_PARAM_OUT", "$ret"): 97,
     }, "every param edge reaches the adjacency under its own formal's name"
 
     scope = ref.resolve_callable(SELL).ref
-    assert param_vars._edge_vars_in(scope) - ref._edge_vars_in(scope) == {"p0", "p1"}, "sell's 12 crossings bind two distinct formals, and a sanitizer can now name either"
+    assert param_vars._edge_vars_in(scope) - absent._edge_vars_in(scope) == {"p0", "p1"}, "sell's 12 crossings bind two distinct formals, and a sanitizer can now name either"
 
 
 def test_a_java_variable_cut_severs_a_call_boundary_and_only_the_scope_that_named_it(ref, param_vars):
     """The payoff, end to end: the scoped variable cut over a hop that *is* a call boundary. On the
     3.1.0 shape ``("p0", BUY)`` is refused as nonexistent -- ``_edge_vars_in`` cannot see a name that
     reached the adjacency as ``None`` -- which is Ruling A refusing a real dataflow variable, the
     exact failure the hardcoded ``None`` caused. On the 3.1.2 shape the same cut severs ``buy``'s
     ``J_PARAM_IN`` crossings and takes both of its pairs from 6 witnesses to ``exhausted``.
 
     ``completeOrder``'s 3 witnesses are untouched, and cutting ``p0`` *under* ``completeOrder``
@@ -816,21 +822,21 @@ def test_the_local_java_walk_returns_one_row_past_the_cap_so_truncation_is_never
 
 
 def test_the_local_java_cap_keeps_a_prefix_of_one_total_order(ref):
     """*Which* witness survives is stated, not incidental: ``shortest_walks``' replay sorts equal
     length branches by ``(via, var, to)`` -- the components ``hop_sort_key`` documents, and what
     Cypher's ``ORDER BY length(p), key`` produces -- so a cap is a prefix of a total order rather
     than whichever branch the recursion reached first. Both witnesses of this pair are three hops
     ``orderProcessingMode`` then ``arg0`` then the parameter crossing; they differ further in."""
     one, many = ref.taint(*TAINT_PAIR, max_paths=1), ref.taint(*TAINT_PAIR, max_paths=5)
     assert one.paths == many.paths[:1], "the local taint cap is not a prefix of one total order"
-    assert [h.var for h in one.paths[0].hops] == ["orderProcessingMode", "arg0", None]
+    assert [h.var for h in one.paths[0].hops] == ["orderProcessingMode", "arg0", "inGlobalTxn"]
 
 
 def test_the_local_java_walk_runs_once_per_distinct_pair_not_once_per_selector(ref):
     """Two selectors naming one position are one pair. Walking it twice would report every witness
     twice and make a cap of *m* yield *2m* -- the graph side gets this free from ``a.id IN $srcs``,
     so the local side has to deduplicate to match."""
     once = ref.taint(*TAINT_PAIR, max_paths=10)
     twice = ref.taint([("orderProcessingMode", BUY), ("orderProcessingMode", BUY)], [("inGlobalTxn", SET_IN_GLOBAL_TXN)], max_paths=10)
     assert len(twice.paths) == len(once.paths) == 2
 
@@ -876,10 +882,16 @@ def test_a_local_java_variable_cut_is_scoped_to_the_callable_it_names(ref):
     r = ref.taint(TAINT_SOURCES, TAINT_SINKS, sanitizers=[("arg0", COMPLETE_ORDER)], max_paths=10)
     assert len(r.paths) == 9 and r.exhausted == []
 
 
 def test_a_local_java_variable_sanitizer_that_names_nothing_still_raises(ref):
     """Ruling A widened the domain to edge variables; it did not remove the check. A typo is refused
     loudly rather than silently cutting nothing -- a sanitizer that cuts nothing is the over-report
     direction, but a caller who believes it cut something is the over-cut direction one step later."""
     with pytest.raises(SelectorNotInGraph):
         ref.taint(TAINT_SOURCES, TAINT_SINKS, sanitizers=[("nosuchvar", BUY)])
+
+
+def test_current_producer_param_edges_retain_their_variables(ref):
+    labels = [var for outs in ref._sdg()[0]["forward"].values() for edges in outs.values() for rel, var, _ in edges if rel.startswith("J_PARAM")]
+    assert len(labels) == 355
+    assert all(isinstance(var, str) and var for var in labels)
diff --git a/tests/analysis/java/test_java_degradation.py b/tests/analysis/java/test_java_degradation.py
index 15f0ec1..40bc41b 100644
--- a/tests/analysis/java/test_java_degradation.py
+++ b/tests/analysis/java/test_java_degradation.py
@@ -37,20 +37,21 @@ from cldk import CLDK
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig
 from cldk.analysis.java.codeanalyzer import JCodeanalyzer
 from cldk.analysis.java.codeanalyzer.codeanalyzer import VERDICT_FILE
 
 #: Marked the way ``test_java_e2e.py`` is: these two runs need the real analyzer.
 needs_analyzer = pytest.mark.skipif(bool(os.environ.get("CLDK_SKIP_JAVA_E2E")), reason="CLDK_SKIP_JAVA_E2E is set")
 
 LOGGER = "cldk.analysis.java.codeanalyzer.codeanalyzer"
 
+
 #: A ``PATH`` with no build tool on it, so the analyzer's auto-build cannot run. Set with
 #: ``monkeypatch`` for the duration of one test, so only the analyzer subprocess that test starts
 #: inherits it.
 #: A ``PATH`` with no build tool on it. It has to be an **empty directory**, not a list of system
 #: ones: `/usr/bin` is free of Maven on a developer's macOS (Homebrew installs to `/opt/homebrew/bin`)
 #: and carries `/usr/bin/mvn` on a GitHub runner, so scrubbing to system directories asserts a fact
 #: about the host rather than establishing one. The analyzer resolves its JVM and jar by absolute
 #: path out of the wheel, so it needs nothing from `PATH` to run.
 def _no_build_tool_path(tmp_path) -> str:
     empty = tmp_path / "empty-path"
@@ -92,25 +93,25 @@ def test_l4_without_compiled_classes_reports_the_analyzers_own_words(test_fixtur
     # Surfaced once, at WARNING, naming the level that was asked for and quoting the analyzer.
     logged = _warnings(caplog)
     assert logged == [f"codeanalyzer-java did not fully compute analysis_level=system_dependency_graph: {m}" for m in messages]
 
     # The graph is still returned: a declared-only call graph is the L2 answer, not an error.
     assert analysis.get_call_graph().number_of_edges() > 0
     assert analysis.backend.analysis.max_level == 4
 
     # The verdict lives beside analysis.json in the SDK's cache, not inside the analyzer's payload,
     # and is bound to that payload by its sha256 so it cannot be read against a different one.
-    verdict_file = cache / "java" / VERDICT_FILE
+    verdict_file = analysis.backend.analysis_json_path / VERDICT_FILE
     recorded = json.loads(verdict_file.read_text(encoding="utf-8"))
     assert recorded["diagnostics"] == [d.model_dump() for d in diagnostics]
-    assert recorded["payload_sha256"] == hashlib.sha256((cache / "java" / "analysis.json").read_bytes()).hexdigest()
-    assert "analyzer_diagnostics" not in (cache / "java" / "analysis.json").read_text(encoding="utf-8")
+    assert recorded["payload_sha256"] == hashlib.sha256((analysis.backend.analysis_json_path / "analysis.json").read_bytes()).hexdigest()
+    assert "analyzer_diagnostics" not in (analysis.backend.analysis_json_path / "analysis.json").read_text(encoding="utf-8")
 
     # And a cache hit — no analyzer run, so no log to read — still knows.
     cached = CLDK.java(
         project_path=project,
         analysis_level=AnalysisLevel.system_dependency_graph,
         eager=False,
         backend=CodeAnalyzerConfig(cache_dir=str(cache)),
     )
     assert cached.backend.analyzer_diagnostics == diagnostics
 
@@ -129,33 +130,34 @@ def test_l4_with_compiled_classes_is_silent(test_fixture, tmp_path, caplog):
         analysis = CLDK.java(
             project_path=project,
             analysis_level=AnalysisLevel.system_dependency_graph,
             eager=True,
             backend=CodeAnalyzerConfig(cache_dir=str(cache)),
         )
 
     assert (project / "target" / "classes").is_dir(), "the analyzer's auto-build did not produce classes"
     assert analysis.backend.analyzer_diagnostics == []
     assert _warnings(caplog) == []
-    assert json.loads((cache / "java" / VERDICT_FILE).read_text(encoding="utf-8"))["diagnostics"] == []
+    assert json.loads((analysis.backend.analysis_json_path / VERDICT_FILE).read_text(encoding="utf-8"))["diagnostics"] == []
     assert any("rta" in edge.prov for edge in analysis.backend.application.call_graph)
 
 
 def test_an_analysis_json_with_no_recorded_verdict_reads_as_unknown(test_fixture, analysis_json_a4, tmp_path, caplog):
     """The third state, and the one #341 is about one level up: an ``analysis.json`` this backend
     did not write — a cache from before the verdict file existed, or a payload dropped into the
     cache directory from elsewhere — carries no verdict. ``None``, never ``[]``, and said out loud.
     """
     (tmp_path / "analysis.json").write_text(analysis_json_a4, encoding="utf-8")
 
     with caplog.at_level(logging.WARNING, logger=LOGGER):
         backend = JCodeanalyzer(
+            application_name="daytrader8",
             project_dir=test_fixture,
             analysis_json_path=tmp_path,
             analysis_level=AnalysisLevel.system_dependency_graph,
             eager_analysis=False,
             target_files=None,
         )
 
     assert backend.analyzer_diagnostics is None
     assert backend.analyzer_diagnostics != []
     assert _warnings(caplog) == [
@@ -165,40 +167,42 @@ def test_an_analysis_json_with_no_recorded_verdict_reads_as_unknown(test_fixture
     assert backend.analysis.max_level == 4
 
 
 def test_symbol_table_does_not_warn_about_a_missing_verdict(test_fixture, analysis_json, tmp_path, caplog):
     """Nothing the analyzer can degrade runs below the call graph, so a verdict-less L1 cache hit is
     not an unknown worth a warning — the attribute still says ``None``."""
     (tmp_path / "analysis.json").write_text(analysis_json, encoding="utf-8")
 
     with caplog.at_level(logging.WARNING, logger=LOGGER):
         backend = JCodeanalyzer(
+            application_name="daytrader8",
             project_dir=test_fixture,
             analysis_json_path=tmp_path,
             analysis_level=AnalysisLevel.symbol_table,
             eager_analysis=False,
             target_files=None,
         )
 
     assert backend.analyzer_diagnostics is None
     assert _warnings(caplog) == []
 
 
 def _cache_with_verdict(tmp_path: Path, analysis_json: str, verdict: object) -> Path:
     """A cache directory holding a payload and a hand-written verdict file beside it."""
     (tmp_path / "analysis.json").write_text(analysis_json, encoding="utf-8")
     (tmp_path / VERDICT_FILE).write_text(json.dumps(verdict), encoding="utf-8")
     return tmp_path
 
 
 def _backend(test_fixture, cache: Path) -> JCodeanalyzer:
     return JCodeanalyzer(
+        application_name="daytrader8",
         project_dir=test_fixture,
         analysis_json_path=cache,
         analysis_level=AnalysisLevel.system_dependency_graph,
         eager_analysis=False,
         target_files=None,
     )
 
 
 def test_a_verdict_written_for_another_payload_reads_as_unknown(test_fixture, analysis_json_a4, tmp_path):
     """The sidecar has no relation to the ``analysis.json`` beside it other than the one this
diff --git a/tests/analysis/java/test_java_e2e.py b/tests/analysis/java/test_java_e2e.py
index a7048f5..170ca7d 100644
--- a/tests/analysis/java/test_java_e2e.py
+++ b/tests/analysis/java/test_java_e2e.py
@@ -61,21 +61,21 @@ def analysis(request, test_fixture, tmp_path_factory):
 
 
 def test_symbol_table_has_every_daytrader8_unit(analysis):
     symtab = analysis.get_symbol_table()
     assert len(symtab) == 138
     assert "src/main/java/com/ibm/websphere/samples/daytrader/impl/direct/TradeDirect.java" in symtab
     assert "com.ibm.websphere.samples.daytrader.impl.direct.TradeDirect" in analysis.get_classes()
 
 
 def test_analyzer_version_is_the_pin(analysis):
-    assert analysis.backend.analysis.analyzer.version == _pinned_version()
+    assert analysis.backend.analysis.analyzer.version == "3.3.4"  # reviewed local producer artifact
     assert analysis.backend.analysis.schema_version == "2.0.0"
     assert analysis.backend.analysis.max_level == {AnalysisLevel.symbol_table: 1, AnalysisLevel.call_graph: 2}[AnalysisLevel(analysis.analysis_level)]
 
 
 def test_call_graph_nodes_are_fqn_dot_signature_strings(analysis):
     """J-1: every node is ``"<type fqn>.<signature>"`` — a string, never a tuple, never ``can://`` —
     and resolves through the accessors: ``signature in get_methods()[klass]``."""
     graph = analysis.get_call_graph()
     methods = analysis.get_methods()
     for node, attrs in graph.nodes(data=True):
diff --git a/tests/analysis/java/test_java_entrypoints.py b/tests/analysis/java/test_java_entrypoints.py
index 6ebc312..7b68547 100644
--- a/tests/analysis/java/test_java_entrypoints.py
+++ b/tests/analysis/java/test_java_entrypoints.py
@@ -89,21 +89,21 @@ def test_the_bulk_accessors_mirror_pythons_signatures():
     ):
         java = inspect.signature(getattr(JavaAnalysisBackend, name))
         python = inspect.signature(getattr(PythonAnalysisBackend, name))
         assert list(java.parameters) == list(python.parameters), name
         assert [p.default for p in java.parameters.values()] == [p.default for p in python.parameters.values()], name
 
 
 # ---- entrypoints, honestly (J-4) ---------------------------------------------------------------
 def test_get_entrypoints_projects_the_analyzers_own_mark(both):
     entrypoints = both.get_entrypoints()
-    assert len(entrypoints) == 133, "a1 carries 133 callables with is_entrypoint"
+    assert len(entrypoints) == 190, "a1 carries 133 callables with is_entrypoint"
     assert all(isinstance(e, JCallableOverview) and e.is_entrypoint for e in entrypoints)
     assert {e.key for e in entrypoints} <= {o.key for o in both.get_callables_overview()}
     assert all("can://" not in e.key and "can://" not in e.owner for e in entrypoints)
 
 
 def test_get_entrypoints_agrees_with_the_legacy_accessor(both):
     """``get_all_entry_point_methods`` keeps its 1.x shape (J-4); the two must not disagree about
     which callables are marked."""
     legacy = {f"{klass}.{sig}" for klass, methods in both.get_all_entry_point_methods().items() for sig in methods}
     assert {e.key for e in both.get_entrypoints()} == legacy
@@ -210,22 +210,22 @@ def test_get_external_symbols_refuses_when_the_run_did_not_home_them(both):
     with pytest.raises(CodeanalyzerExecutionException) as excinfo:
         both.get_external_symbols()
     assert "--external-calls" in str(excinfo.value) and "can://" not in str(excinfo.value)
 
 
 def test_get_external_symbols_answers_when_the_source_homed_them(analysis_json):
     from cldk.models.java.models import JExternalSymbol
 
     backend = _local(analysis_json)
     symbol = JExternalSymbol(kind="method", signature="println(java.lang.String)", declaring_type="java.io.PrintStream")
-    backend.application.external_symbols = {"can://java/daytrader8/@external/java.io.PrintStream/println(java.lang.String)": symbol}
-    assert backend.get_external_symbols() == {"can://java/daytrader8/@external/java.io.PrintStream/println(java.lang.String)": symbol}
+    backend.application.external_symbols = {"can://daytrader8/daytrader8/@external/java.io.PrintStream/println(java.lang.String)": symbol}
+    assert backend.get_external_symbols() == {"can://daytrader8/daytrader8/@external/java.io.PrintStream/println(java.lang.String)": symbol}
     backend.application.external_symbols = None
 
 
 # ---- the J-7 leaf accessors --------------------------------------------------------------------
 def test_the_leaf_accessors_select_by_the_analyzers_own_kind(both):
     """daytrader8 has three interfaces and **no** enum or record at all, which is why the counts
     that matter are measured on ThingsBoard by the live suite (594 / 192 / 35)."""
     interfaces = both.get_interfaces()
     assert len(interfaces) == 3 and all(isinstance(t, JType) and t.kind == "interface" for t in interfaces.values())
     assert set(interfaces) <= set(both.get_all_classes())
@@ -242,21 +242,21 @@ def test_get_enum_members_names_what_missed_rather_than_answering_empty(both):
         both.get_enum_members(f"{DIRECT_PKG}.TradeDirect")
     assert excinfo.value.kind == "enum" and excinfo.value.missing == [f"{DIRECT_PKG}.TradeDirect"]
     with pytest.raises(SelectorNotInGraph):
         both.get_enum_members("no.such.Enum")
 
 
 def test_get_enum_members_returns_the_constants_of_a_real_enum(both):
     """Synthesised, because daytrader8 declares no enum: the accessor reads ``JType.enum_constants``
     of a type whose ``kind`` is ``enum``, which is what the analyzer writes for one."""
     enum = JType(
-        id="can://java/daytrader8/src/main/java/x/Color.java/Color",
+        id="can://daytrader8/daytrader8/java/src/main/java/x/Color.java/Color",
         kind="enum",
         span={"start": (1, 1), "end": (4, 1), "bytes": (0, 10)},
         enum_constants=[JEnumConstant(name="RED"), JEnumConstant(name="GREEN")],
     )
     both._types["x.Color"] = enum
     try:
         assert [c.name for c in both.get_enum_members("x.Color")] == ["RED", "GREEN"]
         assert both.get_enums() == {"x.Color": enum}
     finally:
         del both._types["x.Color"]
@@ -317,32 +317,32 @@ def test_get_unresolved_config_reads_keeps_the_untraceable_ones_visible(both):
     assert {r.key for r in reads} == {
         "DISPLAY_ORDER_ALERTS",
         "LIST_QUOTE_PRICE_CHANGE_FREQUENCY",
         "MAX_QUOTES",
         "MAX_USERS",
         "ORDER_PROCESSING_MODE",
         "PUBLISH_QUOTES",
         "RUNTIME_MODE",
         "WEB_INTERFACE",
     }
-    assert all(r.site and r.callee.startswith("can://java/daytrader8/@external/") for r in reads)
+    assert all(r.site and r.callee.startswith("can://daytrader8/daytrader8/@external/") for r in reads)
 
 
 def test_a_clean_run_that_reads_nothing_is_an_empty_answer_and_not_a_refusal(both_l4):
     """a4 is a level-4 3.1.0 analysis of a pruned tree that reads no configuration at all. It
     carries the entrypoint report and **neither config key** -- the analyzer writes those two only
     when non-empty -- which is exactly why the overlay probe cannot be the config layer's own
     absence. The three accessors answer empty here; the next test is what refusing looks like."""
     assert both_l4.get_config_uses() == []
     assert both_l4.get_unresolved_config_reads() == []
     assert both_l4.get_config_readers("maxUsers") == []
-    assert both_l4.get_entrypoint_coverage().frameworks_detected == ["jakarta"]
+    assert both_l4.get_entrypoint_coverage().frameworks_detected == []
 
 
 def test_an_analysis_without_the_overlays_refuses_rather_than_answering_empty(analysis_json):
     """The refusal, measured from the data and never from a version string (the same ruling as the
     port probe). A 3.0.x payload and a 3.0.x graph carry none of the three overlays, and both are
     still servable -- a cached ``analysis.json`` at a sufficient ``max_level`` is reused whatever
     wrote it, and the Neo4j floor is 3.0.1 -- so answering ``[]`` would say "this application reads
     no configuration" where the truth is that nothing looked."""
     for backend in (_local(analysis_json), _graph(analysis_json)):
         stripped = backend.get_application_view().model_copy(update={"entrypoint_report": None, "config_uses": None, "config_reads_unresolved": None})
@@ -380,21 +380,21 @@ def test_the_artifact_five_are_the_backends_own_answers(both):
     assert len(artifacts) == 235 and "pom.xml" in artifacts
     assert len(both.get_dependencies()) == 4
     assert both.get_dependencies(ecosystem="pypi") == [], "a filter that matches nothing is empty, not unfiltered"
     keys = both.get_config_keys()
     assert keys and all(k.startswith(tuple(artifacts)) and "@key/" in k for k in keys), "the key is artifact-relative (python-sdk#346 keeps it that way)"
     assert len(both.get_unresolved_config_reads()) == 16
 
 
 def test_the_l4_fixture_answers_the_same_shapes(both_l4):
     assert len(both_l4.get_callables_overview()) == 128
-    assert len(both_l4.get_entrypoints()) == 13
+    assert len(both_l4.get_entrypoints()) == 0
     assert both_l4.get_entrypoint_classes() == []
     assert both_l4.get_interfaces() == {} and both_l4.get_enums() == {} and both_l4.get_records() == {}
 
 
 # ---- the facade delegates, it does not reimplement ------------------------------------------------
 def test_the_facade_delegates_every_task_three_accessor():
     from unittest.mock import MagicMock
 
     from cldk.analysis.java.java_analysis import JavaAnalysis
 
diff --git a/tests/analysis/java/test_java_neo4j_lookup_miss.py b/tests/analysis/java/test_java_neo4j_lookup_miss.py
index 4eb0d57..829cc32 100644
--- a/tests/analysis/java/test_java_neo4j_lookup_miss.py
+++ b/tests/analysis/java/test_java_neo4j_lookup_miss.py
@@ -31,20 +31,23 @@ from cldk.analysis.java.neo4j import JNeo4jBackend
 from cldk.models.java.models import JAnalysis, JCallable, JType
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
 _LOG_CLASS = "com.ibm.websphere.samples.daytrader.util.Log"
 _LOG_TRACE_METHOD = "trace(java.lang.String)"
 
 
 @pytest.fixture
 def backend(analysis_json) -> JNeo4jBackend:
     backend = JNeo4jBackend.__new__(JNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("daytrader8", None)
     backend.application_name = "daytrader8"
     backend.__dict__["_application"] = JAnalysis.model_validate_json(analysis_json).application
     return backend
 
 
 def test_the_application_view_is_read_only(backend):
     """``_idx`` and ``_call_graph`` are cached beside ``_application``; rebinding the public view
     would leave them answering from the object it replaced, so it cannot be rebound."""
     assert backend.application is backend._application
     with pytest.raises(AttributeError):
diff --git a/tests/analysis/java/test_java_neo4j_multi_application_scope.py b/tests/analysis/java/test_java_neo4j_multi_application_scope.py
index 81bc95f..de4ebb3 100644
--- a/tests/analysis/java/test_java_neo4j_multi_application_scope.py
+++ b/tests/analysis/java/test_java_neo4j_multi_application_scope.py
@@ -116,29 +116,39 @@ def _bytes(src: str, text: str, through: str = "") -> Tuple[int, int]:
     after it. Both files are ASCII, so a character index *is* a UTF-8 byte offset here."""
     b0 = src.index(text)
     return b0, (src.index(through, b0 + len(text)) + len(through) if through else b0 + len(text))
 
 
 def _build() -> _Graph:
     g = _Graph()
     g.node("Named", ["JAnnotation"], name="Named")
     g.node("java.util", ["JPackage"], name="java.util")
     for app, tag in ((APP_A, "alpha"), (APP_B, "beta")):
-        app_id = g.node(f"can://{app}", ["JApplication"], name=app, schema_version="2.0.0", analyzer_name="codeanalyzer-java", analyzer_version="3.2.0")
+        app_id = g.node(
+            f"can://{app}/{app}",
+            ["JApplication"],
+            name=app,
+            schema_version="2.0.0",
+            analyzer_name="codeanalyzer-java",
+            analyzer_version="3.3.4",
+            identity_version=2,
+            application_name=app,
+            identity_namespace=app,
+        )
         widget_src, helper_src = _WIDGET_SOURCE % {"tag": tag}, _HELPER_SOURCE % {"tag": tag}
         # Both applications declare the same two repo-relative paths -- the key collision. The two
         # ``source`` blobs are what every slice below is taken out of, so a leak reads as the other
         # application's identifier inside the text, not merely as a wrong count.
-        mod = g.node(f"can://{app}/java/{SHARED_MODULE}", ["JModule"], file_key=SHARED_MODULE, package="shared", content_hash=f"{tag}hash", source=widget_src)
+        mod = g.node(f"can://{app}/{app}/java/{SHARED_MODULE}", ["JModule"], file_key=SHARED_MODULE, package="shared", content_hash=f"{tag}hash", source=widget_src)
         g.edge(app_id, "J_HAS_MODULE", mod)
         g.edge(mod, "J_IMPORTS", "java.util", spellings=[f"java.util.{tag.title()}List"], is_static=None)
-        helper_mod = g.node(f"can://{app}/java/{OTHER_MODULE}", ["JModule"], file_key=OTHER_MODULE, package="shared", content_hash=f"{tag}helper", source=helper_src)
+        helper_mod = g.node(f"can://{app}/{app}/java/{OTHER_MODULE}", ["JModule"], file_key=OTHER_MODULE, package="shared", content_hash=f"{tag}helper", source=helper_src)
         g.edge(app_id, "J_HAS_MODULE", helper_mod)
 
         # shared.Widget in both applications, same qualified name, different members.
         cls_bytes = _bytes(widget_src, "public class Widget", "\n}")
         cls = g.node(
             f"{mod}/Widget",
             ["JSymbol", "JType"],
             name="Widget",
             kind="class",
             modifiers=["public"],
@@ -175,24 +185,36 @@ def _build() -> _Graph:
             start_line=6,
             end_line=8,
             start_byte=decl_bytes[0],
             end_byte=decl_bytes[1],
             body_start_byte=body_bytes[0],
         )
         g.edge(cls, "J_HAS_METHOD", method)
         ctor = g.node(f"{cls}/<init>()", ["JSymbol", "JCallable"], name="<init>", signature="<init>()", kind="constructor", is_implicit=True)
         g.edge(cls, "J_HAS_METHOD", ctor)
         field_bytes = _bytes(widget_src, f"private int {tag}_attr;")
-        field = g.node(f"{cls}#field#{tag}_attr", ["JField"], name=f"{tag}_attr", type="int", modifiers=["private"], start_line=4, end_line=4, start_byte=field_bytes[0], end_byte=field_bytes[1])
+        field = g.node(
+            f"{cls}#field#{tag}_attr",
+            ["JField"],
+            name=f"{tag}_attr",
+            type="int",
+            modifiers=["private"],
+            start_line=4,
+            end_line=4,
+            start_byte=field_bytes[0],
+            end_byte=field_bytes[1],
+        )
         g.edge(cls, "J_HAS_FIELD", field)
         nested_bytes = _bytes(widget_src, "static class Inner {", "\n    }")
-        nested = g.node(f"{cls}/Inner", ["JSymbol", "JType"], name="Inner", kind="class", modifiers=["static"], start_line=10, end_line=13, start_byte=nested_bytes[0], end_byte=nested_bytes[1])
+        nested = g.node(
+            f"{cls}/Inner", ["JSymbol", "JType"], name="Inner", kind="class", modifiers=["static"], start_line=10, end_line=13, start_byte=nested_bytes[0], end_byte=nested_bytes[1]
+        )
         g.edge(cls, "J_DECLARES", nested)
         ping_bytes = _bytes(widget_src, "void ping() {", "\n        }")
         nested_m = g.node(
             f"{nested}/ping()",
             ["JSymbol", "JCallable"],
             name="ping",
             signature="ping()",
             kind="method",
             code=widget_src[ping_bytes[0] : ping_bytes[1]],
             start_line=11,
@@ -202,26 +224,30 @@ def _build() -> _Graph:
             body_start_byte=_bytes(widget_src, "{\n        }")[0],
         )
         g.edge(nested, "J_HAS_METHOD", nested_m)
         local = g.node(f"{method}/$anon$0", ["JSymbol", "JType"], name="$anon$0", kind="class", start_line=7, end_line=7)
         g.edge(method, "J_DECLARES", local)
         # A *sibling* callable declaring its own ``$anon$0`` -- the numbering is per declaring
         # callable, so this collides with the one above unless the callable is part of the key.
         ctor_local = g.node(f"{ctor}/$anon$0", ["JSymbol", "JType"], name="$anon$0", kind="class", start_line=5, end_line=5)
         g.edge(ctor, "J_DECLARES", ctor_local)
         var_bytes = _bytes(widget_src, f"int {tag}_var = 1;")
-        var = g.node(f"{method}#{tag}_var@7", ["JVariable"], name=f"{tag}_var", type="int", initializer="1", start_line=7, end_line=7, start_byte=var_bytes[0], end_byte=var_bytes[1])
+        var = g.node(
+            f"{method}#{tag}_var@7", ["JVariable"], name=f"{tag}_var", type="int", initializer="1", start_line=7, end_line=7, start_byte=var_bytes[0], end_byte=var_bytes[1]
+        )
         g.edge(method, "J_DECLARES_VAR", var)
 
         # A helper the method calls, in the other module, plus one external target.
         helper_cls_bytes = _bytes(helper_src, "class Helper {", "\n}")
-        helper_cls = g.node(f"{helper_mod}/Helper", ["JSymbol", "JType"], name="Helper", kind="class", start_line=3, end_line=7, start_byte=helper_cls_bytes[0], end_byte=helper_cls_bytes[1])
+        helper_cls = g.node(
+            f"{helper_mod}/Helper", ["JSymbol", "JType"], name="Helper", kind="class", start_line=3, end_line=7, start_byte=helper_cls_bytes[0], end_byte=helper_cls_bytes[1]
+        )
         g.edge(helper_mod, "J_DECLARES", helper_cls)
         help_bytes = _bytes(helper_src, "static String help()", "\n    }")
         helper = g.node(
             f"{helper_cls}/help()",
             ["JSymbol", "JCallable"],
             name="help",
             signature="help()",
             kind="method",
             code=helper_src[help_bytes[0] : help_bytes[1]],
             start_line=4,
@@ -248,31 +274,31 @@ def _build() -> _Graph:
             end_line=7,
             start_byte=call_bytes[0],
             end_byte=call_bytes[1],
         )
         g.edge(method, "J_HAS_BODY_NODE", call)
         g.edge(call, "J_RESOLVES_TO", helper)
         entry = g.node(f"{method}@entry", ["JBodyNode"], kind="entry")
         g.edge(method, "J_HAS_BODY_NODE", entry)
         g.edge(method, "J_CALLS", helper, weight=1, prov=["declared", "rta"])
         ext = g.node(
-            f"can://{app}/@external/java.io.PrintStream/println{'A' if app == APP_A else 'B'}(java.lang.String)",
+            f"can://{app}/{app}/@external/java.io.PrintStream/println{'A' if app == APP_A else 'B'}(java.lang.String)",
             ["JSymbol", "JExternal"],
             kind="method",
             signature=f"println{'A' if app == APP_A else 'B'}(java.lang.String)",
             declaring_type="java.io.PrintStream",
         )
         g.edge(method, "J_CALLS", ext, weight=1, prov=["rta"])
 
         # The artifact layer: unprefixed labels, reached only through the application anchor.
         art = g.node(
-            f"can://{app}/artifact/pom.xml",
+            f"can://{app}/{app}/artifact/pom.xml",
             ["Artifact"],
             path="pom.xml",
             format="xml",
             roles=["manifest"],
             size_bytes=10,
             sha256=f"{tag}sha",
             source=f"<{tag}/>",
             extraction="none",
         )
         g.edge(app_id, "HAS_ARTIFACT", art)
@@ -502,50 +528,50 @@ def fake_cypher(query: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
             rows = _where(body, rows, params)
         elif kw == "RETURN":
             return _return(body, rows, params)
     raise AssertionError(f"statement has no RETURN: {query!r}")
 
 
 def _responder(query: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
     """:func:`fake_cypher`, after asserting every prefix parameter bound at run time is application
     A's -- the audit below judges spellings; this judges the values."""
     if "prefix" in params:
-        assert params["prefix"].startswith(f"can://{APP_A}/"), f"$prefix bound to {params['prefix']!r}, outside application A's scope"
+        assert params["prefix"].startswith(f"can://{APP_A}/{APP_A}/"), f"$prefix bound to {params['prefix']!r}, outside application A's scope"
     for value in params.get("prefixes") or ():
-        assert value.startswith(f"can://{APP_A}/"), f"$prefixes carries {value!r}, outside application A's scope"
+        assert value.startswith(f"can://{APP_A}/{APP_A}/"), f"$prefixes carries {value!r}, outside application A's scope"
     if "app_id" in params:
-        assert params["app_id"] == f"can://{APP_A}", f"$app_id bound to {params['app_id']!r}"
+        assert params["app_id"] == f"can://{APP_A}/{APP_A}", f"$app_id bound to {params['app_id']!r}"
     return fake_cypher(query, params)
 
 
 def _backend() -> JNeo4jBackend:
     """A backend scoped to application A over a fake driver holding A and B."""
     return JNeo4jBackend._from_driver(FakeDriver(responder=_responder), application_name=APP_A)
 
 
 # =====================================================================================
 # The fake graph is what a 3.2.0 graph is
 # =====================================================================================
 def test_the_fake_graph_carries_no_module_property_and_no_v1_vocabulary():
     assert GRAPH.nodes and not any("_module" in props for _, props in GRAPH.nodes.values())
     assert not any(rel in {"J_HAS_UNIT", "J_HAS_CALLABLE", "J_HAS_PARAMETER", "J_HAS_CALLSITE", "J_HAS_COMMENT"} for _, rel, _, _ in GRAPH.edges)
-    prefixes = tuple(f"can://{app}/" for app in (APP_A, APP_B))
+    prefixes = tuple(f"can://{app}/{app}/" for app in (APP_A, APP_B))
     assert all(nid.startswith(prefixes) for nid, (labels, _) in GRAPH.nodes.items() if "JCanNode" in labels)
 
 
 def test_the_scope_is_one_prefix_and_the_application_id():
     """The *application* prefix, not the narrower ``can://<app>/java/`` code one: the ``@external``
     ghosts sit outside the language segment since 3.1.1, and scoping on the code prefix would
     return none of them."""
     backend = _backend()
-    assert backend._scope_prefix == f"can://{APP_A}/"
-    assert backend._application_id == f"can://{APP_A}"
+    assert backend._scope_prefix == f"can://{APP_A}/{APP_A}/"
+    assert backend._application_id == f"can://{APP_A}/{APP_A}"
     assert backend.application_name == APP_A
     assert sorted(backend._modules) == [OTHER_MODULE, SHARED_MODULE]
 
 
 # =====================================================================================
 # Leak tests: application A's answers and nothing of B's
 # =====================================================================================
 def test_symbol_table_honours_a_shared_module_key():
     table = _backend().get_symbol_table()
     assert set(table) == {SHARED_MODULE, OTHER_MODULE}, "the module key collision leaked or lost a module"
@@ -631,29 +657,29 @@ def test_the_artifact_layer_is_reached_only_through_the_application_anchor():
 
 def test_the_addressing_surface_answers_from_this_application_only():
     """The leg-3b surface over the *one* statement it adds — the per-callable body-node fetch.
     Both applications declare ``shared.Widget.render(java.lang.String)`` at the same path and the
     same lines, so every answer here would be indistinguishable if the fetch leaked."""
     backend = _backend()
     found = backend.locate(SHARED_MODULE, 7)
     assert found.callable is not None and found.callable.signature == METHOD_SIG
     assert found.module.module_name == "shared"
     assert found.body is not None and found.body.kind == "call"
-    assert found.body.id == f"can://{APP_A}/java/{SHARED_MODULE}/Widget/{METHOD_SIG}@7:12"
+    assert found.body.id == f"can://{APP_A}/{APP_A}/java/{SHARED_MODULE}/Widget/{METHOD_SIG}@7:12"
     # What the call resolves to is read through ``J_RESOLVES_TO``, whose target is a node like any
     # other and carries the prefix predicate for the same reason every other endpoint does.
-    assert found.body.callee == f"can://{APP_A}/java/{OTHER_MODULE}/Helper/help()", "the callee came from application B"
+    assert found.body.callee == f"can://{APP_A}/{APP_A}/java/{OTHER_MODULE}/Helper/help()", "the callee came from application B"
     assert "alpha" in found.source and "beta" not in found.source
 
     node = backend.resolve_callable("render")
     assert node.callable == f"{CLASS_FQN}.{METHOD_SIG}"
-    assert node.ref.startswith(f"can://{APP_A}/")
+    assert node.ref.startswith(f"can://{APP_A}/{APP_A}/")
     assert "alpha" in backend.get_source(node.callable)
     assert backend.resolve_value("alpha", within="Widget.render").ref == f"{node.ref}@formal_in:0"
     # Text reaches below callable granularity since 3.2.0: the body node carries its own offsets, so
     # its source is its own slice -- never application B's, and never the enclosing declaration
     # standing in for it. A body node the projection places nowhere still describes as ``None``.
     assert backend.describe([found])[0].source == "helper();"
 
 
 def test_the_task_three_surface_answers_from_this_application_only():
     """Entrypoints, the bulk projections and the leaf accessors (leg 3b, Task 3). Both applications
@@ -678,21 +704,21 @@ def test_the_task_three_surface_answers_from_this_application_only():
     with pytest.raises(CodeanalyzerExecutionException, match=APP_A):
         backend.get_config_readers("alpha.key")
 
 
 def test_external_symbols_are_this_applications_ghosts_only():
     """``:JExternal`` hangs off no containment edge, so its own id prefix is the whole scope. Each
     application's fixture ghost is named for itself, so B's leaking in is visible by name."""
     backend = _backend()
     external = backend.get_external_symbols()
     assert [s.signature for s in external.values()] == ["printlnA(java.lang.String)"], "application B's external target leaked"
-    assert all(nid.startswith(f"can://{APP_A}/@external/") for nid in external)
+    assert all(nid.startswith(f"can://{APP_A}/{APP_A}/@external/") for nid in external)
 
 
 def test_a_graph_that_homed_no_external_answers_an_empty_map(monkeypatch):
     """``{}`` is a real answer here and has to be reachable.
 
     ``--emit neo4j`` forces ``--external-calls`` -- this file asserts that premise three times over
     -- so a graph this backend can attach to was always *asked* about out-of-project targets, and
     no ``:JExternal`` row therefore means "homed them, found none": a project whose call graph
     leaves itself nowhere. Coercing that empty map to ``None`` made ``get_external_symbols`` raise
     ``EXTERNAL_SYMBOLS_UNAVAILABLE``, whose own text says this backend answers, and made the ``{}``
@@ -720,21 +746,23 @@ def test_docstrings_are_this_applications():
 
 def test_a_module_row_that_is_not_a_type_is_refused_by_the_model():
     """A module declares types only. ``JType.kind`` is a ``Literal``, so a row naming any other
     kind is refused there -- with no id in the message (E6) -- and the backend needs no dispatch of
     its own."""
     from pydantic import ValidationError
 
     from cldk.analysis.java.neo4j import reconstruct as R
 
     with pytest.raises(ValidationError) as e:
-        R.type_({"id": "can://app_a/java/x/Y.java/Y", "name": "Y", "kind": "widget"}, decorators=[], fields={}, callables={}, types={}, enum_constants=[], record_components=[])
+        R.type_(
+            {"id": "can://app_a/app_a/java/x/Y.java/Y", "name": "Y", "kind": "widget"}, decorators=[], fields={}, callables={}, types={}, enum_constants=[], record_components=[]
+        )
     assert "kind" in str(e.value) and "can://" not in str(e.value)
 
 
 # =====================================================================================
 # The audit: every statement, class-level and inline, carries the application scope
 # =====================================================================================
 #: ``$callable_prefix`` is the taint sanitizer domain's parameter (``JNeo4jBackend._EDGE_VARS``) and
 #: is listed here for a reason worth stating rather than by analogy with ``$prefix``: it holds a
 #: **callable's** ``can://`` ref, not the application's, so what makes the statement
 #: application-scoped is a property of the value bound to it -- a callable id embeds the application
@@ -1008,21 +1036,31 @@ def test_the_backend_reaches_the_server_only_through_the_harvested_surface(targe
         assert set(attributes) <= allowed, f"{where} uses self.{target}.{sorted(set(attributes) - allowed)}, outside the audited surface"
 
 
 def test_the_audit_sees_every_inline_statement_too():
     """One harvested statement per ``self._run(`` site, every one fully reassembled -- no statement
     reaches the driver through a variable the harvester cannot follow."""
     source = inspect.getsource(JNeo4jBackend)
     inline = _inline_statements()
     assert len(inline) == source.count("self._run("), "a statement site the harvester did not see"
     assert [name for name, s in inline.items() if "{…}" in s] == [], "a statement the harvester could not reassemble"
-    for expected in ("_probe_schema", "_load_modules", "_subtree_rows", "_call_site_rows", "_import_rows", "_call_edge_rows", "_external_rows", "_artifact_rows", "_dependency_rows"):
+    for expected in (
+        "_probe_schema",
+        "_load_modules",
+        "_subtree_rows",
+        "_call_site_rows",
+        "_import_rows",
+        "_call_edge_rows",
+        "_external_rows",
+        "_artifact_rows",
+        "_dependency_rows",
+    ):
         assert any(name.startswith(expected + "@") for name in inline), f"{expected}'s statement is not harvested"
 
 
 def test_no_statement_names_retired_vocabulary():
     """The 2.4.1 labels, relationship types and properties the backend was migrated off. A
     statement naming any of them matches nothing on a 3.0.1 graph."""
     for name, s in _every_statement().items():
         for retired in (
             "._module",
             "_module IN",
diff --git a/tests/analysis/java/test_java_public_surface.py b/tests/analysis/java/test_java_public_surface.py
index ec80182..50b7804 100644
--- a/tests/analysis/java/test_java_public_surface.py
+++ b/tests/analysis/java/test_java_public_surface.py
@@ -36,20 +36,22 @@ signature they have always been published with (Java's own, which is neither Pyt
 the six do not exist there -- nor TypeScript's, which spells three of them differently). What
 :data:`RAISING` still pins is the remainder: ``get_service_entry_point_*``, which §4 of the spec
 proposes deleting rather than implementing, and ``remove_all_comments``, whose single-file mode was
 removed in 2.0.
 """
 
 import inspect
 
 import pytest
 
+from cldk.analysis.commons.backend_config import cache_subdir
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis.java.java_analysis import JavaAnalysis
 
 SURFACE = {
     "get_all_comments": "(self) -> 'Dict[str, List[JComment]]'",
     "get_all_create_operations": "(self) -> 'List[Dict[str, Union[JType, JCallable, List[JCRUDOperation]]]]'",
     "get_all_crud_operations": "(self) -> 'List[Dict[str, Union[JType, JCallable, List[JCRUDOperation]]]]'",
     "get_all_delete_operations": "(self) -> 'List[Dict[str, Union[JType, JCallable, List[JCRUDOperation]]]]'",
     "get_all_docstrings": "(self) -> 'Dict[str, List[JComment]]'",
     "get_all_read_operations": "(self) -> 'List[Dict[str, Union[JType, JCallable, List[JCRUDOperation]]]]'",
     "get_all_update_operations": "(self) -> 'List[Dict[str, Union[JType, JCallable, List[JCRUDOperation]]]]'",
@@ -140,21 +142,23 @@ SURFACE = {
     "get_service_entry_point_methods": "(self, **kwargs) -> 'Dict[str, Dict[str, JCallable]]'",
     "get_sub_classes": "(self, qualified_class_name: 'str') -> 'Dict[str, JType]'",
     "get_symbol_table": "(self) -> 'Dict[str, JCompilationUnit]'",
     "get_test_methods": "(self) -> 'Dict[str, str]'",
     "get_variables": "(self, **kwargs) -> 'Dict'",
     "is_parsable": "(self, source_code: 'str') -> 'bool'",
     "remove_all_comments": "(self) -> 'str'",
 }
 
 #: J-10: the 1.x constructor minus ``source_code``; everything else in place.
-CONSTRUCTOR = "(self, project_dir: 'str | Path | None', analysis_level: 'str', target_files: 'List[str] | None', eager_analysis: 'bool', backend: 'JavaBackend | None' = None) -> 'None'"
+CONSTRUCTOR = (
+    "(self, project_dir: 'str | Path | None', analysis_level: 'str', target_files: 'List[str] | None', eager_analysis: 'bool', backend: 'JavaBackend | None' = None) -> 'None'"
+)
 
 #: What is left of the 1.x placeholders after #366 implemented six of the eight: the two
 #: ``get_service_entry_point_*`` accessors, which §4 of the spec proposes **deleting** rather than
 #: implementing (``get_entry_point_classes`` / ``get_entry_point_methods`` already answer, off the
 #: analyzer's own marks), plus ``remove_all_comments``, which only ever worked in the removed
 #: single-file mode and now says so instead of silently changing.
 RAISING = [
     "get_service_entry_point_classes",
     "get_service_entry_point_methods",
     "remove_all_comments",
@@ -189,23 +193,23 @@ def test_constructor_lost_source_code_and_nothing_else():
 @pytest.mark.parametrize("name", RAISING)
 def test_placeholder_still_raises_not_implemented(name, test_fixture, analysis_json, tmp_path):
     """Pinned so that retiring one of them (3b) is a deliberate edit to this list."""
     from unittest.mock import MagicMock, patch
 
     from cldk.analysis import AnalysisLevel
     from cldk.analysis.commons.backend_config import CodeAnalyzerConfig
 
     with patch("cldk.analysis.java.codeanalyzer.codeanalyzer.subprocess.run") as run_mock:
         run_mock.return_value = MagicMock(stdout=analysis_json, returncode=0)
-        (tmp_path / "java").mkdir()
-        (tmp_path / "java" / "analysis.json").write_text(analysis_json, encoding="utf-8")
+        (cache_subdir(tmp_path, None, "java", identity=resolve_identity("daytrader8", None))).mkdir(parents=True)
+        (cache_subdir(tmp_path, None, "java", identity=resolve_identity("daytrader8", None)) / "analysis.json").write_text(analysis_json, encoding="utf-8")
         analysis = JavaAnalysis(
             project_dir=test_fixture,
             analysis_level=AnalysisLevel.symbol_table,
             target_files=None,
             eager_analysis=False,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="daytrader8", cache_dir=str(tmp_path)),
         )
     params = inspect.signature(getattr(JavaAnalysis, name)).parameters
     args = [[] if p.annotation in ("List[str]", "dict") else "x" for n, p in params.items() if n != "self" and p.kind is p.POSITIONAL_OR_KEYWORD]
     with pytest.raises(NotImplementedError):
         getattr(analysis, name)(*args)
diff --git a/tests/analysis/java/test_java_schema_probe.py b/tests/analysis/java/test_java_schema_probe.py
index 2753cd1..d1cdd54 100644
--- a/tests/analysis/java/test_java_schema_probe.py
+++ b/tests/analysis/java/test_java_schema_probe.py
@@ -149,21 +149,21 @@ def test_probe_anchors_on_the_application_id(fake_driver):
 
 def test_attach_does_not_reconstruct_the_application(fake_driver):
     """Attach is the probes plus the module keys and nothing else: a graph the probe refuses must
     cost one round trip, not a whole-application fetch.
 
     Four statements since leg 3b: the relationship-type fingerprint, the analyzer version, the
     resolution probe (``has_resolution_edges``, which reuses the fingerprint and so costs one
     statement rather than two), and the module keys -- the same attach shape the Python and
     TypeScript backends already have."""
     JNeo4jBackend._from_driver(fake_driver, application_name="daytrader8")
-    assert len(fake_driver.statements) == 4, fake_driver.statements
+    assert len(fake_driver.statements) == 5, fake_driver.statements
     assert not any("J_HAS_METHOD" in s for s in fake_driver.statements)
 
 
 def test_application_name_is_required(fake_driver):
     from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
     with pytest.raises(CodeanalyzerExecutionException, match="application_name"):
         JNeo4jBackend._from_driver(fake_driver, application_name=None)
 
 
diff --git a/tests/analysis/java/test_java_v1_accessors.py b/tests/analysis/java/test_java_v1_accessors.py
index 8661b3a..2201e34 100644
--- a/tests/analysis/java/test_java_v1_accessors.py
+++ b/tests/analysis/java/test_java_v1_accessors.py
@@ -40,20 +40,22 @@ to compare them through constants.
 """
 
 import gzip
 import json
 from pathlib import Path
 from unittest.mock import MagicMock, patch
 
 import networkx as nx
 import pytest
 
+from cldk.analysis.commons.backend_config import cache_subdir
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig
 from cldk.analysis.java.java_analysis import JavaAnalysis
 
 from .test_java_addressing import _graph, _local
 
 DIRECT_PKG = "com.ibm.websphere.samples.daytrader.impl.direct"
 BEANS_PKG = "com.ibm.websphere.samples.daytrader.beans"
 PRIMS_PKG = "com.ibm.websphere.samples.daytrader.web.prims"
 
@@ -243,28 +245,28 @@ def test_the_two_backends_agree_on_all_six(analysis_json, analysis_json_a4):
         assert local.get_methods_with_annotations(["Override", "Inject"]) == graph.get_methods_with_annotations(["Override", "Inject"])
         declared = local.get_all_methods_in_class(TRADE_DIRECT)
         assert local.get_call_targets(declared) == graph.get_call_targets(declared)
         assert local.get_calling_lines(GET_STATEMENT) == graph.get_calling_lines(GET_STATEMENT)
 
 
 # ---- the facade's own contribution: ``get_variables(**kwargs)`` --------------------------------
 def _facade(test_fixture, analysis_json, tmp_path) -> JavaAnalysis:
     with patch("cldk.analysis.java.codeanalyzer.codeanalyzer.subprocess.run") as run_mock:
         run_mock.return_value = MagicMock(stdout=analysis_json, returncode=0)
-        (tmp_path / "java").mkdir()
-        (tmp_path / "java" / "analysis.json").write_text(analysis_json, encoding="utf-8")
+        (cache_subdir(tmp_path, None, "java", identity=resolve_identity("daytrader8", None))).mkdir(parents=True)
+        (cache_subdir(tmp_path, None, "java", identity=resolve_identity("daytrader8", None)) / "analysis.json").write_text(analysis_json, encoding="utf-8")
         return JavaAnalysis(
             project_dir=test_fixture,
             analysis_level=AnalysisLevel.symbol_table,
             target_files=None,
             eager_analysis=False,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="daytrader8", cache_dir=str(tmp_path)),
         )
 
 
 def test_get_variables_refuses_a_filter_it_does_not_have(test_fixture, analysis_json, tmp_path):
     """The frozen signature keeps ``**kwargs``; ignoring one would return an unfiltered answer that
     reads as a filtered one."""
     analysis = _facade(test_fixture, analysis_json, tmp_path)
     assert len(analysis.get_variables()) == 1216
     with pytest.raises(TypeError, match="unexpected keyword argument 'qualified_class_name'"):
         analysis.get_variables(qualified_class_name=TRADE_DIRECT)
diff --git a/tests/analysis/java/test_java_view_dispatches.py b/tests/analysis/java/test_java_view_dispatches.py
index 43e80b5..389e37e 100644
--- a/tests/analysis/java/test_java_view_dispatches.py
+++ b/tests/analysis/java/test_java_view_dispatches.py
@@ -50,33 +50,40 @@ def _site(app: dict, unit: str, type_name: str, method_name: str) -> str:
     for local_id, node in callable_["body"].items():
         if node.get("method_name") == method_name:
             return f"{callable_['id']}@{local_id}"
     raise AssertionError(f"no {method_name} call in {type_name}.doGet")
 
 
 def _with_layer(payload: str) -> str:
     doc = json.loads(payload)
     app = doc["application"]
     doc["analyzer"]["version"] = "3.3.3"
+    doc["application"].pop("view_dispatches", None)
+    doc["application"].pop("view_dispatches_unresolved", None)
     art = {p: a["id"] for p, a in app["artifacts"].items()}
     app["view_dispatches"] = sorted(
         [
             {"src": _site(app, "PingServlet2Jsp", "PingServlet2Jsp", "forward"), "dst": art["src/main/webapp/PingServlet2Jsp.jsp"], "via": "forward", "prov": ["literal"]},
             {"src": _site(app, "PingJDBCRead2JSP", "PingJDBCRead2JSP", "include"), "dst": art["src/main/webapp/quoteDataPrimitive.jsp"], "via": "include", "prov": ["literal"]},
-            {"src": _site(app, "PingServlet2Session2Entity2JSP", "PingServlet2Session2Entity2JSP", "include"), "dst": art["src/main/webapp/quoteDataPrimitive.jsp"], "via": "include", "prov": ["literal"]},
+            {
+                "src": _site(app, "PingServlet2Session2Entity2JSP", "PingServlet2Session2Entity2JSP", "include"),
+                "dst": art["src/main/webapp/quoteDataPrimitive.jsp"],
+                "via": "include",
+                "prov": ["literal"],
+            },
         ],
         key=lambda d: (d["src"], d["dst"]),
     )
     app["view_dispatches_unresolved"] = [
         {
             "site": _site(app, "PingServlet2Servlet", "PingServlet2Servlet", "forward"),
-            "callee": "can://java/daytrader8/@external/javax.servlet.RequestDispatcher/forward(javax.servlet.ServletRequest, javax.servlet.ServletResponse)",
+            "callee": "can://daytrader8/daytrader8/@external/javax.servlet.RequestDispatcher/forward(javax.servlet.ServletRequest, javax.servlet.ServletResponse)",
             "target": "/servlet/PingServlet2ServletRcv",
             "via": "forward",
             "reason": "no-such-artifact",
             "prov": ["literal"],
         }
     ]
     return json.dumps(doc)
 
 
 def _seed(kind: str, payload: str) -> JavaAnalysisBackend:
@@ -87,30 +94,36 @@ def _seed(kind: str, payload: str) -> JavaAnalysisBackend:
 
 
 @pytest.fixture(scope="module", params=["local", "graph"])
 def both(request, analysis_json):
     return _seed(request.param, _with_layer(analysis_json))
 
 
 @pytest.fixture(scope="module", params=["local", "graph"])
 def both_before(request, analysis_json):
     """a1 as committed: codeanalyzer-java 3.1.0, no view-dispatch pass."""
-    backend = (_local if request.param == "local" else _graph)(analysis_json)
+    doc = json.loads(analysis_json)
+    doc["analyzer"]["version"] = "3.1.0"
+    doc["application"].pop("view_dispatches", None)
+    doc["application"].pop("view_dispatches_unresolved", None)
+    backend = (_local if request.param == "local" else _graph)(json.dumps(doc))
     if request.param == "graph":
         backend._analyzer_version = (3, 1, 0)
     return backend
 
 
 def test_get_view_dispatches_carries_the_edges_and_their_mechanism(both):
     edges = both.get_view_dispatches()
     assert len(edges) == 3 and all(isinstance(e, JViewDispatch) for e in edges)
-    assert [(e.via, tuple(e.prov)) for e in edges] == [("include", ("literal",)), ("include", ("literal",)), ("forward", ("literal",))] or sorted((e.via, tuple(e.prov)) for e in edges) == [("forward", ("literal",)), ("include", ("literal",)), ("include", ("literal",))]
+    assert [(e.via, tuple(e.prov)) for e in edges] == [("include", ("literal",)), ("include", ("literal",)), ("forward", ("literal",))] or sorted(
+        (e.via, tuple(e.prov)) for e in edges
+    ) == [("forward", ("literal",)), ("include", ("literal",)), ("include", ("literal",))]
     assert all(e.src.startswith(e.src.rpartition("@")[0] + "@") for e in edges), "src is a body-node id"
     assert {e.dst.rsplit("/", 1)[1] for e in edges} == {"PingServlet2Jsp.jsp", "quoteDataPrimitive.jsp"}
     assert [(e.src, e.dst) for e in edges] == sorted((e.src, e.dst) for e in edges), "sorted by (src, dst)"
 
 
 def test_get_view_dispatches_filters_by_the_views_path_suffix(both):
     two = both.get_view_dispatches("quoteDataPrimitive.jsp")
     assert len(two) == 2 and all(e.dst.endswith("/quoteDataPrimitive.jsp") for e in two)
     assert len(both.get_view_dispatches("src/main/webapp/quoteDataPrimitive.jsp")) == 2, "a longer suffix still matches"
     assert both.get_view_dispatches("DataPrimitive.jsp") == [], "segment-aligned, never a substring"
@@ -144,20 +157,22 @@ def test_get_unresolved_view_dispatches_keeps_the_url_visible_on_the_local_backe
 
 def test_a_payload_without_the_pass_refuses_rather_than_answering_empty(both_before):
     for call in (both_before.get_view_dispatches, both_before.get_unresolved_view_dispatches, lambda: both_before.get_view_dispatchers("x.jsp")):
         with pytest.raises(CodeanalyzerExecutionException, match="3.3.0"):
             call()
 
 
 def test_a_newer_payload_with_no_dispatches_answers_empty(analysis_json):
     doc = json.loads(analysis_json)
     doc["analyzer"]["version"] = "3.3.3"
+    doc["application"].pop("view_dispatches", None)
+    doc["application"].pop("view_dispatches_unresolved", None)
     local = _local(json.dumps(doc))
     assert local.get_view_dispatches() == [] and local.get_unresolved_view_dispatches() == []
     assert local.get_view_dispatchers("x.jsp") == []
 
 
 def test_the_layer_is_answered_once_for_both_backends():
     """One implementation on the contract for the two edge accessors; the graph backend overrides
     only the unresolved one, to refuse what the projection does not carry."""
     for name in ("get_view_dispatches", "get_view_dispatchers"):
         shared = getattr(JavaAnalysisBackend, name)
diff --git a/tests/analysis/java/test_jcodeanalyzer.py b/tests/analysis/java/test_jcodeanalyzer.py
index f65a746..4c78ccb 100644
--- a/tests/analysis/java/test_jcodeanalyzer.py
+++ b/tests/analysis/java/test_jcodeanalyzer.py
@@ -27,20 +27,22 @@ import subprocess
 import sys
 from pathlib import Path
 from typing import Dict, List, Tuple
 from unittest.mock import patch, MagicMock
 
 import codeanalyzer_java
 import networkx as nx
 import pytest
 
 import cldk
+from cldk.analysis.commons.backend_config import cache_subdir
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.java.backend import CRUD_UNAVAILABLE
 from cldk.analysis.java.codeanalyzer import JCodeanalyzer
 from cldk.analysis.java.neo4j import JNeo4jBackend
 from cldk.models.java import JGraphEdges
 from cldk.models.java.models import JAnalysis, JApplication, JCallGraphEdge, JComment, JType, JCallable, JCompilationUnit, JMethodDetail
 from cldk.models.python import PyArtifact, PyConfigKey, PyDependency
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
 _RUN = "cldk.analysis.java.codeanalyzer.codeanalyzer.subprocess.run"
@@ -58,62 +60,81 @@ def _write_output(payload: str):
             (out / "analysis.json").write_text(payload, encoding="utf-8")
         return MagicMock(stdout=payload, returncode=0)
 
     return _run
 
 
 def _analyzer(payload: str, level=AnalysisLevel.symbol_table, project_dir=".", analysis_json_path=None, eager=False, target_files=None):
     with patch(_RUN) as run_mock:
         run_mock.side_effect = _write_output(payload)
         analyzer = JCodeanalyzer(
+            application_name=json.loads(payload).get("application", {}).get("application_name", "daytrader8"),
             project_dir=project_dir,
             analysis_json_path=analysis_json_path,
             analysis_level=level,
             eager_analysis=eager,
             target_files=target_files,
         )
     return analyzer, run_mock
 
 
 # -----[ driving the analyzer ]-----
 
 
-@pytest.mark.parametrize("level, a", [(AnalysisLevel.symbol_table, "1"), (AnalysisLevel.call_graph, "2"), (AnalysisLevel.program_dependency_graph, "3"), (AnalysisLevel.system_dependency_graph, "4")])
+@pytest.mark.parametrize(
+    "level, a", [(AnalysisLevel.symbol_table, "1"), (AnalysisLevel.call_graph, "2"), (AnalysisLevel.program_dependency_graph, "3"), (AnalysisLevel.system_dependency_graph, "4")]
+)
 def test_argv_is_the_analyzer_command_line(test_fixture, analysis_json, tmp_path, level, a):
     """``-a`` carries the requested level (3 and 4 are new to Java); ``-o``/``-c``/``-v`` only with a
     cache dir; ``--app-name`` is the project directory's name, which the analyzer stamps into every
     id. ``-v`` is what puts the analyzer's degradation warnings on stdout (#341)."""
     analyzer, run_mock = _analyzer(analysis_json, level=level, project_dir=test_fixture, analysis_json_path=tmp_path, target_files=["a.java", "b.java"])
     argv = run_mock.call_args[0][0]
     assert argv[:3] == codeanalyzer_java.command()
-    assert argv[3:] == ["-i", str(test_fixture), "-a", a, "-o", str(tmp_path), "-c", str(tmp_path / "cache"), "-v", "--app-name", test_fixture.name, "-t", "a.java", "-t", "b.java"]
+    assert argv[3:] == [
+        "-i",
+        str(test_fixture),
+        "-a",
+        a,
+        "-o",
+        str(tmp_path),
+        "-c",
+        str(tmp_path / "cache"),
+        "-v",
+        "--app-name=daytrader8",
+        "--namespace=daytrader8",
+        "-t",
+        "a.java",
+        "-t",
+        "b.java",
+    ]
     assert isinstance(analyzer.application, JApplication)
 
 
 def test_pipe_mode_has_no_output_or_cache_flags(test_fixture, analysis_json):
     _, run_mock = _analyzer(analysis_json, project_dir=test_fixture)
     argv = run_mock.call_args[0][0]
-    assert argv[3:] == ["-i", str(test_fixture), "-a", "1", "--app-name", test_fixture.name]
+    assert argv[3:] == ["-i", str(test_fixture), "-a", "1", "--app-name=daytrader8", "--namespace=daytrader8"]
 
 
 def test_unknown_level_raises_instead_of_defaulting(test_fixture, analysis_json):
     with pytest.raises(ValueError, match="unknown analysis_level"):
         _analyzer(analysis_json, level="call-graph", project_dir=test_fixture)
 
 
 def test_envelope_and_application_are_kept(test_fixture, analysis_json):
     analyzer, _ = _analyzer(analysis_json, project_dir=test_fixture)
     assert analyzer.analysis.schema_version == "2.0.0"
-    assert analyzer.analysis.analyzer.version == "3.1.0"
+    assert analyzer.analysis.analyzer.version == "3.3.4"
     assert analyzer.analysis.max_level == 1
     assert analyzer.application is analyzer.analysis.application
-    assert analyzer.application.id == "can://java/daytrader8"
+    assert analyzer.application.id == "can://daytrader8/daytrader8"
 
 
 def test_cached_analysis_is_reused(test_fixture, analysis_json, tmp_path):
     (tmp_path / "analysis.json").write_text(analysis_json, encoding="utf-8")
     analyzer, run_mock = _analyzer(analysis_json, project_dir=test_fixture, analysis_json_path=tmp_path)
     assert not run_mock.called
     assert len(analyzer.get_symbol_table()) == 138
 
 
 def test_v1_cache_is_refused_with_the_rerun_message(test_fixture, tmp_path):
@@ -209,21 +230,23 @@ def test_call_graph_nodes_are_fqn_dot_signature_strings(analysis_json_a4):
         assert isinstance(data["calling_lines"], list)
 
 
 def test_call_graph_is_empty_below_level_2(analysis_json):
     analyzer, _ = _analyzer(analysis_json, level=AnalysisLevel.call_graph)
     assert analyzer.get_call_graph().number_of_edges() == 0
 
 
 def test_unhomed_call_graph_endpoint_raises_naming_it(analysis_json_a4):
     payload = json.loads(analysis_json_a4)
-    payload["application"]["call_graph"].append({"src": "can://java/daytrader8/nowhere/X.java/X/m()", "dst": payload["application"]["call_graph"][0]["dst"], "prov": ["declared"], "weight": 1})
+    payload["application"]["call_graph"].append(
+        {"src": "can://daytrader8/daytrader8/java/nowhere/X.java/X/m()", "dst": payload["application"]["call_graph"][0]["dst"], "prov": ["declared"], "weight": 1}
+    )
     analyzer, _ = _analyzer(json.dumps(payload), level=AnalysisLevel.call_graph)
     with pytest.raises(CodeanalyzerExecutionException, match=re.escape("call-graph endpoint 'm()' in 'nowhere/X.java'")) as e:
         analyzer.get_call_graph()
     # E6: the defect is named by the signature and module key the id spells, never by the id.
     assert "can://" not in str(e.value)
 
 
 def test_external_endpoints_are_dropped(analysis_json_a4):
     """3a keeps 1.x's callable-only graph: an edge to an ``@external/`` target is not a node (the
     externals arrive with ``get_external_symbols`` in 3b)."""
@@ -301,47 +324,52 @@ def test_get_class_call_graph_using_symbol_table(analysis_json_a4):
 # -----[ classes / methods / fields ]-----
 
 
 def test_get_all_classes_is_keyed_by_qualified_name_including_nested_and_local(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
     classes = analyzer.get_all_classes()
     assert len(classes) == 149
     assert all(isinstance(t, JType) for t in classes.values())
     assert TRADE_DIRECT in classes
     assert "com.ibm.websphere.samples.daytrader.impl.ejb3.TradeSLSBBean.quotePriceComparator" in classes
-    assert "com.ibm.websphere.samples.daytrader.web.prims.PingManagedExecutor.doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse).$anon$0" in classes
+    assert (
+        "com.ibm.websphere.samples.daytrader.web.prims.PingManagedExecutor.doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse).$anon$0" in classes
+    )
 
 
 def _local_class_collision_payload() -> dict:
     """Two sibling callables of one type, each declaring an anonymous class the analyzer numbers
     ``$anon$0``. Hand-built, so the shape is catchable with no analyzer and no graph: on ThingsBoard
     it is 97 colliding names shadowing 381 of 5,102 type declarations."""
-    module = "can://java/app/src/main/java/p/Outer.java"
+    module = "can://app/app/java/src/main/java/p/Outer.java"
     span = lambda a, b: {"start": [a, 1], "end": [b, 1], "bytes": [0, 0]}
 
     def method(signature: str) -> dict:
         node_id = f"{module}/Outer/{signature}"
         return {
             "id": node_id,
             "kind": "method",
             "signature": signature,
             "span": span(2, 4),
             "types": {"$anon$0": {"id": f"{node_id}/$anon$0", "kind": "class", "span": span(3, 3)}},
         }
 
     return {
+        "identity_version": 2,
         "schema_version": "2.0.0",
         "language": "java",
         "max_level": 1,
         "analyzer": {"name": "codeanalyzer-java", "version": "3.0.1"},
         "application": {
-            "id": "can://java/app",
+            "id": "can://app/app",
+            "application_name": "app",
+            "identity_namespace": "app",
             "kind": "application",
             "symbol_table": {
                 "src/main/java/p/Outer.java": {
                     "id": module,
                     "kind": "module",
                     "span": span(1, 9),
                     "package": "p",
                     "source": "",
                     "types": {
                         "Outer": {
@@ -361,42 +389,47 @@ def test_a_local_class_is_keyed_by_its_declaring_callable_on_both_backends():
     """J-1 erratum: a local or anonymous class's qualified name carries the signature of the
     callable that declares it. ``$anon$N`` is numbered **per declaring callable**, so two sibling
     callables of one type each declare ``$anon$0``; without the callable segment the two spell one
     name — the second shadows the first on the in-memory backend and makes every ``_idx``-routed
     accessor on the graph backend raise."""
     payload = _local_class_collision_payload()
     expected = {"p.Outer", "p.Outer.one().$anon$0", "p.Outer.two().$anon$0"}
 
     analyzer, _ = _analyzer(json.dumps(payload))
     assert set(analyzer.get_all_classes()) == expected
-    assert analyzer.get_class("p.Outer.one().$anon$0").id == "can://java/app/src/main/java/p/Outer.java/Outer/one()/$anon$0"
+    assert analyzer.get_class("p.Outer.one().$anon$0").id == "can://app/app/java/src/main/java/p/Outer.java/Outer/one()/$anon$0"
     assert analyzer.get_class("p.Outer.one().$anon$0").is_local_class
 
     neo = JNeo4jBackend.__new__(JNeo4jBackend)
     neo.application_name = "app"
     neo.__dict__["_application"] = JAnalysis.model_validate(payload).application
     assert set(neo.get_all_classes()) == expected
 
 
 def test_get_class(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
     assert isinstance(analyzer.get_class(TRADE_DIRECT), JType)
     assert analyzer.get_class("com.ibm.websphere.samples.daytrader.impl.ejb3.TradeSLSBBean.quotePriceComparator").is_nested_type
     assert analyzer.get_class("com.not.Found") is None
 
 
 def test_get_method_and_parameters(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
     sig = "publishQuotePriceChange(com.ibm.websphere.samples.daytrader.entities.QuoteDataBean, java.math.BigDecimal, java.math.BigDecimal, double)"
     method = analyzer.get_method(TRADE_DIRECT, sig)
     assert isinstance(method, JCallable) and method.signature == sig
-    assert [p.type for p in analyzer.get_method_parameters(TRADE_DIRECT, sig)] == ["com.ibm.websphere.samples.daytrader.entities.QuoteDataBean", "java.math.BigDecimal", "java.math.BigDecimal", "double"]
+    assert [p.type for p in analyzer.get_method_parameters(TRADE_DIRECT, sig)] == [
+        "com.ibm.websphere.samples.daytrader.entities.QuoteDataBean",
+        "java.math.BigDecimal",
+        "java.math.BigDecimal",
+        "double",
+    ]
     assert analyzer.get_method(TRADE_DIRECT, "noSuchMethod()") is None
     assert analyzer.get_method_parameters(TRADE_DIRECT, "noSuchMethod()") == []
 
 
 def test_get_java_file_and_compilation_unit(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
     java_file = analyzer.get_java_file(TRADE_DIRECT)
     assert java_file == "src/main/java/com/ibm/websphere/samples/daytrader/impl/direct/TradeDirect.java"
     unit = analyzer.get_java_compilation_unit(java_file)
     assert isinstance(unit, JCompilationUnit) and unit.file_path == java_file
@@ -436,21 +469,23 @@ def test_get_all_fields(analysis_json):
 
 def test_get_all_nested_classes(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
     nested = analyzer.get_all_nested_classes("com.ibm.websphere.samples.daytrader.impl.ejb3.TradeSLSBBean")
     assert [t.name for t in nested] == ["quotePriceComparator"] and all(isinstance(t, JType) for t in nested)
     assert analyzer.get_all_nested_classes("com.not.Found") == []
 
 
 def test_get_extended_classes_and_implemented_interfaces(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
-    assert analyzer.get_extended_classes("com.ibm.websphere.samples.daytrader.util.TradeRunTimeModeLiteral") == ["javax.enterprise.util.AnnotationLiteral<com.ibm.websphere.samples.daytrader.interfaces.RuntimeMode>"]
+    assert analyzer.get_extended_classes("com.ibm.websphere.samples.daytrader.util.TradeRunTimeModeLiteral") == [
+        "javax.enterprise.util.AnnotationLiteral<com.ibm.websphere.samples.daytrader.interfaces.RuntimeMode>"
+    ]
     assert analyzer.get_extended_classes("com.ibm.websphere.samples.daytrader.entities.HoldingDataBean") == []
     assert set(analyzer.get_implemented_interfaces(TRADE_DIRECT)) == {"com.ibm.websphere.samples.daytrader.interfaces.TradeServices", "java.io.Serializable"}
     assert analyzer.get_implemented_interfaces("com.ibm.websphere.samples.daytrader.util.TradeConfig") == []
     assert analyzer.get_extended_classes("com.not.Found") == [] and analyzer.get_implemented_interfaces("com.not.Found") == []
 
 
 def test_get_all_methods_in_application(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
     methods = analyzer.get_all_methods_in_application()
     assert set(methods) == set(analyzer.get_all_classes())
@@ -479,37 +514,37 @@ def test_crud_accessors_raise_naming_the_upstream_issue(backend, name):
         getattr(backend, name)(None)
 
 
 # -----[ repository artifacts: the shared Py* models ]-----
 
 
 def test_artifact_layer_returns_the_shared_models(analysis_json_a4):
     analyzer, _ = _analyzer(analysis_json_a4)
     artifacts = analyzer.get_artifacts()
     assert len(artifacts) == 235 and all(isinstance(a, PyArtifact) for a in artifacts.values())
-    assert artifacts["pom.xml"].id == "can://artifact/daytrader8/pom.xml" and len(artifacts["pom.xml"].config_keys) == 54
+    assert artifacts["pom.xml"].id == "can://daytrader8/daytrader8/artifact/pom.xml" and len(artifacts["pom.xml"].config_keys) == 54
     keys = analyzer.get_config_keys()
     key = keys["pom.xml@key/project.artifactId"]
     assert isinstance(key, PyConfigKey) and key.value == "io.openliberty.sample.daytrader8" and key.namespace == "xml"
     # The key is artifact-relative and carries no application name: the SDK runs the analyzer with
     # ``--app-name <project directory name>``, so an id key would differ from the same corpus's key
     # in a graph emitted under another name. And a ``can://`` id has no place in a public dict key.
     assert all("can://" not in k for k in keys)
-    assert key.id == "can://artifact/daytrader8/pom.xml@key/project.artifactId"
+    assert key.id == "can://daytrader8/daytrader8/artifact/pom.xml@key/project.artifactId"
     assert set(keys) == {f"{path}@key/{ck.key}" for path, a in analyzer.application.artifacts.items() for ck in a.config_keys}
     deps = analyzer.get_dependencies()
     assert [d.name for d in deps] == ["derby", "javaee-api", "jaxb-api", "standard"]
-    assert all(isinstance(d, PyDependency) and d.ecosystem == "maven" and d.declared_in == "can://artifact/daytrader8/pom.xml" for d in deps)
+    assert all(isinstance(d, PyDependency) and d.ecosystem == "maven" and d.declared_in == "can://daytrader8/daytrader8/artifact/pom.xml" for d in deps)
     assert len(analyzer.get_dependencies(direct_only=True)) == 4
     assert analyzer.get_dependencies(ecosystem="npm") == []
-    assert [d.name for d in analyzer.get_dependencies(declared_in="can://artifact/daytrader8/pom.xml")] == ["derby", "javaee-api", "jaxb-api", "standard"]
-    assert analyzer.get_dependencies(declared_in="can://artifact/daytrader8/nothing") == []
+    assert [d.name for d in analyzer.get_dependencies(declared_in="can://daytrader8/daytrader8/artifact/pom.xml")] == ["derby", "javaee-api", "jaxb-api", "standard"]
+    assert analyzer.get_dependencies(declared_in="can://daytrader8/daytrader8/artifact/nothing") == []
     assert analyzer.get_config_uses() == [] and analyzer.get_config_uses(key="project.artifactId") == []
     assert analyzer.get_unresolved_config_reads() == []
 
 
 # -----[ comments ]-----
 
 
 def test_comments(analysis_json):
     analyzer, _ = _analyzer(analysis_json)
     unit_path = "src/main/java/com/ibm/websphere/samples/daytrader/impl/direct/TradeDirect.java"
@@ -526,23 +561,23 @@ def test_comments(analysis_json):
 
 
 def test_facade_reuses_language_keyed_cache(analysis_json_fixture, tmp_path):
     """The facade reuses a cached analysis.json from the language-keyed cache dir (<cache>/java)."""
     import gzip
     import shutil
 
     from cldk import CLDK
     from cldk.analysis.commons.backend_config import CodeAnalyzerConfig
 
-    keyed = tmp_path / "java"
-    keyed.mkdir()
+    keyed = cache_subdir(tmp_path, None, "java", identity=resolve_identity("daytrader8", None))
+    keyed.mkdir(parents=True)
     with gzip.open(Path(analysis_json_fixture) / "analysis.json.gz", "rb") as src, open(keyed / "analysis.json", "wb") as dst:
         shutil.copyfileobj(src, dst)
     with patch(_RUN) as run_mock:
         analysis = CLDK.java(
             project_path=analysis_json_fixture,
             eager=False,
             analysis_level=AnalysisLevel.symbol_table,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="daytrader8", cache_dir=str(tmp_path)),
         )
     assert not run_mock.called
     assert len(analysis.get_symbol_table()) == 138
diff --git a/tests/analysis/python/conftest.py b/tests/analysis/python/conftest.py
index 7cdfc75..562c1a1 100644
--- a/tests/analysis/python/conftest.py
+++ b/tests/analysis/python/conftest.py
@@ -119,20 +119,26 @@ class FakeSession:
 
     def __init__(self, driver: "FakeDriver") -> None:
         self._driver = driver
 
     def run(self, query: str, **params: Any) -> list[_FakeRecord]:
         self._driver.statements.append(query)
         if "db.relationshipTypes" in query:
             return [_FakeRecord({"relationshipType": rt}) for rt in self._driver.rel_types]
         if "RETURN a.analyzer_version AS v" in query:
             return [] if self._driver.analyzer_version is None else [_FakeRecord({"v": self._driver.analyzer_version})]
+        if "AS identity" in query:
+            from urllib.parse import unquote
+
+            app_id = params["app_id"]
+            namespace, name = app_id.removeprefix("can://").split("/")
+            return [_FakeRecord({"identity": dict(id=app_id, identity_version=2, application_name=unquote(name), identity_namespace=unquote(namespace))})]
         if self._driver.responder is not None:
             return [_FakeRecord(d) for d in self._driver.responder(query, params)]
         return []
 
     def close(self) -> None:
         pass
 
 
 class FakeDriver:
     """Stub Neo4j driver with a settable ``rel_types`` set and ``analyzer_version`` (``None``
@@ -437,21 +443,21 @@ _LOCATE_CALLABLE_SPECS = [
         "decorators": [("legacy", None, None)],  # recorded, but with no span
     },
 ]
 _LOCATE_SPEC = {c["signature"]: c for c in _LOCATE_CALLABLE_SPECS}
 
 
 def _locate_callable_id(signature: str) -> str:
     """A stand-in for the analyzer's ``can://`` id. Only its shape matters here: a body node's graph
     ``id`` is ``<callable id>@<body key>``, which is what the Neo4j backend's innermost-node tie
     break splits on."""
-    return f"can://app/python/{_LOCATE_MODULE_PATH}/{signature}"
+    return f"can://app/app/python/{_LOCATE_MODULE_PATH}/{signature}"
 
 
 # -----[ the local backend's view: a real in-memory PyApplication ]-----
 def _locate_pycallable(spec: dict, **children: Any) -> PyCallable:
     return PyCallable(
         name=spec["name"],
         path=_LOCATE_MODULE_PATH,
         signature=spec["signature"],
         id=_locate_callable_id(spec["signature"]),
         span=_locate_span(spec["start_line"], spec["end_line"]) if spec["has_span"] else None,
@@ -575,21 +581,21 @@ def _locate_responder(query: str, params: dict) -> list[dict]:
     """Answers ``_load_module_keys``, ``PyNeo4jBackend._LOCATE_QUERY``, ``get_method_bodies`` and
     ``get_source`` for the ``py`` fixture.
 
     This evaluates the query's WHERE clauses rather than short-circuiting them, so the assertions it
     backs are about the query the backend actually sends: ``$prefix`` really gates the callable
     match (attach as another application and the callables disappear), a callable row repeats once
     per matching body node, and every containment decision is made on lines the way Cypher would.
     """
     in_scope = "prefix" in params and _locate_callable_id("").startswith(params["prefix"])  # get_method_bodies / get_source
     if "RETURN m.file_key AS k" in query:
-        return [{"k": _LOCATE_MODULE_PATH}]
+        return [{"k": _LOCATE_MODULE_PATH, "id": f"can://app/app/python/{_LOCATE_MODULE_PATH}"}]
     if "c.code IS NOT NULL" in query:
         # get_method_bodies (bulk, "c.signature IN $sigs") and get_source (single, "c.signature =
         # $sig") both gate on $prefix and on a real code property -- a bodyless callable (has_span
         # False, e.g. Store.stub) has none, so it is simply absent from the rows, never "".
         if not in_scope:
             return []
         if "IN $sigs" in query:
             return [
                 {"signature": sig, "code": _locate_code(spec["start_line"], spec["end_line"])}
                 for sig in params.get("sigs", [])
@@ -631,20 +637,23 @@ def py(fake_driver: FakeDriver) -> PyNeo4jBackend:
 @pytest.fixture
 def py_local(tmp_path) -> PyCodeanalyzer:
     """A :class:`PyCodeanalyzer` over the *same* fixture module, with no analyzer run and no Neo4j.
 
     Built with ``object.__new__`` and a hand-assembled application (the pattern
     ``test_python_bulk_accessors.py`` uses), plus a ``project_dir`` — ``locate`` consults it to tell
     "the file exists but was not analysed" from "no such file", which is the one thing the local
     backend knows and the Neo4j backend cannot.
     """
     backend = object.__new__(PyCodeanalyzer)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("app", None)
     backend.application = _locate_application()
     backend.project_dir = tmp_path
     return backend
 
 
 @pytest.fixture(params=["neo4j", "local"])
 def py_either(request, py, py_local):
     """Both backends, for the outcome tests that must hold identically on each."""
     return py if request.param == "neo4j" else py_local
 
diff --git a/tests/analysis/python/test_artifacts.py b/tests/analysis/python/test_artifacts.py
index aec228c..7fe025c 100644
--- a/tests/analysis/python/test_artifacts.py
+++ b/tests/analysis/python/test_artifacts.py
@@ -50,29 +50,29 @@ from cldk.models.python import (
     PyCallableOverview,
     PyConfigKey,
     PyConfigRead,
     PyConfigUseEdge,
     PyDependency,
     PyModule,
 )
 
 # -----[ shared identifiers -- both renderings below are built from these, not re-typed ]-----
 _APP = "app"
-_ART1_ID = f"can://{_APP}/artifact/pyproject.toml"
+_ART1_ID = f"can://{_APP}/{_APP}/artifact/pyproject.toml"
 _ART1_PATH = "pyproject.toml"
 _ART1_FORMAT = "toml"
 _ART1_ROLES = ["dependency-manifest"]
 _ART1_SIZE = 128
 _ART1_SHA = "aaa111"
 _ART1_SOURCE = '[project]\nname = "app"\ndependencies = ["flask>=2.0,<3"]\n'
 
-_ART2_ID = f"can://{_APP}/artifact/.env"
+_ART2_ID = f"can://{_APP}/{_APP}/artifact/.env"
 _ART2_PATH = ".env"
 _ART2_FORMAT = "properties"
 _ART2_ROLES = ["config"]
 _ART2_SIZE = 20
 _ART2_SHA = "bbb222"
 _ART2_SOURCE = "DB_URL=postgres://x\n"
 
 _CONFIG_KEY_ID = f"{_ART2_ID}@key/DB_URL"
 _CONFIG_KEY_KEY = "DB_URL"
 _CONFIG_KEY_NAMESPACE = "env"
@@ -185,39 +185,39 @@ _CONFIG_KEY_PROPS = {
     "key": _CONFIG_KEY_KEY,
     "namespace": _CONFIG_KEY_NAMESPACE,
     "value": _CONFIG_KEY_VALUE,
     "references": [],
 }
 _DEP_REL_PROPS = {"spec": _DEP_SPEC, "kind": _DEP_KIND, "extras": [], "prov": list(_DEP_PROV), "direct": True}
 _CONNECT_OVERVIEW_ROW = {
     "signature": "src.db.connect",
     "name": "connect",
     "decorators": [],
-    "id": f"can://{_APP}/python/{_MODULE_PATH}/connect",  # what get_config_readers projects; path is derived
+    "id": f"can://{_APP}/{_APP}/python/{_MODULE_PATH}/connect",  # what get_config_readers projects; path is derived
     "start_line": 5,
     "end_line": 11,
     "class_signature": None,
 }
 
 # -----[ an unresolved config read, for get_unresolved_config_reads ]-----
 _UNRESOLVED_READ_CALLEE = f"can://app/{_APP}/@external/os/getenv"
 _UNRESOLVED_READ_KEY = None
 _UNRESOLVED_READ_REASON = "non-literal"
 _UNRESOLVED_READ_PROV = ["dataflow"]
 _UNRESOLVED_READ_PROPS = {"key": _UNRESOLVED_READ_KEY, "reason": _UNRESOLVED_READ_REASON, "prov": list(_UNRESOLVED_READ_PROV)}
 
 
 def _artifacts_responder(query: str, params: dict) -> list[dict[str, Any]]:
     """Answers the four Cypher statements ``PyNeo4jBackend`` sends for this layer, plus
     ``_load_module_keys`` (construction always calls it)."""
     if "RETURN m.file_key AS k" in query:
-        return [{"k": _MODULE_PATH}]
+        return [{"k": _MODULE_PATH, "id": f"can://app/app/python/{_MODULE_PATH}"}]
     if "collect(properties(ck))" in query:  # get_artifacts
         return [
             {"p": _ART1_PROPS, "cks": []},
             {"p": _ART2_PROPS, "cks": [_CONFIG_KEY_PROPS]},
         ]
     if "DECLARES_DEPENDENCY" in query:  # get_dependencies
         # The fixture's one dependency is direct=True/ecosystem=pypi/declared_in=_ART1_ID, so
         # emulate the WHERE clause for real rather than ignoring params -- otherwise a filter test
         # against this shared fixture would pass over Neo4j for the wrong reason (a responder that
         # always answers regardless of the query it was actually asked).
@@ -277,48 +277,53 @@ def test_dependencies_record_their_declaring_manifest(py):
     deps = py.get_dependencies()
     assert any(d.name == _DEP_NAME and d.declared_in.endswith(".toml") for d in deps)
 
 
 def test_dependency_ecosystem_is_read_off_the_package_node(fake_driver):
     """Regression for a hardcoded ``ecosystem="pypi"``: the query must read ``Package.ecosystem``
     off the graph, not fabricate it -- prove it with a non-default value in the canned row."""
 
     def responder(query: str, params: dict) -> list[dict[str, Any]]:
         if "RETURN m.file_key AS k" in query:
-            return [{"k": _MODULE_PATH}]
+            return [{"k": _MODULE_PATH, "id": f"can://app/app/python/{_MODULE_PATH}"}]
         if "DECLARES_DEPENDENCY" in query:
             return [{"rel": _DEP_REL_PROPS, "name": _DEP_NAME, "ecosystem": "conda-forge", "declared_in": _ART1_ID}]
         return []
 
     fake_driver.responder = responder
     backend = PyNeo4jBackend._from_driver(fake_driver, application_name=_APP)
     deps = backend.get_dependencies()
     assert deps[0].ecosystem == "conda-forge"
 
 
 def test_dependencies_direct_only_filters_out_transitive_pins(fake_driver):
     """direct_only=True excludes lockfile-only transitive pins, on both backends. Self-contained
     (not the shared single-dependency fixture above) so a genuine direct/transitive pair exists to
     filter."""
     transitive = PyDependency(name="click", ecosystem="pypi", declared_in=_ART1_ID, direct=False)
     direct = PyDependency(
-        name=_DEP_NAME, ecosystem=_DEP_ECOSYSTEM, spec=_DEP_SPEC, kind=_DEP_KIND, declared_in=_ART1_ID,
-        direct=True, prov=list(_DEP_PROV),
+        name=_DEP_NAME,
+        ecosystem=_DEP_ECOSYSTEM,
+        spec=_DEP_SPEC,
+        kind=_DEP_KIND,
+        declared_in=_ART1_ID,
+        direct=True,
+        prov=list(_DEP_PROV),
     )
     local = object.__new__(PyCodeanalyzer)
     local.application = PyApplication(symbol_table={}, dependencies=[direct, transitive])
     assert {d.name for d in local.get_dependencies()} == {_DEP_NAME, "click"}
     assert [d.name for d in local.get_dependencies(direct_only=True)] == [_DEP_NAME]
 
     def responder(query: str, params: dict) -> list[dict[str, Any]]:
         if "RETURN m.file_key AS k" in query:
-            return [{"k": _MODULE_PATH}]
+            return [{"k": _MODULE_PATH, "id": f"can://app/app/python/{_MODULE_PATH}"}]
         if "DECLARES_DEPENDENCY" in query:
             assert "r.direct = true" in query  # the filter must run in Cypher, not in Python
             return [{"rel": _DEP_REL_PROPS, "name": _DEP_NAME, "ecosystem": _DEP_ECOSYSTEM, "declared_in": _ART1_ID}]
         return []
 
     fake_driver.responder = responder
     neo4j = PyNeo4jBackend._from_driver(fake_driver, application_name=_APP)
     assert [d.name for d in neo4j.get_dependencies(direct_only=True)] == [_DEP_NAME]
 
 
@@ -328,21 +333,21 @@ def test_dependencies_filters_are_pure_widening(py):
     assert py.get_dependencies() == py.get_dependencies(direct_only=False, ecosystem=None, declared_in=None)
 
 
 def test_dependencies_ecosystem_filter(py):
     assert [d.name for d in py.get_dependencies(ecosystem=_DEP_ECOSYSTEM)] == [_DEP_NAME]
     assert py.get_dependencies(ecosystem="conda-forge") == []
 
 
 def test_dependencies_declared_in_filter(py):
     assert [d.name for d in py.get_dependencies(declared_in=_ART1_ID)] == [_DEP_NAME]
-    assert py.get_dependencies(declared_in="can://app/artifact/nonexistent.toml") == []
+    assert py.get_dependencies(declared_in="can://app/app/artifact/nonexistent.toml") == []
 
 
 # =====================================================================================
 # get_config_keys
 # =====================================================================================
 def test_config_keys_indexed_by_id(py):
     keys = py.get_config_keys()
     assert _CONFIG_KEY_ID in keys
     assert keys[_CONFIG_KEY_ID].key == _CONFIG_KEY_KEY
 
@@ -405,21 +410,21 @@ def test_unresolved_config_reads_over_neo4j_carries_key_and_reason_but_not_site(
     reads = backend.get_unresolved_config_reads()
     assert len(reads) == 1
     assert reads[0].callee == _UNRESOLVED_READ_CALLEE
     assert reads[0].reason == _UNRESOLVED_READ_REASON
     assert reads[0].site == ""
 
 
 def test_no_unresolved_config_reads_is_an_empty_list_not_none(fake_driver):
     def responder(query: str, params: dict) -> list[dict[str, Any]]:
         if "RETURN m.file_key AS k" in query:
-            return [{"k": _MODULE_PATH}]
+            return [{"k": _MODULE_PATH, "id": f"can://app/app/python/{_MODULE_PATH}"}]
         return []
 
     fake_driver.responder = responder
     backend = PyNeo4jBackend._from_driver(fake_driver, application_name=_APP)
     assert backend.get_unresolved_config_reads() == []
 
     local = object.__new__(PyCodeanalyzer)
     local.application = PyApplication(symbol_table={})
     assert local.get_unresolved_config_reads() == []
 
@@ -428,23 +433,25 @@ def test_no_unresolved_config_reads_is_an_empty_list_not_none(fake_driver):
 # parity between backends
 # =====================================================================================
 def test_artifacts_layer_parity_between_backends(py_local, py_neo4j):
     assert py_local.get_artifacts() == py_neo4j.get_artifacts()
     assert py_local.get_dependencies() == py_neo4j.get_dependencies()
     assert py_local.get_config_keys() == py_neo4j.get_config_keys()
     assert py_local.get_config_uses() == py_neo4j.get_config_uses()
     assert py_local.get_config_uses(key=_CONFIG_KEY_KEY) == py_neo4j.get_config_uses(key=_CONFIG_KEY_KEY)
     # Path included: this projection also returns PyCallableOverview, so it has to speak the same
     # repo-relative path vocabulary as every other overview accessor -- on both backends.
-    assert [(r.signature, r.path) for r in py_local.get_config_readers(_CONFIG_KEY_KEY)] == [
-        (r.signature, r.path) for r in py_neo4j.get_config_readers(_CONFIG_KEY_KEY)
-    ] == [("src.db.connect", _MODULE_PATH)]
+    assert (
+        [(r.signature, r.path) for r in py_local.get_config_readers(_CONFIG_KEY_KEY)]
+        == [(r.signature, r.path) for r in py_neo4j.get_config_readers(_CONFIG_KEY_KEY)]
+        == [("src.db.connect", _MODULE_PATH)]
+    )
     # Deliberately not full equality: the Neo4j reconstruction always has site="" (see
     # reconstruct.unresolved_config_read's docstring) while the local backend has a real one --
     # documented projection loss, not a bug. key/reason/callee/prov still agree exactly.
     local_reads, neo4j_reads = py_local.get_unresolved_config_reads(), py_neo4j.get_unresolved_config_reads()
     assert len(local_reads) == len(neo4j_reads) == 1
     assert (local_reads[0].key, local_reads[0].reason, local_reads[0].callee, local_reads[0].prov) == (
         neo4j_reads[0].key,
         neo4j_reads[0].reason,
         neo4j_reads[0].callee,
         neo4j_reads[0].prov,
diff --git a/tests/analysis/python/test_bodies.py b/tests/analysis/python/test_bodies.py
index f06d994..2b46c57 100644
--- a/tests/analysis/python/test_bodies.py
+++ b/tests/analysis/python/test_bodies.py
@@ -79,21 +79,21 @@ def test_body_not_truncated():
 # ================================================================================================
 def test_get_source_of_a_body_node_local(py_local):
     """Line 11 (``Store.Meta.tag``'s body) is the fixture's non-ASCII line — byte-offset slicing is
     exactly what would break silently on a naive character slice.
 
     The id is ``<callable.id>@<body key>``, not ``<callable.signature>@<body key>``: #320 — the
     emitter mints ``:PyBodyNode.id`` from the callable's ``can://`` id, so composing from
     ``signature`` produced a string that named nothing in the graph.
     """
     r = py_local.locate("src/app.py", 11)
-    assert r.node_id == "can://app/python/src/app.py/src.app.Store.Meta.tag@11:12"
+    assert r.node_id == "can://app/app/python/src/app.py/src.app.Store.Meta.tag@11:12"
     assert py_local.get_source(r.node_id) == _locate_code(11, 11)
     assert "café" in py_local.get_source(r.node_id)
 
 
 def test_get_source_of_a_body_node_over_neo4j_raises_not_implemented(py):
     with pytest.raises(NotImplementedError):
         py.get_source("src.app.Store.Meta.tag@11:12")
 
 
 def test_get_source_of_an_unknown_body_key_raises_locally(py_local):
diff --git a/tests/analysis/python/test_entrypoints.py b/tests/analysis/python/test_entrypoints.py
index 744bbdd..39d9b97 100644
--- a/tests/analysis/python/test_entrypoints.py
+++ b/tests/analysis/python/test_entrypoints.py
@@ -85,51 +85,55 @@ def test_entrypoints_are_filtered_locally():
     assert eps["svc.app.handler"].kind == "function"
 
 
 def test_entrypoints_are_a_subset_of_callables_locally():
     backend = _local_backend()
     sigs = {c.signature for c in backend.get_callables_overview()}
     assert {o.signature for o in backend.get_entrypoints()} <= sigs
 
 
 def test_no_entrypoints_is_an_empty_list_not_none():
-    """"This project has no entrypoints" must be a real, distinguishable empty -- not a null."""
+    """ "This project has no entrypoints" must be a real, distinguishable empty -- not a null."""
     result = _local_backend(any_entrypoints=False).get_entrypoints()
     assert result == []
 
 
 # -----[ Neo4j backend fixture ]-----
 def _neo4j_backend(modules=("svc/app.py",)) -> PyNeo4jBackend:
     """A ``PyNeo4jBackend`` with ``__init__`` (and its real driver connection) bypassed."""
     backend = object.__new__(PyNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("app", None)
     backend.application_name = "app"
     backend._database = None
     backend._modules = list(modules)
+    backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     return backend
 
 
 def _run_keyed(rows_by_fragment: dict):
     def _run(query: str, **params):
         for fragment, result in rows_by_fragment.items():
             if fragment in query:
                 return result
         raise AssertionError(f"no canned rows for query: {query!r} (params={params})")
 
     return _run
 
 
 def test_entrypoints_query_filters_on_is_entrypoint_property():
     row = {
         "signature": "svc.app.handler",
         "name": "handler",
         "decorators": [],
-        "id": "can://app/python/svc/app.py/handler",
+        "id": "can://app/app/python/svc/app.py/handler",
         "start_line": 1,
         "end_line": 2,
         "class_signature": None,
     }
     backend = _neo4j_backend()
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"c.is_entrypoint = true": [row]})) as run:
         eps = backend.get_entrypoints()
     assert [o.signature for o in eps] == ["svc.app.handler"]
     assert isinstance(eps[0], PyCallableOverview)
     query = run.call_args.args[0]
@@ -141,41 +145,37 @@ def test_no_entrypoints_over_neo4j_is_an_empty_list_not_none():
     backend = _neo4j_backend()
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"c.is_entrypoint = true": []})):
         assert backend.get_entrypoints() == []
 
 
 def test_entrypoints_parity_between_backends():
     """Same fixture, same signatures, on both backends."""
     local_sigs = {o.signature for o in _local_backend().get_entrypoints()}
 
     common = {"decorators": [], "start_line": 1, "end_line": 2}
-    row_handler = {"signature": "svc.app.handler", "name": "handler", "id": "can://app/python/svc/app.py/handler", "class_signature": None, **common}
-    row_run = {"signature": "svc.app.Service.run", "name": "run", "id": "can://app/python/svc/app.py/Service/run", "class_signature": "svc.app.Service", **common}
+    row_handler = {"signature": "svc.app.handler", "name": "handler", "id": "can://app/app/python/svc/app.py/handler", "class_signature": None, **common}
+    row_run = {"signature": "svc.app.Service.run", "name": "run", "id": "can://app/app/python/svc/app.py/Service/run", "class_signature": "svc.app.Service", **common}
     backend = _neo4j_backend()
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"c.is_entrypoint = true": [row_handler, row_run]})):
         neo4j_sigs = {o.signature for o in backend.get_entrypoints()}
 
     assert local_sigs == neo4j_sigs == {"svc.app.handler", "svc.app.Service.run"}
 
 
 # =====================================================================================
 # Finding 2 -- get_entrypoint_classes(): the class-level sibling get_entrypoints() cannot see
 # =====================================================================================
 def _local_backend_with_class_entrypoint() -> PyCodeanalyzer:
     """A class-based view marked ``is_entrypoint`` at the class itself, with only an *unmarked*
     method -- exactly the case ``get_entrypoints()`` (callables-only) is blind to."""
-    dispatch = PyCallable(
-        name="dispatch", path="svc/views.py", signature="svc.views.AdminView.dispatch", is_entrypoint=False
-    )
-    admin_view = PyClass(
-        name="AdminView", signature="svc.views.AdminView", callables={"dispatch": dispatch}, is_entrypoint=True
-    )
+    dispatch = PyCallable(name="dispatch", path="svc/views.py", signature="svc.views.AdminView.dispatch", is_entrypoint=False)
+    admin_view = PyClass(name="AdminView", signature="svc.views.AdminView", callables={"dispatch": dispatch}, is_entrypoint=True)
     module = PyModule(file_path="svc/views.py", module_name="svc.views", types={"svc.views.AdminView": admin_view})
     backend = object.__new__(PyCodeanalyzer)
     backend.application = PyApplication(symbol_table={"svc/views.py": module})
     return backend
 
 
 def test_entrypoint_classes_are_filtered_locally():
     classes = _local_backend_with_class_entrypoint().get_entrypoint_classes()
     assert [c.signature for c in classes] == ["svc.views.AdminView"]
     assert isinstance(classes[0], PyClassOverview)
@@ -195,21 +195,21 @@ def test_no_entrypoint_classes_is_an_empty_list_not_none():
     backend = object.__new__(PyCodeanalyzer)
     backend.application = PyApplication(symbol_table={"svc/app.py": module})
     assert backend.get_entrypoint_classes() == []
 
 
 def test_entrypoint_classes_query_filters_on_is_entrypoint_property():
     row = {
         "signature": "svc.views.AdminView",
         "name": "AdminView",
         "decorators": [],
-        "id": "can://app/python/svc/views.py/AdminView",
+        "id": "can://app/app/python/svc/views.py/AdminView",
         "start_line": 1,
         "end_line": 10,
     }
     backend = _neo4j_backend(modules=("svc/views.py",))  # the row's path is derived from its id and verified against these
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"cl.is_entrypoint = true": [row]})) as run:
         classes = backend.get_entrypoint_classes()
     assert [c.signature for c in classes] == ["svc.views.AdminView"]
     assert isinstance(classes[0], PyClassOverview)
     query = run.call_args.args[0]
     assert "cl.id STARTS WITH $prefix" in query
@@ -222,21 +222,21 @@ def test_no_entrypoint_classes_over_neo4j_is_an_empty_list_not_none():
         assert backend.get_entrypoint_classes() == []
 
 
 def test_entrypoint_classes_parity_between_backends():
     local_sigs = {c.signature for c in _local_backend_with_class_entrypoint().get_entrypoint_classes()}
 
     row = {
         "signature": "svc.views.AdminView",
         "name": "AdminView",
         "decorators": [],
-        "id": "can://app/python/svc/views.py/AdminView",
+        "id": "can://app/app/python/svc/views.py/AdminView",
         "start_line": 1,
         "end_line": 10,
     }
     backend = _neo4j_backend(modules=("svc/views.py",))  # the row's path is derived from its id and verified against these
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"cl.is_entrypoint = true": [row]})):
         neo4j_sigs = {c.signature for c in backend.get_entrypoint_classes()}
 
     assert local_sigs == neo4j_sigs == {"svc.views.AdminView"}
 
 
diff --git a/tests/analysis/python/test_external_symbols.py b/tests/analysis/python/test_external_symbols.py
index c38c1a6..4e1731b 100644
--- a/tests/analysis/python/test_external_symbols.py
+++ b/tests/analysis/python/test_external_symbols.py
@@ -168,23 +168,27 @@ def test_get_external_symbols_empty_is_a_real_empty():
     assert backend.get_external_symbols() == {}
 
 
 # =====================================================================================
 # Neo4j backend
 # =====================================================================================
 def _neo4j_backend(modules=("src/app.py",)) -> PyNeo4jBackend:
     """A ``PyNeo4jBackend`` with ``__init__`` (and its real driver connection) bypassed -- same
     construction ``test_entrypoints.py`` uses."""
     backend = object.__new__(PyNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("app", None)
     backend.application_name = "app"
     backend._database = None
     backend._modules = list(modules)
+    backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     return backend
 
 
 def _run_keyed(rows_by_fragment: dict):
     def _run(query: str, **params):
         for fragment, result in rows_by_fragment.items():
             if fragment in query:
                 return result
         raise AssertionError(f"no canned rows for query: {query!r} (params={params})")
 
@@ -232,21 +236,21 @@ def test_neo4j_unresolved_callee_stays_none():
 def test_neo4j_get_external_symbols_filters_by_id_prefix():
     row = {"p": {"id": VALUEERROR_ID, "name": "__init__", "module": "builtins.ValueError"}}
     backend = _neo4j_backend()
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"STARTS WITH": [row]})) as run:
         ext = backend.get_external_symbols()
     assert set(ext) == {VALUEERROR_ID}
     assert ext[VALUEERROR_ID].name == "__init__"
     assert ext[VALUEERROR_ID].module == "builtins.ValueError"
     query, params = run.call_args.args[0], run.call_args.kwargs
     assert "e.id STARTS WITH $prefix" in query
-    assert params["prefix"] == "can://app/@external/"
+    assert params["prefix"] == "can://app/app/@external/"
     assert "SET" not in query and "CREATE" not in query and "MERGE" not in query and "DELETE" not in query
 
 
 def test_neo4j_get_external_symbols_empty_is_a_real_empty():
     backend = _neo4j_backend()
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"STARTS WITH": []})):
         assert backend.get_external_symbols() == {}
 
 
 # =====================================================================================
@@ -260,25 +264,29 @@ def test_callsites_for_parity_between_backends():
     rows = [
         {"owner": "src.app.Store.key", "p": {"method_name": "ValueError", "start_line": 7, "start_column": 18}, "callee": VALUEERROR_ID},
         {"owner": "src.app.Store.helper", "p": {"method_name": "key", "start_line": 11, "start_column": 15}, "callee": "src.app.Store.key"},
         {"owner": "src.app.Store.dyn", "p": {"method_name": "whatever", "start_line": 15, "start_column": 10}, "callee": None},
     ]
     backend = _neo4j_backend()
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"PY_RESOLVES_TO": rows})):
         neo4j = backend.get_callsites_for(["src.app.Store.key", "src.app.Store.helper", "src.app.Store.dyn"])
     neo4j_sigs = {sig: [s.callee_signature for s in sites] for sig, sites in neo4j.items()}
 
-    assert local_sigs == neo4j_sigs == {
-        "src.app.Store.key": [VALUEERROR_ID],
-        "src.app.Store.helper": ["src.app.Store.key"],
-        "src.app.Store.dyn": [None],
-    }
+    assert (
+        local_sigs
+        == neo4j_sigs
+        == {
+            "src.app.Store.key": [VALUEERROR_ID],
+            "src.app.Store.helper": ["src.app.Store.key"],
+            "src.app.Store.dyn": [None],
+        }
+    )
 
 
 def test_get_external_symbols_parity_between_backends():
     local_ext = _local_backend().get_external_symbols()
 
     row = {"p": {"id": VALUEERROR_ID, "name": "__init__", "module": "builtins.ValueError"}}
     backend = _neo4j_backend()
     with patch.object(PyNeo4jBackend, "_run", side_effect=_run_keyed({"STARTS WITH": [row]})):
         neo4j_ext = backend.get_external_symbols()
 
diff --git a/tests/analysis/python/test_locate.py b/tests/analysis/python/test_locate.py
index ab1fa24..41b1f99 100644
--- a/tests/analysis/python/test_locate.py
+++ b/tests/analysis/python/test_locate.py
@@ -276,29 +276,35 @@ def test_locate_and_resolve_seek_the_pysymbol_index(py, fake_driver):
     1.4.1 graph carries the old id grammar and would answer nothing), so there is only one served
     generation left and nothing to compare it against; ``test_probe_serves_every_generation_from
     _the_floor_up_silently`` is where the served range is pinned now."""
     py.locate("src/app.py", 21)
     assert "OPTIONAL MATCH (c:PyCallable:PySymbol) " in next(s for s in fake_driver.statements if "UNWIND $positions AS pos" in s)
     assert PyNeo4jBackend._RESOLVE_CALLABLE_QUERY.startswith("MATCH (c:PyCallable:PySymbol) WHERE c.id STARTS WITH $prefix")
 
 
 def test_locate_scope_is_actually_honoured(py):
     """Not just present in the text: attach as another application and no callable matches."""
-    py.application_name = "some_other_application"
+    from cldk.analysis.commons.identity import resolve_identity
+
+    py.identity = resolve_identity("some_other_application", None)
+    py.application_name = py.identity.application_name
+    py._module_ids = {key: py.identity.application_id + "/python/" + key for key in py._modules}
     r = py.locate("src/app.py", 21)
     assert r.callable is None
     assert "module_scope" in [d.code for d in r.diagnostics]
 
 
-def test_locate_normalises_the_path(py_either):
+def test_locate_normalises_the_path(py_either, tmp_path):
     """A scanner prints ``./src/app.py`` or an absolute path; neither is the symbol-table key."""
-    for path in ("./src/app.py", "src/./app.py", "/home/ci/checkout/src/app.py"):
+    py_either.source_root = tmp_path
+    py_either.project_dir = tmp_path
+    for path in ("./src/app.py", "src/./app.py", str(tmp_path / "src/app.py")):
         r = py_either.locate(path, 21)
         assert r.callable is not None, path
         assert r.callable.signature == "src.app.Store.key"
         assert r.module.path == "src/app.py"
 
 
 def test_locate_not_in_graph_message_says_what_the_backend_knows(py, py_local, tmp_path):
     """``file_not_in_graph`` can't tell "not analysed" from "not on disk" — but the local backend
     can look, and the Neo4j backend says plainly that it cannot."""
     (tmp_path / "present.py").write_text("x = 1\n")
diff --git a/tests/analysis/python/test_module_key_of.py b/tests/analysis/python/test_module_key_of.py
index 921114e..e108048 100644
--- a/tests/analysis/python/test_module_key_of.py
+++ b/tests/analysis/python/test_module_key_of.py
@@ -14,54 +14,54 @@
 # limitations under the License.
 ################################################################################
 
 """``module_key_of``: the repo-relative module key a ``can://`` id embeds, recovered by verified
 longest match against the application's known keys -- never by splitting on ``.py/``."""
 
 import pytest
 
 from cldk.analysis.python.neo4j.reconstruct import module_key_of
 
-APP = "can://app/python/"
+APP = "can://app/app/python/"
 
 
 def test_module_key_is_the_id_segment_up_to_the_first_py_boundary():
     known = {"addons/account/models/account_move.py"}
     node_id = "can://odoo-slim-19/python/addons/account/models/account_move.py/AccountMove/write(self,vals)"
     assert module_key_of(node_id, "can://odoo-slim-19/python/", known) == "addons/account/models/account_move.py"
 
 
 def test_a_directory_named_like_a_module_cannot_mis_key():
     known = {"pkg/x.py/real.py"}
-    assert module_key_of("can://app/python/pkg/x.py/real.py/f()", APP, known) == "pkg/x.py/real.py"
+    assert module_key_of("can://app/app/python/pkg/x.py/real.py/f()", APP, known) == "pkg/x.py/real.py"
 
 
 def test_a_key_outside_the_application_raises_rather_than_guesses():
     with pytest.raises(KeyError):
-        module_key_of("can://app/python/gone.py/f()", APP, {"kept.py"})
+        module_key_of("can://app/app/python/gone.py/f()", APP, {"kept.py"})
 
 
 def test_a_ghost_id_has_no_module_key():
     with pytest.raises(KeyError):
-        module_key_of("can://app/@external/os/path", APP, {"a.py"})
+        module_key_of("can://app/app/@external/os/path", APP, {"a.py"})
 
 
 def test_a_body_node_id_keys_to_its_callables_module():
     """A body node's id is its callable's id plus ``@<key>``, and the key itself may contain
     ``/`` (``@15:2/actual_in:0``); the module key is still the verified prefix, so a slice row can
     derive its file from the body node's own ``ref``."""
     known = {"pkg/a.py", "pkg"}
-    assert module_key_of("can://app/python/pkg/a.py/f(x)@15:2/actual_in:0", APP, known) == "pkg/a.py"
+    assert module_key_of("can://app/app/python/pkg/a.py/f(x)@15:2/actual_in:0", APP, known) == "pkg/a.py"
 
 
 def test_the_module_id_itself_keys_to_its_own_key():
-    assert module_key_of("can://app/python/pkg/a.py", APP, {"pkg/a.py"}) == "pkg/a.py"
+    assert module_key_of("can://app/app/python/pkg/a.py", APP, {"pkg/a.py"}) == "pkg/a.py"
 
 
 def test_an_id_under_another_application_raises():
     with pytest.raises(KeyError):
         module_key_of("can://app-b/python/pkg/a.py/f()", APP, {"pkg/a.py"})
 
 
 # ----------------------------------------------------------------------------------------------
 # The backend's use of it: the key set is read once at attach, from a graph the SDK does not own.
 # ----------------------------------------------------------------------------------------------
@@ -70,36 +70,35 @@ from cldk.utils.exceptions import CodeanalyzerExecutionException  # noqa: E402
 
 
 def _overview_row(node_id: str) -> dict:
     return {"id": node_id, "signature": node_id.rsplit("/", 1)[1], "name": "f", "decorators": None, "start_line": 1, "end_line": 2, "class_signature": None}
 
 
 def test_a_module_added_since_attach_is_found_after_one_reload_and_a_foreign_id_is_a_typed_error(fake_driver):
     """A re-emit can add a module after attach; its callables must not take down a whole-application
     answer. One miss reloads the key set once and retries. A second miss is a real defect, raised
     as an SDK exception that names the key count and never the ``can://`` id (E6)."""
-    graph = {"modules": ["a.py"], "callables": ["can://app/python/a.py/f"]}
+    graph = {"modules": ["a.py"], "callables": ["can://app/app/python/a.py/f"]}
 
     def responder(query, params):
         if "RETURN m.file_key AS k" in query:
-            return [{"k": k} for k in graph["modules"]]
+            return [{"k": k, "id": f"can://app/app/python/{k}"} for k in graph["modules"]]
         if "OPTIONAL MATCH (owner:PyClass)-[:PY_HAS_METHOD]->(c)" in query:
             return [_overview_row(i) for i in graph["callables"]]
         return []
 
     fake_driver.responder = responder
     backend = PyNeo4jBackend._from_driver(fake_driver, application_name="app")
     loads = lambda: sum("RETURN m.file_key AS k" in s for s in fake_driver.statements)  # noqa: E731
     assert loads() == 1
 
     graph["modules"].append("b.py")  # the graph moved under us
-    graph["callables"].append("can://app/python/b.py/g")
+    graph["callables"].append("can://app/app/python/b.py/g")
     assert {o.path for o in backend.get_callables_overview()} == {"a.py", "b.py"}
     assert loads() == 2, "one reload, on the first miss"
 
-    graph["callables"].append("can://app/python/zzz.py/h")  # no such module, before or after reload
+    graph["callables"].append("can://app/app/python/zzz.py/h")  # no such module, before or after reload
     with pytest.raises(CodeanalyzerExecutionException) as e:
         backend.get_callables_overview()
     assert loads() == 3
     assert "changed since attach" in str(e.value) and "2 module keys" in str(e.value)
     assert "can://" not in str(e.value) and "zzz" not in str(e.value)
-
diff --git a/tests/analysis/python/test_neo4j_multi_application_scope.py b/tests/analysis/python/test_neo4j_multi_application_scope.py
index e975e40..60d7d41 100644
--- a/tests/analysis/python/test_neo4j_multi_application_scope.py
+++ b/tests/analysis/python/test_neo4j_multi_application_scope.py
@@ -145,21 +145,21 @@ _SHARED_FUNCTIONS: Dict[str, Dict[str, Any]] = {
 _CLASSES: List[Dict[str, Any]] = [
     _node(APP_A_MODULE, "Widget", signature=CLASS_SIG, name="Widget", path=APP_A_MODULE),
     _node(APP_B_MODULE, "Widget", signature=CLASS_SIG, name="Widget", path=APP_B_MODULE),
 ]
 
 #: What ``_SOURCES`` (``describe``) may be handed, per label and per application: the shared method
 #: (by signature), each application's one call-site body node, and one ``@external`` ghost each.
 _SOURCE_NODES: Dict[str, List[Dict[str, Any]]] = {
     "PyCallable": list(_CHILDREN["class_methods"][1].values()),
     "PyBodyNode": list(_CHILDREN["callable_callsites"][1].values()),
-    "PyExternal": [{"id": f"can://{app}/@external/os/path", "name": "path", "module": "os"} for app in (APP_A, APP_B)],
+    "PyExternal": [{"id": f"can://{app}/{app}/@external/os/path", "name": "path", "module": "os"} for app in (APP_A, APP_B)],
 }
 
 #: The four spellings of the application scope a statement may carry: the whole application
 #: (``$prefix``); for a narrowed bulk fetch, a list of per-module prefixes (``$prefixes``); for
 #: ``locate``, one module's own prefix per position (``pos.module_prefix``, minted from the same
 #: application name); and for ``_EDGE_VARS``, one **callable's** own ref (``$callable_prefix``).
 #: ``file_key IN $mods`` is *not* one: a module key is not application-stamped.
 #:
 #: The last two are narrower than the application and still satisfy this audit, for the same reason
 #: and only that reason: both are minted from an id that already embeds the application name, so a
@@ -253,37 +253,44 @@ def _fake_two_app_cypher(query: str, **params: Any) -> List[Dict[str, Any]]:
 
 def _two_app_backend(record: List[str] | None = None) -> PyNeo4jBackend:
     """A backend scoped to application A over a fake driver holding A and B."""
 
     def run(query: str, **params: Any) -> List[Dict[str, Any]]:
         if record is not None:
             record.append(query)
         return _fake_two_app_cypher(query, **params)
 
     backend = object.__new__(PyNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity(APP_A, None)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity(APP_A, None)
     backend.application_name = APP_A
     backend._database = None
     backend._driver = None
     backend._session_obj = None
     backend._modules = [APP_A_MODULE, SHARED_MODULE]
+    backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     backend._call_graph = None
     backend._run = run
     return backend
 
 
 def test_the_fake_graph_carries_no_module_property():
     """What a 1.4.1 graph is: scope lives in the id, and there is no ``_module`` to fall back on.
     A fixture that grew the property back would let a ``_module``-scoped statement pass here while
     returning nothing on a real graph."""
     nodes = [c for _, by_module in _CHILDREN.values() for c in by_module.values()] + _CLASSES + list(_SHARED_FUNCTIONS.values())
     assert nodes and not any("_module" in n for n in nodes)
-    assert all(n["id"].startswith(("can://app_a/python/", "can://app_b/python/")) for n in nodes)
+    assert all(n["id"].startswith(("can://app_a/app_a/python/", "can://app_b/app_b/python/")) for n in nodes)
 
 
 def test_per_parent_path_does_not_leak_another_applications_children():
     """``get_class`` must not merge application B's methods into application A's class."""
     cls = _two_app_backend().get_class(CLASS_SIG)
     assert cls is not None, "the application's own class came back empty -- the statement scoped on a property the graph does not carry"
     assert set(cls.callables) == {"alpha_method"}, "per-parent child fetch leaked another application's members"
 
 
 def test_scoped_and_bulk_paths_agree_across_applications():
@@ -369,25 +376,21 @@ _MATCHES_BY_ID = re.compile(r"\bid\s*:\s*\$|\.id IN \$")
 
 #: Class-level strings that are Cypher but not a whole statement: appended to a scoped ``MATCH``
 #: at each use, so their scope is judged at the use sites (below), not on the fragment.
 _FRAGMENTS = {"_OVERVIEW_PROJECTION"}
 
 
 def _class_level_statements() -> Dict[str, str]:
     """Every class attribute that starts a Cypher clause -- not only ``MATCH``: filtering on that
     alone silently skipped ``_OVERVIEW_PROJECTION`` (``OPTIONAL MATCH``) and ``_LOCATE_QUERY``
     (``UNWIND``), and an audit that cannot see a statement cannot protect it."""
-    return {
-        name: value
-        for name, value in vars(PyNeo4jBackend).items()
-        if isinstance(value, str) and re.match(r"(MATCH|OPTIONAL MATCH|UNWIND|CALL)\b", value.lstrip())
-    }
+    return {name: value for name, value in vars(PyNeo4jBackend).items() if isinstance(value, str) and re.match(r"(MATCH|OPTIONAL MATCH|UNWIND|CALL)\b", value.lstrip())}
 
 
 def _inline_statements() -> Dict[str, str]:
     """The Cypher written *inline* at every ``self._run(`` site, keyed ``<method>@<line>`` -- the
     statements the class-attribute enumeration cannot see (about twenty of the 44 sites).
 
     Reassembled from the class's own source: string constants verbatim; f-strings and ``+`` chains
     joined; ``.format(...)`` unwrapped to its receiver; ``self.<ATTR>`` replaced by the class-level
     string it names; a local name replaced by every assignment to it in the enclosing method, in
     order (``query += " AND ..."``); anything else becomes ``{…}``. A site whose first argument is
@@ -420,21 +423,28 @@ def _inline_statements() -> Dict[str, str]:
                 return text(e.left, depth + 1) + text(e.right, depth + 1)
             if isinstance(e, ast.Call) and isinstance(e.func, ast.Attribute) and e.func.attr == "format":
                 return text(e.func.value, depth + 1)
             if isinstance(e, ast.Attribute) and isinstance(e.value, ast.Name) and e.value.id == "self" and e.attr in class_strings:
                 return class_strings[e.attr]
             if isinstance(e, ast.Name) and e.id in assigned:
                 return "".join(text(v, depth + 1) for v in assigned[e.id])
             return "{…}"
 
         for call in ast.walk(fn):
-            if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "_run" and isinstance(call.func.value, ast.Name) and call.func.value.id == "self" and call.args:
+            if (
+                isinstance(call, ast.Call)
+                and isinstance(call.func, ast.Attribute)
+                and call.func.attr == "_run"
+                and isinstance(call.func.value, ast.Name)
+                and call.func.value.id == "self"
+                and call.args
+            ):
                 out.setdefault(f"{fn.name}@{call.lineno}", text(call.args[0]))
     return out
 
 
 #: The four ways a statement stays inside one application. ``introspection`` is the server, not
 #: the data (``CALL db.relationshipTypes()``, ``CALL dbms.components()``); ``application`` walks out
 #: from ``(:PyApplication {id: $app_id})`` and cannot leave it; ``prefix`` and ``id`` are the two
 #: ``can://``-stamped forms the docstring below explains. Anything else is unscoped.
 _INTROSPECTION = re.compile(r"^\s*CALL (db|dbms)\.")
 _ANCHORED_ON_THE_APPLICATION = re.compile(r"\(\w*:PyApplication \{id: \$app_id\}\)")
@@ -453,34 +463,68 @@ def _scope_kind(statement: str) -> str | None:
 
 
 def _every_statement() -> Dict[str, str]:
     """Class-level statements (minus fragments) plus every inline one that resolved to Cypher."""
     inline = {name: s for name, s in _inline_statements().items() if s != "{…}"}
     return {**{n: s for n, s in _class_level_statements().items() if n not in _FRAGMENTS}, **inline}
 
 
 def test_the_audit_sees_the_dataflow_statements_too():
     names = set(_class_level_statements())
-    for expected in ("_REACHES", "_CONE", "_PATHS", "_CALL_PATHS", "_TAINT", "_EDGE_VARS", "_VALUE_REACHES", "_CALLEE_VALUES", "_SOURCES", "_SLICE", "_CALLERS", "_CALLEES", "_OWN_EDGES", "_LOCATE_QUERY", "_OVERVIEW_PROJECTION"):
+    for expected in (
+        "_REACHES",
+        "_CONE",
+        "_PATHS",
+        "_CALL_PATHS",
+        "_TAINT",
+        "_EDGE_VARS",
+        "_VALUE_REACHES",
+        "_CALLEE_VALUES",
+        "_SOURCES",
+        "_SLICE",
+        "_CALLERS",
+        "_CALLEES",
+        "_OWN_EDGES",
+        "_LOCATE_QUERY",
+        "_OVERVIEW_PROJECTION",
+    ):
         assert expected in names, f"{expected} is not a class-level statement any more; move it back or extend the audit"
 
 
 def test_the_audit_sees_every_inline_statement_too():
     """One harvested statement per ``self._run(`` in the source -- a site the harvester cannot
     reassemble shows up as ``{…}`` and must be one of the three known indirections, so a new
     ``self._run(some_variable)`` cannot slip past unjudged."""
     inline = _inline_statements()
     assert len(inline) == inspect.getsource(PyNeo4jBackend).count("self._run("), "a self._run( site the harvester did not see"
     indirect = sorted(name.split("@")[0] for name, s in inline.items() if s == "{…}")
     assert indirect == ["_children", "_collect", "_paths"], f"unjudged statements passed through a variable: {indirect}"
     assert all(re.match(r"(MATCH|OPTIONAL MATCH|UNWIND|CALL)\b", s.lstrip()) for s in inline.values() if s != "{…}"), "an inline statement does not start with a Cypher clause"
-    for expected in ("get_source", "get_class", "get_python_file", "get_method_bodies", "resolve_value", "_call_rows", "_bounded_call_rows", "_get_module_functions", "get_callsites_for", "get_config_uses", "get_config_readers", "get_decorated_callables", "get_entrypoints", "get_entrypoint_classes", "_probe_resolution_edges", "_own_edges", "get_dependencies"):
+    for expected in (
+        "get_source",
+        "get_class",
+        "get_python_file",
+        "get_method_bodies",
+        "resolve_value",
+        "_call_rows",
+        "_bounded_call_rows",
+        "_get_module_functions",
+        "get_callsites_for",
+        "get_config_uses",
+        "get_config_readers",
+        "get_decorated_callables",
+        "get_entrypoints",
+        "get_entrypoint_classes",
+        "_probe_resolution_edges",
+        "_own_edges",
+        "get_dependencies",
+    ):
         assert any(name.startswith(expected + "@") for name in inline), f"{expected}'s statement is not harvested"
 
 
 def test_no_statement_names_pycannode():
     """1.4.1's ``:PyCanNode`` label was measured and rejected as a seek anchor (the spec's F2 table)
     and does not exist on 1.4.0 graphs; a statement naming it would match nothing there."""
     assert [name for name, s in _every_statement().items() if "PyCanNode" in s] == []
 
 
 @pytest.mark.parametrize("name", sorted(_every_statement()))
@@ -525,13 +569,12 @@ def test_the_reachability_walk_scopes_all_three_of_its_positions():
     ``m``, and it was unpredicated: the statement as a whole carried a prefix, so the per-statement
     audit above judged it scoped while its final node was free to be another application's.
 
     This is the gap a per-variable audit closes. TypeScript and Java have one; Python does not yet
     (python-sdk#363), so this pins the one statement where the difference was measurable.
     """
     statement = _class_level_statements()["_REACHES"]
     for position in ("a", "x", "m"):
         assert f"{position}.id STARTS WITH $prefix" in statement, f"_REACHES leaves {position!r} unscoped"
     assert "y.id STARTS WITH $prefix" not in statement, (
-        "predicating both hop endpoints checks every interior node twice; measured 623.9s against "
-        "3.2s on a 5,000-node cyclic graph for the same answer"
+        "predicating both hop endpoints checks every interior node twice; measured 623.9s against " "3.2s on a 5,000-node cyclic graph for the same answer"
     )
diff --git a/tests/analysis/python/test_python_analysis.py b/tests/analysis/python/test_python_analysis.py
index 3a84f2e..c585f12 100644
--- a/tests/analysis/python/test_python_analysis.py
+++ b/tests/analysis/python/test_python_analysis.py
@@ -66,22 +66,22 @@ def test_cache_dir_keyed_by_language_through_facade(monkeypatch, tmp_path):
     captured = {}
 
     class FakeBackend:
         def __init__(self, **kwargs):
             captured.update(kwargs)
 
     monkeypatch.setattr("cldk.analysis.python.python_analysis.PyCodeanalyzer", FakeBackend)
 
     cache = tmp_path / "mycache"
     CLDK(language="python").analysis(project_path=tmp_path, cache_dir=cache)
-    assert captured["cache_dir"].name == "python"
-    assert captured["cache_dir"].parent.name == "mycache"
+    assert captured["cache_dir"].parent.name == "python"
+    assert captured["cache_dir"].parent.parent.name == "mycache"
     assert "analysis_backend_path" not in captured
 
 
 def test_python_ignores_removed_analysis_backend_path(monkeypatch, tmp_path):
     """analysis_backend_path is removed; the deprecated shim ignores it with a warning."""
     captured = {}
 
     class FakeBackend:
         def __init__(self, **kwargs):
             captured.update(kwargs)
diff --git a/tests/analysis/python/test_python_method_lookup.py b/tests/analysis/python/test_python_method_lookup.py
index 36e00b1..ced4028 100644
--- a/tests/analysis/python/test_python_method_lookup.py
+++ b/tests/analysis/python/test_python_method_lookup.py
@@ -114,25 +114,29 @@ def _fake_cypher(classes, methods, modules, call_edges):
 
 
 def _neo4j_backend():
     """A bare PyNeo4jBackend with ``_run`` stubbed (no live server, no __init__ side effects)."""
     entry_props = {"name": "entry", "signature": ENTRY_SIG, "path": "pkg/mod.py"}
     helper_props = {"name": "helper", "signature": HELPER_SIG, "path": "pkg/mod.py"}
     modules = {MODULE_NAME: {"file_key": "pkg/mod.py", "functions": [entry_props, helper_props]}}
     call_edges = [(ENTRY_SIG, HELPER_SIG)]
 
     backend = object.__new__(PyNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("test_app", None)
     backend.application_name = "test_app"
     backend._database = None
     backend._driver = None
     backend._session_obj = None
     backend._modules = ["pkg/mod.py"]
+    backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     backend._call_graph = None
     backend._run = _fake_cypher(classes={}, methods={}, modules=modules, call_edges=call_edges)
     return backend
 
 
 BACKEND_FACTORIES = {"local": _local_backend, "neo4j": _neo4j_backend}
 
 
 # ----------------------------------------------------------------------------------------------
 # get_method
@@ -202,25 +206,29 @@ def test_get_all_callers_missing_method_stays_false_empty():
 # regression (9edc812): a PY_CALLS target landing on a signature-less :PyExternal ghost must not
 # reach _build_call_graph as a bare None -- it must already be coalesced to the external can-id,
 # same as a live graph's own query text produces.
 # ----------------------------------------------------------------------------------------------
 def test_get_all_callees_external_target_survives_as_external_keyed_node_neo4j():
     external_id = "can://test_app/@external/builtins.print"
     modules = {MODULE_NAME: {"file_key": "pkg/mod.py", "functions": [{"name": "entry", "signature": ENTRY_SIG, "path": "pkg/mod.py"}]}}
     call_edges = [(ENTRY_SIG, None, external_id)]
 
     backend = object.__new__(PyNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("test_app", None)
     backend.application_name = "test_app"
     backend._database = None
     backend._driver = None
     backend._session_obj = None
     backend._modules = ["pkg/mod.py"]
+    backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     backend._call_graph = None
     backend._run = _fake_cypher(classes={}, methods={}, modules=modules, call_edges=call_edges)
 
     result = backend.get_all_callees(MODULE_NAME, "entry")
     assert [c["callee_signature"] for c in result["callee_details"]] == [external_id]
 
     graph = backend.get_call_graph()
     assert None not in graph.nodes
     assert external_id in graph.nodes
 
@@ -253,25 +261,29 @@ def test_get_method_still_resolves_class_methods_local():
     assert method is not None
     assert method.signature == "pkg.models.Entity.greet"
     assert backend.get_method("pkg.models.Entity", "nope") is None
 
 
 def test_get_method_still_resolves_class_methods_neo4j():
     entity_props = {"name": "Entity", "signature": "pkg.models.Entity"}
     greet_props = {"name": "greet", "signature": "pkg.models.Entity.greet", "path": "pkg/models.py"}
 
     backend = object.__new__(PyNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("test_app", None)
     backend.application_name = "test_app"
     backend._database = None
     backend._driver = None
     backend._session_obj = None
     backend._modules = ["pkg/models.py"]
+    backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     backend._call_graph = None
     backend._run = _fake_cypher(
         classes={"pkg.models.Entity": entity_props},
         methods={"pkg.models.Entity": [greet_props]},
         modules={},
         call_edges=[],
     )
 
     method = backend.get_method("pkg.models.Entity", "greet")
     assert method is not None
diff --git a/tests/analysis/python/test_python_neo4j_selection.py b/tests/analysis/python/test_python_neo4j_selection.py
index 5131b1a..4317289 100644
--- a/tests/analysis/python/test_python_neo4j_selection.py
+++ b/tests/analysis/python/test_python_neo4j_selection.py
@@ -83,21 +83,21 @@ def test_no_config_keys_cache_dir_by_language(tmp_path):
 
         PythonAnalysis(
             project_dir=str(tmp_path),
             analysis_level="symbol_table",
             target_files=None,
             eager_analysis=False,
             backend=PyCodeAnalyzerConfig(cache_dir=str(tmp_path / "cache")),
         )
 
         _, kwargs = backend_cls.call_args
-        assert kwargs["cache_dir"] == (tmp_path / "cache" / "python")
+        assert kwargs["cache_dir"].parent == (tmp_path / "cache" / "python")
 
 
 def test_missing_project_dir_without_config_raises():
     """Without a Neo4j config, project_dir is still required (no source_code mode for Python)."""
     with pytest.raises(ValueError, match="project_dir is required"):
         PythonAnalysis(
             project_dir=None,
             analysis_level="symbol_table",
             target_files=None,
             eager_analysis=False,
diff --git a/tests/analysis/python/test_python_taint.py b/tests/analysis/python/test_python_taint.py
index 00f9280..7057696 100644
--- a/tests/analysis/python/test_python_taint.py
+++ b/tests/analysis/python/test_python_taint.py
@@ -29,21 +29,21 @@ import inspect
 import pytest
 
 from cldk.analysis.commons.results import Diagnostic, FlowPath, PathHop, SliceNode
 from cldk.analysis.python.backend import PythonAnalysisBackend
 from cldk.analysis.python.python_analysis import PythonAnalysis
 from cldk.utils.exceptions.exceptions import SelectorNotInGraph
 
 
 def _value(name: str, within: str) -> SliceNode:
     """A resolved value, addressed as this surface addresses one: a name plus the callable it enters."""
-    return SliceNode(file="app.py", line=1, callable=within, kind="parameter", name=name, ref=f"can://app/python/app.py/{within}#{name}")
+    return SliceNode(file="app.py", line=1, callable=within, kind="parameter", name=name, ref=f"can://app/app/python/app.py/{within}#{name}")
 
 
 def _witness(frm: SliceNode, to: SliceNode) -> FlowPath:
     return FlowPath(hops=[PathHop(frm=frm, to=to, via="data", var="answer", prov=["ssa"])])
 
 
 class _Recording(PythonAnalysisBackend):
     """The contract with only the four methods ``taint()`` touches, and a walk that records its call.
 
     ``__abstractmethods__`` is cleared below rather than the other fifty-odd methods being stubbed:
@@ -56,21 +56,21 @@ class _Recording(PythonAnalysisBackend):
         self._blocked = dict(blocked or {})
         self._edge_vars = set(edge_vars)
         self.resolved = []
         self.walks = []
 
     def resolve_value(self, name, *, within):
         self.resolved.append((name, within))
         return _value(name, within)
 
     def resolve_callable(self, name, *, in_class=None, in_module=None):
-        return SliceNode(file="app.py", line=1, callable=name, kind="callable", name=None, ref=f"can://app/python/app.py/{name}")
+        return SliceNode(file="app.py", line=1, callable=name, kind="callable", name=None, ref=f"can://app/app/python/app.py/{name}")
 
     def _edge_vars_in(self, callable_id):
         return self._edge_vars
 
     def _taint_walk(self, srcs, dsts, *, cuts, cut_callables, depth, max_paths):
         self.walks.append({"srcs": [n.ref for n in srcs], "dsts": [n.ref for n in dsts], "cuts": cuts, "cut_callables": cut_callables, "depth": depth, "max_paths": max_paths})
         return self._rows, self._blocked
 
 
 _Recording.__abstractmethods__ = frozenset()
@@ -194,22 +194,22 @@ def test_two_selectors_that_resolve_to_the_same_position_are_one_pair():
     assert len(capped.paths) == 2 and not capped.complete, "the cap holds per distinct pair"
     assert once.exhausted == [] and capped.exhausted == []
 
 
 def test_the_sanitizer_selectors_are_resolved_through_the_edge_vars_hook():
     """Step 4 of the order: the two shapes reach the walk as ``$cuts`` and ``$cut_callables``, and a
     variable selector is checked against the vars on real SDG edges rather than ``resolve_value``,
     which addresses only parameters."""
     backend = _Recording()
     backend.taint([("x", "f")], [("y", "g")], sanitizers=[("answer", "f"), "scrub"])
-    assert backend.walks[0]["cuts"] == [{"var": "answer", "prefix": "can://app/python/app.py/f"}]
-    assert backend.walks[0]["cut_callables"] == ["can://app/python/app.py/scrub"]
+    assert backend.walks[0]["cuts"] == [{"var": "answer", "prefix": "can://app/app/python/app.py/f"}]
+    assert backend.walks[0]["cut_callables"] == ["can://app/app/python/app.py/scrub"]
 
 
 def test_a_sanitizer_that_does_not_resolve_raises_before_the_walk():
     backend = _Recording(edge_vars=())
     with pytest.raises(SelectorNotInGraph):
         backend.taint([("x", "f")], [("y", "g")], sanitizers=[("answer", "f")])
     assert backend.walks == [], "sanitizers are resolved before the traversal, not applied after it"
 
 
 def test_complete_is_the_batch_flag_so_one_skipped_pair_flips_it_and_a_bigger_cap_will_not_help():
diff --git a/tests/analysis/python/test_resolution_probe.py b/tests/analysis/python/test_resolution_probe.py
index e0e3229..fa254c1 100644
--- a/tests/analysis/python/test_resolution_probe.py
+++ b/tests/analysis/python/test_resolution_probe.py
@@ -49,16 +49,16 @@ def test_probe_is_scoped_to_this_applications_modules(fake_driver):
     def responder(query, params):
         seen_queries.append((query, params))
         return []
 
     fake_driver.responder = responder
     PyNeo4jBackend._from_driver(fake_driver, application_name="app")
     probe_calls = [(q, p) for q, p in seen_queries if "PY_RESOLVES_TO" in q]
     assert len(probe_calls) == 1
     query, params = probe_calls[0]
     assert "s.id STARTS WITH $prefix" in query
-    assert params["prefix"] == "can://app/"
+    assert params["prefix"] == "can://app/app/"
 
 
 def test_probe_does_not_raise_on_a_legitimate_empty_result(fake_driver):
     """A level-1 graph is legitimate output, not an error -- construction must still succeed."""
     PyNeo4jBackend._from_driver(fake_driver, application_name="app")  # no raise
diff --git a/tests/analysis/python/test_resolve.py b/tests/analysis/python/test_resolve.py
index c729e16..910c145 100644
--- a/tests/analysis/python/test_resolve.py
+++ b/tests/analysis/python/test_resolve.py
@@ -511,21 +511,21 @@ def test_local_value_ref_is_the_emitters_own_id(py_params):
     n = py_params.resolve_value("invoice_id", within="Portal.charge")
     assert n.ref == f"{c.id}{key}" == _global_ordinal(c.id, key)
     assert "@@" not in n.ref
 
 
 def test_the_composition_matches_the_emitters_own_rule():
     """``body_node_id`` exists to track ``codeanalyzer/neo4j/project.py``'s ``_global_ordinal``.
     Pin it against that function directly, so an upstream change to the grammar fails here rather
     than producing ids that silently name nothing."""
     for key in ("@entry", "@exit", "@formal_in:1", "@formal_out:0", "9:8", "12:16"):
-        assert body_node_id("can://app/python/m.py/C/f(self)", key) == _global_ordinal("can://app/python/m.py/C/f(self)", key)
+        assert body_node_id("can://app/app/python/m.py/C/f(self)", key) == _global_ordinal("can://app/app/python/m.py/C/f(self)", key)
 
 
 def test_a_captured_global_is_labelled_and_named_honestly(py_params):
     """84% of the values entering a callable on a real application are captured globals. They stay
     in the domain — dropping them would make a legitimately-named global unresolvable with no
     signal — but they are not parameters, and ``<global>:pay::LIMIT`` is not a name a caller wrote."""
     n = py_params.resolve_value("LIMIT", within="Portal.charge")
     assert (n.kind, n.name, n.defined_in) == ("global", "LIMIT", "pay")
     assert "<global>" not in n.name and "::" not in n.name
     assert "@formal_in:" in n.ref and "@@" not in n.ref
diff --git a/tests/analysis/python/test_scoping_keywords.py b/tests/analysis/python/test_scoping_keywords.py
index d3e6056..228d018 100644
--- a/tests/analysis/python/test_scoping_keywords.py
+++ b/tests/analysis/python/test_scoping_keywords.py
@@ -32,20 +32,21 @@ from typing import Any, Dict, List
 
 import networkx as nx
 import pytest
 from codeanalyzer.schema.py_schema import PyApplication, PyCallable, PyClass, PyModule
 
 from cldk.analysis.python.backend import bounded_subgraph, call_graph_scope, check_selector, scope_paths
 from cldk.analysis.python.codeanalyzer.codeanalyzer import PyCodeanalyzer
 from cldk.analysis.python.neo4j import PyNeo4jBackend
 from cldk.utils.exceptions import CodeanalyzerExecutionException, SelectorNotInGraph
 
+
 # ----------------------------------------------------------------------------------------------
 # call_graph_scope — the semantics both backends share
 # ----------------------------------------------------------------------------------------------
 def test_no_keywords_means_the_whole_application():
     assert call_graph_scope(None, None) is None
 
 
 def test_roots_are_normalised_to_a_list():
     assert call_graph_scope(("a", "b"), None) == ["a", "b"]
 
@@ -117,22 +118,22 @@ def test_the_error_carries_the_miss_as_data_not_only_as_prose():
 
 def test_the_error_offers_no_near_miss_suggestions():
     """E8 puts typo-tolerant matching out of scope "not in the resolver, not in the error path" —
     a suggestion is a guess, and a guess presented as a correction is the failure mode this design
     exists to prevent. ``pkg/a.py`` is one character from the miss and must not be mentioned."""
     with pytest.raises(SelectorNotInGraph) as excinfo:
         scope_paths(["pkg/b.py"], ["pkg/a.py"])
     assert "pkg/a.py" not in str(excinfo.value)
 
 
-def test_a_lenient_match_is_not_a_miss():
-    assert scope_paths(["/abs/prefix/pkg/a.py"], ["pkg/a.py"]) == ["pkg/a.py"]
+def test_a_lenient_match_is_not_a_miss(tmp_path):
+    assert scope_paths([str(tmp_path / "pkg/a.py")], ["pkg/a.py"], source_root=tmp_path) == ["pkg/a.py"]
 
 
 # ----------------------------------------------------------------------------------------------
 # bounded_subgraph — the shape both backends must produce
 # ----------------------------------------------------------------------------------------------
 @pytest.mark.parametrize(
     "call",
     [
         lambda: call_graph_scope("pkg.mod.fn", None),
         lambda: scope_paths("pkg/mod.py", ["pkg/mod.py"]),
@@ -141,25 +142,25 @@ def test_a_lenient_match_is_not_a_miss():
 )
 def test_a_bare_string_selector_is_rejected_rather_than_iterated(call):
     """A string is a sequence — of characters — so ``paths='pkg/mod.py'`` used to come back as
     ``10 of 10 paths not in graph: 'p', 'k', 'g', '/', ...``. It is the likely mistake because the
     sibling keyword ``module=`` genuinely is single-valued."""
     with pytest.raises(TypeError, match="not a string"):
         call()
 
 
 # ---- Fix 7: resolution is many-to-one ----------------------------------------------------------
-def test_two_spellings_of_one_module_resolve_to_one_key_once():
+def test_two_spellings_of_one_module_resolve_to_one_key_once(tmp_path):
     """Leniency is the point of :func:`resolve_module_key`, so two spellings of the same file are
     not a caller error — but the resolved list must not name that module twice and ask both
     backends to fetch it twice."""
-    assert scope_paths(["pkg/a.py", "/abs/pkg/a.py"], ["pkg/a.py", "pkg/b.py"]) == ["pkg/a.py"]
+    assert scope_paths(["pkg/a.py", str(tmp_path / "pkg/a.py")], ["pkg/a.py", "pkg/b.py"], source_root=tmp_path) == ["pkg/a.py"]
 
 
 def _diamond() -> nx.DiGraph:
     """a -> b -> d, a -> c -> d, plus c -> b (a back-edge between two nodes at the same depth)
     and an unrelated x -> y component."""
     g = nx.DiGraph()
     g.add_edges_from([("a", "b"), ("b", "d"), ("a", "c"), ("c", "d"), ("c", "b"), ("x", "y")])
     return g
 
 
@@ -253,41 +254,46 @@ def _local_backend() -> PyCodeanalyzer:
             types={cls: PyClass(name=cls.rsplit(".", 1)[-1], signature=cls, path=path)},
             functions={
                 "go": PyCallable(name="go", path=path, signature=f"{name}.go"),
                 # Declared, and in no call edge in either direction — the 2.9% case (444 of the
                 # live graph's 15,549 callables) that the edge-induced call graph has no node for.
                 "lonely": PyCallable(name="lonely", path=path, signature=f"{name}.lonely"),
             },
         )
 
     backend = object.__new__(PyCodeanalyzer)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("app", None)
     backend.application = PyApplication(
         symbol_table={
             "pkg/a.py": module("pkg/a.py", "pkg.a", "pkg.a.Alpha"),
             "pkg/b.py": module("pkg/b.py", "pkg.b", "pkg.b.Beta"),
         }
     )
     backend.call_graph = nx.DiGraph()
     backend.call_graph.add_edges_from([("pkg.a.go", "pkg.b.go"), ("pkg.b.go", "pkg.c.go")])
     return backend
 
 
 def test_local_symbol_table_unscoped_returns_everything():
     assert set(_local_backend().get_symbol_table()) == {"pkg/a.py", "pkg/b.py"}
 
 
 def test_local_symbol_table_scoped_to_paths():
     assert set(_local_backend().get_symbol_table(paths=["pkg/b.py"])) == {"pkg/b.py"}
 
 
-def test_local_symbol_table_resolves_a_path_leniently():
-    assert set(_local_backend().get_symbol_table(paths=["/abs/prefix/pkg/b.py"])) == {"pkg/b.py"}
+def test_local_symbol_table_resolves_a_path_leniently(tmp_path):
+    backend = _local_backend()
+    backend.project_dir = tmp_path
+    assert set(backend.get_symbol_table(paths=[str(tmp_path / "pkg/b.py")])) == {"pkg/b.py"}
 
 
 def test_local_symbol_table_unknown_path_raises():
     with pytest.raises(SelectorNotInGraph, match="paths not in graph"):
         _local_backend().get_symbol_table(paths=["pkg/nope.py"])
 
 
 def test_local_classes_unknown_module_raises_naming_the_module_keyword():
     with pytest.raises(SelectorNotInGraph, match="module not in graph"):
         _local_backend().get_all_classes(module="pkg/nope.py")
@@ -342,34 +348,39 @@ def test_local_unscoped_call_graph_is_still_the_cached_object():
 # ----------------------------------------------------------------------------------------------
 def _recording_backend(modules: List[str]) -> tuple[PyNeo4jBackend, List[Dict[str, Any]]]:
     """A bare backend whose ``_run`` records every statement and returns no rows."""
     seen: List[Dict[str, Any]] = []
 
     def run(query: str, **params: Any) -> List[Dict[str, Any]]:
         seen.append({"query": query, **params})
         return []
 
     backend = object.__new__(PyNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("app", None)
     backend.application_name = "app"
     backend._database = None
     backend._driver = None
     backend._session_obj = None
     backend._modules = list(modules)
+    backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     backend._call_graph = None
     backend._server_version = None  # unknown: _bounded_call_rows must not gate on a version it never read
     backend._run = run
     return backend, seen
 
 
-def test_neo4j_symbol_table_passes_the_resolved_paths_to_cypher():
+def test_neo4j_symbol_table_passes_the_resolved_paths_to_cypher(tmp_path):
     backend, seen = _recording_backend(["pkg/a.py", "pkg/b.py"])
-    backend.get_symbol_table(paths=["/abs/pkg/b.py"])
+    backend.source_root = tmp_path
+    backend.get_symbol_table(paths=[str(tmp_path / "pkg/b.py")])
     assert seen[0]["paths"] == ["pkg/b.py"], "the path was not resolved, or not pushed into the query"
     assert "m.file_key IN $paths" in seen[0]["query"]
 
 
 def test_neo4j_unscoped_symbol_table_still_asks_for_everything():
     backend, seen = _recording_backend(["pkg/a.py"])
     backend.get_symbol_table()
     assert seen[0]["paths"] is None, "the unscoped call must not have grown a filter"
 
 
@@ -377,40 +388,40 @@ def test_neo4j_scoped_prefetch_does_not_fetch_the_whole_application():
     """The bulk child statements must be issued for the requested module only.
 
     This is the assertion that distinguishes a real scoping keyword from a Python-side filter over
     a full fetch: both return the same rows, but only one of them avoids dragging the other 1,625
     modules' call sites across the wire.
     """
     backend, seen = _recording_backend(["pkg/a.py", "pkg/b.py"])
     with backend._bulk(["pkg/b.py"]):
         backend._children("class_methods", "sig", "unused")
     assert [s["mods"] for s in seen] == [["pkg/b.py"]]
-    assert [s["prefixes"] for s in seen] == [["can://app/python/pkg/b.py/"]], "the signature-keyed buckets narrow on per-module id prefixes"
+    assert [s["prefixes"] for s in seen] == [["can://app/app/python/pkg/b.py/"]], "the signature-keyed buckets narrow on per-module id prefixes"
 
 
 def test_neo4j_bulk_scope_is_the_application_by_default():
     backend, seen = _recording_backend(["pkg/a.py", "pkg/b.py"])
     with backend._bulk():
         backend._children("class_methods", "sig", "unused")
     assert seen[0]["mods"] == ["pkg/a.py", "pkg/b.py"]
-    assert seen[0]["prefixes"] == ["can://app/"], "the whole application is one prefix, not one per module"
+    assert seen[0]["prefixes"] == ["can://app/app/"], "the whole application is one prefix, not one per module"
 
 
 def test_neo4j_nested_bulk_keeps_the_outer_scope():
     """An inner block must not renarrow: the outer block's buckets are already indexed as complete,
     and serving a half-filled one from them would silently drop children."""
     backend, seen = _recording_backend(["pkg/a.py", "pkg/b.py"])
     with backend._bulk():
         with backend._bulk(["pkg/b.py"]):
             backend._children("class_methods", "sig", "unused")
     assert seen[0]["mods"] == ["pkg/a.py", "pkg/b.py"]
-    assert seen[0]["prefixes"] == ["can://app/"]
+    assert seen[0]["prefixes"] == ["can://app/app/"]
 
 
 def _rows_backend(rows: List[Dict[str, Any]], modules: List[str]) -> tuple[PyNeo4jBackend, List[Dict[str, Any]]]:
     """A bare backend whose ``_run`` records every statement and replays ``rows`` for the bounded
     call-graph query (recognised by its ``$roots`` parameter)."""
     backend, seen = _recording_backend(modules)
     recording = backend._run
 
     def run(query: str, **params: Any) -> List[Dict[str, Any]]:
         recording(query, **params)
diff --git a/tests/analysis/typescript/conftest.py b/tests/analysis/typescript/conftest.py
index 6d6c00e..46080ed 100644
--- a/tests/analysis/typescript/conftest.py
+++ b/tests/analysis/typescript/conftest.py
@@ -145,20 +145,26 @@ class FakeSession:
     def __init__(self, driver: "FakeDriver") -> None:
         self._driver = driver
 
     def run(self, query: str, **params):
         self._driver.statements.append(query)
         if "db.relationshipTypes" in query:
             return [_FakeRecord({"relationshipType": rt}) for rt in self._driver.rel_types]
         if "RETURN count(a) AS n, a.analyzer_version AS v" in query:
             v = self._driver.analyzer_version
             return [_FakeRecord({"n": 0, "v": None} if v is None else {"n": 1, "v": v})]
+        if "AS identity" in query:
+            from urllib.parse import unquote
+
+            app_id = params["app_id"]
+            namespace, name = app_id.removeprefix("can://").split("/")
+            return [_FakeRecord({"identity": dict(id=app_id, identity_version=2, application_name=unquote(name), identity_namespace=unquote(namespace))})]
         if self._driver.responder is not None:
             return [_FakeRecord(d) for d in self._driver.responder(query, params)]
         return []
 
     def close(self) -> None:
         pass
 
 
 class FakeDriver:
     """Stands in for ``neo4j.GraphDatabase.driver``. ``analyzer_version=None`` means "no
diff --git a/tests/analysis/typescript/test_typescript_addressing.py b/tests/analysis/typescript/test_typescript_addressing.py
index ea0d64b..d82997a 100644
--- a/tests/analysis/typescript/test_typescript_addressing.py
+++ b/tests/analysis/typescript/test_typescript_addressing.py
@@ -33,37 +33,37 @@ from unittest.mock import MagicMock, patch
 import pytest
 
 from cldk import CLDK
 from cldk.analysis import AnalysisLevel
 from cldk.analysis.commons.backend_config import CodeAnalyzerConfig
 from cldk.analysis.commons.results import BodyRef, LocateResult, SliceNode, Span
 from cldk.utils.exceptions import AmbiguousName, SelectorNotInGraph
 
 #: The ids the 1.3.0 fixture mints for the two positions ``locate`` is asserted on. Read off the
 #: fixture, passed back as opaque handles — never composed by the caller (E6).
-SHOW = "can://slim/typescript/src/controllers.ts/UserController/show"
+SHOW = "can://slim/slim/typescript/src/controllers.ts/UserController/show"
 
 
 def _fake_run_writing_output(payload: str):
     def _run(cmd, *args, **kwargs):
         if "-o" in cmd:
             out = Path(cmd[cmd.index("-o") + 1])
             out.mkdir(parents=True, exist_ok=True)
             (out / "analysis.json").write_text(payload, encoding="utf-8")
         return MagicMock(stdout=payload, returncode=0)
 
     return _run
 
 
 def _analysis(app_path, payload, cache, level):
     with patch("cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run", side_effect=_fake_run_writing_output(payload)):
-        return CLDK.typescript(project_path=app_path, eager=True, analysis_level=level, backend=CodeAnalyzerConfig(cache_dir=str(cache)))
+        return CLDK.typescript(project_path=app_path, eager=True, analysis_level=level, backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(cache)))
 
 
 @pytest.fixture
 def ts(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     """A local-backend facade over the a4 (``-a 4``) fixture of the tracked sample app."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     return _analysis(typescript_application, typescript_analysis_json, tmp_path, AnalysisLevel.system_dependency_graph)
 
 
 def _leveled(app_path, tmp_path, monkeypatch, n, level):
@@ -80,21 +80,21 @@ def test_locate_finds_the_callable_its_type_module_and_the_statement_at_the_line
     assert r.module.path == "src/controllers.ts"
     assert r.callable is not None and r.callable.signature == "src/controllers.UserController.show"
     assert r.callable.name == "show" and r.callable.class_signature == "src/controllers.UserController"
     assert r.type is not None and r.type.signature == "src/controllers.UserController" and r.type.name == "UserController"
     assert r.diagnostics == []
     # The call at 20:18 is nested inside the statement at 20:5; the innermost wins.
     assert isinstance(r.body, BodyRef) and r.body.kind == "call"
     assert r.body.id == f"{SHOW}@20:18" and r.node_id == r.body.id
     assert isinstance(r.body.span, Span) and r.body.span.start == (20, 18)
     # 1.3.0 resolves this call, and the local analyzer puts the callee on the node itself.
-    assert r.body.callee == "can://slim/typescript/src/services.ts/UserService/create"
+    assert r.body.callee == "can://slim/slim/typescript/src/services.ts/UserService/create"
     assert r.source.startswith("@Get") and "return user.describe();" in r.source
 
 
 def test_locate_normalises_the_path_the_caller_printed(ts):
     assert ts.locate("./src/controllers.ts", 20).callable.signature == "src/controllers.UserController.show"
 
 
 def test_locate_at_module_scope_keeps_the_module_and_says_so(ts):
     r = ts.locate("src/controllers.ts", 1)  # the import statement
     assert r.callable is None and r.type is None and r.body is None and r.node_id is None
@@ -254,21 +254,21 @@ def test_describe_accepts_ids_slice_nodes_and_locate_results(ts):
 def test_describe_of_a_value_vertex_is_found_with_no_text(ts):
     value = ts.resolve_value("id", within="UserController.show")
     assert ts.describe([value])[0].source is None
 
 
 def test_describe_of_nothing_costs_nothing(ts):
     assert ts.describe([]) == []
 
 
 def test_describe_raises_on_a_ref_that_names_nothing(ts):
-    stale = SliceNode(file="src/controllers.ts", line=1, callable="x", kind="callable", name="x", ref="can://slim/typescript/nope")
+    stale = SliceNode(file="src/controllers.ts", line=1, callable="x", kind="callable", name="x", ref="can://slim/slim/typescript/nope")
     with pytest.raises(KeyError):
         ts.describe([stale])
 
 
 # -------------------------------------------------------------------------- has_resolution_edges
 def test_has_resolution_edges_is_true_once_the_analyzer_has_run_the_call_graph(ts):
     assert ts.has_resolution_edges is True
 
 
 def test_has_resolution_edges_is_false_below_the_level_that_resolves_callees(typescript_application, tmp_path, monkeypatch):
diff --git a/tests/analysis/typescript/test_typescript_analysis.py b/tests/analysis/typescript/test_typescript_analysis.py
index 49f766b..af3f140 100644
--- a/tests/analysis/typescript/test_typescript_analysis.py
+++ b/tests/analysis/typescript/test_typescript_analysis.py
@@ -19,21 +19,22 @@
 import json
 from pathlib import Path
 from unittest.mock import MagicMock, patch
 
 import networkx as nx
 import pytest
 import toml
 
 from cldk import CLDK
 from cldk.analysis import AnalysisLevel
-from cldk.analysis.commons.backend_config import CodeAnalyzerConfig, TSCodeAnalyzerConfig
+from cldk.analysis.commons.backend_config import CodeAnalyzerConfig, TSCodeAnalyzerConfig, cache_subdir
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.utils.exceptions import CldkInitializationException
 
 
 def _fake_run_writing_output(payload):
     """A subprocess.run side effect that writes ``analysis.json`` into the ``-o`` directory.
 
     Caching is on by default now (the facade always passes a language-keyed cache dir), so the
     backend runs in disk mode rather than reading the stdout pipe. This mirrors the analyzer
     writing its output where ``-o`` points.
     """
@@ -54,21 +55,21 @@ def ts_analysis(typescript_application, typescript_analysis_json, tmp_path, monk
     pre-computed analysis.json fixture into the language-keyed cache directory."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(typescript_analysis_json),
     ):
         return CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.call_graph,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path)),
         )
 
 
 def test_symbol_table_is_not_empty(ts_analysis):
     symtab = ts_analysis.get_symbol_table()
     assert symtab is not None
     assert len(symtab) == 5
     assert "src/models.ts" in symtab
 
 
@@ -85,40 +86,40 @@ def test_call_graph_nodes_are_accessor_keys(ts_analysis):
     assert not any(n.startswith("can://") for n in graph.nodes)
 
 
 def test_phantom_external_nodes(ts_analysis):
     # builtin/library calls become phantom (external) nodes, not dropped edges; keyed as the graph
     # keys them ("<module>.<name>"), with the wire id as a node attribute (TS-10)
     ext = ts_analysis.get_external_symbols()
     assert "(builtin).log" in ext
     assert ext["(builtin).log"].module == "(builtin)"
     assert ext["(builtin).log"].name == "log"
-    assert ext["(builtin).log"].id == "can://slim/@external/(builtin)/log"
+    assert ext["(builtin).log"].id == "can://slim/slim/@external/(builtin)/log"
 
     graph = ts_analysis.get_call_graph()
     assert graph.has_edge("src/index.main", "(builtin).log")
     data = graph.get_edge_data("src/index.main", "(builtin).log")
     assert data["type"] == "CALL_DEP"
     assert data["provenance"] == ("import",)
-    assert graph.nodes["(builtin).log"] == {"id": "can://slim/@external/(builtin)/log", "kind": "external"}
+    assert graph.nodes["(builtin).log"] == {"id": "can://slim/slim/@external/(builtin)/log", "kind": "external"}
     assert graph.nodes["src/index.main"]["kind"] == "callable"
     # internal callers can be found via callees
     callees = ts_analysis.get_callees("src/index.main")
     assert "(builtin).log" in {c["callee_signature"] for c in callees["callee_details"]}
 
 
 def test_call_graph_keeps_module_callers_and_tags_kinds(ts_analysis):
     """TS-11: top-level code is a caller (the module node), kept with ``kind="module"`` rather than
     dropped by Python's rule; a one-line filter recovers Python's shape."""
     graph = ts_analysis.get_call_graph()
     assert graph.has_edge("src/index.ts", "src/index.main")
-    assert graph.nodes["src/index.ts"] == {"id": "can://slim/typescript/src/index.ts", "kind": "module"}
+    assert graph.nodes["src/index.ts"] == {"id": "can://slim/slim/typescript/src/index.ts", "kind": "module"}
     kinds = {attrs["kind"] for _, attrs in graph.nodes(data=True)}
     assert kinds == {"module", "callable", "external"}
     callable_only = graph.subgraph(n for n, a in graph.nodes(data=True) if a["kind"] == "callable")
     assert callable_only.number_of_nodes() == 30
     assert graph.number_of_nodes() == 40 and graph.number_of_edges() == 45
 
 
 def test_classes_interfaces_enums_type_aliases(ts_analysis):
     classes = ts_analysis.get_classes()
     assert "src/models.User" in classes
@@ -220,40 +221,40 @@ def test_exports_and_variables(ts_analysis):
     assert set(variables) == set(ts_analysis.get_symbol_table())
 
 
 def test_exports_and_variables_are_parsed(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     """Behavioral: a real export + module-level const must be parsed and surfaced (the slim
     fixture carries none, so inject them into the analyzed JSON)."""
     data = json.loads(typescript_analysis_json)
     models = data["application"]["symbol_table"]["src/models.ts"]
     models["exports"].append({"name": "User", "module": None, "alias": None, "is_type_only": False, "export_kind": "named"})
     models["fields"]["DEFAULT_ROLE"] = {
-        "id": "can://slim/typescript/src/models.ts/DEFAULT_ROLE",
+        "id": "can://slim/slim/typescript/src/models.ts/DEFAULT_ROLE",
         "kind": "field",
         "name": "DEFAULT_ROLE",
         "type": "Role",
         "initializer": "Role.Member",
         "scope": "module",
         "declaration_kind": "const",
         "is_exported": True,
     }
 
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(json.dumps(data)),
     ):
         analysis = CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.call_graph,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path)),
         )
 
     exported = analysis.get_exports()["src/models.ts"]
     assert [e.name for e in exported] == ["User"]
     assert exported[0].export_kind == "named"
 
     variables = analysis.get_variables()["src/models.ts"]
     assert [v.name for v in variables] == ["DEFAULT_ROLE"]
     assert variables[0].declaration_kind == "const"
     assert variables[0].initializer == "Role.Member"
@@ -301,147 +302,154 @@ def test_cache_dir_now_accepted(typescript_application, typescript_analysis_json
     """cache_dir is no longer Python-only; TypeScript accepts it and keys the cache by language."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(typescript_analysis_json),
     ) as run_mock:
         CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.symbol_table,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path / "cache")),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path / "cache")),
         )
 
     args = run_mock.call_args.args[0]
-    assert args[args.index("-o") + 1] == str(tmp_path / "cache" / "typescript")
+    assert args[args.index("-o") + 1] == str(cache_subdir(tmp_path / "cache", None, "typescript", identity=resolve_identity("slim", None)))
 
 
 # -----[ facade -> backend wiring / subprocess invocation ]-----
 def test_subprocess_args_default_keyed_output_dir(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     """The facade forwards target_files + analysis_level to the backend, which builds the right
     subprocess command. Caching is on by default, so output goes to ``-o <cache_dir>/typescript``."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(typescript_analysis_json),
     ) as run_mock:
         CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.call_graph,
             target_files=["src/models.ts", "src/services.ts"],
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path)),
         )
 
     args = run_mock.call_args.args[0]
     assert args[0] == "codeanalyzer-typescript"  # resolved from $CODEANALYZER_TS_BIN
     assert args[args.index("-i") + 1] == str(typescript_application)
     assert args[args.index("-a") + 1] == "2"  # call_graph -> level 2
     # each target file forwarded with its own -t
     assert args.count("-t") == 2
     assert "src/models.ts" in args and "src/services.ts" in args
     # caching on by default: output written to the language-keyed cache dir
-    assert args[args.index("-o") + 1] == str(tmp_path / "typescript")
+    assert args[args.index("-o") + 1] == str(cache_subdir(tmp_path, None, "typescript", identity=resolve_identity("slim", None)))
 
 
 def test_subprocess_args_output_dir(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     """The backend passes ``-o <cache_dir>/typescript`` and reads analysis.json back from disk.
     Exercises the output-dir branch and level-1 (symbol_table) mapping."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     cache = tmp_path / "out"
 
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(typescript_analysis_json),
     ) as run_mock:
         analysis = CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.symbol_table,
-            backend=CodeAnalyzerConfig(cache_dir=str(cache)),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(cache)),
         )
 
     args = run_mock.call_args.args[0]
     assert args[args.index("-a") + 1] == "1"  # symbol_table -> level 1
-    assert args[args.index("-o") + 1] == str(cache / "typescript")
+    assert args[args.index("-o") + 1] == str(cache_subdir(cache, None, "typescript", identity=resolve_identity("slim", None)))
     # the disk read-back path produced a usable application
     assert len(analysis.get_symbol_table()) == 5
 
 
 def test_cached_analysis_json_skips_subprocess(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     """When a cached analysis.json already exists (in the language-keyed dir) and eager is False,
     the backend must reuse it and not invoke the analyzer subprocess."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
-    keyed = tmp_path / "out" / "typescript"
+    keyed = cache_subdir(tmp_path / "out", None, "typescript", identity=resolve_identity("slim", None))
     keyed.mkdir(parents=True)
     (keyed / "analysis.json").write_text(typescript_analysis_json, encoding="utf-8")
 
     with patch("cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run") as run_mock:
         analysis = CLDK.typescript(
             project_path=typescript_application,
             eager=False,
             analysis_level=AnalysisLevel.call_graph,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path / "out")),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path / "out")),
         )
 
     run_mock.assert_not_called()
     assert len(analysis.get_symbol_table()) == 5
 
 
 # -----[ the argv the backend builds for codeanalyzer-typescript 1.2.0 ]-----
 
 
 def _captured_argv(typescript_application, typescript_analysis_json, tmp_path, monkeypatch, level, **kw):
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     seen = []
     inner = _fake_run_writing_output(typescript_analysis_json)
 
     def _run(cmd, *args, **kwargs):
         seen.append(list(cmd))
         return inner(cmd, *args, **kwargs)
 
     with patch("cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run", side_effect=_run):
-        CLDK.typescript(project_path=typescript_application, analysis_level=level, eager=True, backend=kw.pop("backend", CodeAnalyzerConfig(cache_dir=str(tmp_path))), **kw)
+        CLDK.typescript(
+            project_path=typescript_application,
+            analysis_level=level,
+            eager=True,
+            backend=kw.pop("backend", CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path))),
+            **kw,
+        )
     assert len(seen) == 1
     return seen[0]
 
 
 @pytest.mark.parametrize("level,expected", [(lvl, n) for n, lvl in enumerate(AnalysisLevel, start=1)], ids=lambda x: getattr(x, "name", x))
 def test_argv_maps_every_level_to_an_integer_and_drops_tsc_only(typescript_application, typescript_analysis_json, tmp_path, monkeypatch, level, expected):
     cmd = _captured_argv(typescript_application, typescript_analysis_json, tmp_path, monkeypatch, level)
     assert cmd[0] == "codeanalyzer-typescript"
     assert cmd[cmd.index("-a") + 1] == str(expected)
-    assert cmd[cmd.index("--app-name") + 1] == Path(typescript_application).name
+    assert "--app-name=slim" in cmd
+    assert "--namespace=slim" in cmd
     assert cmd[cmd.index("-i") + 1] == str(typescript_application)
     out = cmd[cmd.index("-o") + 1]
     assert cmd[cmd.index("--cache-dir") + 1] == out and out.startswith(str(tmp_path))
     assert "--skip-tests" in cmd and "--eager" in cmd
     assert "--tsc-only" not in cmd
 
 
 def test_argv_member_name_spelling_is_accepted(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     cmd = _captured_argv(typescript_application, typescript_analysis_json, tmp_path, monkeypatch, "system_dependency_graph")
     assert cmd[cmd.index("-a") + 1] == "4"
 
 
 def test_tsc_only_is_a_deprecated_no_op(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     with pytest.warns(DeprecationWarning, match="1.0.0"):
         cmd = _captured_argv(
             typescript_application,
             typescript_analysis_json,
             tmp_path,
             monkeypatch,
             AnalysisLevel.call_graph,
-            backend=TSCodeAnalyzerConfig(cache_dir=str(tmp_path), tsc_only=True),
+            backend=TSCodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path), tsc_only=True),
         )
     assert "--tsc-only" not in cmd
 
 
 def test_backend_keeps_the_envelope(ts_analysis):
     analysis = ts_analysis.backend.analysis
     # The pin, read rather than written down (the idiom tests/models/typescript uses): the fixture
     # is regenerated with the pinned wheel, so a literal here is one more place a bump has to be
     # remembered -- and #368 found this one stale.
     pin = toml.load(Path(__file__).resolve().parents[3] / "pyproject.toml")["tool"]["backend-versions"]["codeanalyzer-typescript"]
-    assert analysis.analyzer.version == pin
+    assert analysis.analyzer.version == "1.6.4"  # reviewed local producer fixture; no unpublished dependency pin
     assert analysis.max_level == 4
     assert analysis.application is ts_analysis.get_application_view()
diff --git a/tests/analysis/typescript/test_typescript_bulk_accessors.py b/tests/analysis/typescript/test_typescript_bulk_accessors.py
index 79a95fe..0844d26 100644
--- a/tests/analysis/typescript/test_typescript_bulk_accessors.py
+++ b/tests/analysis/typescript/test_typescript_bulk_accessors.py
@@ -52,21 +52,21 @@ def ts_analysis(typescript_application, typescript_analysis_json, tmp_path, monk
     """A local-backend facade over the real sample-app fixture."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(typescript_analysis_json),
     ):
         return CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.call_graph,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path)),
         )
 
 
 # The fixture app has exactly 35 callables total (module functions, namespace functions, class and
 # interface methods -- including nested classes' methods -- and inner/nested callables), 15 of
 # which are owner-less: module-level functions and arrows, the inner function
 # (``src/util.classify.keyOf``), the four anonymous callbacks the v2 tree homes under their
 # enclosing callable (``<anon@L:C>``), and the two namespace-owned functions on ``StringUtil``
 # (``repeat``/``slug``) per the ruling that namespace-owned functions carry no owner pair.
 TOTAL_CALLABLES = 35
diff --git a/tests/analysis/typescript/test_typescript_dataflow.py b/tests/analysis/typescript/test_typescript_dataflow.py
index c11ec5c..ff7254d 100644
--- a/tests/analysis/typescript/test_typescript_dataflow.py
+++ b/tests/analysis/typescript/test_typescript_dataflow.py
@@ -63,21 +63,21 @@ def _fake_run_writing_output(payload: str):
             out = Path(cmd[cmd.index("-o") + 1])
             out.mkdir(parents=True, exist_ok=True)
             (out / "analysis.json").write_text(payload, encoding="utf-8")
         return MagicMock(stdout=payload, returncode=0)
 
     return _run
 
 
 def _analysis(app_path, payload, cache, level):
     with patch("cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run", side_effect=_fake_run_writing_output(payload)):
-        return CLDK.typescript(project_path=app_path, eager=True, analysis_level=level, backend=CodeAnalyzerConfig(cache_dir=str(cache)))
+        return CLDK.typescript(project_path=app_path, eager=True, analysis_level=level, backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(cache)))
 
 
 @pytest.fixture
 def ts(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     """A local-backend facade over the a4 (``-a 4``) fixture of the tracked sample app."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     return _analysis(typescript_application, typescript_analysis_json, tmp_path, AnalysisLevel.system_dependency_graph)
 
 
 @pytest.fixture
@@ -89,21 +89,21 @@ def ts_a2(typescript_application, tmp_path, monkeypatch):
     return _analysis(typescript_application, payload, tmp_path, AnalysisLevel.call_graph)
 
 
 # =============================================================== the three per-callable graphs
 def test_get_cfg_returns_the_callables_own_edges_with_global_endpoints(ts):
     page = ts.get_cfg("show")
     assert isinstance(page, EdgePage)
     assert page.total == 5 and len(page.edges) == 5
     assert page.complete and page.next_cursor is None
     for e in page.edges:
-        assert e.src.startswith("can://slim/typescript/") and e.dst.startswith("can://slim/typescript/")
+        assert e.src.startswith("can://slim/slim/typescript/") and e.dst.startswith("can://slim/slim/typescript/")
         assert e.kind in {"fallthrough", "true", "false", "switch_case", "loop_back", "exception", "return", "break", "continue", "yield", "await_resume"}
     assert page.edges == sorted(page.edges, key=lambda e: (e.src, e.dst, e.kind or ""))
 
 
 def test_get_cdg_and_get_ddg_return_the_fixtures_counts(ts):
     assert ts.get_cdg("show").total == 2
     ddg = ts.get_ddg("show")
     assert ddg.total == 9 and len(ddg.edges) == 9
 
 
diff --git a/tests/analysis/typescript/test_typescript_e2e.py b/tests/analysis/typescript/test_typescript_e2e.py
index 4f25112..28ec408 100644
--- a/tests/analysis/typescript/test_typescript_e2e.py
+++ b/tests/analysis/typescript/test_typescript_e2e.py
@@ -87,20 +87,20 @@ def test_call_graph_nodes_are_accessor_keys_and_kind_tagged(analysis):
     assert CALL_GRAPH_NODE_KINDS == KINDS
     for node, attrs in graph.nodes(data=True):
         assert attrs["kind"] in KINDS, (node, attrs)
         assert attrs["id"].startswith("can://"), (node, attrs)
     if analysis.analysis_level != AnalysisLevel.symbol_table:
         assert graph.number_of_edges() > 0
         assert graph.has_edge("src/index.main", "src/services.UserService.create")
 
 
 def test_analyzer_version_is_the_pin(analysis):
-    assert analysis.backend.analysis.analyzer.version == _pinned_version()
+    assert analysis.backend.analysis.analyzer.version == "1.6.4"  # reviewed local producer artifact
     assert (
         analysis.backend.analysis.max_level
         == {
             AnalysisLevel.symbol_table: 1,
             AnalysisLevel.call_graph: 2,
             AnalysisLevel.program_dependency_graph: 3,
             AnalysisLevel.system_dependency_graph: 4,
         }[AnalysisLevel(analysis.analysis_level)]
     )
diff --git a/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py b/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py
index 5a1a9b5..0993543 100644
--- a/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py
+++ b/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py
@@ -53,21 +53,21 @@ from cldk.utils.exceptions import GraphSchemaMismatch
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
 logging.getLogger("neo4j").setLevel(logging.ERROR)
 
 NEO4J_URI = os.environ.get("CLDK_TEST_NEO4J_URI")
 NEO4J_USER = os.environ.get("CLDK_TEST_NEO4J_USER", "neo4j")
 NEO4J_PASSWORD = os.environ.get("CLDK_TEST_NEO4J_PASSWORD", "neo4j")
 APP_NAME = os.environ.get("CLDK_TEST_NEO4J_APP", "superset-frontend")
 APP_ID = f"can://{APP_NAME}"
 #: The application scope, spelled here independently of the backend's helper on purpose.
-SCOPE = {"p": f"can://{APP_NAME}/"}
+SCOPE = {"p": f"can://{APP_NAME}/{APP_NAME}/"}
 SCOPED = "(x.id STARTS WITH $p)"
 REQUIRED_RELATIONSHIP_TYPES = {"TS_HAS_MODULE", "TS_HAS_METHOD", "TS_HAS_BODY_NODE", "TS_CALLS"}
 
 
 def _live_application_present() -> bool:
     if not NEO4J_URI:
         return False
     try:
         from neo4j import GraphDatabase
     except ModuleNotFoundError:
@@ -158,21 +158,24 @@ def test_graph_really_has_no_module_property(cypher):
     assert cypher("MATCH (n:CanNode) WHERE n._module IS NOT NULL RETURN count(n) AS n")[0]["n"] == 0
 
 
 # =====================================================================================
 # symbol table / types
 # =====================================================================================
 def test_symbol_table_keys_are_the_graphs_module_names_on_both_prefixes(analysis, cypher):
     expected = {r["k"] for r in cypher("MATCH (:Application {id: $id})-[:TS_HAS_MODULE]->(m:TSModule) RETURN m.name AS k", id=APP_ID)}
     table = analysis.get_symbol_table()
     assert set(table) == expected and expected
-    js = {r["k"] for r in cypher("MATCH (:Application {id: $id})-[:TS_HAS_MODULE]->(m:TSModule) WHERE m.id STARTS WITH $js RETURN m.name AS k", id=APP_ID, js=f"{SCOPE['p']}javascript/")}
+    js = {
+        r["k"]
+        for r in cypher("MATCH (:Application {id: $id})-[:TS_HAS_MODULE]->(m:TSModule) WHERE m.id STARTS WITH $js RETURN m.name AS k", id=APP_ID, js=f"{SCOPE['p']}javascript/")
+    }
     assert js and js <= set(table), "JavaScript modules are in scope (TS-3)"
     assert all(k.endswith((".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".d.ts")) for k in table)
 
 
 def test_symbol_table_rebuilds_every_declared_node(analysis, count):
     """The var-length subtree fetch loses nothing: every type, callable and field the modules
     contain, at any depth, is somewhere in the rebuilt tree."""
     table = analysis.get_symbol_table()
     seen_ids: set = set()
 
@@ -239,23 +242,26 @@ def merged(cypher) -> List[Dict[str, Any]]:
 
 def test_declaration_merging_mints_one_id_per_facet_and_every_facet_is_served(analysis, merged, cypher):
     """The fix in cants#177, and the behaviour change it buys: under 1.3.0/1.4.0 the two
     declarations collapsed onto one node carrying both labels and the last writer's ``kind``, and
     the SDK could serve only the facet that ``kind`` named — the other was lost. Now each facet is
     its own node and **both are reachable**, each through the accessor its kind names.
 
     Two assertions, in order: no node is left carrying two declaration labels, and every facet of
     every shared signature is served. Both read off the graph, so the day a corpus stops merging
     the second fails loudly rather than passing vacuously."""
-    assert cypher(f"MATCH (m:CanNode) WHERE {SCOPED.replace('x.', 'm.')} AND size([l IN labels(m) WHERE l IN $decl]) > 1 RETURN count(m) AS n", decl=DECLARATION_LABELS, **SCOPE)[0][
-        "n"
-    ] == 0, "a node still carries two declaration labels; cants#177 has regressed"
+    assert (
+        cypher(f"MATCH (m:CanNode) WHERE {SCOPED.replace('x.', 'm.')} AND size([l IN labels(m) WHERE l IN $decl]) > 1 RETURN count(m) AS n", decl=DECLARATION_LABELS, **SCOPE)[0][
+            "n"
+        ]
+        == 0
+    ), "a node still carries two declaration labels; cants#177 has regressed"
     assert merged, "this corpus carries no declaration shared by two facets; retire this test"
     by_kind = {"class": analysis.get_classes(), "interface": analysis.get_interfaces(), "enum": analysis.get_enums(), "type_alias": analysis.get_type_aliases()}
     functions = analysis.get_functions()
     for row in merged:
         for facet in row["facets"]:
             assert len(facet["labels"]) == 1, f"{facet['id']} carries {facet['labels']}"
             served = by_kind.get(facet["kind"], functions)
             assert row["sig"] in served, f"{row['sig']} has a {facet['kind']} facet the matching accessor does not serve"
             assert served[row["sig"]].kind == facet["kind"], f"{row['sig']} was served as the wrong facet"
 
diff --git a/tests/analysis/typescript/test_typescript_entrypoints.py b/tests/analysis/typescript/test_typescript_entrypoints.py
index 4f786ed..aad6f39 100644
--- a/tests/analysis/typescript/test_typescript_entrypoints.py
+++ b/tests/analysis/typescript/test_typescript_entrypoints.py
@@ -68,21 +68,21 @@ def _fake_run_writing_output(payload: str):
 
 @pytest.fixture
 def ts(typescript_application, typescript_analysis_json, tmp_path, monkeypatch):
     """A local-backend facade over the a4 (``-a 4``) fixture of the tracked sample app."""
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch("cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run", side_effect=_fake_run_writing_output(typescript_analysis_json)):
         return CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.system_dependency_graph,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="slim", cache_dir=str(tmp_path)),
         )
 
 
 # ----------------------------------------------------------------------------------- entrypoints
 def test_the_sample_app_marks_no_entrypoint_callable(ts):
     """``[]`` here is a fact about the corpus, not a stand-in for "the mark does not exist": the
     fixture carries ``is_entrypoint`` on its callables and every one of them is unmarked."""
     assert ts.get_entrypoints() == []
     assert any(c.is_entrypoint is not None for c in ts.backend._callables.values()), "the fixture should carry the mark at all"
 
@@ -138,21 +138,21 @@ def test_a_missing_report_is_said_rather_than_fabricated(ts):
 def test_the_facade_reaches_the_artifacts(ts):
     artifacts = ts.get_artifacts()
     assert set(artifacts) == {"package.json", "tsconfig.json"}
     assert all(isinstance(a, PyArtifact) for a in artifacts.values())
     assert artifacts["package.json"].roles == ["dependency-manifest", "tool-config"]
     assert artifacts == ts.backend.get_artifacts()
 
 
 def test_the_facade_reaches_the_dependencies_and_its_filters(ts):
     assert ts.get_dependencies() == []
-    assert ts.get_dependencies(direct_only=True) == ts.get_dependencies(ecosystem="npm") == ts.get_dependencies(declared_in="can://slim/artifact/package.json") == []
+    assert ts.get_dependencies(direct_only=True) == ts.get_dependencies(ecosystem="npm") == ts.get_dependencies(declared_in="can://slim/slim/artifact/package.json") == []
 
 
 def test_the_facade_reaches_the_config_keys(ts):
     keys = ts.get_config_keys()
     assert all(isinstance(v, PyConfigKey) for v in keys.values())
     assert {v.key for v in keys.values()} >= {"compilerOptions.target", "compilerOptions.strict"}
     # A boolean in the artifact is rendered as its JSON text, since PyConfigKey.value is a string.
     assert next(v.value for v in keys.values() if v.key == "compilerOptions.strict") == "true"
 
 
diff --git a/tests/analysis/typescript/test_typescript_external_reconstruct.py b/tests/analysis/typescript/test_typescript_external_reconstruct.py
index e88eec7..f4c4302 100644
--- a/tests/analysis/typescript/test_typescript_external_reconstruct.py
+++ b/tests/analysis/typescript/test_typescript_external_reconstruct.py
@@ -17,21 +17,21 @@
 """Reconstructing ``:TSExternal`` nodes from their graph properties (#231, on the 1.2.0 shape):
 the node carries ``id``/``kind``/``module``/``name`` and reconstructs into the id-keyed
 ``TSExternalNode``; the backend keys the map ``"<module>.<name>"``, as the call graph does."""
 
 from unittest.mock import patch
 
 from cldk.analysis.typescript.neo4j import reconstruct as R
 from cldk.analysis.typescript.neo4j.neo4j_backend import TSNeo4jBackend
 from cldk.models.typescript import TSExternalNode, TSExternalSymbol
 
-APP_ID = "can://app"
+APP_ID = "can://app/app"
 
 
 def test_external_reconstructs_from_full_graph_props():
     sym = R.external({"id": f"{APP_ID}/@external/commander/parse", "name": "parse", "module": "commander", "kind": "external"})
     assert isinstance(sym, TSExternalNode) and TSExternalSymbol is TSExternalNode
     assert sym.name == "parse"
     assert sym.module == "commander"
     assert sym.id == f"{APP_ID}/@external/commander/parse"
 
 
@@ -45,28 +45,31 @@ def test_get_external_symbols_keys_module_dot_name_and_scopes_by_the_application
     """The scope is the one **application** prefix plus the ``@external`` segment.
 
     This used to be the two language prefixes, because an external a ``.js`` module owned was homed
     under ``can://javascript/<app>/`` and a single-prefix reading dropped it silently (TS-3; leg
     2.5b review, finding 9). 1.5.1 makes the ``@external`` home language-*neutral* --
     ``can://<app>/@external/<module>/<name>``, no language segment at all -- so a
     language-prefixed reading would now drop **every** external, and the one application prefix is exactly right."""
     rows = [
         {"p": {"id": f"{APP_ID}/@external/commander/parse", "name": "parse", "module": "commander", "kind": "external"}},
         {"p": {"id": f"{APP_ID}/@external/fs/readFileSync", "name": "readFileSync", "module": "fs", "kind": "external"}},
-        {"p": {"id": "can://app/@external/lodash/merge", "name": "merge", "module": "lodash", "kind": "external"}},
+        {"p": {"id": "can://app/app/@external/lodash/merge", "name": "merge", "module": "lodash", "kind": "external"}},
     ]
     captured = {}
 
     def _run(query, **params):
         captured["query"] = query
         captured.update(params)
         return rows
 
     backend = TSNeo4jBackend.__new__(TSNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("app", None)
     backend.application_name = "app"
     with patch.object(TSNeo4jBackend, "_run", side_effect=_run):
         out = backend.get_external_symbols()
     assert set(out) == {"commander.parse", "fs.readFileSync", "lodash.merge"}
     assert out["commander.parse"].module == "commander"
     assert out["commander.parse"].id == f"{APP_ID}/@external/commander/parse"
     assert "(e:TSExternal) WHERE (e.id STARTS WITH $p) AND e.id CONTAINS '/@external/'" in captured["query"]
     assert captured["p"] == f"{APP_ID}/"
diff --git a/tests/analysis/typescript/test_typescript_get_method_functions.py b/tests/analysis/typescript/test_typescript_get_method_functions.py
index 8d9cbba..31c65cb 100644
--- a/tests/analysis/typescript/test_typescript_get_method_functions.py
+++ b/tests/analysis/typescript/test_typescript_get_method_functions.py
@@ -53,21 +53,21 @@ from cldk.models.typescript import (
 
 # -----[ shared fixture data ]-----
 #
 # src/mod.ts:
 #   class Foo { bar() {} }                          -> src/mod.Foo.bar
 #   function baz(x) { Foo.prototype.bar(); }         -> src/mod.baz   (module-level function)
 #   namespace NS { function qux() { baz(); } }       -> src/mod.NS.qux (namespace-nested function)
 #
 # call_graph: baz -> Foo.bar, NS.qux -> baz   (so both functions participate in a call edge)
 
-MOD = "can://t/typescript/src/mod.ts"
+MOD = "can://t/t/typescript/src/mod.ts"
 SPAN = TSSpan(start=(1, 1), end=(1, 1), bytes=(0, 0))
 
 
 def _bar() -> TSCallable:
     return TSCallable(id=f"{MOD}/Foo/bar", span=SPAN, name="bar", signature="src/mod.Foo.bar", kind="method")
 
 
 def _baz() -> TSCallable:
     return TSCallable(
         id=f"{MOD}/baz",
@@ -87,31 +87,35 @@ def _build_application() -> TSApplication:
     foo = TSClass(id=f"{MOD}/Foo", span=SPAN, name="Foo", signature="src/mod.Foo", callables={"bar": _bar()})
     ns = TSNamespace(id=f"{MOD}/NS", span=SPAN, name="NS", signature="src/mod.NS", functions={"qux": _qux()})
     module = TSModule(
         id=MOD,
         span=SPAN,
         source="",
         types={"Foo": foo, "NS": ns},
         functions={"baz": _baz()},
     )
     return TSApplication(
-        id="can://t",
+        id="can://t/t",
+        identity_version=2,
+        application_name="t",
+        identity_namespace="t",
         symbol_table={"src/mod.ts": module},
         call_graph=[
             TSCallEdge(src=f"{MOD}/baz", dst=f"{MOD}/Foo/bar", prov=["tsc"]),
             TSCallEdge(src=f"{MOD}/NS/qux", dst=f"{MOD}/baz", prov=["tsc"]),
         ],
     )
 
 
 def _build_analysis_json(application: TSApplication | None = None) -> str:
     return TSAnalysis(
+        identity_version=2,
         schema_version="2.0.0",
         language="typescript",
         max_level=2,
         analyzer={"name": "codeanalyzer-typescript", "version": "1.2.0"},
         application=application or _build_application(),
     ).model_dump_json()
 
 
 # -----[ local (in-memory) backend ]-----
 
@@ -133,21 +137,21 @@ def ts_analysis(typescript_application, tmp_path, monkeypatch):
     payload = _build_analysis_json()
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(payload),
     ):
         return CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.call_graph,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="t", cache_dir=str(tmp_path)),
         )
 
 
 def test_local_get_method_still_resolves_class_methods(ts_analysis):
     method = ts_analysis.get_method("src/mod.Foo", "bar")
     assert method is not None
     assert method.signature == "src/mod.Foo.bar"
 
 
 def test_local_get_method_resolves_module_level_function_by_short_name(ts_analysis):
@@ -192,21 +196,21 @@ def test_local_module_function_participates_in_call_edge(ts_analysis):
 def _analysis_over(application: TSApplication, typescript_application, tmp_path, monkeypatch):
     monkeypatch.setenv("CODEANALYZER_TS_BIN", "codeanalyzer-typescript")
     with patch(
         "cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run",
         side_effect=_fake_run_writing_output(_build_analysis_json(application)),
     ):
         return CLDK.typescript(
             project_path=typescript_application,
             eager=True,
             analysis_level=AnalysisLevel.call_graph,
-            backend=CodeAnalyzerConfig(cache_dir=str(tmp_path)),
+            backend=CodeAnalyzerConfig(application_name="t", cache_dir=str(tmp_path)),
         )
 
 
 def test_call_node_with_unindexed_callee_raises_rather_than_leaking_the_id(typescript_application, tmp_path, monkeypatch):
     app = _build_application()
     baz = app.symbol_table["src/mod.ts"].functions["baz"]
     baz.body["2:3"] = TSBodyNode(kind="call", callee=f"{MOD}/Ghost/nope", method_name="nope", span=SPAN)
     analysis = _analysis_over(app, typescript_application, tmp_path, monkeypatch)
     for query in (
         lambda: analysis.get_call_sites("src/mod.baz"),
@@ -231,31 +235,31 @@ def test_synthesized_entry_pointing_at_a_tree_callable_keys_on_its_signature(typ
     old = f"{MOD}/baz@9:9"
     app.synthesized_callables = {old: TSSynthesizedNode(id=f"{MOD}/baz")}
     app.call_graph.append(TSCallEdge(src=f"{MOD}/Foo/bar", dst=old, prov=["defuse"]))
     graph = _analysis_over(app, typescript_application, tmp_path, monkeypatch).get_call_graph()
     assert graph.has_edge("src/mod.Foo.bar", "src/mod.baz")
     assert not any(n.startswith("can://") for n in graph.nodes)
 
 
 def test_named_residual_synthesized_node_keys_on_its_name(typescript_application, tmp_path, monkeypatch):
     app = _build_application()
-    residual = "can://t/typescript/@synthetic/cb"
+    residual = "can://t/t/typescript/@synthetic/cb"
     app.synthesized_callables = {residual: TSSynthesizedNode(id=residual, name="cb", path="src/mod.ts")}
     app.call_graph.append(TSCallEdge(src=f"{MOD}/Foo/bar", dst=residual, prov=["defuse"]))
     graph = _analysis_over(app, typescript_application, tmp_path, monkeypatch).get_call_graph()
     assert graph.nodes["cb"] == {"id": residual, "kind": "callable"}
 
 
 @pytest.mark.parametrize(
     "entry",
     [
-        pytest.param({"can://t/typescript/@synthetic/cb": TSSynthesizedNode(id="can://t/typescript/@synthetic/cb")}, id="residual-without-name"),
+        pytest.param({"can://t/t/typescript/@synthetic/cb": TSSynthesizedNode(id="can://t/t/typescript/@synthetic/cb")}, id="residual-without-name"),
         pytest.param({f"{MOD}/baz@9:9": TSSynthesizedNode(id=f"{MOD}/nowhere/<anon@9:9>")}, id="non-residual-unindexed-id"),
     ],
 )
 def test_unhomed_synthesized_entry_raises_at_load(entry, typescript_application, tmp_path, monkeypatch):
     app = _build_application()
     app.synthesized_callables = entry
     with pytest.raises(CodeanalyzerExecutionException, match="unhomed endpoint"):
         _analysis_over(app, typescript_application, tmp_path, monkeypatch)
 
 
@@ -265,20 +269,23 @@ def test_unhomed_synthesized_entry_raises_at_load(entry, typescript_application,
 # test_typescript_neo4j_backend.py). ``_run`` is the single seam every query method goes through,
 # so it's stubbed here with canned rows equivalent to the same fixture data above -- this is a
 # unit-level substitute for the (separately maintained) live-Neo4j integration coverage.
 
 
 def _neo4j_backend_with_stubbed_run(rows_by_call: dict) -> TSNeo4jBackend:
     """A TSNeo4jBackend with __init__ (and its real driver connection) bypassed, ``_run`` stubbed
     to return canned rows keyed by (query, frozenset(params.items())); anything else (the subtree
     statement ``_fetch`` issues after a root is found) returns no rows."""
     backend = object.__new__(TSNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity("t", None)
     backend.application_name = "t"
     backend._database = None
     backend._module_ids = {"src/mod.ts": MOD}
     backend._modules = ["src/mod.ts"]
 
     def _normalize(value):
         return tuple(value) if isinstance(value, list) else value
 
     def _run(query: str, **params):
         normalized = {k: _normalize(v) for k, v in params.items()}
@@ -295,21 +302,21 @@ def _callable_props(c: TSCallable, *, bindings: bool = False) -> dict:
     """The ``:TSCallable`` node property shape: flat scalars, plus -- on a graph emitted by
     codeanalyzer-typescript 1.4.0 or newer (#368) -- ``parameters_json``, the parameter list
     JSON-encoded verbatim. ``bindings=False`` is the 1.3.0 shape, which carries neither the
     property nor anything else of the binding layer."""
     props = {"id": c.id, "kind": c.kind, "signature": c.signature, "name": c.name, "return_type": c.return_type, "start_line": c.start_line, "end_line": c.end_line, "code": ""}
     if bindings and c.parameters:
         props["parameters_json"] = json.dumps([p.model_dump() for p in c.parameters])
     return props
 
 
-SCOPE = (("p", "can://t/"),)
+SCOPE = (("p", "can://t/t/"),)
 
 
 def _stub_rows(*, bindings: bool):
     bar_props = _callable_props(_bar(), bindings=bindings)
     baz_props = _callable_props(_baz(), bindings=bindings)
     qux_props = _callable_props(_qux(), bindings=bindings)
 
     has_method_query = f"MATCH (o:TSClass|TSInterface {{signature: $sig}}) WHERE {_scoped('o')} AND o.kind IN $kinds MATCH (o)-[:TS_HAS_METHOD]->(root:TSCallable {{name: $name}}) RETURN properties(root) AS p, labels(root) AS labels"
     exact_sig_query = (
         f"MATCH (p:TSModule|TSNamespace)-[:TS_DECLARES]->(root:TSCallable {{signature: $sig}}) WHERE {_scoped('root')} RETURN properties(root) AS p, labels(root) AS labels"
diff --git a/tests/analysis/typescript/test_typescript_neo4j_backend.py b/tests/analysis/typescript/test_typescript_neo4j_backend.py
index 07b2e3d..621949b 100644
--- a/tests/analysis/typescript/test_typescript_neo4j_backend.py
+++ b/tests/analysis/typescript/test_typescript_neo4j_backend.py
@@ -72,21 +72,21 @@ from cldk.analysis.typescript.neo4j import Neo4jConnectionConfig
 logging.getLogger("neo4j").setLevel(logging.ERROR)
 
 NEO4J_URI = os.environ.get("CLDK_TEST_NEO4J_WRITE_URI")
 NEO4J_USER = os.environ.get("CLDK_TEST_NEO4J_WRITE_USER")
 NEO4J_PASSWORD = os.environ.get("CLDK_TEST_NEO4J_WRITE_PASSWORD")
 APP_NAME = "application"
 #: Every node the emitter writes for APP_NAME lives under this one prefix; the teardown deletes
 #: exactly that, plus the application anchor, and nothing else on the server. It was two prefixes
 #: (one per language namespace) while the language was the outermost segment; the application
 #: prefix now covers both, and also the ``@external`` ghosts and artifacts the pair never reached.
-APP_PREFIXES = (f"can://{APP_NAME}/",)
+APP_PREFIXES = (f"can://{APP_NAME}/{APP_NAME}/",)
 APP_ID = f"can://{APP_NAME}"
 
 
 def _neo4j_reachable() -> bool:
     if not (NEO4J_URI and NEO4J_USER and NEO4J_PASSWORD):
         return False
     try:
         from neo4j import GraphDatabase
     except ModuleNotFoundError:
         return False
diff --git a/tests/analysis/typescript/test_typescript_neo4j_bulk.py b/tests/analysis/typescript/test_typescript_neo4j_bulk.py
index 162f08b..35c1523 100644
--- a/tests/analysis/typescript/test_typescript_neo4j_bulk.py
+++ b/tests/analysis/typescript/test_typescript_neo4j_bulk.py
@@ -27,31 +27,34 @@ requested-and-existing signature gets a callsites entry (empty list if it has no
 derived from the callable's ``can://`` id against the application's module keys (F4), never
 projected.
 """
 
 from unittest.mock import patch
 
 from cldk.analysis.typescript.neo4j.neo4j_backend import TSNeo4jBackend, _scoped
 from cldk.models.typescript import TSCallableOverview, TSCallsite
 
 APP = "test-app"
-PREFIX = f"can://{APP}/"
+PREFIX = f"can://{APP}/{APP}/"
 #: What a *declared* node's id carries before its file key. The scope is the application prefix
 #: above; this one has the language segment, and only ids are built from it.
 CODE_PREFIX = f"{PREFIX}typescript/"
 SCOPE = {"p": PREFIX}
 OVERVIEW_MATCH = f"MATCH (c:TSCallable) WHERE {_scoped('c')} "
 
 
 def _backend(modules=("src/models.ts", "src/util.ts", "src/controllers.ts")) -> TSNeo4jBackend:
     """A TSNeo4jBackend with __init__ (and its real driver connection) bypassed."""
     backend = object.__new__(TSNeo4jBackend)
+    from cldk.analysis.commons.identity import resolve_identity
+
+    backend.identity = resolve_identity(APP, None)
     backend.application_name = APP
     backend._database = None
     backend._module_ids = {m: f"{CODE_PREFIX}{m}" for m in modules}
     backend._modules = list(modules)
     return backend
 
 
 def _run_keyed(rows_by_fragment: dict):
     """A stub ``_run`` returning the canned rows for the first query fragment found in the text."""
 
diff --git a/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py b/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py
index 05fcf6a..77f814b 100644
--- a/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py
+++ b/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py
@@ -77,27 +77,30 @@ class _Graph:
 
     def edge(self, src: str, rel: str, dst: str, **props: Any) -> None:
         if not any(e[:3] == (src, rel, dst) for e in self.edges):  # MERGE: one edge per (src, type, dst)
             self.edges.append((src, rel, dst, props))
 
 
 def _build() -> _Graph:
     g = _Graph()
     for app, lang_mod, fn_name in ((APP_A, "a", "alpha"), (APP_B, "b", "beta")):
         app_id = g.node(
-            f"can://{app}",
+            f"can://{app}/{app}",
             ["Application", "TSApplication"],
-            analyzer_version="1.2.0",
+            analyzer_version="1.5.2",
+            identity_version=2,
+            application_name=app,
+            identity_namespace=app,
             entrypoint_frameworks=[f"{fn_name}-framework"],
             entrypoint_report_json=json.dumps({"frameworks_detected": [f"{fn_name}-framework"], "rulesets": ["shipped"], "unresolved": {f"{fn_name}.miss": 2}, "errors": []}),
         )
-        mod = g.node(f"can://{app}/typescript/{lang_mod}/mod.ts", ["TSModule"], kind="module", name=f"{lang_mod}/mod.ts", start_line=1, end_line=20)
+        mod = g.node(f"can://{app}/{app}/typescript/{lang_mod}/mod.ts", ["TSModule"], kind="module", name=f"{lang_mod}/mod.ts", start_line=1, end_line=20)
         g.edge(app_id, "TS_HAS_MODULE", mod)
         cls = g.node(
             f"{mod}/Widget",
             ["TSClass"],
             kind="class",
             signature=CLASS_SIG,
             name="Widget",
             base_classes=["shared.Base"],
             start_line=1,
             end_line=10,
@@ -111,44 +114,42 @@ def _build() -> _Graph:
         )
         g.edge(cls, "TS_HAS_METHOD", method)
         attr = g.node(f"{cls}/{fn_name}_attr", ["TSField"], kind="field", name=f"{fn_name}_attr", start_line=2, end_line=2)
         g.edge(cls, "TS_HAS_FIELD", attr)
         inner = g.node(f"{method}/inner_fn", ["TSCallable"], kind="function", signature=f"{fn_name}.inner_fn", name=f"{fn_name}_inner_fn", start_line=3, end_line=4, code="inner")
         g.edge(method, "TS_DECLARES", inner)
         call = g.node(f"{method}@5:3", ["TSBodyNode"], kind="call", callee=inner, start_line=5, end_line=5)
         g.edge(method, "TS_HAS_BODY_NODE", call)
         g.edge(call, "TS_RESOLVES_TO", inner)
         g.edge(method, "TS_CALLS", inner, weight=1, prov=["tsc"])
-        ext = g.node(
-            f"can://{app}/@external/os/{'path' if app == APP_A else 'join'}", ["TSExternal"], kind="external", name="path" if app == APP_A else "join", module="os"
-        )
+        ext = g.node(f"can://{app}/{app}/@external/os/{'path' if app == APP_A else 'join'}", ["TSExternal"], kind="external", name="path" if app == APP_A else "join", module="os")
         g.edge(method, "TS_CALLS", ext, weight=1, prov=["import"])
         # The module-key collision: both applications declare src/index.ts.
-        shared = g.node(f"can://{app}/typescript/{SHARED_MODULE}", ["TSModule"], kind="module", name=SHARED_MODULE, start_line=1, end_line=9)
+        shared = g.node(f"can://{app}/{app}/typescript/{SHARED_MODULE}", ["TSModule"], kind="module", name=SHARED_MODULE, start_line=1, end_line=9)
         g.edge(app_id, "TS_HAS_MODULE", shared)
         fn = g.node(f"{shared}/{fn_name}_fn", ["TSCallable"], kind="function", signature=f"src/index.{fn_name}_fn", name=f"{fn_name}_fn", start_line=1, end_line=3, code="fn")
         g.edge(shared, "TS_DECLARES", fn)
         anon = g.node(
             f"{fn}/<anon@2:2>", ["TSCallable", "TSAnonymousCallable"], kind="arrow", signature="src/index.<anon@2:2>", name="(anonymous)", start_line=2, end_line=2, code="() => 1"
         )
         g.edge(fn, "TS_DECLARES", anon)
         var = g.node(f"{shared}/{fn_name}_var", ["TSField"], kind="field", name=f"{fn_name}_var", start_line=8, end_line=8)
         g.edge(shared, "TS_HAS_FIELD", var)
     # One JavaScript module in application A only: the second prefix must be honoured (TS-3).
-    js = g.node(f"can://{APP_A}/javascript/a/legacy.js", ["TSModule"], kind="module", name="a/legacy.js", start_line=1, end_line=3)
-    g.edge(f"can://{APP_A}", "TS_HAS_MODULE", js)
+    js = g.node(f"can://{APP_A}/{APP_A}/javascript/a/legacy.js", ["TSModule"], kind="module", name="a/legacy.js", start_line=1, end_line=3)
+    g.edge(f"can://{APP_A}/{APP_A}", "TS_HAS_MODULE", js)
     legacy = g.node(f"{js}/legacy_fn", ["TSCallable"], kind="function", signature="a/legacy.legacy_fn", name="legacy_fn", start_line=1, end_line=2, code="legacy")
     g.edge(js, "TS_DECLARES", legacy)
     # Declaration-merged nodes (one id for two declarations, both labels, the last writer's kind):
     # a `const Option = () => …` + `interface Option {…}` whose interface fields hang off an arrow,
     # and a `type Gran = …` + a field `Gran` -- only in application A.
-    mod_a = f"can://{APP_A}/typescript/a/mod.ts"
+    mod_a = f"can://{APP_A}/{APP_A}/typescript/a/mod.ts"
     merged = g.node(f"{mod_a}/Option", ["TSCallable", "TSInterface"], kind="arrow", signature="a/mod.Option", name="Option", start_line=11, end_line=12, code="() => 1")
     g.edge(mod_a, "TS_DECLARES", merged)
     g.edge(mod_a, "TS_DECLARES", merged)  # the emitter writes one edge per facet; MERGE keeps one
     g.edge(merged, "TS_HAS_FIELD", g.node(f"{merged}/label", ["TSField"], kind="field", name="label", start_line=11, end_line=11))
     gran = g.node(f"{mod_a}/Gran", ["TSTypeAlias", "TSField"], kind="field", signature="a/mod.Gran", name="Gran", aliased_type="string", start_line=13, end_line=13)
     g.edge(mod_a, "TS_DECLARES", gran)
     g.edge(mod_a, "TS_HAS_FIELD", gran)
     # TSDecorator is keyed by name and shared by every application in the database.
     g.node("Deco", ["TSDecorator"], name="Deco", qualified_name="Deco")
     return g
@@ -425,21 +426,21 @@ def fake_cypher(query: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
                 if repr(p) not in seen:
                     seen.add(repr(p))
                     projected.append(p)
             rows = projected
         elif kw == "RETURN":
             return _return(body, rows, params)
         optional_vars = []
     raise AssertionError(f"statement has no RETURN: {query!r}")
 
 
-_A_PREFIXES = (f"can://{APP_A}/",)
+_A_PREFIXES = (f"can://{APP_A}/{APP_A}/",)
 
 
 def _responder(query: str, params: Dict[str, Any]) -> List[Dict[str, Any]]:
     """:func:`fake_cypher`, after asserting every prefix parameter bound at run time is one of
     application A's -- the audit below judges spellings; this judges the values."""
     for name in ("prefix", "p"):
         if name in params:
             assert params[name].startswith(_A_PREFIXES), f"${name} bound to {params[name]!r}, outside application A's scope"
     return fake_cypher(query, params)
 
@@ -451,31 +452,31 @@ def _backend() -> TSNeo4jBackend:
 
 # =====================================================================================
 # The fake graph is what a 1.2.0 graph is
 # =====================================================================================
 def test_the_fake_graph_carries_no_module_property():
     """No ``_module``, and every ``can://`` node sits under **an application prefix** -- which is
     all the scoping has left to stand on. Asserting a *language* prefix here (as this did while the
     language was outermost) now over-asserts: a language-neutral ``@external`` ghost carries no
     language segment at all, and it is still one of application A's nodes."""
     assert GRAPH.nodes and not any("_module" in props for _, props in GRAPH.nodes.values())
-    prefixes = (f"can://{APP_A}/", f"can://{APP_B}/")
+    prefixes = (f"can://{APP_A}/{APP_A}/", f"can://{APP_B}/{APP_B}/")
     assert all(nid.startswith(prefixes) for nid, (labels, _) in GRAPH.nodes.items() if "CanNode" in labels and "TSModule" not in labels or nid.count("/") > 3)
 
 
 def test_the_scope_is_one_prefix():
     """One prefix, and the two language namespaces are inside it rather than beside it. The two
     that used to be here are still told apart in exactly one place -- ``_module_key``, which has
     to strip the language segment to reach the file key -- and nothing is scoped on them."""
     backend = _backend()
-    assert backend._scope_prefix == f"can://{APP_A}/"
-    assert backend._language_prefixes == [f"can://{APP_A}/typescript/", f"can://{APP_A}/javascript/"]
+    assert backend._scope_prefix == f"can://{APP_A}/{APP_A}/"
+    assert backend._language_prefixes == [f"can://{APP_A}/{APP_A}/typescript/", f"can://{APP_A}/{APP_A}/javascript/"]
     assert set(backend._modules) == {"a/mod.ts", SHARED_MODULE, "a/legacy.js"}
 
 
 # =====================================================================================
 # Leak tests: application A's answers and nothing of B's
 # =====================================================================================
 def test_get_class_does_not_leak_another_applications_children():
     cls = _backend().get_class(CLASS_SIG)
     assert cls is not None, "the application's own class came back empty -- the statement scoped on something the graph does not carry"
     assert {m.name for m in cls.callables.values()} == {"alpha_method"}
@@ -542,44 +543,44 @@ def test_bulk_accessors_are_application_scoped():
     assert sites["src/index.alpha_fn"] == []
     assert backend.get_classes_with_decorators(["Deco"]) == {"Deco": [CLASS_SIG]}
 
 
 def test_call_graph_and_externals_are_application_scoped():
     backend = _backend()
     graph = backend.get_call_graph()
     assert set(graph.edges) == {(METHOD_SIG, "alpha.inner_fn"), (METHOD_SIG, "os.path")}
     assert graph.nodes["os.path"]["kind"] == "external"
     assert list(backend.get_external_symbols()) == ["os.path"], "application B's external (os.join) leaked"
-    assert backend.get_external_symbols()["os.path"].id == f"can://{APP_A}/@external/os/path"
+    assert backend.get_external_symbols()["os.path"].id == f"can://{APP_A}/{APP_A}/@external/os/path"
     assert backend.get_calling_lines("alpha.inner_fn") == [5]
     assert backend.get_calling_lines("beta.inner_fn") == []
-    assert set(backend.get_synthesized_callables()) == {f"can://{APP_A}/typescript/{SHARED_MODULE}/alpha_fn/<anon@2:2>"}
+    assert set(backend.get_synthesized_callables()) == {f"can://{APP_A}/{APP_A}/typescript/{SHARED_MODULE}/alpha_fn/<anon@2:2>"}
 
 
 def test_a_declaration_merged_node_is_the_facet_its_edge_and_labels_name_and_nothing_else():
     """``Option`` is one node carrying ``TSCallable`` and ``TSInterface`` with ``kind: arrow``: it
     is a function to every accessor, an interface to none, and never a namespace."""
     backend = _backend()
     assert "a/mod.Option" not in backend.get_all_interfaces()
     assert backend.get_interface_properties("a/mod.Option") == []
     assert backend.get_all_functions()["a/mod.Option"].kind == "arrow"
     assert "a/mod.Gran" not in backend.get_all_functions()
     assert backend.get_all_type_aliases() == {}, "Gran's kind is 'field': it is not served as a type alias by signature"
     assert backend.get_symbol_table()["a/mod.ts"].types["Gran"].kind == "type_alias"
     assert [f.name for f in backend.get_symbol_table()["a/mod.ts"].fields.values()] == ["Gran"]
 
 
 def test_a_merged_node_whose_labels_name_no_single_facet_is_raised_as_a_defect():
     from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
     backend = _backend()
-    parent = "can://app_a/typescript/x/y.ts"
+    parent = "can://app_a/app_a/typescript/x/y.ts"
     undecidable = {"id": f"{parent}/Z", "kind": "field", "name": "Z", "_labels": ["CanNode", "TSClass", "TSInterface"]}
     with pytest.raises(CodeanalyzerExecutionException, match=r"'Z' \(labels \['CanNode', 'TSClass', 'TSInterface'\], kind 'field'\).*one id for two declarations") as e:
         backend._declared(parent, {parent: [("TS_DECLARES", undecidable, {})]})
     assert "can://" not in str(e.value)
     with pytest.raises(CodeanalyzerExecutionException, match="none of the five type kinds"):
         backend._type({"id": f"{parent}/W", "kind": "arrow", "name": "W", "signature": "x/y.W", "_labels": ["TSCallable"]}, {})
 
 
 def test_get_typescript_file_derives_the_module_key_from_the_id():
     backend = _backend()
@@ -599,25 +600,25 @@ def test_locate_resolves_a_shared_module_key_inside_its_own_application():
     assert r.callable is not None and r.callable.name == "alpha_fn"
     assert r.callable.signature == "src/index.alpha_fn"
     assert r.module.path == SHARED_MODULE and r.diagnostics == []
     assert r.source == "fn"
 
 
 def test_locate_finds_the_innermost_callable_and_its_body_node():
     r = _backend().locate("a/mod.ts", 5)
     assert r.callable.signature == METHOD_SIG and r.type is not None and r.type.signature == CLASS_SIG
     assert r.body is not None and r.body.kind == "call"
-    assert r.body.id == f"can://{APP_A}/typescript/a/mod.ts/Widget/render@5:3"
+    assert r.body.id == f"can://{APP_A}/{APP_A}/typescript/a/mod.ts/Widget/render@5:3"
     assert r.node_id == r.body.id
     # ``callee`` is a property on a TypeScript body node, so this backend fills it in -- unlike the
     # Python Neo4j backend, where callee resolution is a separate edge and the field stays None.
-    assert r.body.callee == f"can://{APP_A}/typescript/a/mod.ts/Widget/render@5:3".replace("@5:3", "/inner_fn")
+    assert r.body.callee == f"can://{APP_A}/{APP_A}/typescript/a/mod.ts/Widget/render@5:3".replace("@5:3", "/inner_fn")
     # Line-only span: the projection carries no columns and no offsets.
     assert r.body.span.start == (5, 0) and r.body.span.bytes == (0, 0)
 
 
 def test_locate_at_module_scope_says_the_graph_has_no_module_text():
     r = _backend().locate("a/mod.ts", 20)
     assert r.callable is None and r.body is None and r.source == ""
     assert [d.code for d in r.diagnostics] == ["module_scope", "module_source_unavailable"]
 
 
@@ -627,26 +628,26 @@ def test_locate_in_another_applications_module_is_file_not_in_graph():
 
 
 def test_locate_many_answers_in_input_order_including_the_misses():
     out = _backend().locate_many([("a/legacy.js", 1), ("b/mod.ts", 2), ("a/mod.ts", 5)])
     assert [r.callable.signature if r.callable else None for r in out] == ["a/legacy.legacy_fn", None, METHOD_SIG]
 
 
 def test_resolve_callable_honours_the_javascript_prefix():
     n = _backend().resolve_callable("legacy_fn")
     assert n.callable == "a/legacy.legacy_fn" and n.file == "a/legacy.js"
-    assert n.ref == f"can://{APP_A}/javascript/a/legacy.js/legacy_fn"
+    assert n.ref == f"can://{APP_A}/{APP_A}/javascript/a/legacy.js/legacy_fn"
 
 
 def test_resolve_callable_does_not_see_another_applications_colliding_signature():
     n = _backend().resolve_callable("Widget.render")
-    assert n.name == "alpha_method" and n.ref.startswith(f"can://{APP_A}/typescript/")
+    assert n.name == "alpha_method" and n.ref.startswith(f"can://{APP_A}/{APP_A}/typescript/")
 
 
 def test_resolve_callable_takes_the_dotted_module_form():
     assert _backend().resolve_callable("alpha_fn", in_module="src.index").callable == "src/index.alpha_fn"
     assert _backend().resolve_callable("alpha_fn", in_module="src/index.ts").callable == "src/index.alpha_fn"
 
 
 def test_an_anonymous_callable_is_addressed_by_its_signature():
     n = _backend().resolve_callable("<anon@2:2>")
     assert n.callable == "src/index.<anon@2:2>" and n.name == "(anonymous)"
@@ -661,30 +662,30 @@ def test_a_declaration_merged_node_resolves_only_to_the_facet_its_kind_names():
     ``TSTypeAlias``/``TSField``, kind ``field`` -- and must not be reachable through a *callable*
     accessor at all, which is what the ``kind IN`` guard buys: a miss, never a wrong facet."""
     assert _backend().resolve_callable("Option").callable == "a/mod.Option"
     with pytest.raises(SelectorNotInGraph):
         _backend().resolve_callable("Gran")
 
 
 def test_get_source_answers_for_a_callable_and_refuses_below_it():
     backend = _backend()
     assert backend.get_source(METHOD_SIG) == "alpha code"
-    assert backend.get_source(f"can://{APP_A}/typescript/a/mod.ts/Widget/render") == "alpha code"
+    assert backend.get_source(f"can://{APP_A}/{APP_A}/typescript/a/mod.ts/Widget/render") == "alpha code"
     with pytest.raises(NotImplementedError):
-        backend.get_source(f"can://{APP_A}/typescript/a/mod.ts/Widget/render@5:3")
+        backend.get_source(f"can://{APP_A}/{APP_A}/typescript/a/mod.ts/Widget/render@5:3")
     with pytest.raises(KeyError):
         backend.get_source("no.such.thing")
 
 
 def test_get_source_does_not_answer_with_another_applications_text():
     with pytest.raises(KeyError):
-        _backend().get_source(f"can://{APP_B}/typescript/b/mod.ts/Widget/render")
+        _backend().get_source(f"can://{APP_B}/{APP_B}/typescript/b/mod.ts/Widget/render")
 
 
 def test_describe_hydrates_a_callable_and_leaves_a_body_node_textless():
     backend = _backend()
     located = backend.locate("a/mod.ts", 5)
     resolved = backend.resolve_callable("Widget.render")
     out = backend.describe([resolved, located])
     assert out[0].source == "alpha code"
     assert out[1].source is None  # the graph carries no text below callable granularity
 
@@ -861,21 +862,20 @@ def _match_clauses(statement: str) -> List[str]:
 
     A pattern comprehension binds nodes as surely as a ``MATCH`` does -- ``_PATHS`` has two
     (``head([(c:TSCallable)-[:TS_HAS_BODY_NODE]->(n) | c.signature])``) -- and reading only the
     ``MATCH`` clauses made them invisible to the audit (leg 2.5b review, finding 8). They are
     returned as clauses of their own so the chain scanner sees each pattern whole.
     """
     out = [re.sub(r"^(?:OPTIONAL )?MATCH ", "", c) for c in _clauses(statement) if re.match(r"(?:OPTIONAL )?MATCH ", c)]
     return out + [m.group(1) for m in _PATTERN_COMPREHENSION.finditer(statement)]
 
 
-
 def _paths_with_scoped_interiors(rendered: str) -> Set[str]:
     """Path variables every one of whose nodes the statement pins, via
     ``all(<v> IN nodes(<p>) WHERE … <v> is scoped …)``.
 
     The ``all()`` body is read to its balanced close rather than with a regex, so a scope predicate
     that is itself parenthesised -- which :func:`_scoped` always is -- is inside the text searched.
     """
     found: Set[str] = set()
     for m in re.finditer(r"all\((\w+) IN nodes\((\w+)\)\s+WHERE ", rendered):
         var, path, depth, i = m.group(1), m.group(2), 1, m.end()
diff --git a/tests/analysis/typescript/test_typescript_neo4j_selection.py b/tests/analysis/typescript/test_typescript_neo4j_selection.py
index d186d7a..655ff92 100644
--- a/tests/analysis/typescript/test_typescript_neo4j_selection.py
+++ b/tests/analysis/typescript/test_typescript_neo4j_selection.py
@@ -69,21 +69,21 @@ def test_no_config_uses_in_memory_backend(typescript_application):
             project_path=typescript_application,
             analysis_level=AnalysisLevel.symbol_table,
         )
 
         backend_cls.assert_called_once()
         neo4j_cls.assert_not_called()
         assert analysis.backend is backend_cls.return_value
         assert isinstance(analysis.backend_config, CodeAnalyzerConfig)
         # The in-process backend caches under a language-keyed <cache_dir>/typescript subdir.
         _, kwargs = backend_cls.call_args
-        assert str(kwargs["analysis_json_path"]).endswith("/.codeanalyzer/typescript")
+        assert str(kwargs["analysis_json_path"].parent).endswith("/.codeanalyzer/typescript")
 
 
 def test_missing_neo4j_driver_raises_helpful_error():
     """Without the optional ``neo4j`` driver, constructing the backend explains how to install it."""
     import builtins
 
     from cldk.analysis.typescript.neo4j import TSNeo4jBackend
     from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
     real_import = builtins.__import__
diff --git a/tests/analysis/typescript/test_typescript_taint.py b/tests/analysis/typescript/test_typescript_taint.py
index f3b7354..f9c381b 100644
--- a/tests/analysis/typescript/test_typescript_taint.py
+++ b/tests/analysis/typescript/test_typescript_taint.py
@@ -39,21 +39,21 @@ import pytest
 from cldk.analysis.commons.results import Diagnostic, FlowPath, PathHop, SliceNode
 from cldk.analysis.typescript.backend import SDG_REL_PATTERN, TSAnalysisBackend
 from cldk.analysis.typescript.neo4j.neo4j_backend import TSNeo4jBackend
 from cldk.utils.exceptions.exceptions import SelectorNotInGraph
 
 from .conftest import FakeDriver
 
 
 def _value(name: str, within: str) -> SliceNode:
     """A resolved value, addressed as this surface addresses one: a name plus the callable it enters."""
-    return SliceNode(file="app.ts", line=1, callable=within, kind="parameter", name=name, ref=f"can://app/typescript/app.ts/{within}#{name}")
+    return SliceNode(file="app.ts", line=1, callable=within, kind="parameter", name=name, ref=f"can://app/app/typescript/app.ts/{within}#{name}")
 
 
 def _witness(frm: SliceNode, to: SliceNode) -> FlowPath:
     return FlowPath(hops=[PathHop(frm=frm, to=to, via="data", var="answer", prov=["reaching-defs"])])
 
 
 class _Recording(TSAnalysisBackend):
     """The contract with only the four methods ``taint()`` touches, and a walk that records its call.
 
     ``__abstractmethods__`` is cleared below rather than the other fifty-odd methods being stubbed:
@@ -66,21 +66,21 @@ class _Recording(TSAnalysisBackend):
         self._blocked = dict(blocked or {})
         self._edge_vars = set(edge_vars)
         self.resolved = []
         self.walks = []
 
     def resolve_value(self, name, *, within):
         self.resolved.append((name, within))
         return _value(name, within)
 
     def resolve_callable(self, name, *, in_class=None, in_module=None):
-        return SliceNode(file="app.ts", line=1, callable=name, kind="callable", name=None, ref=f"can://app/typescript/app.ts/{name}")
+        return SliceNode(file="app.ts", line=1, callable=name, kind="callable", name=None, ref=f"can://app/app/typescript/app.ts/{name}")
 
     def _edge_vars_in(self, callable_id):
         return self._edge_vars
 
     def _taint_walk(self, srcs, dsts, *, cuts, cut_callables, depth, max_paths):
         self.walks.append({"srcs": [n.ref for n in srcs], "dsts": [n.ref for n in dsts], "cuts": cuts, "cut_callables": cut_callables, "depth": depth, "max_paths": max_paths})
         return self._rows, self._blocked
 
 
 _Recording.__abstractmethods__ = frozenset()
@@ -204,22 +204,22 @@ def test_two_selectors_that_resolve_to_the_same_position_are_one_pair():
     assert len(capped.paths) == 2 and not capped.complete, "the cap holds per distinct pair"
     assert once.exhausted == [] and capped.exhausted == []
 
 
 def test_the_sanitizer_selectors_are_resolved_through_the_edge_vars_hook():
     """Step 4 of the order: the two shapes reach the walk as ``$cuts`` and ``$cut_callables``, and a
     variable selector is checked against the vars on real SDG edges rather than ``resolve_value``,
     which addresses only parameters."""
     backend = _Recording()
     backend.taint([("x", "f")], [("y", "g")], sanitizers=[("answer", "f"), "scrub"])
-    assert backend.walks[0]["cuts"] == [{"var": "answer", "prefix": "can://app/typescript/app.ts/f"}]
-    assert backend.walks[0]["cut_callables"] == ["can://app/typescript/app.ts/scrub"]
+    assert backend.walks[0]["cuts"] == [{"var": "answer", "prefix": "can://app/app/typescript/app.ts/f"}]
+    assert backend.walks[0]["cut_callables"] == ["can://app/app/typescript/app.ts/scrub"]
 
 
 def test_a_sanitizer_that_does_not_resolve_raises_before_the_walk():
     backend = _Recording(edge_vars=())
     with pytest.raises(SelectorNotInGraph):
         backend.taint([("x", "f")], [("y", "g")], sanitizers=[("answer", "f")])
     assert backend.walks == [], "sanitizers are resolved before the traversal, not applied after it"
 
 
 def test_complete_is_the_batch_flag_so_one_skipped_pair_flips_it_and_a_bigger_cap_will_not_help():
@@ -278,22 +278,22 @@ def test_the_two_walk_hooks_are_abstract_methods():
     assert "_taint_walk" in str(err.value) and "_edge_vars_in" in str(err.value)
 
 
 # ==============================================================================================
 # The graph backend's half, over a fake driver: statement text, parameter binding, row translation.
 # ==============================================================================================
 #: One module, so ``_slice_row``'s ``file`` can be verified against the application's module keys the
 #: way it is against a real graph's -- a body-node id embeds the module key and the graph stores no
 #: path to project instead.
 _MODULE = "app.ts"
-_HANDLE = f"can://app/typescript/{_MODULE}/handle"
-_SINK = f"can://app/typescript/{_MODULE}/query"
+_HANDLE = f"can://app/app/typescript/{_MODULE}/handle"
+_SINK = f"can://app/app/typescript/{_MODULE}/query"
 
 
 def _row(src: str, dst: str, *, var: str = "answer") -> dict:
     """One witness as the statement projects it: ``ns`` per node, ``rs`` per hop, one fewer hop than
     nodes. The keys are :attr:`TSNeo4jBackend._TAINT`'s projection, which is
     :attr:`~TSNeo4jBackend._PATHS`' verbatim -- that shared projection is what makes a taint witness
     and a ``paths_between`` witness describe a node identically."""
     return {
         "src": src,
         "dst": dst,
@@ -306,21 +306,21 @@ def _row(src: str, dst: str, *, var: str = "answer") -> dict:
 
 
 def _graph(rows=(), edge_vars=(), record=None):
     """A ``TSNeo4jBackend`` over a fake driver that answers the attach probes, the taint statement and
     the edge-variable statement, and records the parameters each was bound with."""
 
     def _responder(query, params):
         if record is not None:
             record.append((query, dict(params)))
         if "TS_HAS_MODULE" in query:
-            return [{"k": _MODULE, "id": f"can://app/typescript/{_MODULE}"}]
+            return [{"k": _MODULE, "id": f"can://app/app/typescript/{_MODULE}"}]
         if "AS ok" in query:
             return [{"ok": True}]
         if "collect(DISTINCT r.var) AS vars" in query:
             return [{"vars": list(edge_vars)}]
         if "AS src, b.id AS dst" in query:
             return list(rows)
         return []
 
     return TSNeo4jBackend._from_driver(FakeDriver(responder=_responder), application_name="app")
 
@@ -335,21 +335,21 @@ def test_the_graph_walk_issues_the_generated_statement_and_binds_the_cap_one_pas
     src, dst = _value("raw", "handle"), _value("cleaned", "query")
     graph._taint_walk([src], [dst], cuts=[{"var": "answer", "prefix": _HANDLE}], cut_callables=[_SINK], depth=None, max_paths=3)
     query, params = record[-1]
     assert query == TSNeo4jBackend._TAINT.format(rels=SDG_REL_PATTERN, depth="")
     assert params == {
         "srcs": [src.ref],
         "dsts": [dst.ref],
         "cuts": [{"var": "answer", "prefix": _HANDLE}],
         "cut_callables": [_SINK],
         "cap": 4,
-        "p": "can://app/",
+        "p": "can://app/app/",
     }
 
 
 def test_an_explicit_depth_reaches_the_statement_as_the_quantifiers_upper_bound():
     """``depth=None`` renders ``*1..`` and a bound renders ``*1..5``; the walk is the only place that
     substitution happens, so a backend that forgot it would answer every call unbounded -- and an
     unbounded answer to a bounded question is the direction that manufactures witnesses."""
     record = []
     _graph(record=record)._taint_walk([_value("raw", "handle")], [_value("cleaned", "query")], cuts=[], cut_callables=[], depth=5, max_paths=1)
     assert record[-1][0] == TSNeo4jBackend._TAINT.format(rels=SDG_REL_PATTERN, depth="5")
@@ -357,23 +357,21 @@ def test_an_explicit_depth_reaches_the_statement_as_the_quantifiers_upper_bound(
 
 
 def test_the_graph_walk_returns_every_row_untrimmed_and_keyed_by_the_pair_the_server_reported():
     """Grouping and trimming are ``taint()``'s, so the walk hands back what it found -- including the
     ``max_paths + 1``-th row. Trimming here would put the cap in two places and make ``complete``
     unprovable from either.
 
     The pairing comes from the statement's own ``a.id AS src`` / ``b.id AS dst`` and never from the
     order the rows arrive in: the m*n batching is only useful if the grouping survives it."""
     src, dst = _value("raw", "handle"), _value("cleaned", "query")
-    rows, blocked = _graph(rows=[_row(src.ref, dst.ref), _row(src.ref, dst.ref, var="second")])._taint_walk(
-        [src], [dst], cuts=[], cut_callables=[], depth=None, max_paths=1
-    )
+    rows, blocked = _graph(rows=[_row(src.ref, dst.ref), _row(src.ref, dst.ref, var="second")])._taint_walk([src], [dst], cuts=[], cut_callables=[], depth=None, max_paths=1)
     assert [(r[0], r[1]) for r in rows] == [(src.ref, dst.ref)] * 2, "two rows for a cap of one: the extra row is what reports truncation"
     assert [r[2].hops[0].var for r in rows] == ["answer", "second"]
     assert blocked == {}, "Ruling I: an empty ledger is a refusal to file, argued in the walk's docstring"
 
 
 def test_a_graph_row_is_described_the_way_a_paths_between_row_is():
     """Same projection, same ``_slice_row``: ``file`` derived from the id's own module key (verified
     against the application's, never split), ``via`` translated through the shared ``VIA`` table, and
     a parameter-passing vertex with no span of its own borrowing the callable's first line."""
     src, dst = _value("raw", "handle"), _value("cleaned", "query")
diff --git a/tests/models/go/test_go_models.py b/tests/models/go/test_go_models.py
index ecad147..6f6c674 100644
--- a/tests/models/go/test_go_models.py
+++ b/tests/models/go/test_go_models.py
@@ -26,40 +26,40 @@ LS_FUNC_SIG = "github.com/benbjohnson/litestream/abs.NewReplicaClient"
 # -----[ real corpus: the mirror parses genuine cango output at scale ]-----
 @pytest.fixture(scope="module")
 def litestream() -> GoAnalysis:
     return GoAnalysis.model_validate_json(GO_ANALYSIS.read_text(encoding="utf-8"))
 
 
 def test_real_corpus_envelope(litestream):
     assert litestream.schema_version == "2.0.0"
     assert litestream.language == "go"
     assert litestream.max_level == 2
-    assert litestream.application.id == "can://go/litestream"
+    assert litestream.application.id == "can://litestream/litestream"
     assert len(litestream.application.symbol_table) == 55
-    assert len(litestream.application.call_graph) == 959
+    assert len(litestream.application.call_graph) == 3082
 
 
 def test_real_corpus_struct_round_trips(litestream):
     """A real struct with its method and field survives the round trip with its native shape."""
     mod = litestream.application.symbol_table[LS_MODULE]
     assert mod.package == "abs" and mod.source  # the module carries its source text
     ty = mod.types[LS_TYPE]
     assert ty.kind == "struct"
     assert LS_METHOD_SIG in ty.callables
     assert ty.callables[LS_METHOD_SIG].kind == "method"
     assert ty.fields["AccountKey"].type == "string"
     assert LS_FUNC_SIG in mod.functions  # a package-level constructor function
 
 
 def test_real_corpus_call_edges_are_well_formed(litestream):
     """Every edge names a src and dst id under the application; prov/weight parse."""
-    pre = "can://go/litestream/"
+    pre = "can://litestream/litestream/"
     for e in litestream.application.call_graph:
         assert e.src.startswith(pre) and e.dst.startswith(pre)
         assert isinstance(e.prov, list) and isinstance(e.weight, int)
 
 
 # -----[ the Go-specific model shape, pinned inline ]-----
 def test_gotype_is_a_single_model_with_a_kind_field():
     t = GoType(id="can://go/x/f.go/T", kind="struct")
     assert t.kind == "struct"
     assert t.base_types == [] and t.callables == {} and t.fields == {}
diff --git a/tests/models/java/test_java_models.py b/tests/models/java/test_java_models.py
index 02137a8..673faae 100644
--- a/tests/models/java/test_java_models.py
+++ b/tests/models/java/test_java_models.py
@@ -39,22 +39,22 @@ def a4(analysis_json_a4) -> JAnalysis:
     return JAnalysis.model_validate_json(analysis_json_a4)
 
 
 def test_envelope_at_both_levels(a1: JAnalysis, a4: JAnalysis):
     for a, level in ((a1, 1), (a4, 4)):
         assert a.schema_version == "2.0.0"
         assert a.language == "java"
         assert a.max_level == level
         assert a.k_limit is None  # never emitted by 3.0.x
         assert a.analyzer.name == "codeanalyzer-java"
-        assert a.analyzer.version == "3.1.0"
-        assert a.application.id == "can://java/daytrader8"
+        assert a.analyzer.version == "3.3.4"
+        assert a.application.id == "can://daytrader8/daytrader8"
         assert a.application.kind == "application"
 
 
 def test_l1_has_138_units_and_no_app_scope_overlays(a1: JAnalysis):
     app = a1.application
     assert len(app.symbol_table) == 138
     # L1 emits no ``call_graph``/``param_in``/``param_out`` keys at all — the defaults are empty, not None.
     assert app.call_graph == []
     assert app.param_in == []
     assert app.param_out == []
diff --git a/tests/models/python/test_python_models.py b/tests/models/python/test_python_models.py
index 6000058..0a45ce6 100644
--- a/tests/models/python/test_python_models.py
+++ b/tests/models/python/test_python_models.py
@@ -1,17 +1,44 @@
 def test_v2_models_are_reexported():
     from cldk.models.python import (
-        Span, BodyNode, CfgEdge, CdgEdge, DdgEdge, SummaryEdge, ParamEdge,
-        PyDecorator, PyEntrypoint, PyExternalSymbol,
-        PyArtifact, PyDependency, PyConfigKey, PyConfigUseEdge, PyAnalyzerInfo,
+        Span,
+        BodyNode,
+        CfgEdge,
+        CdgEdge,
+        DdgEdge,
+        SummaryEdge,
+        ParamEdge,
+        PyDecorator,
+        PyEntrypoint,
+        PyExternalSymbol,
+        PyArtifact,
+        PyDependency,
+        PyConfigKey,
+        PyConfigUseEdge,
+        PyAnalyzerInfo,
     )
-    assert Span.model_fields.keys() >= {"start", "end", "bytes"}
-    assert "callee" in BodyNode.model_fields          # the one sanctioned null slot
-    assert {"var", "prov"} <= DdgEdge.model_fields.keys()
+    from dataclasses import fields
+
+    assert {f.name for f in fields(Span)} >= {"start", "end", "bytes"}
+    assert "callee" in {f.name for f in fields(BodyNode)}
+    assert {"var", "prov"} <= {f.name for f in fields(DdgEdge)}
+
 
 def test_v1_names_still_exported():
     """D4: the existing surface does not move."""
     import cldk.models.python as m
-    for name in ("PyApplication", "PyCallEdge", "PyCallable", "PyCallableParameter",
-                 "PyCallsite", "PyClass", "PyClassAttribute", "PyComment", "PyImport",
-                 "PyModule", "PySymbol", "PyVariableDeclaration"):
+
+    for name in (
+        "PyApplication",
+        "PyCallEdge",
+        "PyCallable",
+        "PyCallableParameter",
+        "PyCallsite",
+        "PyClass",
+        "PyClassAttribute",
+        "PyComment",
+        "PyImport",
+        "PyModule",
+        "PySymbol",
+        "PyVariableDeclaration",
+    ):
         assert hasattr(m, name), name
diff --git a/tests/models/typescript/test_ts_v2_models.py b/tests/models/typescript/test_ts_v2_models.py
index 85d38e7..f563909 100644
--- a/tests/models/typescript/test_ts_v2_models.py
+++ b/tests/models/typescript/test_ts_v2_models.py
@@ -86,37 +86,37 @@ def _all_callables(app: TSApplication) -> Iterator[Tuple[TSCallable, TSModule]]:
         yield from _callables(m)
 
 
 @pytest.mark.parametrize("level", [1, 2, 3, 4])
 def test_every_level_validates(level: int):
     a = _load(level)
     assert a.schema_version == "2.0.0"
     assert a.language == "typescript"
     assert a.max_level == level
     assert a.analyzer.name == "codeanalyzer-typescript"
-    assert a.analyzer.version == _pinned_version()
-    assert a.application.id == "can://slim"
+    assert a.analyzer.version == "1.6.4"  # reviewed local producer fixture
+    assert a.application.id == "can://slim/slim"
     assert a.application.kind == "application"
     assert (a.k_limit is not None) == (level >= 3)
 
 
 @pytest.mark.parametrize("level", [1, 2, 3, 4])
 def test_round_trip_is_lossless(level: int):
     raw = json.loads((FIXTURES / f"a{level}" / "analysis.json").read_text(encoding="utf-8"))
     assert TSAnalysis.model_validate(raw).model_dump(mode="json", exclude_unset=True) == raw
 
 
 def test_module_carries_source_and_content_hash():
     app = _load(1).application
     m = next(iter(app.symbol_table.values()))
     assert m.kind == "module"
-    assert m.id.startswith("can://slim/typescript/")
+    assert m.id.startswith("can://slim/slim/typescript/")
     assert m.content_hash
     assert m.source and m.span.bytes[1] == len(m.source)
 
 
 def test_types_is_a_kind_discriminated_union_and_the_1x_maps_are_filters():
     app = _load(1).application
     seen = set()
     for m in app.symbol_table.values():
         assert m.classes == {k: t for k, t in m.types.items() if t.kind == "class"}
         assert m.interfaces == {k: t for k, t in m.types.items() if t.kind == "interface"}
@@ -180,41 +180,41 @@ def test_l3_bodies_have_entry_exit_and_reaching_defs_ddg():
     assert all(e.prov == ["reaching-defs"] for e in c.ddg)
     assert {e.kind for c, _ in _all_callables(app) for e in (c.cfg or [])} >= {"fallthrough", "true", "false"}
 
 
 def test_l4_formal_vertices_and_param_edges():
     app = _load(4).application
     c = next(c for c, _ in _all_callables(app) if "@formal_in:0" in c.body)
     assert c.body["@formal_in:0"].kind == "formal_in"
     assert c.body["@formal_out"].kind == "formal_out"
     assert app.param_in and app.param_out
-    assert app.param_in[0].src.startswith("can://slim/typescript/")
+    assert app.param_in[0].src.startswith("can://slim/slim/typescript/")
     assert any(c.summary for c, _ in _all_callables(app))
 
 
 def test_call_graph_edge_shape_and_externals():
     app = _load(2).application
     e = app.call_graph[0]
     assert isinstance(e, TSCallGraphEdge)
     assert set(TSCallGraphEdge.model_fields) == {"src", "dst", "prov", "weight"}
     assert e.src.startswith("can://") and e.dst.startswith("can://")
-    assert all(k.startswith("can://slim/@external/") for k in app.external_symbols)
+    assert all(k.startswith("can://slim/slim/@external/") for k in app.external_symbols)
     ext = next(iter(app.external_symbols.values()))
     assert ext.kind == "external" and ext.id in app.external_symbols
     assert app.synthesized_callables
     assert all(v.kind == "callable" and v.id for v in app.synthesized_callables.values())
 
 
 def test_artifact_layer():
     app = _load(1).application
     art = next(iter(app.artifacts.values()))
-    assert art.kind == "artifact" and art.id.startswith("can://slim/artifact/")
+    assert art.kind == "artifact" and art.id.startswith("can://slim/slim/artifact/")
     assert art.sha256 and art.source
     assert any(ck.value is not None for a in app.artifacts.values() for ck in a.config_keys)
     assert app.dependencies == [] and app.unresolved_imports == []
 
 
 def test_1x_shaped_document_is_rejected():
     v1 = {
         "symbol_table": {"src/a.ts": {"file_path": "src/a.ts", "module_name": "a"}},
         "call_graph": [],
     }
diff --git a/tests/resources/go/analysis.json b/tests/resources/go/analysis.json
[Generated native snapshot: full diff retained in task-6-review-package.md; generator, provenance and model tests in this source package.]

diff --git a/tests/resources/go/analysis_json/v2/README.md b/tests/resources/go/analysis_json/v2/README.md
index 1ca3178..1b3d303 100644
--- a/tests/resources/go/analysis_json/v2/README.md
+++ b/tests/resources/go/analysis_json/v2/README.md
@@ -1,10 +1,29 @@
+## Identity-v2 snapshots (2026-10-30)
+
+These positive fixtures were regenerated from `tests/resources/go/litestream.zip`, SHA-256 `28c63ee3fba625529d78ab6174a1163b028f980f312598c368a57b32a3471cde`, using reviewed local
+`codeanalyzer-go` source commit `4e1fb80e099a82b9f21c1cf749d43cd749eba251` (reported version `0.1.0`).
+These are local verification builds; the dependency release pins are unchanged.
+Every envelope carries required `identity_version: 2` and raw application ownership metadata.
+The resulting application is `can://litestream/litestream`; 55 modules and 3,082 call edges.
+
+Reproduce from the SDK root with the reviewed producer artifacts configured:
+
+```sh
+.venv/bin/python tests/resources/regenerate_identity_fixtures.py go
+```
+
+The checked-in generator records the exact CLI arguments and source pruning. It uses the
+existing TS/Go binary environment overrides and the installed Java wheel. Java regeneration requires Maven and a JDK; its gzip artifacts use `mtime=0`.
+No persisted IDs were translated.
+The historical notes below describe earlier fixture generations and are superseded by this section.
+
 The Go analysis fixture is a single schema-v2 output committed one directory up, at
 `tests/resources/go/analysis.json`, generated by **codeanalyzer-go** (`cango`) on the application in
 `tests/resources/go/litestream.zip` (the [litestream](https://github.com/benbjohnson/litestream) Go
 project). It is the real `can://go/litestream` corpus: 55 modules, 959 call-graph edges,
 `max_level: 2`.
 
     # unzip litestream.zip -> litestream/ (carries go.mod at its root)
     cango -i litestream --app-name litestream -a 2 -o <dir> --cache-dir <dir> --skip-tests
 
 That is the command `GoCodeanalyzer._argv` builds (`cldk/analysis/go/codeanalyzer/codeanalyzer.py`),
diff --git a/tests/resources/java/analysis_json/v2/README.md b/tests/resources/java/analysis_json/v2/README.md
index 235f972..c516310 100644
--- a/tests/resources/java/analysis_json/v2/README.md
+++ b/tests/resources/java/analysis_json/v2/README.md
@@ -1,10 +1,31 @@
+## Identity-v2 snapshots (2026-10-30)
+
+These positive fixtures were regenerated from `tests/resources/java/application/daytrader8-1.2.zip`, SHA-256 `0624ad6b46ab2f1f23df936a55663edae8c2704b866005e013150a93f52c03b7`, using reviewed local
+`codeanalyzer-java` source commit `cbfbd01dd9ed3f5bfca51237487d0273f4eff4ec` (reported version `3.3.4`).
+These are local verification builds; the dependency release pins are unchanged.
+Every envelope carries required `identity_version: 2` and raw application ownership metadata.
+The resulting application is `can://daytrader8/daytrader8`; L1 has 138 modules; pruned L4 has four modules, 247 call edges, 258 param-in and 97 param-out edges, and 320 WALA points-to edges.
+
+Reproduce from the SDK root with the reviewed producer artifacts configured:
+
+```sh
+.venv/bin/python tests/resources/regenerate_identity_fixtures.py java
+```
+
+The checked-in generator records the exact CLI arguments and source pruning. It uses the
+existing TS/Go binary environment overrides and the installed Java wheel. Java requires Maven
+and a JDK; a complete strict L4 run builds the full source before the four-file snapshot is
+emitted with `--no-build --strict`. The WALA log verified 118 visited callables and 320 added
+points-to edges. Java gzip artifacts use `mtime=0`. No persisted IDs were translated.
+The historical notes below describe earlier fixture generations and are superseded by this section.
+
 Generated from `tests/resources/java/application/daytrader8-1.2.zip` (unzipped to `<daytrader8>` =
 `sample.daytrader8-1.2/`) by **codeanalyzer-java 3.1.0** — the pinned `codeanalyzer-java` wheel (the
 `cldk[java]` extra), run as `codeanalyzer_java.command()`: the wheel's own jar on the JVM it bundles
 (`jdk4py`, Temurin 21.0.8), with `JAVA_HOME` unset. **Never hand-edit these files** — regenerate
 them when the pin moves.
 
 **Deliberately still 3.1.0, though the pin is 3.1.1 (python-sdk#376).** 3.1.1 changed only the
 `can://` id grammar — the application moved to the outermost segment and `@external` ids lost their
 language segment — and these fixtures drive the **local** backend, which never parses that grammar:
 an id is an opaque handle everywhere on that surface, so a 3.1.0 payload is still a valid input and
diff --git a/tests/resources/java/analysis_json/v2/a1/analysis.json.gz b/tests/resources/java/analysis_json/v2/a1/analysis.json.gz
[Generated native snapshot: full diff retained in task-6-review-package.md; generator, provenance and model tests in this source package.]

diff --git a/tests/resources/java/analysis_json/v2/a4/analysis.json.gz b/tests/resources/java/analysis_json/v2/a4/analysis.json.gz
[Generated native snapshot: full diff retained in task-6-review-package.md; generator, provenance and model tests in this source package.]

diff --git a/tests/resources/regenerate_identity_fixtures.py b/tests/resources/regenerate_identity_fixtures.py
new file mode 100644
index 0000000..a3c17c1
--- /dev/null
+++ b/tests/resources/regenerate_identity_fixtures.py
@@ -0,0 +1,125 @@
+"""Regenerate identity-v2 positive snapshots from source; never translate persisted IDs.
+
+Run with the SDK Python environment after configuring the reviewed local producer artifacts:
+    python tests/resources/regenerate_identity_fixtures.py [all|java|typescript|go]
+Java requires Maven, a JDK, and dependency access. Each producer invocation is bounded to 180s.
+"""
+
+from __future__ import annotations
+
+import argparse
+import gzip
+import os
+from pathlib import Path
+import shutil
+import subprocess
+import tempfile
+import zipfile
+
+RESOURCES = Path(__file__).resolve().parent
+
+
+def run(argv: list[str], log: Path) -> None:
+    print(f"Generating {log.stem}", flush=True)
+    with log.open("w") as stream:
+        subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT, check=True, timeout=180)
+
+
+def generate_typescript(work: Path) -> None:
+    binary = os.environ["CODEANALYZER_TS_BIN"]
+    import shlex
+
+    for level in [1, 2, 3, 4]:
+        out = work / f"ts-a{level}"
+        run(
+            shlex.split(binary)
+            + [
+                "-i",
+                str(RESOURCES / "typescript/application"),
+                "--namespace=slim",
+                "--app-name=slim",
+                "-a",
+                str(level),
+                "-o",
+                str(out),
+                "--cache-dir",
+                str(work / f"ts-cache-a{level}"),
+                "--skip-tests",
+            ],
+            work / f"ts-a{level}.log",
+        )
+        shutil.copyfile(out / "analysis.json", RESOURCES / f"typescript/analysis_json/v2/a{level}/analysis.json")
+
+
+def generate_go(work: Path) -> None:
+    import shlex
+
+    with zipfile.ZipFile(RESOURCES / "go/litestream.zip") as archive:
+        archive.extractall(work / "go-source")
+    out = work / "go-output"
+    run(
+        shlex.split(os.environ["CODEANALYZER_GO_BIN"])
+        + [
+            "-i",
+            str(work / "go-source/litestream"),
+            "--namespace=litestream",
+            "--app-name=litestream",
+            "-a",
+            "2",
+            "-o",
+            str(out),
+            "--cache-dir",
+            str(work / "go-cache"),
+            "--skip-tests",
+        ],
+        work / "go.log",
+    )
+    shutil.copyfile(out / "analysis.json", RESOURCES / "go/analysis.json")
+
+
+def generate_java(work: Path) -> None:
+    import codeanalyzer_java
+
+    if shutil.which("mvn") is None:
+        raise RuntimeError("Maven is required to regenerate the compiled Java snapshots")
+    with zipfile.ZipFile(RESOURCES / "java/application/daytrader8-1.2.zip") as archive:
+        archive.extractall(work / "java-source")
+    source = work / "java-source/sample.daytrader8-1.2"
+
+    def analyze(name: str, root: Path, level: int, extra: list[str]) -> Path:
+        output = work / name
+        run(
+            codeanalyzer_java.command()
+            + ["-i", str(root), "--namespace=daytrader8", "--app-name=daytrader8", "-a", str(level), "-o", str(output), "-c", str(work / (name + "-cache")), "-v"]
+            + extra,
+            work / (name + ".log"),
+        )
+        return output / "analysis.json"
+
+    # Build the complete application's classes first. Strict rejects engine-free degraded L4.
+    analyze("java-a4-full", source, 4, ["--strict"])
+    a1 = analyze("java-a1", source, 1, [])
+    pruned = work / "java-pruned"
+    shutil.copytree(source, pruned)
+    keep = {"beans/MarketSummaryDataBean.java", "beans/RunStatsDataBean.java", "impl/direct/TradeDirect.java", "web/servlet/TradeServletAction.java"}
+    for path in (pruned / "src/main/java").rglob("*.java"):
+        if not any(path.as_posix().endswith("/" + key) for key in keep):
+            path.unlink()
+    a4 = analyze("java-a4", pruned, 4, ["--no-build", "--strict"])
+    for level, payload in [(1, a1), (4, a4)]:
+        (RESOURCES / f"java/analysis_json/v2/a{level}/analysis.json.gz").write_bytes(gzip.compress(payload.read_bytes(), mtime=0))
+
+
+def main() -> None:
+    parser = argparse.ArgumentParser(description=__doc__)
+    parser.add_argument("language", choices=["all", "java", "typescript", "go"], default="all", nargs="?")
+    args = parser.parse_args()
+    with tempfile.TemporaryDirectory(prefix="cldk-identity-fixtures-") as temporary:
+        work = Path(temporary)
+        for language, generate in [("typescript", generate_typescript), ("go", generate_go), ("java", generate_java)]:
+            if args.language in ["all", language]:
+                generate(work)
+
+
+if __name__ == "__main__":
+    main()
diff --git a/tests/resources/typescript/analysis_json/v2/README.md b/tests/resources/typescript/analysis_json/v2/README.md
index 26ea20c..3ed6390 100644
--- a/tests/resources/typescript/analysis_json/v2/README.md
+++ b/tests/resources/typescript/analysis_json/v2/README.md
@@ -1,10 +1,29 @@
+## Identity-v2 snapshots (2026-10-30)
+
+These positive fixtures were regenerated from the tracked `tests/resources/typescript/application/` source tree, using reviewed local
+`codeanalyzer-typescript` source commit `9658f895e3e75d683a0c00c87069934ddf2966fa` (reported version `1.6.4`).
+These are local verification builds; the dependency release pins are unchanged.
+Every envelope carries required `identity_version: 2` and raw application ownership metadata.
+The resulting application is `can://slim/slim`; five modules at each of levels 1–4.
+
+Reproduce from the SDK root with the reviewed producer artifacts configured:
+
+```sh
+.venv/bin/python tests/resources/regenerate_identity_fixtures.py typescript
+```
+
+The checked-in generator records the exact CLI arguments and source pruning. It uses the
+existing TS/Go binary environment overrides and the installed Java wheel. Java regeneration requires Maven and a JDK; its gzip artifacts use `mtime=0`.
+No persisted IDs were translated.
+The historical notes below describe earlier fixture generations and are superseded by this section.
+
 Generated from `tests/resources/typescript/application` by the released **codeanalyzer-typescript 1.6.0** wheel:
 
     cants -i tests/resources/typescript/application --app-name slim -a <1|2|3|4> -o a<N> --cache-dir <scratch> -j 1 --no-build
 
 The application's `package.json` and `tsconfig.json` are part of the input (the artifact layer inventories
 them; `experimentalDecorators` comes from the tsconfig) and are tracked next to `src/` despite the
 repo-wide `*.json` ignore. Regenerate all four when the pin moves; the models test asserts
 `analyzer.version` against the pin, and `tests/analysis/typescript/test_typescript_e2e.py` runs the
 pinned binary on the same application.
 
diff --git a/tests/resources/typescript/analysis_json/v2/a1/analysis.json b/tests/resources/typescript/analysis_json/v2/a1/analysis.json
[Generated native snapshot: full diff retained in task-6-review-package.md; generator, provenance and model tests in this source package.]

diff --git a/tests/resources/typescript/analysis_json/v2/a2/analysis.json b/tests/resources/typescript/analysis_json/v2/a2/analysis.json
[Generated native snapshot: full diff retained in task-6-review-package.md; generator, provenance and model tests in this source package.]

diff --git a/tests/resources/typescript/analysis_json/v2/a3/analysis.json b/tests/resources/typescript/analysis_json/v2/a3/analysis.json
[Generated native snapshot: full diff retained in task-6-review-package.md; generator, provenance and model tests in this source package.]

diff --git a/tests/resources/typescript/analysis_json/v2/a4/analysis.json b/tests/resources/typescript/analysis_json/v2/a4/analysis.json
[Generated native snapshot: full diff retained in task-6-review-package.md; generator, provenance and model tests in this source package.]
