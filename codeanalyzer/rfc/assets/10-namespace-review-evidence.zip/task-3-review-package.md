fcc9529 fix: require raw namespace metadata before graph projection
f0748df feat: qualify TypeScript analysis identities by namespace
 README.md                             |  32 +++---
 schema.neo4j.json                     |   3 +
 src/build/neo4j/bolt.ts               |  35 ++++---
 src/build/neo4j/project.ts            |   5 +
 src/build/neo4j/rows.ts               |  11 +-
 src/build/neo4j/schema.ts             |   2 +-
 src/cli.ts                            |   4 +-
 src/core.ts                           |  20 +---
 src/options/options.ts                |   8 +-
 src/schema/assignIds.ts               |  22 ++--
 src/schema/emit.ts                    |  50 ++-------
 src/schema/ids.ts                     |  37 ++++---
 src/schema/schema.ts                  |   8 +-
 src/utils/cache.ts                    |   5 +-
 test/artifacts.test.ts                |  16 +--
 test/checker-guard.test.ts            |   4 +-
 test/config-keys.test.ts              |  10 +-
 test/config-use.test.ts               |   8 +-
 test/entrypoints-calls.test.ts        |   8 +-
 test/ids.test.ts                      |  18 ++--
 test/namespace.test.ts                |  72 +++++++++++++
 test/neo4j-artifact-reconcile.test.ts |  26 ++---
 test/neo4j-bolt.test.ts               |   2 +-
 test/neo4j-edge-identity.test.ts      |   4 +-
 test/neo4j-prefix-scope.test.ts       |  44 ++++----
 test/neo4j-schema.test.ts             |   2 +-
 test/schema-v2.test.ts                |  29 +++---
 test/tagged-templates.test.ts         |   2 +-
 test/workspace-root.test.ts           | 190 ----------------------------------
 29 files changed, 262 insertions(+), 415 deletions(-)
diff --git a/README.md b/README.md
index 6592a3f..d9c576b 100644
--- a/README.md
+++ b/README.md
@@ -146,23 +146,21 @@ call graph → dataflow → SDG) as analysis.json, or a Neo4j graph.
 Options:
   -i, --input <path>             project root to analyze (not required for
                                  --emit schema)
   -o, --output <dir>             output directory (omit ⇒ compact output to
                                  stdout)
   --emit <target>                output target: json (analysis.json, default) |
                                  neo4j (graph.cypher or live push) | schema (the
                                  Neo4j schema.json contract) (default: "json")
   --app-name <name>              logical application name for the graph
                                  :Application anchor (default: input dir name)
-  --workspace-root <dir>         directory file keys, module ids and artifact
-                                 ids are relative to (default: --input); must
-                                 contain --input
+  --namespace <name>             application identity namespace (default: app name)
   --neo4j-uri <uri>              push the graph to a live Neo4j over Bolt
                                  (incremental); omit to write graph.cypher (env:
                                  NEO4J_URI)
   --neo4j-user <user>            Neo4j username (default: "neo4j", env:
                                  NEO4J_USERNAME)
   --neo4j-password <password>    Neo4j password (prefer the env var; a flag is
                                  visible in shell history / process list)
                                  (default: "neo4j", env: NEO4J_PASSWORD)
   --neo4j-database <db>          Neo4j database name (env: NEO4J_DATABASE)
   -a, --analysis-level <n>       analysis depth: 1 = symbol table (default); 2 =
@@ -225,28 +223,31 @@ Options:
    cants --input ./my-ts-project --emit neo4j --output ./out     # → ./out/graph.cypher
    cants --input ./my-ts-project --emit neo4j \
      --neo4j-uri bolt://localhost:7687 --neo4j-user neo4j --neo4j-password secret
    ```
 
 3. **Incremental analysis of specific files:**
    ```sh
    cants --input ./my-ts-project --target-files src/a.ts src/b.ts
    ```
 
-4. **Repository-relative paths for a project inside a larger repo:**
+4. **Group applications in a namespace:**
    ```sh
-   cants --input ./monorepo/packages/web --workspace-root ./monorepo
-   # symbol_table key: packages/web/src/app.ts
+   cants --input ./monorepo/packages/web --app-name web --namespace monorepo
+   # application id: can://monorepo/web
+   # symbol_table key: src/app.ts (relative to --input)
    ```
-   Only the published keys and ids change: the application id (`can://<app-name>`) and
-   `signature`s stay as they are, entrypoint path rules still match from `--input`, and the cache
-   is reused either way.
+   Namespace defaults to the application name. Both root segments are always present.
+   Raw identity names are case sensitive and percent encoded; empty names, separators,
+   control characters, and dot names are rejected. Version 2 identities require
+   `identity_version: 2` on the envelope and application anchor. Regenerate legacy output
+   from source. Cache reuse requires the same namespace and application.
 
 5. **Force a clean rebuild with a custom cache directory:**
    ```sh
    cants --input ./my-ts-project --eager --cache-dir /path/to/custom-cache
    ```
 
 6. **Program graphs (level 3): CFG/PDG/SDG in `analysis.json`:**
    ```sh
    cants --input ./my-ts-project -a 3                    # full program_graphs section
    cants --input ./my-ts-project -a 3 --graphs cfg,pdg   # scope the emitted graphs
@@ -257,23 +258,24 @@ Options:
 `cants` builds one analysis in memory and can emit it three ways (`--emit`):
 
 ### `analysis.json` (default)
 
 The **canonical schema v2** — one additive Code Property Graph: a containment tree of nodes
 (`id` / `kind` / `span` / children) with typed edge overlays. Analysis **levels** populate it more
 deeply; each level only ever *adds*.
 
 ```jsonc
 {
-  "schema_version": "2.0.0", "language": "typescript", "max_level": 4, "k_limit": 3,
+  "schema_version": "2.0.0", "identity_version": 2, "language": "typescript", "max_level": 4, "k_limit": 3,
   "application": {
-    "id": "can://<app>", "name": "<app>", "kind": "application",
+    "id": "can://<namespace>/<app>", "name": "<app>", "kind": "application",
+    "identity_version": 2, "application_name": "<app>", "identity_namespace": "<namespace>",
     "symbol_table": {                     // L1: the tree, keyed by file path
       "<file>": { "kind": "module", "source": "…",
         "types":     { /* class | interface | enum | type_alias | namespace nodes */ },
         "functions": { /* callable nodes: { id, kind, span, body{}, cfg[], cdg[], ddg[], summary[] } */ },
         "fields":    { /* module-level bindings */ } } },
     "call_graph": [ /* L2: { src, dst, prov, weight } — callable → callable, can:// ids */ ],
     "param_in":   [ /* L4: actual_in → formal_in, fully-qualified can://…@local ids */ ],
     "param_out":  [ /* L4: formal_out → actual_out */ ]
   }
 }
@@ -330,35 +332,35 @@ Levels 1/2 are unaffected: nothing in level 3 runs unless `-a 3` is requested.
 ### Neo4j graph
 
 `--emit neo4j` projects the **same v2 tree** into a labeled property graph: every node keyed by its
 `can://` id under a shared `:CanNode` merge label (+ a `TS`-prefixed specific kind label, e.g.
 `:TSModule`, `:TSCallable`), containment as `TS_HAS_MODULE`/`TS_DECLARES`/`TS_HAS_METHOD`/
 `TS_HAS_FIELD`/`TS_HAS_BODY_NODE` edges, and the overlays (`TS_CALLS`, `TS_CFG_NEXT`, `TS_CDG`,
 `TS_DDG`, `TS_SUMMARY`, `TS_PARAM_IN`, `TS_PARAM_OUT`) as typed relationships. The graph is
 **always full-depth** — analysis levels gate the JSON path only, so combining `-a`/`--graphs` with
 `--emit neo4j` is an error:
 
-Every node id is `can://<app>/…`, so `can://<app>` is a prefix of every node the application
+Every node id is `can://<namespace>/<app>/…`, so `can://<namespace>/<app>` is a prefix of every node the application
 emits — the `typescript` and `javascript` namespaces are two segments *inside* it, not two
 top-level namespaces a consumer has to enumerate. That single prefix is what the destructive
 statements scope on, and `:Application` is keyed on the id rather than on `--app-name`.
 
 - **Without `--neo4j-uri`** — writes a self-contained `graph.cypher` (constraints + indexes, a
   scoped wipe, then batched `MERGE`s). Load it with `cypher-shell < graph.cypher`.
 - **With `--neo4j-uri`** — pushes to a live Neo4j over Bolt **incrementally**: only modules whose
   content hash changed are rewritten, and on a full run modules whose source file vanished are
   pruned. Every graph carries a `schema_version` on its `:Application` node.
 
   `--eager` purges this application's code nodes but not its `:Artifact`/`:ConfigKey` nodes, which
   are shared with the sibling analyzers. An `--eager` full run (no `--target-files`) reconciles them
-  instead, so a deleted or renamed file, a removed dependency, or re-keying under
-  `--workspace-root` leaves nothing stale. TypeScript-owned artifact edges (`HAS_ARTIFACT`,
+  instead, so deleted or renamed files and removed dependencies within the selected scope
+  leave nothing stale. Legacy roots and other namespaces remain outside this scope. TypeScript-owned artifact edges (`HAS_ARTIFACT`,
   `DECLARES_DEPENDENCY`/`LOCKS` to `pkg:npm/…`, `TS_PROVIDES`, `TS_USES_CONFIG`,
   `TS_READS_CONFIG_UNRESOLVED`, `TS_UNRESOLVED_IMPORT`) are rebuilt. An `:Artifact` or `:ConfigKey`
   the run no longer emits loses its `:TSCanNode` label. An artifact is then deleted only if no other
   analyzer's `HAS_ARTIFACT` still points at it; a config key only if no other analyzer's marker
   (`:JCanNode`, `:PyCanNode`) claims it. Other analyzers' edges are never removed. An
   `--eager --target-files` push reconciles nothing, so stale artifacts wait for the next full
   `--eager` push. The `graph.cypher` snapshot is a full rebuild by design: its wipe deletes every
   node this application wrote, shared artifacts included, and other analyzers restore their edges
   on their next push.
 
@@ -398,21 +400,21 @@ bun run test:container                       # Neo4j bolt tests — needs Docker
 bun run gen:schema                           # regenerate schema.neo4j.json
 bun run gen:readme                           # regenerate the cants --help block above
 ```
 
 ## License
 
 Apache 2.0 — see [LICENSE](./LICENSE).
 
 ## Polyglot applications: all languages, or none
 
-A `--emit neo4j` push is **destructive**. It sweeps everything under `can://<app>/` that this
+A `--emit neo4j` push is **destructive**. It sweeps everything under `can://<namespace>/<app>/` that this
 analyzer marked, then rewrites what it found. Since the id grammar puts the application outermost,
 every analyzer over the same `<app>` shares that prefix — so a push reclaims stale rows belonging to
 *this* analyzer and, in the shared namespaces, sweeps rows a sibling wrote.
 
 For most of what is shared that is harmless: the artifact walk is a whole-repo inventory, so an
 `:Artifact` a sibling wrote is re-created by this push (with a thinner view of it — `roles` falls
 back to `unknown` and its config keys and dependency edges are gone until that sibling pushes
 again). `@external` ghosts are not inventoried that way: they are per-language, so a sibling's
 ghosts are swept and not restored.
 
diff --git a/schema.neo4j.json b/schema.neo4j.json
index f7dbd7c..759798d 100644
--- a/schema.neo4j.json
+++ b/schema.neo4j.json
@@ -6,20 +6,23 @@
     "JSCanNode"
   ],
   "node_labels": [
     {
       "label": "TSApplication",
       "mergeLabel": "Application",
       "key": "id",
       "properties": {
         "id": "string",
         "name": "string",
+        "identity_version": "integer",
+        "application_name": "string",
+        "identity_namespace": "string",
         "schema_version": "string",
         "language": "string",
         "max_level": "integer",
         "k_limit": "integer",
         "analyzer_name": "string",
         "analyzer_version": "string",
         "entrypoint_frameworks": "string[]",
         "entrypoint_report_json": "string"
       }
     },
diff --git a/src/build/neo4j/bolt.ts b/src/build/neo4j/bolt.ts
index 9e43030..f69fa97 100644
--- a/src/build/neo4j/bolt.ts
+++ b/src/build/neo4j/bolt.ts
@@ -79,35 +79,34 @@ export const PURGE_ARTIFACT_EDGES =
 /** The app root's unresolved-read/import edges, and dependency → import edges into its ghosts. */
 export const PURGE_APP_IMPORT_EDGES =
   "MATCH (:TSApplication {id: $appId})-[r:TS_UNRESOLVED_IMPORT|TS_READS_CONFIG_UNRESOLVED]->() " +
   "CALL { WITH r DELETE r } IN TRANSACTIONS OF 1000 ROWS";
 export const PURGE_PROVIDES =
   "MATCH (:Package)-[r:TS_PROVIDES]->(g:TSExternal) WHERE g.id STARTS WITH $prefix " +
   "CALL { WITH r DELETE r } IN TRANSACTIONS OF 1000 ROWS";
 /**
  * Release this analyzer's claim on artifacts/config keys the run no longer emits. An artifact is
  * deleted once no HAS_ARTIFACT is left (every analyzer inventories with one, marked or not); a
- * config key once no other analyzer's `*CanNode` claims it. Pre-1.5.1 artifacts carry no marker,
- * so under the legacy prefix an unmarked node counts as ours.
+ * config key once no other analyzer's `*CanNode` claims it. Only the selected scope is touched.
  */
 export const RELEASE_VANISHED_ARTIFACTS =
   "UNWIND $pres AS pre " +
   "MATCH (n) WHERE (n:Artifact OR n:ConfigKey) AND n.id STARTS WITH pre AND NOT n.id IN $keep " +
-  `AND (n:${TS_MARKER} OR (pre = $legacy AND none(l IN labels(n) WHERE l ENDS WITH 'CanNode'))) ` +
+  `AND n:${TS_MARKER} ` +
   `CALL { WITH n REMOVE n:${TS_MARKER} ` +
   "WITH n WHERE (n:Artifact AND NOT ()-[:HAS_ARTIFACT]->(n)) " +
   "OR (n:ConfigKey AND none(l IN labels(n) WHERE l ENDS WITH 'CanNode')) " +
   "DETACH DELETE n } IN TRANSACTIONS OF 1000 ROWS RETURN count(*) AS released";
 
-/** `can://<app>/artifact/`, and `can://artifact/<app>/` for pre-1.5.1 pushes; both `/`-terminated. */
-export function artifactPrefixes(prefix: string): [string, string] {
-  return [`${prefix}artifact/`, `can://artifact/${prefix.slice("can://".length)}`];
+/** Artifact prefix within the selected namespace/application only. */
+export function artifactPrefixes(prefix: string): string[] {
+  return [`${prefix}artifact/`];
 }
 
 const isArtifactLabel = (label: string): boolean => label === "Artifact" || label === "ConfigKey";
 /** The per-module purge (#140): the module by equality, its subtree by `/`-prefix; `$keys` survive. */
 const PURGE_MODULE_EDGES =
   `MATCH (x:${TS_MARKER}) WHERE x.id = $mid OR x.id STARTS WITH $pre MATCH (x)-[r]->() DELETE r`;
 const PURGE_MODULE_STALE =
   `MATCH (x:${TS_MARKER}) WHERE (x.id = $mid OR x.id STARTS WITH $pre) AND NOT x.id IN $keys DETACH DELETE x`;
 /** The orphan prune (#140): modules inside this app's prefix that the run no longer emits, with their subtrees. */
 const PRUNE_VANISHED =
@@ -126,25 +125,20 @@ export async function boltWriter(
   fullRun: boolean,
   eager: boolean,
 ): Promise<void> {
   // eslint-disable-next-line @typescript-eslint/no-explicit-any
   const neo4j: any = (await import("neo4j-driver")).default;
   const driver = neo4j.driver(cfg.uri, neo4j.auth.basic(cfg.user, cfg.password));
   const sessionOpts = cfg.database ? { database: cfg.database } : {};
   const session = () => driver.session(sessionOpts);
 
   try {
-    // 1. schema (DDL runs in its own autocommit transactions).
-    await withSession(session, async (s) => {
-      for (const stmt of [...CONSTRAINTS, ...INDEXES]) await s.run(stmt);
-    });
-
     // Partition nodes by owning module; shared nodes have no _module.
     const byModule = new Map<string, NodeRow[]>();
     const shared: NodeRow[] = [];
     const moduleOf = new Map<string, string>(); // node value → owning module
     for (const n of rows.nodes) {
       const m = n.module;
       if (typeof m === "string") {
         bucket(byModule, m).push(n);
         moduleOf.set(n.value, m);
       } else {
@@ -157,26 +151,39 @@ export async function boltWriter(
     // node in a shared database and misjudge the version. Absent id → null → forces (safe default).
     const appId = rows.nodes.find((n) => n.labels[0] === "Application")?.value ?? null;
     // Every scoped statement below — the diff, the purges, the prune — needs the application's
     // prefix, and applicationPrefix refuses an empty one (#140). project() always emits the
     // Application row, so this only trips on a hand-built GraphRows.
     const prefix = applicationPrefix(appId);
     let dbSchemaVersion: string | null = null;
     if (appId !== null) {
       await withSession(session, async (s) => {
         const res = await s.run(
-          "MATCH (a:Application {id: $appId}) RETURN a.schema_version AS v LIMIT 1",
+          "MATCH (a:Application {id: $appId}) RETURN a.schema_version AS v, a.identity_version AS identity_version, a.application_name AS application_name, a.identity_namespace AS identity_namespace LIMIT 1",
           { appId },
         );
-        dbSchemaVersion = res.records[0]?.get("v") ?? null;
+        const existing = res.records[0];
+        if (existing) {
+          const marker = existing.get("identity_version");
+          const incoming = rows.nodes.find(n => n.labels.includes("Application"))!.props;
+          if (!(neo4j.isInt(marker) && marker.toNumber() === 2) || existing.get("application_name") !== incoming.application_name || existing.get("identity_namespace") !== incoming.identity_namespace) {
+            throw new Error("Incompatible graph application identity; regenerate from source in a compatible scope");
+          }
+        }
+        dbSchemaVersion = existing?.get("v") ?? null;
       });
     }
+    // 1. schema (DDL runs in its own autocommit transactions).
+    await withSession(session, async (s) => {
+      for (const stmt of [...CONSTRAINTS, ...INDEXES]) await s.run(stmt);
+    });
+
     // Version mismatch no longer deletes anything: a schema change forces a full re-UPSERT, and
     // MERGE overwrites in place. Removing nodes is `--eager`'s job alone (#116).
     const forceAll = shouldForceFullUpsert(dbSchemaVersion, SCHEMA_VERSION);
     if (forceAll) {
       log.info(
         `neo4j(bolt): schema ${dbSchemaVersion ?? "(none)"} → ${SCHEMA_VERSION}, full upsert forced`,
       );
     }
 
     // --eager: drop this application's own nodes and rebuild. Without it the push only ever adds
@@ -187,21 +194,21 @@ export async function boltWriter(
       });
       log.info(`neo4j(bolt): --eager, purged the existing graph under ${prefix}`);
     }
 
     // Artifacts survive EAGER_PURGE; a full eager run reconciles them instead. Auto-commit and
     // batched, so a partial failure is finished by the next eager push.
     const reconcile = fullRun && eager;
     if (reconcile) {
       const pres = artifactPrefixes(prefix);
       const keep = rows.nodes.filter((n) => isArtifactLabel(n.labels[0]!)).map((n) => n.value);
-      const params = { pres, legacy: pres[1], keep, appId, prefix };
+      const params = { pres, keep, appId, prefix };
       let released = 0;
       await withSession(session, async (s) => {
         await s.run(PURGE_ARTIFACT_EDGES, params);
         await s.run(PURGE_APP_IMPORT_EDGES, params);
         await s.run(PURGE_PROVIDES, params);
         const res = await s.run(RELEASE_VANISHED_ARTIFACTS, params);
         released = Number(res.records[0]?.get("released") ?? 0);
       });
       log.info(`neo4j(bolt): released ${released} vanished artifact/config node(s)`);
     }
diff --git a/src/build/neo4j/project.ts b/src/build/neo4j/project.ts
index 0400166..e5478ca 100644
--- a/src/build/neo4j/project.ts
+++ b/src/build/neo4j/project.ts
@@ -1,10 +1,11 @@
+import { applicationIdOf } from "../../schema/ids";
 /**
  * project() — the pure projection from the schema-v2 additive-CPG tree (`TSAnalysis`) to graph
  * rows. It walks the uniform tree (module → types/functions/fields → callables → body) emitting one
  * graph node per tree/body node keyed on its `can://` id, containment as HAS_x / DECLARES edges, and
  * every typed overlay (call_graph, cfg/cdg/ddg/summary, param_in/param_out) as a typed relationship.
  * No I/O: the writers (cypher snapshot / bolt incremental) consume the returned `GraphRows`.
  *
  * The graph is a second projection of the SAME v2 envelope the JSON path emits (finalizeAnalysis),
  * so JSON and graph never diverge. Every project-owned node passes `_module` (its owning file key)
  * to the RowBuilder, which lifts it OFF the graph into NodeRow.module for the incremental diff (#140);
@@ -39,25 +40,29 @@ const KIND_LABEL: Record<string, string> = {
   function: "TSCallable",
   method: "TSCallable",
   constructor: "TSCallable",
   getter: "TSCallable",
   setter: "TSCallable",
   arrow: "TSCallable",
   function_expression: "TSCallable",
 };
 
 export function project(app: TSAnalysis, _appName?: string, builder?: RowBuilder): GraphRows {
+  if (app.identity_version !== 2 || app.application.identity_version !== 2 || typeof app.application.application_name !== "string" || typeof app.application.identity_namespace !== "string" || app.application.id !== applicationIdOf(app.application.application_name, app.application.identity_namespace)) throw new Error("Incompatible application identity");
   const b = builder ?? new RowBuilder(); // a streaming writer supplies its own
   const root: TSApplication = app.application;
 
   const appRef = b.node(["Application", "TSApplication"], "id", root.id, prune({
     id: root.id,
+    identity_version: 2,
+    application_name: root.application_name,
+    identity_namespace: root.identity_namespace,
     name: root.name,
     schema_version: SCHEMA_VERSION,
     language: app.language,
     max_level: app.max_level,
     k_limit: app.k_limit ?? null,
     // Same analyzer{name,version} the JSON envelope carries (emit.ts) — the two co-primary
     // projections must never diverge on analyzer identity (issue #43). Namespaced as
     // analyzer_name/analyzer_version (not bare name/version) to avoid colliding with the
     // application's display name and every other CanNode's bare `name`.
     analyzer_name: app.analyzer.name,
diff --git a/src/build/neo4j/rows.ts b/src/build/neo4j/rows.ts
index 0aacde2..eb55d5e 100644
--- a/src/build/neo4j/rows.ts
+++ b/src/build/neo4j/rows.ts
@@ -54,47 +54,46 @@ export interface NodeRow {
  * every :Artifact node it deletes — including the sibling analyzers' manifests (`pom.xml`,
  * `pyproject.toml`). What it does NOT re-create is a sibling's :ConfigKey nodes and
  * DECLARES_DEPENDENCY/LOCKS edges under an artifact this analyzer does not parse; those are gone
  * until that sibling pushes again. See the polyglot test in test/artifacts.test.ts, which pins
  * both halves of that trade.
  */
 export const CAN_SCHEME = "can://";
 export const TS_MARKER = "TSCanNode";
 export const JS_MARKER = "JSCanNode";
 
-// Positional, never first-segment: the app is segment 1 and may legitimately be NAMED
-// "typescript" or "javascript". The language is segment 2.
-const JS_NAMESPACE = /^can:\/\/[^/]+\/javascript\//;
+// Positional: namespace and application precede the language; either may name a language.
+const JS_NAMESPACE = /^can:\/\/[^/]+\/[^/]+\/javascript\//;
 
 /** The marker labels for a `can://` id — empty for a node keyed on its own natural identity. */
 export function markersFor(id: string): string[] {
   if (!id.startsWith(CAN_SCHEME)) return [];
   return JS_NAMESPACE.test(id) ? [TS_MARKER, JS_MARKER] : [TS_MARKER];
 }
 
 /**
  * The prefix that matches a node's descendants and nothing else. The separator is the point:
  * `can://app/typescript/src/foo.ts` is also a prefix of `can://app/typescript/src/foo.tsx`, so
  * descendants match on `id + '/'` and the node itself by equality.
  */
 export function descendantPrefix(canId: string): string {
   return `${canId}/`;
 }
 
 /**
- * The scope of every destructive statement: `can://<app>/`, one prefix spanning both language
+ * The scope of every destructive statement: `can://<namespace>/<app>/`, one prefix spanning both language
  * namespaces. Refuses anything that is not a bare application id — `STARTS WITH ''` would match
  * every node in the database, and a deeper id would silently narrow the scope to a subtree.
  */
 export function applicationPrefix(appId: string | null | undefined): string {
   const name = appId?.startsWith(CAN_SCHEME) ? appId.slice(CAN_SCHEME.length) : "";
-  if (!name || name.includes("/")) {
+  if (!name || !/^[^/]+\/[^/]+$/.test(name)) {
     throw new Error("neo4j: refusing a destructive statement without an application id");
   }
   return descendantPrefix(appId as string);
 }
 
 export interface EdgeRow {
   type: string;
   from: NodeRef;
   to: NodeRef;
   props: Props;
@@ -134,21 +133,21 @@ export class RowBuilder {
   private readonly keys = new Set<string>(); // every node value seen, for resolved-gating
 
   /**
    * Upsert a node. Re-seeing the same (mergeLabel, value) merges props (last write wins) and
    * unions labels — the in-memory analog of `MERGE (n:Label {key}) SET n += props`. `labels[0]`
    * must be the merge label ("Application" | "CanNode").
    */
   node(labels: string[], keyProp: string, value: string, props: Props): NodeRef {
     const id = `${labels[0]}\0${value}`;
     // `_module` is lifted off the graph (#140): it groups rows for the incremental diff and is
-    // never emitted. The marker labels ride every `can://<app>/` id, as index anchors.
+    // never emitted. The marker labels ride every `can://<namespace>/<app>/` id, as index anchors.
     const { _module, ...rest } = props as Props & { _module?: unknown };
     const module = typeof _module === "string" ? _module : undefined;
     const markers = keyProp === "id" ? markersFor(value) : [];
     const allLabels = [...labels];
     for (const m of markers) if (!allLabels.includes(m)) allLabels.push(m);
     const existing = this.nodes.get(id);
     if (existing) {
       Object.assign(existing.props, rest);
       for (const l of allLabels) if (!existing.labels.includes(l)) existing.labels.push(l);
       if (module !== undefined) existing.module = module;
diff --git a/src/build/neo4j/schema.ts b/src/build/neo4j/schema.ts
index 9b2c07c..889c979 100644
--- a/src/build/neo4j/schema.ts
+++ b/src/build/neo4j/schema.ts
@@ -64,21 +64,21 @@ const SPAN = {
 // `_module` is gone from the graph (#140): scope is the `can://` id prefix. The writer keeps the
 // grouping in memory (NodeRow.module).
 const COMMON = { id: "string", kind: "string" } as const;
 
 export const NODE_LABELS: NodeLabel[] = [
   {
     label: "TSApplication",
     mergeLabel: "Application",
     key: "id",
     properties: {
-      id: "string", name: "string", schema_version: "string", language: "string", max_level: "integer", k_limit: "integer",
+      id: "string", name: "string", identity_version: "integer", application_name: "string", identity_namespace: "string", schema_version: "string", language: "string", max_level: "integer", k_limit: "integer",
       // Analyzer identity — mirrors the JSON envelope's `analyzer{name,version}` (issue #43),
       // namespaced (not bare name/version) to avoid colliding with the application name / every
       // other CanNode's bare `name`.
       analyzer_name: "string", analyzer_version: "string",
       // Entrypoint report (#72; python #182 parity) — sorted-key JSON, since Neo4j has no map type.
       entrypoint_frameworks: "string[]", entrypoint_report_json: "string",
     },
   },
   // Repository-artifact layer (#101, python PR #160 parity): language-NEUTRAL labels — the
   // deliberate exception to TS-prefixing, so sibling analyzers MERGE onto the same
diff --git a/src/cli.ts b/src/cli.ts
index 6ceddd3..9a7d108 100644
--- a/src/cli.ts
+++ b/src/cli.ts
@@ -10,21 +10,21 @@ import { ALL_GRAPHS, type GraphSelector } from "./schema";
  */
 export function buildProgram(): Command {
   const program = new Command();
   program
     .name("cants")
     .description("CLDK TypeScript analyzer — emits the canonical schema-v2 CPG (symbol table → call graph → dataflow → SDG) as analysis.json, or a Neo4j graph.")
     .option("-i, --input <path>", "project root to analyze (not required for --emit schema)")
     .option("-o, --output <dir>", "output directory (omit ⇒ compact output to stdout)")
     .option("--emit <target>", "output target: json (analysis.json, default) | neo4j (graph.cypher or live push) | schema (the Neo4j schema.json contract)", "json")
     .option("--app-name <name>", "logical application name for the graph :Application anchor (default: input dir name)")
-    .option("--workspace-root <dir>", "directory file keys, module ids and artifact ids are relative to (default: --input); must contain --input")
+    .option("--namespace <name>", "application identity namespace (default: application name)")
     // The four Neo4j connection options also read the standard NEO4J_* environment variables when
     // the flag is omitted (an explicit flag wins). Prefer NEO4J_PASSWORD over the flag — a flag
     // value is visible in shell history / the process list. Commander renders the `(env: …)` hint.
     .addOption(
       new Option(
         "--neo4j-uri <uri>",
         "push the graph to a live Neo4j over Bolt (incremental); omit to write graph.cypher",
       ).env("NEO4J_URI"),
     )
     .addOption(new Option("--neo4j-user <user>", "Neo4j username").env("NEO4J_USERNAME").default("neo4j"))
@@ -140,21 +140,21 @@ export function parseArgs(argv: string[]): AnalysisOptions {
   }
   // --emit schema is a static artifact and needs no project; every other target requires -i.
   if (emit !== "schema" && !o.input) program.error("required option '-i, --input <path>' not specified");
   const targets: string[] | null =
     Array.isArray(o.targetFiles) && o.targetFiles.length ? o.targetFiles.map(String) : null;
   return {
     input: o.input ? path.resolve(String(o.input)) : "",
     output: o.output ? path.resolve(String(o.output)) : null,
     emit,
     appName: o.appName ? String(o.appName) : null,
-    workspaceRoot: o.workspaceRoot ? path.resolve(String(o.workspaceRoot)) : null,
+    namespace: o.namespace === undefined ? undefined : String(o.namespace),
     neo4jUri: o.neo4jUri ? String(o.neo4jUri) : null,
     neo4jUser: String(o.neo4jUser),
     neo4jPassword: String(o.neo4jPassword),
     neo4jDatabase: o.neo4jDatabase ? String(o.neo4jDatabase) : null,
     analysisLevel: level,
     graphs,
     graphFieldDepth: k,
     jobs,
     targetFiles: targets,
     programFilter:
diff --git a/src/core.ts b/src/core.ts
index 694c5f0..0d8db28 100644
--- a/src/core.ts
+++ b/src/core.ts
@@ -1,10 +1,11 @@
+import { applicationIdOf } from "./schema/ids";
 import * as fs from "node:fs";
 import * as path from "node:path";
 import { buildProgramGraphs, startExtraction } from "./dataflow";
 import { type LinkerResolutions, mergeCallGraphs, runDefuseLinker, tscProvider } from "./semantic_analysis";
 import { collectGarbage, loadCache, saveCache } from "./utils";
 import { materialize } from "./build";
 import { inventoryArtifacts } from "./artifacts";
 import { loadRules } from "./entrypoints";
 import type { AnalysisOptions } from "./options";
 import type { AnalysisInternal } from "./schema";
@@ -44,50 +45,37 @@ export class InputError extends Error {}
 function assertInputDir(input: string): void {
   let stat: fs.Stats;
   try {
     stat = fs.statSync(input);
   } catch {
     throw new InputError(`input path does not exist: ${input}`);
   }
   if (!stat.isDirectory()) throw new InputError(`input path is not a directory: ${input}`);
 }
 
-/**
- * Published keys are relativized against the workspace root, so --input must be that root or inside
- * it — otherwise a key would need `..`, which the schema forbids (relative, never absolute or `..`).
- * Checked before any work, like the input itself.
- */
-function assertInsideWorkspace(input: string, workspaceRoot: string | null | undefined): void {
-  if (!workspaceRoot) return;
-  const rel = path.relative(path.resolve(workspaceRoot), path.resolve(input));
-  if (rel.startsWith("..") || path.isAbsolute(rel)) {
-    throw new InputError(`--input ${input} is not inside --workspace-root ${workspaceRoot}`);
-  }
-}
-
 export async function analyze(opts: AnalysisOptions): Promise<AnalysisResult> {
   assertInputDir(opts.input);
-  assertInsideWorkspace(opts.input, opts.workspaceRoot);
+  const identity = applicationIdOf(opts.appName ?? path.basename(path.resolve(opts.input)), opts.namespace);
   const log = new Logger(opts.verbosity);
   log.info(`analyzing ${opts.input} (level ${opts.analysisLevel})`);
   resetCheckerFailures();
   // Entrypoint rules are CONFIGURATION, validated before any analysis work: a malformed user file
   // must stop the run here, not after the symbol table, the solve and the dataflow have all run.
   const rules = loadRules(opts.entrypointRules ?? []);
   const cacheDir = opts.cacheDir ?? path.join(opts.input, ".codeanalyzer");
 
   const mat = materialize(opts, log);
   memlog("materialize");
 
   for (const note of mat.notes) log.debug(note);
 
-  const cached = opts.eager ? null : loadCache(cacheDir);
+  const cached = opts.eager ? null : loadCache(cacheDir, identity);
   const { project, symbol_table, programs } = buildSymbolTable(opts, mat, cached?.symbol_table ?? null, log);
   collectGarbage(); // the symbol-table build leaves the heap mostly garbage
   memlog("symbol_table");
 
   // Level 3: post stage-1–4 graph extraction to the worker pool BEFORE the call-graph solve —
   // extraction doesn't need callee resolution, so the two run concurrently (the contract's
   // "points-to solve runs concurrently with stages 1–4") and join in buildProgramGraphs.
   //
   // Multi-program: extraction resolves each callable under the tsconfig that OWNS its file, the
   // same assignment the symbol table and the L2 call graph use (#111). It used to index the whole
@@ -166,20 +154,20 @@ export async function analyze(opts: AnalysisOptions): Promise<AnalysisResult> {
   };
 
   // Level 3 join: stages 5–7 (summary wavefront + SDG) consume the extraction AND the
   // provider-backfilled callee signatures. Strictly flag-gated so -a 1/-a 2 cost nothing.
   const pg = extraction ? await buildProgramGraphs(extraction, symbol_table, opts, log) : null;
   collectGarbage(); // extraction released the programs' ASTs; reclaim before finalize
   memlog("program_graphs");
 
   // Cache the id-free base (ids/body/heritage are per-run layers stamped by finalizeAnalysis;
   // the cached tree must stay --app-name-free).
-  saveCache(cacheDir, { symbol_table });
+  saveCache(cacheDir, { symbol_table, identity_version: 2, application_id: identity });
   memlog("save_cache");
   // Never let "some edges are missing" look like "there were no edges": a node the checker could
   // not resolve is skipped (see schema/checker.ts), and the count is said out loud.
   const skipped = checkerFailures();
   if (skipped) log.warn(`${skipped} symbol resolution(s) skipped — the TypeScript checker could not resolve them; affected call edges are absent`);
   const result = finalizeAnalysis(app, pg, opts, resolutions, project, rules);
   memlog("finalize");
   return result;
 }
diff --git a/src/options/options.ts b/src/options/options.ts
index 941897c..d7504c1 100644
--- a/src/options/options.ts
+++ b/src/options/options.ts
@@ -6,26 +6,22 @@ export type EmitTarget = "json" | "neo4j" | "schema";
 /** Normalized analysis options (produced by the CLI layer, consumed by core). */
 export interface AnalysisOptions {
   /** Project root to analyze (absolute). */
   input: string;
   /** Output directory; null ⇒ print compact JSON to stdout (json emit only). */
   output: string | null;
   /** Output target: json (analysis.json, default) or neo4j (graph.cypher / live Bolt push). */
   emit: EmitTarget;
   /** Logical application name for the graph's :Application anchor; null ⇒ derived from input. */
   appName: string | null;
-  /**
-   * Directory the PUBLISHED file keys (and the module/artifact ids built from them) are relative to
-   * (absolute); null ⇒ `input`. Must contain `input`. Emission-only: signatures, entrypoint
-   * path rules, test detection and the cache keep the input-relative key.
-   */
-  workspaceRoot?: string | null;
+  /** Raw application identity namespace; omitted ⇒ resolved application name. */
+  namespace?: string;
   /** Bolt URI for a live Neo4j push (incremental). null ⇒ write a graph.cypher snapshot to -o. */
   neo4jUri: string | null;
   neo4jUser: string;
   neo4jPassword: string;
   neo4jDatabase: string | null;
   /**
    * Analysis depth requested by the caller (schema v2): 1 = symbol table (+ call sites);
    * 2 = + resolver call graph; 3 = + intraprocedural dataflow (cfg/cdg/ddg in the tree);
    * 4 = + interprocedural SDG (param_in/param_out/summary + synthetic vertices).
    */
diff --git a/src/schema/assignIds.ts b/src/schema/assignIds.ts
index a34fc16..5efc288 100644
--- a/src/schema/assignIds.ts
+++ b/src/schema/assignIds.ts
@@ -1,38 +1,33 @@
 /**
  * Walk the symbol-table tree and stamp every node with its `can://` id — python's
  * `assign_ids.py`. Runs once per analysis run (ids embed the per-invocation app name, so the
  * cached tree is stored id-free and re-stamped on every run; stamping is overwrite-idempotent).
  *
  * Returns the `signature → id` map the later passes join on (callee backfill, call-graph
  * re-identification, dataflow attach), the callable locator for the L3/L4 attach, and the
  * id-uniqueness gate's collision list.
  */
 
-import { applicationIdOf, artifactIdOf, configKeyIdOf, idFromSig, memberKey, moduleIdOf, modulePrefixOf } from "./ids";
+import { applicationIdOf, artifactIdOf, artifactReferenceOf, configKeyIdOf, idFromSig, memberKey, moduleIdOf, modulePrefixOf } from "./ids";
 import type { AnalysisInternal, TSCallable, TSField, TSType } from "./schema";
 
 export interface AssignedIds {
   appId: string;
   idBySig: Map<string, string>; // signature → can:// id (types + callables; the VALUE facet of a merged name)
   typeIdBySig: Map<string, string>; // signature → the first TYPE facet's id (#177; heritage resolves through this)
   callableBySig: Map<string, TSCallable>; // locates each callable's node for the L3/L4 attach
   collisions: string[]; // signatures that mapped to two distinct ids (L1 id-uniqueness gate)
 }
 
-/**
- * @param keyPrefix prepended to every file key an id is minted from (`--workspace-root`: the
- *   input's path under the workspace, with a trailing `/`; `""` when unset). Ids only — the
- *   signature registry stays keyed on the input-relative module prefix every other pass joins on.
- */
-export function assignIds(app: AnalysisInternal, appName: string, keyPrefix = ""): AssignedIds {
-  const appId = applicationIdOf(appName);
+export function assignIds(app: AnalysisInternal, appName: string, namespace?: string): AssignedIds {
+  const appId = applicationIdOf(appName, namespace);
   const idBySig = new Map<string, string>();
   const typeIdBySig = new Map<string, string>();
   const callableBySig = new Map<string, TSCallable>();
   const collisions: string[] = [];
   // #177: every id minted this run, so a second declaration facet of one name (declaration
   // merging) gets its own id instead of silently sharing. Value facets (callables, fields) are
   // always minted before the types of their scope, so a type is the one that yields.
   const usedIds = new Set<string>();
   const typeIds = new Set<string>();
 
@@ -68,53 +63,48 @@ export function assignIds(app: AnalysisInternal, appName: string, keyPrefix = ""
     // The value facet keeps the signature → id slot (call-graph re-identification, callee
     // backfill, homing all mean the callable); a split is not a collision.
     if (t.id === bare) register(t.signature, t.id);
     doFields(t.id, t.fields);
     for (const m of Object.values(t.callables ?? {})) doCallable(moduleId, modulePrefix, m);
     for (const f of Object.values(t.functions ?? {})) doCallable(moduleId, modulePrefix, f); // namespace
     for (const nt of Object.values(t.types ?? {})) doType(moduleId, modulePrefix, nt); // namespace
   };
 
   for (const [fileKey, mod] of Object.entries(app.symbol_table)) {
-    const moduleId = moduleIdOf(appName, keyPrefix + fileKey);
+    const moduleId = moduleIdOf(appName, fileKey, namespace);
     const modulePrefix = modulePrefixOf(fileKey);
     mod.id = moduleId;
     // Module-scope execution is a call-graph SOURCE (python #131 parity: a call in module scope
     // is attributed to the MODULE). The prefix is the module's "signature", so those edges
     // re-identify onto the module node's id instead of dangling.
     register(modulePrefix, moduleId);
     doFields(moduleId, mod.fields);
     for (const fn of Object.values(mod.functions ?? {})) doCallable(moduleId, modulePrefix, fn);
     for (const t of Object.values(mod.types ?? {})) doType(moduleId, modulePrefix, t);
   }
 
   // Repository-artifact layer: same per-run rule (ids embed --app-name). Artifact ids are
   // language-NEUTRAL (`can://<app>/artifact/...`); dependency/import records are flat evidence
   // rows with no node id of their own (the graph's :Package node is purl-keyed).
   for (const [relPath, art] of Object.entries(app.artifacts ?? {})) {
-    art.id = artifactIdOf(appName, keyPrefix + relPath);
+    art.id = artifactIdOf(appName, relPath, namespace);
     // Deployment-env id disambiguation (#101 unit D fix round 1, python v1.3.0 parity verbatim):
     // the `key` FIELD always stays the bare variable name — env-namespace resolution still joins
     // on a plain `key ===` match — but a bare name can collide across mints on the SAME artifact
     // (Dockerfile: `ARG VERSION` + `ENV VERSION=$VERSION`; yaml: a top-level `PAYMENT_HOST:` leaf
     // vs. the `env` dual-mint from `services.web.environment.PAYMENT_HOST`), so only the ID gets
     // an internal prefix: `arg.` for a dockerfile-namespace (ARG) mint, `env.` for a yaml
     // artifact's env dual-mint. Dockerfile's own ENV mint and every ordinary structural key stay
     // unprefixed.
     for (const ck of art.config_keys) {
       let idKey = ck.key;
       if (ck.namespace === "dockerfile") idKey = `arg.${ck.key}`;
       else if (art.format === "yaml" && ck.namespace === "env") idKey = `env.${ck.key}`;
       ck.id = configKeyIdOf(art.id, idKey);
     }
   }
   for (const dep of app.dependencies ?? []) {
-    const artPath = dep.declared_in; // scanners record the REL PATH; re-stamp onto the id
-    // slice(4) drops `can:`, ``, `<app>`, `artifact` — the same depth the old `can://artifact/<app>/`
-    // shape had, so the reorder left this re-stamp guard alone.
-    dep.declared_in = artPath.startsWith("can://")
-      ? artifactIdOf(appName, artPath.split("/").slice(4).join("/"))
-      : artifactIdOf(appName, keyPrefix + artPath);
+    dep.declared_in = artifactReferenceOf(appName, dep.declared_in, namespace);
   }
 
   return { appId, idBySig, typeIdBySig, callableBySig, collisions };
 }
diff --git a/src/schema/emit.ts b/src/schema/emit.ts
index dfa1340..5bfa48a 100644
--- a/src/schema/emit.ts
+++ b/src/schema/emit.ts
@@ -66,51 +66,20 @@ function stripInternal(root: TSApplication): void {
     // modules -- stripping it here made that diff compare against NULL forever, so every push was
     // a full re-upsert. codeanalyzer-python keeps it for the same reason (schema/py_schema.py).
     delete mod["last_modified"];
     delete mod["file_size"];
     delete mod["call_sites"];
     for (const fn of Object.values((mod["functions"] as Record<string, Record<string, unknown>>) ?? {})) stripCallable(fn);
     for (const t of Object.values((mod["types"] as Record<string, Record<string, unknown>>) ?? {})) stripType(t);
   }
 }
 
-/**
- * `--workspace-root`: the input's path under the workspace root, `/`-terminated, prepended to every
- * PUBLISHED file key; `""` when unset or equal to the input. Emission-only — the live tree, the
- * signatures, entrypoint path rules and the cache all keep the input-relative key.
- */
-function workspaceKeyPrefix(opts: AnalysisOptions): string {
-  if (!opts.workspaceRoot || !opts.input) return "";
-  const rel = relPosix(opts.workspaceRoot, opts.input);
-  return rel === "" ? "" : `${rel}/`;
-}
-
-/**
- * The wire's other path-keyed maps, re-keyed under `keyPrefix`: artifacts (map key + `path`) and the
- * synthesized callables' owning-module `path`. Ids were already minted with the prefix by
- * assignIds; this only renames. New objects, so the live tree keeps its input-relative paths.
- */
-function rekeyRepoPaths(root: TSApplication, keyPrefix: string): Partial<TSApplication> {
-  if (!keyPrefix) return {};
-  const artifacts: TSApplication["artifacts"] = {};
-  for (const [key, art] of Object.entries(root.artifacts)) artifacts[keyPrefix + key] = { ...art, path: keyPrefix + art.path };
-  const out: Partial<TSApplication> = { artifacts };
-  if (root.synthesized_callables) {
-    const synthesized: NonNullable<TSApplication["synthesized_callables"]> = {};
-    for (const [id, sc] of Object.entries(root.synthesized_callables)) {
-      synthesized[id] = sc.path === undefined ? sc : { ...sc, path: keyPrefix + sc.path };
-    }
-    out.synthesized_callables = synthesized;
-  }
-  return out;
-}
-
 // ----------------------------------------------------------------------------------------------
 // entry point
 // ----------------------------------------------------------------------------------------------
 
 export interface AnalysisResult {
   application: TSAnalysis; // the wire: deep, internal-field-stripped envelope
   internal: AnalysisInternal; // the live internal working set (tree + sig-keyed provider outputs)
   program_graphs?: ProgramGraphs; // the L3/L4 compute IR (already attached onto the wire tree)
   idBySig: Map<string, string>; // signature → can:// id (real callables + externals + synthesized)
   collisions: string[]; // signatures that mapped to two distinct ids (L1 id-uniqueness gate)
@@ -119,34 +88,36 @@ export interface AnalysisResult {
 
 export function finalizeAnalysis(
   app: AnalysisInternal,
   pg: ProgramGraphs | null,
   opts: AnalysisOptions,
   resolutions?: Map<string, Map<string, string>>,
   project?: Project,
   rules?: RuleSet,
 ): AnalysisResult {
   const level = opts.analysisLevel;
-  const appName = (opts.appName ?? (opts.input ? path.basename(opts.input) : "") ?? "").trim() || "app";
-  const keyPrefix = workspaceKeyPrefix(opts);
+  const appName = opts.appName ?? (opts.input ? path.basename(path.resolve(opts.input)) : "app");
 
   // L1 — stamp ids, derive body{}, project heritage (all overwrite-idempotent per-run passes).
-  const { appId, idBySig, typeIdBySig, callableBySig, collisions } = assignIds(app, appName, keyPrefix);
+  const { appId, idBySig, typeIdBySig, callableBySig, collisions } = assignIds(app, appName, opts.namespace);
   populateL1Body(app);
   // `extends`/`implements` name TYPES: on a merged name (#177) the type facet's id wins over the
   // value facet's, which is what `idBySig` holds for every other pass.
   resolveHeritageIds(app, new Map([...idBySig, ...typeIdBySig]));
   // Level-free, after heritage: unit 4 matches on resolved extends_ids.
   const entrypoint_report = detectEntrypoints(app, opts, rules);
 
   const root: TSApplication = {
     id: appId,
+    identity_version: 2,
+    application_name: appName,
+    identity_namespace: opts.namespace ?? appName,
     name: appName,
     kind: "application",
     symbol_table: app.symbol_table,
     call_graph: [],
     param_in: [],
     param_out: [],
     artifacts: app.artifacts ?? {},
     dependencies: app.dependencies ?? [],
     unresolved_imports: app.unresolved_imports ?? [],
     config_uses: app.config_uses ?? [],
@@ -180,39 +151,34 @@ export function finalizeAnalysis(
 
   // L3/L4 — grow body{} + cfg/cdg/ddg/summary on callables and param_in/param_out on the app.
   let k_limit: number | undefined;
   if (level >= 3 && pg) {
     applyDataflow(root, pg, idBySig, callableBySig, level);
     k_limit = pg.k_limit;
   }
 
   const envelope: TSAnalysis = {
     schema_version: SCHEMA_VERSION,
+    identity_version: 2,
     language: LANGUAGE,
     max_level: Math.min(level, MAX_IMPLEMENTED),
     ...(k_limit !== undefined ? { k_limit } : {}),
     analyzer: { name: ANALYZER_NAME, version: ANALYZER_VERSION },
     application: root,
   };
   // The wire copy: detached from the live tree, internals stripped STRUCTURALLY. The strip only
   // ever touches modules (and what hangs off them), so the clone is per MODULE (#180): one
   // structuredClone of the whole envelope hits Bun's serialization ceiling on a large repository
   // (a TypeError at 13k files on 1.3.0; a hard abort with no exception at ~2 GiB on 1.3.14 —
   // measured), while the largest single module is megabytes. Everything else on the root
   // (call_graph, param_in/out, artifacts, config edges, entrypoint report) is untouched by the
   // strip and shared by reference. A stringify roundtrip is out for the same reason: the string
   // form OOMs at vscode-L4 scale.
   const symbol_table: TSApplication["symbol_table"] = {};
   for (const [key, mod] of Object.entries(root.symbol_table)) {
     const wire = structuredClone(mod);
-    // `resolved_module` names a symbol_table key, so it takes the same prefix (on the clone only).
-    if (keyPrefix) {
-      for (const b of [...(wire.imports ?? []), ...(wire.exports ?? [])]) {
-        if (b.resolved_module !== undefined) b.resolved_module = keyPrefix + b.resolved_module;
-      }
-    }
-    symbol_table[keyPrefix + key] = wire;
+    symbol_table[key] = wire;
   }
-  const application: TSAnalysis = { ...envelope, application: { ...root, symbol_table, ...rekeyRepoPaths(root, keyPrefix) } };
+  const application: TSAnalysis = { ...envelope, application: { ...root, symbol_table } };
   stripInternal(application.application);
   return { application, internal: app, ...(pg ? { program_graphs: pg } : {}), idBySig, collisions, dangling };
 }
diff --git a/src/schema/ids.ts b/src/schema/ids.ts
index bbafae9..cfc854f 100644
--- a/src/schema/ids.ts
+++ b/src/schema/ids.ts
@@ -18,64 +18,69 @@ const JS_EXTS = /\.(jsx|js|mjs|cjs)$/;
  * A module's language namespace, from its file key (#114).
  *
  * The analyzer owns both languages (JS discovery, #98), so this is per MODULE rather than per run:
  * a `.js` file is JavaScript and must not be labelled `typescript`. `.d.ts` falls through to the
  * default rather than matching, so a declaration file stays TypeScript.
  */
 export function languageOf(fileKey: string): string {
   return JS_EXTS.test(fileKey) ? "javascript" : LANGUAGE;
 }
 
-/**
- * `can://<app>` — the application root, and the prefix EVERY id below it shares.
- *
- * The application is the outermost segment and the language sits inside it, so the analyzer's two
- * namespaces (`typescript`, `javascript`) are two children of one application rather than two
- * top-level namespaces that a consumer has to enumerate. The old anchor had to pick a language for
- * a mixed repository and picked the analyzer's own; there is nothing left to pick.
- * See docs/design/specs/js-language-namespace.md.
- */
-export function applicationIdOf(appName: string): string {
-  return `${SCHEME}${appName}`;
+/** Validate and encode one raw namespace or application name without normalizing it. */
+export function identitySegment(value: string): string {
+  if (!value.trim() || value === "." || value === ".." || /[/\\\x00-\x1F\x7F-\x9F]/u.test(value)) throw new Error("Invalid application identity segment");
+  // encodeURIComponent rejects unpaired surrogates; escape its additional punctuation too.
+  return encodeURIComponent(value).replace(/[!'()*]/g, c => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
+}
+export function applicationIdOf(appName: string, namespace?: string): string {
+  return `${SCHEME}${identitySegment(namespace ?? appName)}/${identitySegment(appName)}`;
+}
+
+/** Recover only an artifact suffix; ownership is restamped from validated raw names. */
+export function artifactReferenceOf(appName: string, reference: string, namespace?: string): string {
+  if (!reference.startsWith(SCHEME)) return artifactIdOf(appName, reference, namespace);
+  const match = /^can:\/\/[^/]+\/[^/]+\/artifact\/(.+)$/.exec(reference);
+  if (!match) throw new Error("Unsupported artifact identity reference");
+  return artifactIdOf(appName, match[1]!, namespace);
 }
 
 /**
- * `can://<app>/<lang>/<fileKey>`. Takes the app NAME, not the app id: a module's namespace is its
+ * `can://<namespace>/<app>/<lang>/<fileKey>`. Takes the app NAME, not the app id: a module's namespace is its
  * own, not the application's.
  */
-export function moduleIdOf(appName: string, fileKey: string): string {
-  return `${applicationIdOf(appName)}/${languageOf(fileKey)}/${fileKey}`;
+export function moduleIdOf(appName: string, fileKey: string, namespace?: string): string {
+  return `${applicationIdOf(appName, namespace)}/${languageOf(fileKey)}/${fileKey}`;
 }
 
 /** The module/signature prefix: the file key without its TS/JS extension. */
 export function modulePrefixOf(fileKey: string): string {
   return fileKey.replace(/\.d\.ts$/, "").replace(/\.(tsx|ts|jsx|js|mts|cts|mjs|cjs)$/, "");
 }
 
 /** The containment-path id of a descendant, derived from its dotted signature. */
 export function idFromSig(moduleId: string, modulePrefix: string, sig: string): string {
   const tail = sig.startsWith(`${modulePrefix}.`) ? sig.slice(modulePrefix.length + 1) : sig;
   return `${moduleId}/${tail.split(".").join("/")}`;
 }
 
 /**
  * Repository-artifact ids. Leading "./" and "/" are dropped as SEPARATORS only — dotfiles
  * (`.env`, `.github/...`) keep their leading dot (python's rule).
  */
-export function artifactIdOf(appName: string, relPath: string): string {
+export function artifactIdOf(appName: string, relPath: string, namespace?: string): string {
   let rel = relPath.replace(/\\/g, "/");
   while (rel.startsWith("./")) rel = rel.slice(2);
   rel = rel.replace(/^\/+/, "");
   // Language-NEUTRAL pseudo-segment (python PR #160): `artifact` sits where a language would, so
   // sibling analyzers over the same repo emit the SAME id for the same file — `<app>` agreement is
   // the precondition, and it always was.
-  return `${applicationIdOf(appName)}/artifact/${rel}`;
+  return `${applicationIdOf(appName, namespace)}/artifact/${rel}`;
 }
 
 /** Config-key id: the owning artifact's id, `@key/`, then the dotted path. */
 export function configKeyIdOf(artifactId: string, dotted: string): string {
   return `${artifactId}@key/${dotted}`;
 }
 
 /** Package URL for an npm package name — the cross-language package id (`pkg:npm/...`). */
 export function purlNpm(name: string): string {
   if (name.startsWith("@")) {
diff --git a/src/schema/schema.ts b/src/schema/schema.ts
index eb3cf60..95eaef7 100644
--- a/src/schema/schema.ts
+++ b/src/schema/schema.ts
@@ -543,38 +543,42 @@ export interface AnalysisInternal {
   config_uses?: TSConfigUse[];
   config_reads?: TSConfigRead[];
 }
 
 // ----------------------------------------------------------------------------------------------
 // The wire: envelope → application root → cross-callable edges (what analysis.json IS, and what
 // the Neo4j projection consumes)
 // ----------------------------------------------------------------------------------------------
 
 export interface TSAnalysis {
+  identity_version: 2;
   schema_version: string; // "2.0.0"
   language: string; // "typescript"
   max_level: number; // highest level populated; consumers read this, not key-sniffing
   k_limit?: number; // access-path depth bound for the L3/L4 dataflow (present at L3+)
   analyzer: TSAnalyzer; // which analyzer produced this artifact, and at what version
   application: TSApplication;
 }
 
 /** Analyzer identity — lets consumers correlate an `analysis.json` with the tool/version that emitted it. */
 export interface TSAnalyzer {
   name: string; // "codeanalyzer-typescript"
   version: string; // ANALYZER_VERSION (src/utils/version.ts)
 }
 
 /** The application ROOT node (python's PyApplication): the containment tree + app-scope overlays. */
 export interface TSApplication {
-  id: string; // can://<app> — the prefix every id below it shares
-  name: string; // normalized --app-name, or the input directory basename
+  identity_version: 2;
+  application_name: string;
+  identity_namespace: string;
+  id: string; // can://<namespace>/<app> — the prefix every id below it shares
+  name: string; // raw --app-name, or the input directory basename
   kind: "application";
   symbol_table: Record<string, TSModule>; // keyed by project-relative POSIX path (with extension)
   call_graph: TSCallGraphEdge[]; // L2 — callable → callable (empty at L1)
   param_in: TSParamEdge[]; // L4 (empty until L4)
   param_out: TSParamEdge[]; // L4
   /** Repository-artifact layer — identical at every level (#101, python PR #160 parity). */
   artifacts: Record<string, TSArtifact>;
   dependencies: TSDependency[];
   unresolved_imports: TSImportBinding[];
   /** config_use literal tier (#101 unit C2/C3) — empty until L2; CALL rules need the call graph. */
diff --git a/src/utils/cache.ts b/src/utils/cache.ts
index 452c935..df642a5 100644
--- a/src/utils/cache.ts
+++ b/src/utils/cache.ts
@@ -1,33 +1,36 @@
 import * as fs from "node:fs";
 import * as path from "node:path";
 import type { TSModule } from "../schema";
 import { sha256 } from "./fs";
 import { ANALYZER_VERSION } from "./version";
 
 export interface CacheData {
   analyzer_version?: string;
+  identity_version?: number;
+  application_id?: string;
   symbol_table: Record<string, TSModule>;
 }
 
 export function cacheFilePath(cacheDir: string): string {
   return path.join(cacheDir, "analysis_cache.json");
 }
 
-export function loadCache(cacheDir: string): CacheData | null {
+export function loadCache(cacheDir: string, applicationId?: string): CacheData | null {
   try {
     const p = cacheFilePath(cacheDir);
     if (!fs.existsSync(p)) return null;
     const data = JSON.parse(fs.readFileSync(p, "utf-8")) as CacheData;
     // Invalidate the whole cache when the analyzer version changed — the per-file source hash
     // can't detect that the extraction logic itself moved on.
     if (data.analyzer_version !== ANALYZER_VERSION) return null;
+    if (data.identity_version !== 2 || (applicationId !== undefined && data.application_id !== applicationId)) return null;
     return data;
   } catch {
     return null;
   }
 }
 
 export function saveCache(cacheDir: string, data: CacheData): void {
   try {
     fs.mkdirSync(cacheDir, { recursive: true });
     fs.writeFileSync(cacheFilePath(cacheDir), JSON.stringify({ analyzer_version: ANALYZER_VERSION, ...data }));
diff --git a/test/artifacts.test.ts b/test/artifacts.test.ts
index 2257620..635fedb 100644
--- a/test/artifacts.test.ts
+++ b/test/artifacts.test.ts
@@ -50,22 +50,22 @@ describe("artifact inventory — rules-matched, neutral ids (#101/PR-160)", () =
 
     const bin = arts["logo.bin"];
     expect(bin?.format).toBe("binary");
     expect(bin?.roles).toEqual(["unknown"]);
     expect(bin?.source).toBe("");
     expect(bin?.sha256.length).toBe(64);
     expect(bin?.size_bytes).toBeGreaterThan(0);
   });
 
   test("ids are LANGUAGE-NEUTRAL (can://<app>/artifact/<path>); dotfiles keep the dot", () => {
-    expect(arts[".env"]?.id).toBe("can://artifacts-app/artifact/.env");
-    expect(arts["packages/web/package.json"]?.id).toBe("can://artifacts-app/artifact/packages/web/package.json");
+    expect(arts[".env"]?.id).toBe("can://artifacts-app/artifacts-app/artifact/.env");
+    expect(arts["packages/web/package.json"]?.id).toBe("can://artifacts-app/artifacts-app/artifact/packages/web/package.json");
   });
 
   test("roles and formats from the rules table; roles union across matches", () => {
     expect(arts["package.json"]?.roles).toEqual(["dependency-manifest", "tool-config"]);
     expect(arts["package-lock.json"]?.roles).toEqual(["dependency-manifest"]);
     expect(arts[".env"]?.roles).toEqual(["env"]);
     expect(arts["tsconfig.json"]?.roles).toEqual(["tool-config"]);
     expect(arts["Dockerfile"]?.roles).toEqual(["container-image"]);
     expect(arts[".github/workflows/ci.yml"]?.roles).toEqual(["ci"]);
     expect(arts["README.md"]?.roles).toEqual(["docs"]);
@@ -88,40 +88,40 @@ describe("dependencies — flat, evidence-tagged (#101/PR-160)", () => {
     expect(byName.get("typescript")?.kind).toBe("dev");
     expect(byName.get("fsevents")?.kind).toBe("optional");
     expect(byName.get("react")?.kind).toBe("peer");
     for (const d of deps.filter((d) => d.direct)) {
       expect(d.prov).toContain("declared");
       expect(d.extras).toEqual([]);
     }
   });
 
   test("declared_in is the manifest's neutral artifact id (workspace member keeps its own)", () => {
-    expect(byName.get("express")?.declared_in).toBe("can://artifacts-app/artifact/package.json");
-    expect(byName.get("lodash")?.declared_in).toBe("can://artifacts-app/artifact/packages/web/package.json");
+    expect(byName.get("express")?.declared_in).toBe("can://artifacts-app/artifacts-app/artifact/package.json");
+    expect(byName.get("lodash")?.declared_in).toBe("can://artifacts-app/artifacts-app/artifact/packages/web/package.json");
   });
 
   test("locks backfill locked_version on declared records only, prov gains lockfile", () => {
     expect(byName.get("express")?.locked_version).toBe("4.19.2");
     expect(byName.get("express")?.prov).toEqual(["declared", "lockfile"]);
     expect(byName.get("lodash")?.locked_version).toBe("4.17.21"); // sibling bun.lock (JSONC)
     expect(byName.get("react")?.locked_version).toBeUndefined();
     expect(byName.has("transitive-shadow")).toBe(false); // nested lock entries ignored
   });
 
   test("lock-only packages become direct:false records attributed to the lock", () => {
     const t = deps.find((d) => d.name === "lockonly-transitive");
     expect(t).toBeDefined();
     expect(t?.direct).toBe(false);
     expect(t?.kind).toBe("runtime");
     expect(t?.prov).toEqual(["lockfile"]);
     expect(t?.locked_version).toBe("1.0.0");
-    expect(t?.declared_in).toBe("can://artifacts-app/artifact/package-lock.json");
+    expect(t?.declared_in).toBe("can://artifacts-app/artifacts-app/artifact/package-lock.json");
     // declared packages stay direct
     expect(byName.get("express")?.direct).toBe(true);
     // nested shadow entries are NOT records
     expect(deps.some((d) => d.name === "transitive-shadow")).toBe(false);
   });
 
   test("provides_imports: the name itself; @types/x also provides x", () => {
     expect(byName.get("express")?.provides_imports).toEqual(["express"]);
     expect(byName.get("@types/typed-only-pkg")?.provides_imports).toEqual(["@types/typed-only-pkg", "typed-only-pkg"]);
   });
@@ -202,35 +202,35 @@ describe("Neo4j projection — neutral :Artifact/:Package (#101)", () => {
     // Config keys are in scope too — they hang off an artifact and would otherwise outlive it.
     const key = rows.nodes.find((n) => n.value.endsWith("/.env@key/PAYMENT_HOST"));
     expect(key?.labels).toEqual(["ConfigKey", "TSCanNode"]);
     // :Package keys on a purl, not a can:// id, so it is outside every destructive scope.
     expect(rows.nodes.find((n) => n.value === "pkg:npm/express")?.labels).toEqual(["Package"]);
   });
 
   test("a sibling analyzer's manifest is re-created, but only with this analyzer's view of it", () => {
     // The whole-repo walk inventories pyproject.toml even though nothing here can parse it, so the
     // node the wipe deletes is restored by the same push — it is never missing.
-    const py = rows.nodes.find((n) => n.value === "can://artifacts-app/artifact/pyproject.toml");
+    const py = rows.nodes.find((n) => n.value === "can://artifacts-app/artifacts-app/artifact/pyproject.toml");
     expect(py).toBeDefined();
     expect(py?.labels).toEqual(["Artifact", "TSCanNode"]);
     // ...and this is the cost, stated rather than assumed: a degraded view. Unclassified roles,
     // no extraction, no config keys, no dependency edge — python restores all four when it pushes.
     expect(py?.props["roles"]).toEqual(["unknown"]);
     expect(py?.props["extraction"]).toBe("none");
-    expect(rows.nodes.some((n) => n.value.startsWith("can://artifacts-app/artifact/pyproject.toml@key/"))).toBe(false);
+    expect(rows.nodes.some((n) => n.value.startsWith("can://artifacts-app/artifacts-app/artifact/pyproject.toml@key/"))).toBe(false);
     expect(rows.edges.some((e) => e.type === "DECLARES_DEPENDENCY" && e.from.value.endsWith("/pyproject.toml"))).toBe(false);
     // The pypi package this analyzer cannot see is not invented either.
     expect(rows.nodes.some((n) => n.value.startsWith("pkg:pypi/"))).toBe(false);
   });
 
   test("neutral nodes with purl ids; TS-prefixed claims into the ghost space", () => {
-    const art = rows.nodes.find((n) => n.value === "can://artifacts-app/artifact/package.json");
+    const art = rows.nodes.find((n) => n.value === "can://artifacts-app/artifacts-app/artifact/package.json");
     expect(art?.labels).toEqual(["Artifact", "TSCanNode"]);
     expect(art?.props["roles"]).toEqual(["dependency-manifest", "tool-config"]);
     // Artifact text belongs on the graph: python has carried `source` on :Artifact since it
     // shipped the layer, so a consumer reading the same neutral node from two analyzers must not
     // get text from one and nothing from the other (#116).
     expect(art?.props["source"]).toBeDefined();
     const pkg = rows.nodes.find((n) => n.value === "pkg:npm/react");
     expect(pkg?.labels).toEqual(["Package"]);
     const scoped = rows.nodes.find((n) => n.value === "pkg:npm/%40scope/util");
     expect(scoped, "scoped purl").toBeDefined();
diff --git a/test/checker-guard.test.ts b/test/checker-guard.test.ts
index b3c00e6..87b951e 100644
--- a/test/checker-guard.test.ts
+++ b/test/checker-guard.test.ts
@@ -18,22 +18,22 @@ import { describe, expect, test } from "bun:test";
 import * as fs from "node:fs";
 import * as os from "node:os";
 import * as path from "node:path";
 import { analyze } from "../src/core";
 import { checkerFailures, resetCheckerFailures, symbolAt } from "../src/schema/checker";
 import type { AnalysisOptions } from "../src/options";
 
 const FIXTURE = path.resolve(import.meta.dir, "fixtures/unresolvable-js-app");
 // Two namespaces in one run (#114): a .js module is `javascript`, a .ts module is `typescript`.
 // Both now sit UNDER the one application segment, so they share the `can://<app>/` prefix.
-const TS = "can://unresolvable-js-app/typescript";
-const JS = "can://unresolvable-js-app/javascript";
+const TS = "can://unresolvable-js-app/unresolvable-js-app/typescript";
+const JS = "can://unresolvable-js-app/unresolvable-js-app/javascript";
 
 function options(over: Partial<AnalysisOptions> = {}): AnalysisOptions {
   return {
     input: FIXTURE, output: null, emit: "json", appName: "unresolvable-js-app", neo4jUri: null,
     neo4jUser: "neo4j", neo4jPassword: "", neo4jDatabase: null, analysisLevel: 2, graphs: [],
     graphFieldDepth: 3, jobs: 1, targetFiles: null, skipTests: true, eager: true, noBuild: true,
     phantoms: true, cacheDir: fs.mkdtempSync(path.join(os.tmpdir(), "cants-guard-")), verbosity: 0,
     ...over,
   } as AnalysisOptions;
 }
diff --git a/test/config-keys.test.ts b/test/config-keys.test.ts
index 60a0e2b..583ced0 100644
--- a/test/config-keys.test.ts
+++ b/test/config-keys.test.ts
@@ -31,21 +31,21 @@ describe("config keys — flat and JSON (#101 unit B)", () => {
 
   test("JSONC tsconfig parses despite comments and trailing commas", () => {
     const k = keysOf("tsconfig.json");
     expect(k["compilerOptions.strict"]?.value).toBe(true);
     expect(k["compilerOptions.target"]?.value).toBe("ES2022");
     expect(k["include.0"]?.value).toBe("src"); // arrays get numeric segments
     expect(arts["tsconfig.json"]?.extraction).toBe("full");
   });
 
   test("key ids chain off the artifact id", () => {
-    expect(keysOf(".env")["PAYMENT_HOST"]?.id).toBe("can://artifacts-app/artifact/.env@key/PAYMENT_HOST");
+    expect(keysOf(".env")["PAYMENT_HOST"]?.id).toBe("can://artifacts-app/artifacts-app/artifact/.env@key/PAYMENT_HOST");
   });
 
   test("a dependency manifest is never also a config file — manifests/lockfiles yield zero keys", () => {
     expect(arts["package.json"]?.config_keys.length).toBe(0);
     expect(arts["package-lock.json"]?.config_keys.length).toBe(0);
     expect(arts["packages/web/bun.lock"]?.config_keys.length).toBe(0);
     // fix round 2: the gate is checked on `roles` before the format switch, so it must hold for
     // YAML too — pnpm-lock.yaml is format "yaml" with role dependency-manifest; previously only
     // exercised by probe, not a committed test.
     expect(arts["pnpm-lock.yaml"]?.config_keys.length).toBe(0);
@@ -288,37 +288,37 @@ describe("deployment-env namespaces (#101 unit D)", () => {
   // confirmed to actually happen via `ARG VERSION` + `ENV VERSION=$VERSION`, a routine Dockerfile
   // idiom (promote a build arg into a runtime env var under the same name). The `key` FIELD stays
   // the bare name in both cases (env-namespace resolution still joins on a plain `key ===` match);
   // only the id gets an internal prefix — python v1.3.0 parity, applied in assignIds.ts.
   test("ARG VERSION + ENV VERSION=$VERSION mint the same bare key in two namespaces with DISTINCT ids", () => {
     const keys = arts["Dockerfile"]?.config_keys ?? [];
     const argVersion = keys.find((k) => k.namespace === "dockerfile" && k.key === "VERSION");
     const envVersion = keys.find((k) => k.namespace === "env" && k.key === "VERSION");
     expect(argVersion?.key).toBe("VERSION"); // key field stays bare — only the id is disambiguated
     expect(envVersion?.key).toBe("VERSION");
-    expect(argVersion?.id).toBe("can://artifacts-app/artifact/Dockerfile@key/arg.VERSION");
-    expect(envVersion?.id).toBe("can://artifacts-app/artifact/Dockerfile@key/VERSION"); // ENV: unprefixed
+    expect(argVersion?.id).toBe("can://artifacts-app/artifacts-app/artifact/Dockerfile@key/arg.VERSION");
+    expect(envVersion?.id).toBe("can://artifacts-app/artifacts-app/artifact/Dockerfile@key/VERSION"); // ENV: unprefixed
     expect(argVersion?.id).not.toBe(envVersion?.id);
   });
 
   // Same collision class, one namespace over: a yaml artifact's TOP-LEVEL leaf and its "env"
   // dual-mint (compose/k8s) can share a bare name too — docker-compose.yml now carries both a
   // root PAYMENT_HOST: leaf and services.web.environment.PAYMENT_HOST (which dual-mints an "env"
   // key named bare "PAYMENT_HOST"). Only the dual-mint's id gets the `env.` prefix.
   test("a yaml artifact's top-level leaf and its env dual-mint share a bare name but get DISTINCT ids", () => {
     const keys = arts["docker-compose.yml"]?.config_keys ?? [];
     const structural = keys.find((k) => k.namespace === "yaml" && k.key === "PAYMENT_HOST");
     const deployEnv = keys.find((k) => k.namespace === "env" && k.key === "PAYMENT_HOST");
     expect(structural?.value).toBe("https://root-level.example.com");
     expect(deployEnv?.value).toBe("https://pay.example.com");
-    expect(structural?.id).toBe("can://artifacts-app/artifact/docker-compose.yml@key/PAYMENT_HOST");
-    expect(deployEnv?.id).toBe("can://artifacts-app/artifact/docker-compose.yml@key/env.PAYMENT_HOST");
+    expect(structural?.id).toBe("can://artifacts-app/artifacts-app/artifact/docker-compose.yml@key/PAYMENT_HOST");
+    expect(deployEnv?.id).toBe("can://artifacts-app/artifacts-app/artifact/docker-compose.yml@key/env.PAYMENT_HOST");
     expect(structural?.id).not.toBe(deployEnv?.id);
   });
 
   // The regression guard that would have caught the original bug: every config-key id across the
   // WHOLE fixture app, unique — not just within the two cases spelled out above.
   test("no two config keys anywhere in the fixture app share an id", () => {
     const ids = Object.values(arts).flatMap((a) => a.config_keys.map((k) => k.id));
     expect(new Set(ids).size).toBe(ids.length);
   });
 
diff --git a/test/config-use.test.ts b/test/config-use.test.ts
index 7074cbe..ec392cf 100644
--- a/test/config-use.test.ts
+++ b/test/config-use.test.ts
@@ -57,28 +57,28 @@ describe("config_access body nodes (#101 unit C1)", () => {
 });
 
 const r2 = await analyze(options(2));
 const app2 = r2.application.application;
 const useDsts = (fnFragment: string): string[] =>
   app2.config_uses.filter((u) => u.src.includes(fnFragment)).map((u) => u.dst).sort();
 
 describe("config_use literal tier (#101 unit C3)", () => {
   test("a literal env read joins every declaring ConfigKey", () => {
     const dsts = useDsts("readHost");
-    expect(dsts).toContain("can://artifacts-app/artifact/.env@key/PAYMENT_HOST");
-    expect(dsts).toContain("can://artifacts-app/artifact/Dockerfile@key/PAYMENT_HOST");
+    expect(dsts).toContain("can://artifacts-app/artifacts-app/artifact/.env@key/PAYMENT_HOST");
+    expect(dsts).toContain("can://artifacts-app/artifacts-app/artifact/Dockerfile@key/PAYMENT_HOST");
     expect(app2.config_uses.every((u) => u.prov.includes("literal"))).toBe(true);
   });
 
   test("src is a global ordinal body-node id", () => {
     const u = app2.config_uses.find((x) => x.src.includes("readHost"));
-    expect(u?.src).toMatch(/^can:\/\/artifacts-app\/typescript\/src\/config\.ts\/readHost@\d+:\d+$/);
+    expect(u?.src).toMatch(/^can:\/\/artifacts-app\/artifacts-app\/typescript\/src\/config\.ts\/readHost@\d+:\d+$/);
   });
 
   test("a literal with no declared key is an undefined-key read, not an edge", () => {
     const read = app2.config_reads.find((r) => r.key === "NOT_DECLARED_ANYWHERE");
     expect(read?.reason).toBe("undefined-key");
     expect(read?.prov).toEqual(["literal"]);
     expect(app2.config_uses.some((u) => u.src.includes("readUndeclared"))).toBe(false);
   });
 
   test("a dynamic key is a non-literal read at L2", () => {
@@ -192,21 +192,21 @@ describe("config_use interproc tier (#101 unit C3, -a 4)", () => {
     const key = (u: { src: string; dst: string }): string => `${u.src}|${u.dst}`;
     const l4 = new Set(app4.config_uses.map(key));
     for (const u of app3.config_uses) expect(l4.has(key(u))).toBe(true);
   });
 });
 
 describe("Neo4j projection of the config layer (#101)", () => {
   const rows = neoProject(r2.application);
 
   test("ConfigKey nodes are neutral and hang off their artifact", () => {
-    const id = "can://artifacts-app/artifact/.env@key/PAYMENT_HOST";
+    const id = "can://artifacts-app/artifacts-app/artifact/.env@key/PAYMENT_HOST";
     const n = rows.nodes.find((x) => x.value === id);
     expect(n?.labels).toContain("ConfigKey");
     expect(n?.labels).not.toContain("TSConfigKey");
     expect(rows.edges.some((e) => e.type === "DEFINES_CONFIG" && e.to.value === id)).toBe(true);
   });
 
   test("TS_USES_CONFIG carries prov and points at a ConfigKey", () => {
     const e = rows.edges.find((x) => x.type === "TS_USES_CONFIG");
     expect(e?.props["prov"]).toEqual(["literal"]);
     expect(String(e?.to.value)).toContain("@key/");
diff --git a/test/entrypoints-calls.test.ts b/test/entrypoints-calls.test.ts
index 7dd6a0a..a241d2c 100644
--- a/test/entrypoints-calls.test.ts
+++ b/test/entrypoints-calls.test.ts
@@ -44,24 +44,24 @@ describe("calls: heuristic tier (Express shape)", () => {
     const root = rootOf(await analyze(opts(fixture(EXPRESS))));
     const byName: Record<string, unknown[]> = {};
     for (const m of Object.values(root.symbol_table)) forEachCallable(m, (c) => { byName[c.name] = c.entrypoints ?? []; });
     expect(byName.named).toEqual(expect.arrayContaining([
       expect.objectContaining({ rule: "heuristic.http-verb-call", evidence: "app.get", route: "/a", http_methods: ["GET"], confidence: "heuristic", framework: "heuristic" }),
       expect.objectContaining({ evidence: "app.delete", route: "/d", http_methods: ["DELETE"] }),
     ]));
     expect(byName.arrow?.[0]).toMatchObject({ evidence: "app.put", route: "/c", http_methods: ["PUT"] });
     expect(byName["(anonymous)"]?.[0]).toMatchObject({ evidence: "app.post", route: "/b", http_methods: ["POST"] });
     // via is the module-scope call node id
-    expect((byName.named?.[0] as { via?: string }).via).toMatch(/^can:\/\/c\/typescript\/src\/app\.ts@5:\d+$/);
+    expect((byName.named?.[0] as { via?: string }).via).toMatch(/^can:\/\/c\/c\/typescript\/src\/app\.ts@5:\d+$/);
     // via for a call site owned by a callable (app.delete inside setup()) names THAT callable, not the module
     const deleteRecord = byName.named?.find((e) => (e as { evidence?: string }).evidence === "app.delete") as { via?: string } | undefined;
-    expect(deleteRecord?.via).toMatch(/^can:\/\/c\/typescript\/src\/app\.ts\/setup@10:\d+$/);
+    expect(deleteRecord?.via).toMatch(/^can:\/\/c\/c\/typescript\/src\/app\.ts\/setup@10:\d+$/);
   });
 
   test("an unresolvable handler is counted, not fabricated", async () => {
     const root = rootOf(await analyze(opts(fixture(EXPRESS))));
     expect(root.entrypoint_report.unresolved["app.use"]).toBe(1);
   });
 
   test("never doubles: a node a framework rule claimed gets no calls record", async () => {
     // Not exercisable until a framework rule can claim a handler; assert the invariant at the
     // record level instead: the same handler registered twice gets two records (two calls), but
@@ -99,15 +99,15 @@ describe("calls: heuristic tier (Express shape)", () => {
       "export function named(req: unknown, res: unknown): void {}",
       "function setup() {",
       "  router.get('/a',named).get('/b',named);",
       "}",
     ].join("\n");
     const root = rootOf(await analyze(opts(fixture(src))));
     let named: Array<{ via?: string; evidence?: string }> = [];
     for (const m of Object.values(root.symbol_table)) forEachCallable(m, (c) => { if (c.name === "named") named = (c.entrypoints ?? []) as typeof named; });
     expect(named).toHaveLength(2);
     const byEvidence = Object.fromEntries(named.map((e) => [e.evidence, e.via]));
-    expect(byEvidence["router.get('/a',named).get"]).toMatch(/^can:\/\/c\/typescript\/src\/app\.ts\/setup@5:\d+$/);
-    expect(byEvidence["router.get"]).toMatch(/^can:\/\/c\/typescript\/src\/app\.ts\/setup@5:\d+\/2$/);
+    expect(byEvidence["router.get('/a',named).get"]).toMatch(/^can:\/\/c\/c\/typescript\/src\/app\.ts\/setup@5:\d+$/);
+    expect(byEvidence["router.get"]).toMatch(/^can:\/\/c\/c\/typescript\/src\/app\.ts\/setup@5:\d+\/2$/);
     expect(byEvidence["router.get('/a',named).get"]).not.toBe(byEvidence["router.get"]);
   });
 });
diff --git a/test/ids.test.ts b/test/ids.test.ts
index 8adfaa6..01a78d6 100644
--- a/test/ids.test.ts
+++ b/test/ids.test.ts
@@ -14,40 +14,40 @@ describe("per-module language namespace (#114)", () => {
     expect(languageOf(f)).toBe("typescript");
   });
 
   test.each([["b.js"], ["b.jsx"], ["b.mjs"], ["b.cjs"]])("%s is javascript", (f) => {
     expect(languageOf(f)).toBe("javascript");
   });
 
   // A declaration file is TypeScript. The suffix must not be read as `.ts` on a file named `a.d`.
   test("a .d.ts declaration file is typescript", () => {
     expect(languageOf("types/x.d.ts")).toBe("typescript");
-    expect(moduleIdOf("app", "types/x.d.ts")).toBe("can://app/typescript/types/x.d.ts");
+    expect(moduleIdOf("app", "types/x.d.ts")).toBe("can://app/app/typescript/types/x.d.ts");
   });
 
   // The match is anchored: a DIRECTORY named `foo.js` must not make its .ts children javascript.
   test("a directory named *.js does not change its children's namespace", () => {
     expect(languageOf("vendor.js/index.ts")).toBe("typescript");
   });
 
   test("module ids carry their own namespace, nested under the one application", () => {
-    expect(applicationIdOf("app")).toBe("can://app");
-    expect(moduleIdOf("app", "src/bar.ts")).toBe("can://app/typescript/src/bar.ts");
-    expect(moduleIdOf("app", "lib/foo.js")).toBe("can://app/javascript/lib/foo.js");
+    expect(applicationIdOf("app")).toBe("can://app/app");
+    expect(moduleIdOf("app", "src/bar.ts")).toBe("can://app/app/typescript/src/bar.ts");
+    expect(moduleIdOf("app", "lib/foo.js")).toBe("can://app/app/javascript/lib/foo.js");
   });
 });
 
 describe("the application is the outermost segment", () => {
   test("artifact ids nest under the app instead of forming a parallel scheme", () => {
     // Was can://artifact/<app>/<path> — a third top-level namespace. Now one rule.
-    expect(artifactIdOf("app", "package.json")).toBe("can://app/artifact/package.json");
-    expect(artifactIdOf("app", "./.env")).toBe("can://app/artifact/.env");
+    expect(artifactIdOf("app", "package.json")).toBe("can://app/app/artifact/package.json");
+    expect(artifactIdOf("app", "./.env")).toBe("can://app/app/artifact/.env");
   });
 
   test("every id shares the application prefix — both language namespaces included", () => {
     // This is what makes ONE prefix-scoped delete correct where two used to be needed, so assert
     // it directly rather than inferring it from the mint functions.
     const app = applicationIdOf("app");
     for (const id of [
       moduleIdOf("app", "src/bar.ts"),
       moduleIdOf("app", "lib/foo.js"),
       artifactIdOf("app", "package.json"),
@@ -62,15 +62,15 @@ describe("the application is the outermost segment", () => {
     for (const id of [applicationIdOf("app"), moduleIdOf("app", "lib/foo.js"), artifactIdOf("app", "package.json")]) {
       expect(id.startsWith("can://typescript/")).toBe(false);
       expect(id.startsWith("can://javascript/")).toBe(false);
       expect(id.startsWith("can://artifact/")).toBe(false);
     }
   });
 
   test("an app named after a language is still addressable (the segment-1 collision)", () => {
     // can://typescript/typescript/... is legal and unambiguous POSITIONALLY. Anything that reads
     // the language off the FIRST segment gets it wrong here; segment 2 is the language.
-    expect(moduleIdOf("typescript", "lib/foo.js")).toBe("can://typescript/javascript/lib/foo.js");
-    expect(moduleIdOf("javascript", "src/bar.ts")).toBe("can://javascript/typescript/src/bar.ts");
-    expect(applicationIdOf("artifact")).toBe("can://artifact");
+    expect(moduleIdOf("typescript", "lib/foo.js")).toBe("can://typescript/typescript/javascript/lib/foo.js");
+    expect(moduleIdOf("javascript", "src/bar.ts")).toBe("can://javascript/javascript/typescript/src/bar.ts");
+    expect(applicationIdOf("artifact")).toBe("can://artifact/artifact");
   });
 });
diff --git a/test/namespace.test.ts b/test/namespace.test.ts
new file mode 100644
index 0000000..86fda18
--- /dev/null
+++ b/test/namespace.test.ts
@@ -0,0 +1,72 @@
+import { expect, test } from 'bun:test';
+import fixture from './fixtures/identity/namespaces.json';
+import { applicationIdOf, moduleIdOf, artifactIdOf } from '../src/schema/ids';
+for (const row of fixture.roots) test(`root ${JSON.stringify(row)}`, () => expect(applicationIdOf(row.application_name, row.namespace ?? undefined)).toBe(row.expected_root));
+for (const row of fixture.invalid) test(`invalid ${row.reason}`, () => {
+ expect(() => applicationIdOf(row.value)).toThrow();
+ expect(() => applicationIdOf('app', row.value)).toThrow();
+});
+for (const row of fixture.modules.filter(r => ['typescript','javascript'].includes(r.language))) test(row.expected_uri, () => expect(moduleIdOf(row.application_name,row.file_key,row.namespace ?? undefined)).toBe(row.expected_uri));
+test('artifact scope', () => expect(artifactIdOf('a%b','package.json','team')).toBe('can://team/a%25b/artifact/package.json'));
+
+import { analyze } from '../src/core';
+import { finalizeAnalysis } from '../src/schema/emit';
+import { project } from '../src/build/neo4j/project';
+import { loadCache } from '../src/utils/cache';
+import type { AnalysisOptions } from '../src/options';
+import * as fs from 'node:fs';
+import * as os from 'node:os';
+import * as path from 'node:path';
+const cacheDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cants-namespace-'));
+const options = {
+ input: path.join(import.meta.dir,'fixtures/artifacts-app'), appName: 'a%b', namespace: 'first',
+ analysisLevel: 2, graphs: ['cfg','dfg','pdg','sdg'], graphFieldDepth: 3, jobs: 1,
+ skipTests: true, eager: true, noBuild: true, phantoms: true, cacheDir, verbosity: 0,
+} as AnalysisOptions;
+test('repeat finalization restamps every reference and preserves input-relative keys', async () => {
+ const first = await analyze(options);
+ expect(first.application.identity_version).toBe(2);
+ const second = finalizeAnalysis(first.internal,null,{...options,namespace:'second'}).application;
+ expect(second.application.application_name).toBe('a%b');
+ expect(second.application.identity_namespace).toBe('second');
+ expect(second.application.identity_version).toBe(2);
+ expect(Object.keys(second.application.symbol_table)).toEqual(Object.keys(first.application.application.symbol_table));
+ expect(JSON.stringify(second)).not.toContain('can://first/');
+ expect(second.application.dependencies.length).toBeGreaterThan(0);
+ for (const dependency of second.application.dependencies) expect(dependency.declared_in).toStartWith('can://second/a%25b/artifact/');
+ expect(Object.keys(second.application.external_symbols ?? {}).length).toBeGreaterThan(0);
+ for (const mod of Object.values(second.application.symbol_table)) expect(mod.id).toStartWith('can://second/a%25b/');
+ expect(project(second).nodes.find(n=>n.labels.includes('TSApplication'))?.props.identity_namespace).toBe('second');
+ expect(loadCache(cacheDir, 'can://first/a%25b')).not.toBeNull();
+ expect(loadCache(cacheDir, 'can://second/a%25b')).toBeNull();
+ for (const marker of [undefined,1,'2',2.5]) {
+  const stale = structuredClone(second);
+  (stale as any).identity_version=marker;
+  expect(()=>project(stale)).toThrow();
+ }
+ const mismatch = structuredClone(second);
+ mismatch.application.identity_namespace='first';
+ expect(()=>project(mismatch)).toThrow();
+});
+test('explicit empty namespace fails before analysis', async () => {
+ await expect(analyze({...options,namespace:''})).rejects.toThrow();
+});
+test('cache rejects legacy and noninteger markers without rewriting the input', () => {
+ const file = path.join(cacheDir, 'analysis_cache.json');
+ const original = fs.readFileSync(file,'utf8');
+ try {
+  for (const marker of [undefined, 1, '2', 2.5]) {
+   const data = JSON.parse(original);
+   data.identity_version = marker;
+   const bytes = JSON.stringify(data);
+   fs.writeFileSync(file,bytes);
+   expect(loadCache(cacheDir,'can://first/a%25b')).toBeNull();
+   expect(fs.readFileSync(file,'utf8')).toBe(bytes);
+  }
+ } finally { fs.writeFileSync(file,original); }
+});
+test('application metadata is required even for the default namespace', async () => {
+ const wire = (await analyze({...options,appName:'app',namespace:undefined})).application;
+ delete (wire.application as any).identity_namespace;
+ expect(()=>project(wire)).toThrow();
+});
diff --git a/test/neo4j-artifact-reconcile.test.ts b/test/neo4j-artifact-reconcile.test.ts
index 6521ad8..686d4a5 100644
--- a/test/neo4j-artifact-reconcile.test.ts
+++ b/test/neo4j-artifact-reconcile.test.ts
@@ -11,38 +11,38 @@ import { Neo4jContainer, type StartedNeo4jContainer } from "@testcontainers/neo4
 import neo4j, { type Driver } from "neo4j-driver";
 import { type BoltConfig, boltWriter, project } from "../src/build/neo4j";
 import type { GraphRows } from "../src/build/neo4j/rows";
 import { analyze } from "../src/core";
 import type { AnalysisOptions } from "../src/options";
 import { Logger } from "../src/utils";
 
 const FIXTURES = path.resolve(import.meta.dir, "fixtures");
 const TMP = fs.mkdtempSync(path.join(os.tmpdir(), "cants-reconcile-"));
 const log = new Logger(0);
-const APP = "can://app";
+const APP = "can://app/app";
 const ART = `${APP}/artifact/`;
 const containerSuite = process.env.RUN_CONTAINER_TESTS ? describe : describe.skip;
 
 /** artifacts-app copied to `<repo>/services/app`, so it can be pushed with or without a workspace root. */
 function repo(): { repo: string; input: string } {
   const root = fs.mkdtempSync(path.join(TMP, "repo-"));
   const input = path.join(root, "services/app");
   fs.cpSync(path.join(FIXTURES, "artifacts-app"), input, { recursive: true });
   return { repo: root, input };
 }
 
 async function rows(input: string, over: Partial<AnalysisOptions> = {}): Promise<GraphRows> {
   const opts = {
     input, output: null, emit: "json", appName: "app", neo4jUri: null, neo4jUser: "neo4j",
     neo4jPassword: "", neo4jDatabase: null, analysisLevel: 2, graphs: [], graphFieldDepth: 3, jobs: 1,
     targetFiles: null, skipTests: true, eager: true, noBuild: true, phantoms: true, verbosity: 0,
-    cacheDir: fs.mkdtempSync(path.join(TMP, "cache-")), workspaceRoot: null, ...over,
+    cacheDir: fs.mkdtempSync(path.join(TMP, "cache-")), namespace: undefined, ...over,
   } as AnalysisOptions;
   return project((await analyze(opts)).application);
 }
 
 containerSuite("neo4j bolt artifact reconciliation", () => {
   let container: StartedNeo4jContainer;
   let driver: Driver;
   let cfg: BoltConfig;
 
   beforeAll(async () => {
@@ -73,41 +73,41 @@ containerSuite("neo4j bolt artifact reconciliation", () => {
       return typeof v?.toNumber === "function" ? v.toNumber() : Number(v ?? 0);
     } finally {
       await s.close();
     }
   }
 
   const stale = (rooted: string) =>
     num("MATCH (n) WHERE (n:Artifact OR n:ConfigKey) AND n.id STARTS WITH $p AND NOT n.id STARTS WITH $r RETURN count(n)",
       { p: ART, r: ART + rooted });
 
-  test("toggling --workspace-root leaves no old-keyed artifact, config key or edge", async () => {
+  test("an identical re-push keeps artifact keys and edges stable", async () => {
     const { repo: root, input } = repo();
     await boltWriter(await rows(input), cfg, log, true, true);
     expect(await num("MATCH (a:Artifact {id: $id}) RETURN count(a)", { id: ART + "package.json" })).toBe(1);
 
-    const rooted = await rows(input, { workspaceRoot: root });
+    const rooted = await rows(input);
     await boltWriter(rooted, cfg, log, true, true);
 
-    expect(await stale("services/app/")).toBe(0);
+    expect(await stale("")).toBe(0);
     const arts = rooted.nodes.filter((n) => n.labels[0] === "Artifact").length;
     expect(await num("MATCH (:TSApplication)-[r:HAS_ARTIFACT]->() RETURN count(r)")).toBe(arts);
     expect(await num("MATCH ()-[r:DECLARES_DEPENDENCY]->(:Package {id: 'pkg:npm/react'}) RETURN count(r)")).toBe(1);
     const uses = rooted.edges.filter((e) => e.type === "TS_USES_CONFIG").length;
     expect(uses).toBeGreaterThan(0);
     expect(await num("MATCH ()-[r:TS_USES_CONFIG]->() RETURN count(r)")).toBe(uses);
   }, 180_000);
 
   test("a targeted or non-eager push reconciles no artifacts", async () => {
     const { repo: root, input } = repo();
     await boltWriter(await rows(input), cfg, log, true, true);
-    const rooted = await rows(input, { workspaceRoot: root });
+    const rooted = await rows(input, { namespace: "other" });
     await boltWriter(rooted, cfg, log, false, true);
     await boltWriter(rooted, cfg, log, true, false);
     expect(await num("MATCH (a:Artifact {id: $id}) RETURN count(a)", { id: ART + "package.json" })).toBe(1);
   }, 180_000);
 
   test("a changed manifest drops its removed dependency, config key and their edges", async () => {
     const { input } = repo();
     await boltWriter(await rows(input), cfg, log, true, true);
     expect(await num("MATCH ()-[r:DECLARES_DEPENDENCY]->(:Package {id: 'pkg:npm/react'}) RETURN count(r)")).toBe(1);
     const envKey = `${ART}.env@key/PAYMENT_HOST`;
@@ -135,21 +135,21 @@ containerSuite("neo4j bolt artifact reconciliation", () => {
     expect(await num(shape)).toBe(before);
   }, 180_000);
 
   test("a sibling's claims survive: shared nodes, its edges, and nodes only it wrote", async () => {
     const { input } = repo();
     await boltWriter(await rows(input), cfg, log, true, true);
     // What codeanalyzer-python writes: its own inventory of pyproject.toml with a pypi dependency and
     // a config key, plus an artifact TypeScript never emits.
     await run(
       "MATCH (a:Artifact {id: $pp}) SET a:PyCanNode " +
-        "MERGE (app:PyApplication {id: 'can://app'}) MERGE (app)-[:HAS_ARTIFACT]->(a) " +
+        "MERGE (app:PyApplication {id: 'can://app/app'}) MERGE (app)-[:HAS_ARTIFACT]->(a) " +
         "MERGE (p:Package {id: 'pkg:pypi/flask'}) MERGE (a)-[:DECLARES_DEPENDENCY {_k: 'runtime'}]->(p) " +
         "MERGE (k:ConfigKey:PyCanNode {id: $pp + '@key/tool.name'}) MERGE (a)-[:DEFINES_CONFIG]->(k) " +
         "MERGE (o:Artifact:PyCanNode {id: $py}) MERGE (app)-[:HAS_ARTIFACT]->(o)",
       { pp: ART + "pyproject.toml", py: ART + "setup.cfg" },
     );
     // Stop emitting pyproject.toml: TypeScript releases its claim but must not delete python's node.
     fs.rmSync(path.join(input, "pyproject.toml"));
     await boltWriter(await rows(input), cfg, log, true, true);
 
     const pp = ART + "pyproject.toml";
@@ -168,57 +168,57 @@ containerSuite("neo4j bolt artifact reconciliation", () => {
     const env = fs.readFileSync(path.join(input, ".env"), "utf8");
     fs.writeFileSync(path.join(input, ".env"), env.split("\n").filter((l) => !l.startsWith("PAYMENT_HOST")).join("\n"));
     await boltWriter(await rows(input), cfg, log, true, true);
     expect(await num("MATCH (:Artifact)-[:DEFINES_CONFIG]->(k:ConfigKey:PyCanNode {id: $k}) WHERE NOT k:TSCanNode RETURN count(k)", { k: key })).toBe(1);
   }, 180_000);
 
   test("an app whose name extends another's is not reconciled by it", async () => {
     const a = repo();
     const b = repo();
     await boltWriter(await rows(b.input, { appName: "apps" }), cfg, log, true, true);
-    const before = await num("MATCH (n) WHERE (n:Artifact OR n:ConfigKey) AND n.id STARTS WITH 'can://apps/' RETURN count(n)");
+    const before = await num("MATCH (n) WHERE (n:Artifact OR n:ConfigKey) AND n.id STARTS WITH 'can://apps/apps/' RETURN count(n)");
     expect(before).toBeGreaterThan(0);
     for (const f of fs.readdirSync(a.input)) if (f !== "src") fs.rmSync(path.join(a.input, f), { recursive: true });
     await boltWriter(await rows(a.input), cfg, log, true, true);
-    expect(await num("MATCH (n:TSCanNode) WHERE (n:Artifact OR n:ConfigKey) AND n.id STARTS WITH 'can://apps/' RETURN count(n)")).toBe(before);
+    expect(await num("MATCH (n:TSCanNode) WHERE (n:Artifact OR n:ConfigKey) AND n.id STARTS WITH 'can://apps/apps/' RETURN count(n)")).toBe(before);
   }, 180_000);
 
-  test("pre-re-key artifacts are released; a sibling's are left alone", async () => {
+  test("legacy artifacts and sibling claims are outside the selected scope", async () => {
     await run(
       "MERGE (a:Artifact {id: 'can://artifact/app/old.json'}) MERGE (k:ConfigKey {id: 'can://artifact/app/old.json@key/x'}) " +
         "MERGE (a)-[:DEFINES_CONFIG]->(k) MERGE (j:Artifact:JCanNode {id: 'can://artifact/app/pom.xml'})",
     );
     const { input } = repo();
     await boltWriter(await rows(input), cfg, log, true, true);
-    expect(await num("MATCH (n) WHERE n.id STARTS WITH 'can://artifact/app/old.json' RETURN count(n)")).toBe(0);
+    expect(await num("MATCH (n) WHERE n.id STARTS WITH 'can://artifact/app/old.json' RETURN count(n)")).toBe(2);
     expect(await num("MATCH (n:JCanNode {id: 'can://artifact/app/pom.xml'}) RETURN count(n)")).toBe(1);
   }, 180_000);
 
   test("--eager --target-files purges no artifact and drops none of their edges", async () => {
     const { input } = repo();
     const full = await rows(input);
     await boltWriter(full, cfg, log, true, true);
     // A sibling's claim on the shared package.json: the old purge DETACH-deleted it on every eager run.
-    await run("MATCH (a:Artifact {id: $id}) MERGE (p:PyApplication {id: 'can://app'}) MERGE (p)-[:HAS_ARTIFACT]->(a) " +
+    await run("MATCH (a:Artifact {id: $id}) MERGE (p:PyApplication {id: 'can://app/app'}) MERGE (p)-[:HAS_ARTIFACT]->(a) " +
       "MERGE (k:Package {id: 'pkg:pypi/flask'}) MERGE (a)-[:DECLARES_DEPENDENCY {_k: 'runtime'}]->(k)", { id: ART + "package.json" });
     const shape = "MATCH (a) WHERE a:Artifact OR a:ConfigKey OPTIONAL MATCH (a)-[r]-() " +
       "RETURN count(DISTINCT a) * 1000000 + count(DISTINCT r)";
     const before = await num(shape);
     await boltWriter(full, cfg, log, false, true);
     expect(await num(shape)).toBe(before);
     expect(await num("MATCH (:PyApplication)-[:HAS_ARTIFACT]->(:Artifact {id: $id})-[:DECLARES_DEPENDENCY]->(:Package {id: 'pkg:pypi/flask'}) " +
       "RETURN count(*)", { id: ART + "package.json" })).toBe(1);
   }, 180_000);
 
   test("a pre-1.5.1 unmarked artifact a sibling still inventories survives", async () => {
     await run("MERGE (a:Artifact {id: 'can://artifact/app/requirements.txt'}) " +
-      "MERGE (p:PyApplication {id: 'can://app'}) MERGE (p)-[:HAS_ARTIFACT]->(a)");
+      "MERGE (p:PyApplication {id: 'can://app/app'}) MERGE (p)-[:HAS_ARTIFACT]->(a)");
     const { input } = repo();
     await boltWriter(await rows(input), cfg, log, true, true);
     expect(await num("MATCH (:PyApplication)-[:HAS_ARTIFACT]->(a:Artifact {id: 'can://artifact/app/requirements.txt'}) " +
       "RETURN count(a)")).toBe(1);
   }, 180_000);
 
   test("a removed dependency and a now-declared import drop their import edges", async () => {
     const { input } = repo();
     await boltWriter(await rows(input), cfg, log, true, true);
     const provides = "MATCH (:Package {id: 'pkg:npm/express'})-[r:TS_PROVIDES]->() RETURN count(r)";
diff --git a/test/neo4j-bolt.test.ts b/test/neo4j-bolt.test.ts
index e65c075..f320fcd 100644
--- a/test/neo4j-bolt.test.ts
+++ b/test/neo4j-bolt.test.ts
@@ -228,21 +228,21 @@ containerSuite("neo4j bolt writer", () => {
         await num("MATCH (n:TSCanNode) WHERE n.id STARTS WITH $pre AND (n:Artifact OR n:ConfigKey) RETURN count(n)", { pre: `${appId}/` }),
       ).toBe(artifactRows.length);
     },
     120_000,
   );
 
   test(
     "a second application in the same language, with colliding module paths, survives every purge (#140)",
     async () => {
       // Same fixture, two application names — every file key collides. `saX` is chosen so that
-      // `can://sa` is a string prefix of `can://saX`: the boundary case the trailing `/` handles.
+      // `can://sa/sa` is a string prefix of `can://saX/saX`: the boundary case the trailing `/` handles.
       const a = project((await analyze(optsFor({ appName: "sa" }))).application);
       const b = project((await analyze(optsFor({ appName: "saX" }))).application);
       const under = (app: string) => num("MATCH (n:TSCanNode) WHERE n.id STARTS WITH $p RETURN count(n)", { p: `can://${app}/` });
 
       await boltWriter(a, cfg, log, true, true);
       const a0 = await under("sa");
       expect(a0).toBeGreaterThan(0);
       await boltWriter(b, cfg, log, true, true); // saX's --eager purge + prune must not touch sa
       expect(await under("sa")).toBe(a0);
       const b0 = await under("saX");
diff --git a/test/neo4j-edge-identity.test.ts b/test/neo4j-edge-identity.test.ts
index 0909d31..d26fccd 100644
--- a/test/neo4j-edge-identity.test.ts
+++ b/test/neo4j-edge-identity.test.ts
@@ -4,22 +4,22 @@
  * per variable (plus the prov split), and a conditional's true/false CFG_NEXT pair shares its
  * endpoints. Discriminated families MERGE on `{_k: row.k}` so each survives; undiscriminated
  * families keep the plain endpoint-pair MERGE.
  */
 import { describe, expect, test } from "bun:test";
 import { renderCypher } from "../src/build/neo4j";
 import { RowBuilder } from "../src/build/neo4j/rows";
 
 function twoVarDdgRows() {
   const b = new RowBuilder();
-  const a = b.node(["CanNode", "TSBodyNode"], "id", "can://ts/app/f.ts/f()@1:0", {});
-  const c = b.node(["CanNode", "TSBodyNode"], "id", "can://ts/app/f.ts/f()@2:0", {});
+  const a = b.node(["CanNode", "TSBodyNode"], "id", "can://ts/ts/app/f.ts/f()@1:0", {});
+  const c = b.node(["CanNode", "TSBodyNode"], "id", "can://ts/ts/app/f.ts/f()@2:0", {});
   b.edge("TS_DDG", a, c, { var: "x", prov: ["reaching-defs"] }, "x|reaching-defs");
   b.edge("TS_DDG", a, c, { var: "y", prov: ["reaching-defs"] }, "y|reaching-defs");
   b.edge("TS_CDG", a, c); // undiscriminated control family stays a plain MERGE
   return b.finish();
 }
 
 describe("edge identity discriminant (_k)", () => {
   test("per-var DDG edges between one endpoint pair both survive rendering", () => {
     const cypher = renderCypher(twoVarDdgRows(), "app");
     expect(cypher).toContain("MERGE (a)-[r:TS_DDG {_k: row.k}]->(b)");
diff --git a/test/neo4j-prefix-scope.test.ts b/test/neo4j-prefix-scope.test.ts
index f213c5a..9cbbe03 100644
--- a/test/neo4j-prefix-scope.test.ts
+++ b/test/neo4j-prefix-scope.test.ts
@@ -13,109 +13,109 @@ import { analyze } from "../src/core";
 import { EAGER_PURGE } from "../src/build/neo4j/bolt";
 import { project, renderCypher, MARKER_LABELS } from "../src/build/neo4j";
 import { RowBuilder, applicationPrefix, descendantPrefix, markersFor } from "../src/build/neo4j/rows";
 import type { AnalysisOptions } from "../src/options";
 
 const FIXTURE = path.resolve(import.meta.dir, "fixtures/sample-app");
 const opts = { input: FIXTURE, appName: "ps", analysisLevel: 1, eager: true, noBuild: true, emit: "neo4j", entrypointRules: null } as unknown as AnalysisOptions;
 
 describe("can:// prefix scoping (#140)", () => {
   test("one /-terminated application prefix; anything that is not a bare app id is refused", () => {
-    expect(applicationPrefix("can://app")).toBe("can://app/");
-    expect(descendantPrefix("can://app/typescript/src/a.ts")).toBe("can://app/typescript/src/a.ts/");
+    expect(applicationPrefix("can://app/app")).toBe("can://app/app/");
+    expect(descendantPrefix("can://app/app/typescript/src/a.ts")).toBe("can://app/app/typescript/src/a.ts/");
     // A deeper id would silently narrow the scope to a subtree, so it is refused too.
-    for (const bad of [null, undefined, "", "can://", "can://app/typescript", "app"]) {
+    for (const bad of [null, undefined, "", "can://", "can://app/app/typescript", "app"]) {
       expect(() => applicationPrefix(bad as never)).toThrow(/refusing a destructive statement/);
     }
   });
 
   test("one marker spans every can:// id, artifacts included; JSCanNode rides along", () => {
-    expect(markersFor("can://app/typescript/src/a.ts/f")).toEqual(["TSCanNode"]);
-    expect(markersFor("can://app/javascript/src/a.js/f")).toEqual(["TSCanNode", "JSCanNode"]);
+    expect(markersFor("can://app/app/typescript/src/a.ts/f")).toEqual(["TSCanNode"]);
+    expect(markersFor("can://app/app/javascript/src/a.js/f")).toEqual(["TSCanNode", "JSCanNode"]);
     // Artifacts and their config keys are marked, so the wipe reaches them: an unmarked artifact
     // is unreachable by every destructive statement and accumulates forever. The polyglot cost is
     // measured in artifacts.test.ts, not assumed here.
-    expect(markersFor("can://app/artifact/package.json")).toEqual(["TSCanNode"]);
-    expect(markersFor("can://app/artifact/.env@key/PAYMENT_HOST")).toEqual(["TSCanNode"]);
+    expect(markersFor("can://app/app/artifact/package.json")).toEqual(["TSCanNode"]);
+    expect(markersFor("can://app/app/artifact/.env@key/PAYMENT_HOST")).toEqual(["TSCanNode"]);
     // A node keyed on its own natural identity (:Package purl, :TSDecorator name) is never marked.
     expect(markersFor("pkg:npm/express")).toEqual([]);
     expect(markersFor("Get")).toEqual([]);
     // The language is read POSITIONALLY (segment 2), so an app NAMED after a language still works.
-    expect(markersFor("can://javascript/typescript/src/a.ts/f")).toEqual(["TSCanNode"]);
-    expect(markersFor("can://typescript/javascript/src/a.js/f")).toEqual(["TSCanNode", "JSCanNode"]);
+    expect(markersFor("can://javascript/javascript/typescript/src/a.ts/f")).toEqual(["TSCanNode"]);
+    expect(markersFor("can://typescript/typescript/javascript/src/a.js/f")).toEqual(["TSCanNode", "JSCanNode"]);
   });
 
   test("RowBuilder lifts _module off the row and adds the markers for id-keyed can:// nodes", () => {
     const b = new RowBuilder();
-    b.node(["CanNode", "TSCallable"], "id", "can://app/typescript/src/a.ts/f", { id: "x", _module: "src/a.ts", name: "f" });
-    b.node(["CanNode", "TSCallable"], "id", "can://app/javascript/src/b.js/g", { id: "y", _module: "src/b.js", name: "g" });
-    b.node(["Artifact"], "id", "can://app/artifact/package.json", { id: "z", path: "package.json" });
+    b.node(["CanNode", "TSCallable"], "id", "can://app/app/typescript/src/a.ts/f", { id: "x", _module: "src/a.ts", name: "f" });
+    b.node(["CanNode", "TSCallable"], "id", "can://app/app/javascript/src/b.js/g", { id: "y", _module: "src/b.js", name: "g" });
+    b.node(["Artifact"], "id", "can://app/app/artifact/package.json", { id: "z", path: "package.json" });
     b.node(["Package"], "id", "pkg:npm/express", { id: "pkg:npm/express", name: "express" });
     b.node(["TSDecorator"], "name", "Get", { name: "Get" });
     const rows = b.finish();
     const byValue = new Map(rows.nodes.map((n) => [n.value, n]));
-    const ts = byValue.get("can://app/typescript/src/a.ts/f")!;
+    const ts = byValue.get("can://app/app/typescript/src/a.ts/f")!;
     expect(ts.labels).toEqual(["CanNode", "TSCallable", "TSCanNode"]);
     expect(ts.module).toBe("src/a.ts");
     expect("_module" in ts.props).toBe(false);
-    expect(byValue.get("can://app/javascript/src/b.js/g")!.labels).toEqual(["CanNode", "TSCallable", "TSCanNode", "JSCanNode"]);
-    expect(byValue.get("can://app/artifact/package.json")!.labels).toEqual(["Artifact", "TSCanNode"]);
+    expect(byValue.get("can://app/app/javascript/src/b.js/g")!.labels).toEqual(["CanNode", "TSCallable", "TSCanNode", "JSCanNode"]);
+    expect(byValue.get("can://app/app/artifact/package.json")!.labels).toEqual(["Artifact", "TSCanNode"]);
     expect(byValue.get("pkg:npm/express")!.labels).toEqual(["Package"]);
     expect(byValue.get("Get")!.labels).toEqual(["TSDecorator"]);
   });
 
   test("a real projection: no row carries _module; every node under the app prefix carries TSCanNode", async () => {
     const rows = project((await analyze(opts)).application);
     expect(rows.nodes.some((n) => "_module" in n.props)).toBe(false);
-    const owned = rows.nodes.filter((n) => n.value.startsWith("can://ps/"));
+    const owned = rows.nodes.filter((n) => n.value.startsWith("can://ps/ps/"));
     expect(owned.length).toBeGreaterThan(10);
     // No can:// row is left unmarked, so no row is beyond the reach of the scoped delete.
     for (const n of owned) expect(n.labels).toContain("TSCanNode");
     expect(rows.nodes.filter((n) => n.module !== undefined).length).toBeGreaterThan(10);
     expect([...MARKER_LABELS]).toEqual(["TSCanNode", "JSCanNode"]);
   });
 
   test("every can:// node the projection emits sits under the one application prefix", async () => {
     // The property the flip exists for: one prefix reaches everything, in either namespace.
     const rows = project((await analyze(opts)).application);
     const can = rows.nodes.filter((n) => n.keyProp === "id" && n.value.startsWith("can://"));
     expect(can.length).toBeGreaterThan(10);
     for (const n of can) {
-      expect(n.value === "can://ps" || n.value.startsWith("can://ps/")).toBe(true);
+      expect(n.value === "can://ps/ps" || n.value.startsWith("can://ps/ps/")).toBe(true);
       expect(n.value.startsWith("can://typescript/")).toBe(false);
       expect(n.value.startsWith("can://javascript/")).toBe(false);
       expect(n.value.startsWith("can://artifact/")).toBe(false);
     }
   });
 
   test("two applications project as two distinct roots", async () => {
     // The multi-service failure mode. :Application already merges on `id` rather than on the
     // free-text --app-name, so this holds by construction — pinned here against regression, and
     // because the root's id is now the prefix every other id in the projection is scoped by.
     const a = project((await analyze({ ...opts, appName: "svc-quotes" })).application);
     const b = project((await analyze({ ...opts, appName: "svc-orders" })).application);
     const rootOf = (rows: ReturnType<typeof project>) => rows.nodes.find((n) => n.labels[0] === "Application")!;
     expect(rootOf(a).keyProp).toBe("id");
-    expect(rootOf(a).value).toBe("can://svc-quotes");
-    expect(rootOf(b).value).toBe("can://svc-orders");
+    expect(rootOf(a).value).toBe("can://svc-quotes/svc-quotes");
+    expect(rootOf(b).value).toBe("can://svc-orders/svc-orders");
     expect(rootOf(a).value).not.toBe(rootOf(b).value);
     // The root carries the index anchor, so the prefix-scoped delete can reach its subtree.
     expect(rootOf(a).labels).toContain("TSCanNode");
     // Neither application's prefix reaches the other's nodes.
-    for (const n of b.nodes) expect(n.value.startsWith("can://svc-quotes/")).toBe(false);
+    for (const n of b.nodes) expect(n.value.startsWith("can://svc-quotes/svc-quotes/")).toBe(false);
   });
 
   test("every destructive statement anchors on a marker and a /-terminated prefix", async () => {
     expect(EAGER_PURGE).toMatch(/^MATCH \(n:TSCanNode\) WHERE n\.id STARTS WITH \$prefix/);
     expect(EAGER_PURGE).not.toContain("_module");
     const rows = project((await analyze(opts)).application);
     const cypher = renderCypher(rows, "ps");
     // the snapshot wipe: ONE marker-scoped delete on a /-terminated prefix, then the app by equality
-    expect(cypher).toContain("MATCH (x:TSCanNode) WHERE x.id STARTS WITH 'can://ps/' DETACH DELETE x;");
-    expect(cypher).toContain("MATCH (a:Application {id: 'can://ps'}) DETACH DELETE a;");
+    expect(cypher).toContain("MATCH (x:TSCanNode) WHERE x.id STARTS WITH 'can://ps/ps/' DETACH DELETE x;");
+    expect(cypher).toContain("MATCH (a:Application {id: 'can://ps/ps'}) DETACH DELETE a;");
     expect(cypher).not.toContain("JSCanNode) WHERE");
     // `_module` is in-memory only (#140). Asserted on the property keys, NOT as a substring of the
     // rendered cypher: :TSModule now carries whole-file `source` (#201), and any fixture that says
     // `node_modules` in its text puts the substring `_module` in the output legitimately.
     for (const n of rows.nodes) expect(Object.keys(n.props)).not.toContain("_module");
   });
 });
diff --git a/test/neo4j-schema.test.ts b/test/neo4j-schema.test.ts
index f97854f..c870917 100644
--- a/test/neo4j-schema.test.ts
+++ b/test/neo4j-schema.test.ts
@@ -75,21 +75,21 @@ describe("neo4j schema conformance", () => {
       }
     }
   });
 
   test("TSApplication retains its display name while merging by id", () => {
     const application = rows.nodes.find((node) => node.labels.includes("TSApplication"));
     const declaration = byLabel.get("TSApplication");
 
     expect(application, "TSApplication row").toBeDefined();
     expect(application!.keyProp).toBe("id");
-    expect(application!.value).toBe("can://dataflow-app");
+    expect(application!.value).toBe("can://dataflow-app/dataflow-app");
     expect(application!.props.name).toBe("dataflow-app");
     expect(declaration?.key).toBe("id");
     expect(declaration?.properties.name).toBe("string");
   });
 
   test("every emitted relationship type + property + endpoint is declared", () => {
     for (const edge of rows.edges) {
       const decl = relByType.get(edge.type);
       expect(decl, `undeclared relationship type: ${edge.type}`).toBeDefined();
       expect(mergeLabelsFor(decl!.from).has(edge.from.label), `bad source ${edge.from.label} for ${edge.type}`).toBe(true);
diff --git a/test/schema-v2.test.ts b/test/schema-v2.test.ts
index 1724a0c..e806ed4 100644
--- a/test/schema-v2.test.ts
+++ b/test/schema-v2.test.ts
@@ -83,51 +83,48 @@ function allIds(): string[] {
   }
   return out;
 }
 
 describe("schema v2 — L1 envelope", () => {
   test("root envelope matches the canonical shape", () => {
     expect(v2.schema_version).toBe("2.0.0");
     expect(v2.language).toBe("typescript");
     expect(v2.max_level).toBe(1);
     expect(Object.keys(root).sort()).toEqual([
+      "application_name",
       "artifacts",
       "call_graph",
       "config_reads",
       "config_uses",
       "dependencies",
       "entrypoint_report", // #72 unit 1: level-free coverage report
       "id",
+      "identity_namespace",
+      "identity_version",
       "kind",
       "name",
       "param_in",
       "param_out",
       "symbol_table",
       "unresolved_imports",
     ]);
-    expect(root.id).toBe("can://sample-app");
+    expect(root.id).toBe("can://sample-app/sample-app");
     expect(root.name).toBe("sample-app");
     expect(root.kind).toBe("application");
   });
 
-  test("application name and id share the normalized app-name fallback", async () => {
-    for (const [appName, expected] of [["  logical-name  ", "logical-name"], ["   ", "app"]]) {
-      const named = await run({ appName });
-      const namedRoot = named.application.application;
-      const applicationRow = project(named.application).nodes.find((node) => node.labels.includes("TSApplication"));
-
-      expect(namedRoot.name).toBe(expected);
-      expect(namedRoot.id).toBe(`can://${expected}`);
-      expect(applicationRow?.keyProp).toBe("id");
-      expect(applicationRow?.value).toBe(`can://${expected}`);
-      expect(applicationRow?.props.name).toBe(expected);
-    }
+  test("raw application names are encoded without trimming", async () => {
+    const named = (await run({appName: "  logical-name  "})).application;
+    expect(named.application.name).toBe("  logical-name  ");
+    expect(named.application.id).toBe("can://%20%20logical-name%20%20/%20%20logical-name%20%20");
+    expect(project(named).nodes[0]!.props.identity_version).toBe(2);
+    await expect(run({appName: "   "})).rejects.toThrow();
   });
 
   test("edge lists are empty at L1 (populated at L2/L4)", () => {
     expect(root.call_graph).toEqual([]);
     expect(root.param_in).toEqual([]);
     expect(root.param_out).toEqual([]);
   });
 
   test("symbol_table keys are project-relative POSIX paths", () => {
     for (const key of Object.keys(st)) {
@@ -144,30 +141,30 @@ describe("schema v2 — L1 envelope", () => {
 });
 
 describe("schema v2 — L1 identity", () => {
   test("every can:// id is unique and well-formed", () => {
     const ids = allIds();
     expect(collisions).toEqual([]);
     expect(new Set(ids).size).toBe(ids.length);
     // The grammar gate: application OUTERMOST, language second. Anchored on the app so an id in
     // the sibling `javascript` namespace would still pass the prefix but be caught by the shape.
     for (const id of ids) {
-      expect(id.startsWith("can://sample-app/")).toBe(true);
-      expect(id).toMatch(/^can:\/\/sample-app\/(typescript|javascript)\/.+/);
+      expect(id.startsWith("can://sample-app/sample-app/")).toBe(true);
+      expect(id).toMatch(/^can:\/\/sample-app\/sample-app\/(typescript|javascript)\/.+/);
       expect(id.startsWith("can://typescript/")).toBe(false);
       expect(id.startsWith("can://javascript/")).toBe(false);
     }
   });
 
   test("module ids derive from the file key", () => {
     for (const [key, m] of Object.entries(st) as [string, TSModule][]) {
-      expect(m.id).toBe(`can://sample-app/typescript/${key}`);
+      expect(m.id).toBe(`can://sample-app/sample-app/typescript/${key}`);
       expect(m.kind).toBe("module");
     }
   });
 });
 
 describe("schema v2 — L1 source & spans (get_method_body)", () => {
   test("each module carries its full source", () => {
     for (const m of Object.values(st) as TSModule[]) expect(typeof m.source).toBe("string");
   });
 
diff --git a/test/tagged-templates.test.ts b/test/tagged-templates.test.ts
index 8b5db6a..3b66a6a 100644
--- a/test/tagged-templates.test.ts
+++ b/test/tagged-templates.test.ts
@@ -44,13 +44,13 @@ describe("tagged template calls (#98)", () => {
   });
 
   test("a parameter-default initializer call is attributed to the callable (#98)", () => {
     expect(result.internal.call_graph.some((e) => e.source === "src/x.createRule" && e.target === "src/x.mkSheet")).toBe(true);
   });
 
   test("the tagged call is a body call node with a refined callee", () => {
     const fn = result.application.application.symbol_table["src/x.ts"]?.functions["asCSSUrl"];
     const calls = Object.values(fn?.body ?? {}).filter((b) => b.kind === "call");
     expect(calls.length).toBe(1);
-    expect(calls[0]?.callee).toBe("can://tagged/typescript/src/x.ts/inline");
+    expect(calls[0]?.callee).toBe("can://tagged/tagged/typescript/src/x.ts/inline");
   });
 });
diff --git a/test/workspace-root.test.ts b/test/workspace-root.test.ts
deleted file mode 100644
index 25047b6..0000000
--- a/test/workspace-root.test.ts
+++ /dev/null
@@ -1,190 +0,0 @@
-/**
- * `--workspace-root`: published file keys and the ids built from them are repo-relative.
- *
- * Re-keying happens at emission only: signatures, entrypoint path rules, test-file detection and
- * the cache keep the --input-relative key, so a workspace root changes WHAT a file is called, never
- * WHETHER it is analysed or how it matches. Same semantics as codeanalyzer-java, so a
- * language-neutral artifact id names the same node whichever analyzer emitted it.
- */
-import { describe, expect, test } from "bun:test";
-import * as fs from "node:fs";
-import * as os from "node:os";
-import * as path from "node:path";
-import { InputError, analyze } from "../src/core";
-import type { AnalysisOptions } from "../src/options";
-import { project } from "../src/build/neo4j";
-import { forEachCallable, type TSAnalysis, type TSApplication } from "../src/schema";
-import { loadCache } from "../src/utils";
-
-const ROOT = path.resolve(import.meta.dir, "..");
-const FIXTURES = path.resolve(import.meta.dir, "fixtures");
-
-/**
- * A repository whose path ABOVE --input holds a `test` segment: discovery's test-tree skip must
- * judge the --input-relative key, or every file here would read as a test and vanish.
- */
-function repoWith(fixture: string): { repo: string; input: string; prefix: string } {
-  const repo = fs.mkdtempSync(path.join(os.tmpdir(), "cants-219-"));
-  const rel = "test/services/app";
-  const input = path.join(repo, rel);
-  fs.cpSync(path.join(FIXTURES, fixture), input, { recursive: true });
-  return { repo, input, prefix: `${rel}/` };
-}
-
-function options(input: string, over: Partial<AnalysisOptions> = {}): AnalysisOptions {
-  return {
-    input, output: null, emit: "json", appName: "app", neo4jUri: null, neo4jUser: "neo4j",
-    neo4jPassword: "", neo4jDatabase: null, analysisLevel: 1, graphs: ["cfg", "dfg", "pdg", "sdg"], graphFieldDepth: 3, jobs: 1,
-    targetFiles: null, skipTests: true, eager: true, noBuild: true, phantoms: true,
-    cacheDir: fs.mkdtempSync(path.join(os.tmpdir(), "cants-219-cache-")), verbosity: 0,
-    workspaceRoot: null, ...over,
-  } as AnalysisOptions;
-}
-
-/** Every `can://app/...` id in a payload, wherever it sits. */
-function idsIn(json: string): string[] {
-  return [...json.matchAll(/"(can:\/\/app\/[^"]*)"/g)].map((m) => m[1]!);
-}
-
-function cli(args: string[]): { code: number; stderr: string } {
-  const p = Bun.spawnSync(["bun", "run", path.join(ROOT, "src/index.ts"), ...args], { cwd: ROOT, stdout: "pipe", stderr: "pipe" });
-  return { code: p.exitCode, stderr: p.stderr.toString() };
-}
-
-describe("--workspace-root", () => {
-  test("symbol_table keys, module ids and every code id below them are repo-relative, through L3", async () => {
-    const { repo, input, prefix } = repoWith("dataflow-app");
-    const without = (await analyze(options(input, { analysisLevel: 3 }))).application.application;
-    const r = await analyze(options(input, { analysisLevel: 3, workspaceRoot: repo }));
-    const app = r.application.application;
-
-    expect(app.id).toBe("can://app"); // the app segment does not move
-    const keys = Object.keys(app.symbol_table);
-    expect(keys.length).toBe(Object.keys(without.symbol_table).length); // nothing lost to the test-dir skip
-    for (const k of keys) {
-      expect(k.startsWith(prefix)).toBe(true);
-      expect(k.startsWith("/") || k.includes("..")).toBe(false);
-      expect(app.symbol_table[k]!.id).toBe(`can://app/typescript/${k}`);
-    }
-    for (const k of Object.keys(without.symbol_table)) expect(app.symbol_table[prefix + k]).toBeDefined();
-
-    const json = JSON.stringify(app);
-    const ids = idsIn(json).filter((id) => /^can:\/\/app\/(typescript|javascript)\//.test(id));
-    expect(ids.length).toBeGreaterThan(0);
-    for (const id of ids) expect(id).toMatch(new RegExp(`^can://app/(typescript|javascript)/${prefix}`));
-    expect(json).toContain('"cfg"'); // L3 overlays rode along
-
-    expect(app.call_graph.length).toBe(without.call_graph.length);
-    for (const e of app.call_graph) expect(e.src.includes(`/${prefix}`)).toBe(true);
-  });
-
-  test("resolved_module names a published symbol_table key, so internal import edges survive", async () => {
-    const { repo, input, prefix } = repoWith("sample-app");
-    const bindings = (a: TSApplication) =>
-      Object.values(a.symbol_table).flatMap((m) => [...(m.imports ?? []), ...(m.exports ?? [])]);
-    const internalImports = (a: TSAnalysis) =>
-      project(a).edges.filter((e) => (e.type === "TS_IMPORTS" || e.type === "TS_RE_EXPORTS") && e.to.label !== "TSExternal").length;
-    const without = (await analyze(options(input))).application;
-    const rooted = (await analyze(options(input, { workspaceRoot: repo }))).application;
-
-    const resolved = bindings(rooted.application).map((b) => b.resolved_module).filter((k) => k !== undefined);
-    expect(resolved.length).toBeGreaterThan(0);
-    for (const k of resolved) {
-      expect(k.startsWith(prefix)).toBe(true);
-      expect(rooted.application.symbol_table[k]).toBeDefined();
-    }
-    expect(internalImports(without)).toBeGreaterThan(0);
-    expect(internalImports(rooted)).toBe(internalImports(without));
-  });
-
-  test("signatures stay --input-relative: the re-key is the published name, not the analysis", async () => {
-    const { repo, input } = repoWith("sample-app");
-    const a = (await analyze(options(input))).application.application;
-    const b = (await analyze(options(input, { workspaceRoot: repo }))).application.application;
-    const sigs = (app: typeof a) =>
-      Object.values(app.symbol_table).flatMap((m) => Object.values(m.functions ?? {}).map((f) => f.signature)).sort();
-    expect(sigs(b)).toEqual(sigs(a));
-  });
-
-  test("entrypoint path rules still match against the --input-relative key", async () => {
-    // A Next.js route file: the shipped rule `app/**/route.{ts,...}` is matched against the
-    // --input-relative key, so the prefix above it must not stop it matching.
-    const { repo, input, prefix } = repoWith("sample-app");
-    // The Next.js rules are gated on `next` being a declared dependency.
-    const pkg = JSON.parse(fs.readFileSync(path.join(input, "package.json"), "utf8"));
-    fs.writeFileSync(path.join(input, "package.json"), JSON.stringify({ ...pkg, dependencies: { next: "14.0.0" } }));
-    const route = path.join(input, "app/api/hello/route.ts");
-    fs.mkdirSync(path.dirname(route), { recursive: true });
-    fs.writeFileSync(route, "export async function GET() { return new Response('hi'); }\n");
-    const get = (app: TSApplication, key: string) => {
-      let found: unknown[] | undefined;
-      forEachCallable(app.symbol_table[key]!, (c) => { if (c.name === "GET") found = c.entrypoints ?? []; });
-      return found;
-    };
-    const a = (await analyze(options(input))).application.application;
-    const b = (await analyze(options(input, { workspaceRoot: repo }))).application.application;
-    const expected = { rule: "nextjs.app-route", evidence: "app/api/hello/route.ts", route: "/api/hello" };
-    expect(get(a, "app/api/hello/route.ts")?.[0]).toMatchObject(expected); // precondition: the rule fires
-    expect(get(b, `${prefix}app/api/hello/route.ts`)?.[0]).toMatchObject(expected);
-  });
-
-  test("artifact keys, paths and ids are prefixed; classification and extraction are unchanged", async () => {
-    const { repo, input, prefix } = repoWith("artifacts-app");
-    const a = (await analyze(options(input))).application.application;
-    const b = (await analyze(options(input, { workspaceRoot: repo }))).application.application;
-
-    expect(Object.keys(b.artifacts).sort()).toEqual(Object.keys(a.artifacts).map((k) => prefix + k).sort());
-    for (const [k, art] of Object.entries(a.artifacts)) {
-      const moved = b.artifacts[prefix + k]!;
-      expect(moved.path).toBe(prefix + k);
-      expect(moved.id).toBe(`can://app/artifact/${prefix}${k}`);
-      expect(moved.format).toBe(art.format);
-      expect(moved.roles).toEqual(art.roles);
-      expect(moved.config_keys.length).toBe(art.config_keys.length);
-      for (const ck of moved.config_keys) expect(ck.id.startsWith(moved.id)).toBe(true);
-    }
-    expect(b.dependencies.length).toBe(a.dependencies.length);
-    for (const d of b.dependencies) expect(d.declared_in.startsWith(`can://app/artifact/${prefix}`)).toBe(true);
-  });
-
-  test("the cache stays --input-relative, so toggling the flag reuses it", async () => {
-    const { repo, input, prefix } = repoWith("sample-app");
-    const cacheDir = fs.mkdtempSync(path.join(os.tmpdir(), "cants-219-shared-"));
-    const plain = (await analyze(options(input, { cacheDir }))).application.application;
-    const cachedKeys = () => Object.keys(loadCache(cacheDir)!.symbol_table).sort();
-    const before = cachedKeys();
-    const moved = (await analyze(options(input, { cacheDir, eager: false, workspaceRoot: repo }))).application.application;
-    expect(cachedKeys()).toEqual(before); // no prefixed key written into the cache
-    for (const k of before) expect(k.startsWith(prefix)).toBe(false);
-    expect(Object.keys(moved.symbol_table).sort()).toEqual(Object.keys(plain.symbol_table).map((k) => prefix + k).sort());
-  });
-
-  test("a workspace root equal to --input changes nothing", async () => {
-    const { input } = repoWith("artifacts-app");
-    const a = (await analyze(options(input))).application;
-    const b = (await analyze(options(input, { workspaceRoot: input }))).application;
-    expect(JSON.stringify(b)).toBe(JSON.stringify(a));
-  });
-
-  test("an --input outside the workspace root is an InputError naming both", async () => {
-    const { input } = repoWith("sample-app");
-    const elsewhere = fs.mkdtempSync(path.join(os.tmpdir(), "cants-219-elsewhere-"));
-    const run = analyze(options(input, { workspaceRoot: elsewhere }));
-    await expect(run).rejects.toBeInstanceOf(InputError);
-    await expect(analyze(options(input, { workspaceRoot: elsewhere }))).rejects.toThrow(elsewhere);
-  });
-
-  test("CLI: the flag reaches the analysis, and an outside input exits 1 writing nothing", () => {
-    const { repo, input, prefix } = repoWith("sample-app");
-    const out = path.join(repo, "out");
-    expect(cli(["-i", input, "-o", out, "--no-build", "--app-name", "app", "--workspace-root", repo]).code).toBe(0);
-    const j = JSON.parse(fs.readFileSync(path.join(out, "analysis.json"), "utf8"));
-    for (const k of Object.keys(j.application.symbol_table)) expect(k.startsWith(prefix)).toBe(true);
-
-    const bad = path.join(repo, "bad-out");
-    const r = cli(["-i", input, "-o", bad, "--no-build", "--workspace-root", path.join(repo, "nope")]);
-    expect(r.code).toBe(1);
-    expect(r.stderr).toContain("--workspace-root");
-    expect(fs.existsSync(path.join(bad, "analysis.json"))).toBe(false);
-  });
-});
# codeanalyzer-typescript: dbb5ccdcad46f5ce9c39e279297cf535579907d0..fcc9529a932bc40a6be426fb85298237e19ffe65
