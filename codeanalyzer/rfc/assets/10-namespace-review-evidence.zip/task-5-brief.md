### Task 5: Apply the same contract to Go

**Files:**
- Modify: `codeanalyzer-go/cmd/codeanalyzer/{main.go,main_test.go}` and `internal/options/options.go`.
- Modify: `codeanalyzer-go/internal/schema/v2/{ids.go,ids_test.go,schema.go}`.
- Modify: `codeanalyzer-go/internal/syntactic_analysis/v2emit/emit.go`, `emit_l3.go`, `emit_l4.go` and `internal/neo4j/{project.go,rows.go,schema.go,cypher.go}` as needed for propagated IDs/metadata.
- Extend: `internal/syntactic_analysis/v2emit/emit_test.go`, `internal/neo4j/{project_test.go,schema_test.go}` and `README.md` in that repo.

**Interfaces:**
- Consumes: Task 1 fixture and Go identity interfaces above.
- Produces: `Options.Namespace *string`, CLI presence-aware namespace resolution, canonical JSON/graph endpoints, marker and raw scope metadata.

- [ ] **Step 1: Write failing tests.** Add `TestResolveIdentityFixtures`, `TestNamespaceExplicitEmptyRejected`, and CLI emission tests for explicit/default scope. Test invalid UTF-8 as an error and verify nested body/external/artifact IDs use the application root.
- [ ] **Step 2: Verify failure.** Run `go test ./internal/schema/v2 ./cmd/codeanalyzer` from `codeanalyzer-go`.
- [ ] **Step 3: Implement Go inputs/identity propagation.** Resolve default app names before namespace; pass the resolved identity into `v2emit.Emit` through a named identity parameter instead of inserting a namespace into an existing string argument. Update all Emit callers and graph anchor/version fields. Module and ordinal builders continue accepting canonical parent IDs.
- [ ] **Step 4: Verify.** Run `go test ./internal/schema/v2 ./internal/syntactic_analysis/v2emit ./internal/neo4j ./cmd/codeanalyzer`, then `go test ./...`. Run Go formatting on changed Go files.
- [ ] **Step 5: Commit on the companion branch.** Use `feat: qualify Go analysis identities by namespace`.

