# Task 5 fix round 1 independent review

Scope: only the two previous findings and breakage introduced by `8fabbf69a11c2c3a338ee60577ca300c52280165..f62c3ec5df679858add19694c3c37d88c8037e30`. Reviewed the supplied fix package and report fix section; companion HEAD matches the fix commit. No suites rerun, Git mutation, or subagents.

1. **Filesystem prevalidation: ADDRESSED.** `internal/core/analyzer.go:346` resolves identity at the start of `WriteOutput`, before `EnsureDir`, temporary-file creation, or streaming. The new regression checks both a nonexistent nested destination and an existing protected file, including directory contents.

2. **Persisted site/context edge facts: ADDRESSED.** Both snapshot and Bolt MERGE now include the same private `_fact` digest, computed by the shared helper from canonical JSON of pruned properties. Existing `_k` values remain independent MERGE components. Thus the previously collapsing same-endpoint/type/key rows with different site/context properties receive different relationship identities. Tests exercise keyed/unkeyed forms, equal-site/different-context cases, original-key preservation, agreement between snapshot and recorded Bolt parameters, and reversed-input determinism. Schema vocabulary/document and README declare the discriminator. This follows the controller-approved private property design without changing public URI grammar or identity version.

New breakage found in the fix diff: **none**.

Spec verdict: **PASS for this scoped fix**. Quality verdict: **PASS for this scoped fix**.

Verification evidence: the report records the targeted RED failures and subsequent GREEN regressions, plus **175 passing test/subtest events across core and Neo4j**, zero failures, formatting and diff checks. These results were reviewed as reported evidence rather than rerun. Live Neo4j integration remains unrun because Docker is unavailable; no broader re-review was performed.
