Implement namespace/application-qualified identity in codeanalyzer-java so services with overlapping local file keys retain distinct owners.

Repurpose existing [workspace-root PR #275](https://github.com/codellm-devkit/codeanalyzer-java/pull/275): remove its unmerged `--workspace-root` option/setting and preserve unrelated artifact reconciliation fixes.

## Namespace identity contract

Application-owned IDs use `can://<namespace>/<application>/<existing-language-and-entity-suffix>`. An omitted application name defaults to the selected input root basename; an omitted namespace defaults to the resolved application name. Thus `inventory` emits `can://inventory/inventory`, while currencyservice in online-boutique emits `can://online-boutique/currencyservice/javascript/server.js`. Both root segments remain present.

Root inputs are case-sensitive raw strings: encode UTF-8 bytes outside ASCII letters/digits/`-._~` with uppercase percent escapes, without trimming or Unicode normalization. Reject empty/whitespace-only names, controls, unpaired surrogates, slash/backslash, and whole-name `.`/`..`. For example application `a%b`, namespace `team space` yields `can://team%20space/a%25b`.

Require integer `identity_version: 2` in existing analysis envelopes and application anchors, while preserving `schema_version: "2.0.0"`. Retain raw `application_name` and `identity_namespace` on application records. Keep language suffixes, input-relative file keys, and `pkg:` identities unchanged. Qualify all embedded application-owned references; include namespace in cache identity; reject incompatible outputs read-only and regenerate from source without aliases or ID translation.

## Acceptance

- Add the namespace option and preserve explicit app-name/default behavior; distinguish omitted namespace from explicit empty input.
- Qualify JSON and Neo4j entities, embedded references, and application-scoped cleanup consistently.
- Add self-contained checked-in golden fixtures covering defaults, percent encoding, Unicode, case distinctions, invalid inputs, and duplicate canonical module rows.
- Verify unchanged language/entity suffixes and application-relative file keys, namespace cache separation, and marker enforcement.
- Coordinate SDK consumption with compatible producer outputs; no release modeling, alias migration, or new source mapping API is included.
