e35d7dca feat: qualify Java analysis identities by namespace
 README.md                                          |  52 +++---
 docs/design/specs/2026-10-24-workspace-root.md     | 205 +++------------------
 schema.neo4j.json                                  |   3 +
 src/main/java/com/ibm/cldk/CodeAnalyzer.java       |  50 +++--
 .../com/ibm/cldk/artifacts/ArtifactDiscovery.java  |  15 +-
 .../java/com/ibm/cldk/artifacts/ConfigUses.java    |   9 +-
 .../com/ibm/cldk/artifacts/ViewDispatches.java     |   7 +-
 src/main/java/com/ibm/cldk/neo4j/BoltWriter.java   |  87 +++++----
 src/main/java/com/ibm/cldk/neo4j/CypherWriter.java |  87 ++-------
 src/main/java/com/ibm/cldk/neo4j/RowBuilder.java   |  25 ++-
 .../java/com/ibm/cldk/neo4j/V2GraphProjector.java  |  14 +-
 .../java/com/ibm/cldk/neo4j/V2SchemaCatalog.java   |   3 +-
 src/main/java/com/ibm/cldk/schema/Analysis.java    |   1 +
 src/main/java/com/ibm/cldk/schema/CanId.java       |  63 ++++++-
 .../java/com/ibm/cldk/schema/JApplication.java     |   2 +
 src/main/java/com/ibm/cldk/schema/V2Emitter.java   |  13 +-
 .../com/ibm/cldk/syntactic_analysis/L1Cache.java   |   4 +-
 .../ibm/cldk/syntactic_analysis/L1Extractor.java   |  15 +-
 .../ibm/cldk/syntactic_analysis/L2CallGraph.java   |   8 +-
 .../java/com/ibm/cldk/CodeAnalyzerV2CliTest.java   | 114 +++++++++---
 src/test/java/com/ibm/cldk/L3WalaOverlaysTest.java |   2 +-
 .../com/ibm/cldk/WorkspaceRootNeo4jPushTest.java   |  73 ++++----
 .../com/ibm/cldk/neo4j/BoltWriterPurgeTest.java    |  46 +++--
 .../ibm/cldk/neo4j/CanonicalIdentityRowsTest.java  |  49 +++++
 .../ibm/cldk/neo4j/CypherWriterStreamingTest.java  |  12 +-
 .../cldk/neo4j/V2Neo4jSchemaConformanceTest.java   |   8 +-
 src/test/java/com/ibm/cldk/schema/CanIdTest.java   |  41 ++++-
 .../com/ibm/cldk/schema/L2SchemaOracleTest.java    |   2 +
 .../com/ibm/cldk/schema/L3SchemaOracleTest.java    |   2 +
 .../com/ibm/cldk/schema/L4SchemaOracleTest.java    |   2 +
 src/test/java/com/ibm/cldk/schema/V2JsonTest.java  |  13 ++
 .../ibm/cldk/syntactic_analysis/L1CacheTest.java   |  10 +
 src/test/resources/schema/analysis.v2.schema.json  |  15 +-
 33 files changed, 556 insertions(+), 496 deletions(-)
diff --git a/README.md b/README.md
index ad332c9e..82d210af 100644
--- a/README.md
+++ b/README.md
@@ -119,67 +119,70 @@ Run the Gradle wrapper script to build the project. This will compile the projec
 
 ### 2.3. Using `codeanalyzer`
 
 The jar will be built at `build/libs/codeanalyzer-<version>.jar`. It may be used as follows:
 
 ```help
 Usage: codeanalyzer [-hvV] [--no-build] [--no-clean-dependencies]
                     [-a=<analysisLevel>] [-b=<build>] [-f=<projectRootPom>]
                     [-i=<input>] [-o=<output>] [-s=<sourceAnalysis>]
                     [--emit=<emit>] [--app-name=<appName>]
-                    [--workspace-root=<dir>]
+                    [--namespace=<namespace>]
                     [--neo4j-uri=<uri>] [--neo4j-user=<user>]
                     [--neo4j-password=<password>] [--neo4j-database=<db>]
                     [-t=<targetFiles>]...
 Analyze java application.
   -i, --input=<input>        Path to the project root directory.
   -s, --source-analysis=<s>  Analyze a single string of java source code instead
                                of the project.
   -o, --output=<output>      Destination directory to save the output graphs. By
                                default, the analysis JSON is printed to the console.
   -b, --build-cmd=<build>    Custom build command. Defaults to auto build.
       --no-build             Do not build your application (use if already built).
   -a, --analysis-level=<n>   Level of analysis: 1 (symbol table) or 2 (call graph).
                                Default: 1. Level 2 adds J_CALLS edges to the graph.
   -t, --target-files=<f>...  Restrict analysis to specific files (incremental).
       --emit=<emit>          Output target: json (analysis.json, default) |
                                neo4j (graph.cypher or live Bolt push) |
                                schema (the Neo4j schema.neo4j.json contract).
       --app-name=<name>      Logical application name for the graph :JApplication
                                anchor (default: input dir name).
-      --workspace-root=<dir> Directory that file keys, module ids and artifact
-                               ids are relative to (default: --input). Must
-                               contain --input. Not supported with --schema v1.
+      --namespace=<name>     Identity namespace (defaults to application name).
       --neo4j-uri=<uri>      Push the graph to a live Neo4j over Bolt (incremental);
                                omit to write graph.cypher. Falls back to the
                                NEO4J_URI environment variable.
       --neo4j-user=<user>    Neo4j username (env: NEO4J_USERNAME, default: neo4j).
       --neo4j-password=<pw>  Neo4j password (env: NEO4J_PASSWORD, default: neo4j).
       --neo4j-database=<db>  Neo4j database name (env: NEO4J_DATABASE, default:
                                server default).
   -v, --verbose              Print logs to console.
   -h, --help                 Show this help message and exit.
   -V, --version              Print version information and exit.
 ```
 
-**Repository-relative paths.** By default, `symbol_table` keys and the ids built from them are relative to
-`--input`. When the project sits inside a larger repository, pass `--workspace-root` to make them
-repository-relative instead:
+**Application identity.** `--app-name` defaults to the basename of `--input` and `--namespace`
+defaults to the resolved application name. The canonical root always contains both segments:
+`can://<namespace>/<application>`, including `can://inventory/inventory` for a default monolith.
+Names are case-sensitive raw strings encoded as UTF-8 URI segments without trimming or Unicode
+normalization. Explicit empty/whitespace-only names, controls, unpaired surrogates, slashes,
+backslashes, `.` and `..` are rejected. `--namespace` is unavailable with `--schema v1`.
 
 ```bash
-codeanalyzer -i monorepo/services/orders --workspace-root monorepo
-# symbol_table key: services/orders/src/main/java/com/acme/Order.java
+codeanalyzer -i monorepo/services/orders --app-name orders --namespace commerce
+# root: can://commerce/orders
+# symbol_table key: src/main/java/com/acme/Order.java
 ```
 
-Only the path part of ids changes. The application id (`can://<app-name>`) stays the same. Keys
-change when you toggle the flag, so a `--cache-dir` written without it is not reused by a run with
-it, and the other way round.
+File and artifact keys remain relative to `--input`. The draft `--workspace-root` option has
+been removed. Analysis envelopes and graph application anchors carry `identity_version: 2`;
+anchors also retain raw `application_name` and `identity_namespace`. Namespace changes invalidate
+the L1 cache. Legacy outputs must be regenerated from source; retire legacy graph data explicitly.
 
 
 ## 3. Installing `codeanalyzer` as a native binary (once built, no JVM will be required for running `codeanalyzer`)
 
 To install `codeanalyzer`, follow these steps:
 
 ### 3.1. Install GraalVM using SDKMan
 
 1. You can list all available GraalVM versions with:
 
@@ -251,37 +254,36 @@ comments are `:JComment` nodes in addition to the convenience `docstring` proper
 The full contract (node labels, their keys and typed properties, relationship types and endpoints,
 plus the constraint/index DDL) lives in [`schema.neo4j.json`](./schema.neo4j.json) and is visualized
 in [`neo4j-schema.drawio`](./neo4j-schema.drawio). Java-specific node labels are `J`-prefixed and
 relationship types `J_`-prefixed (e.g. `:JType`, `:JCallable`, `J_CALLS`) so a Java graph can share a
 Neo4j database with another language's backend without colliding. The exceptions are deliberate:
 `:Artifact`, `:Package` and `:ConfigKey` and their containment edges carry **no** prefix, because a
 build manifest or a configuration key is not a Java concept — a sibling-language analyzer scanning
 the same repository lands on the same nodes instead of a per-language duplicate.
 `SCHEMA_VERSION` is stamped onto the `:JApplication` node of every emitted graph.
 
-Every node id starts with `can://<app>/` — `can://<app>/java/…` for code, `can://<app>/artifact/…`
-for build manifests and config keys, `can://<app>/@external/…` for library symbols — so
-`can://<app>` is a prefix of every node the application emits, which is what the destructive
+Every node id starts with `can://<namespace>/<app>/` — `can://<namespace>/<app>/java/…` for code, `can://<namespace>/<app>/artifact/…`
+for build manifests and config keys, `can://<namespace>/<app>/@external/…` for library symbols — so
+`can://<namespace>/<app>` is a prefix of every node the application emits, which is what the destructive
 statements scope on. (`:Package` is the exception: it is keyed on a `pkg:` purl, sits under no
 application, and no wipe reaches it.) `:JApplication` is keyed on that id, not on the free-text
 `--app-name`, so the root is addressable by the same id its descendants are prefixed with. The id
-is derived from `--app-name` (`can://<app-name>`), so it does
-**not** disambiguate two services analyzed under the same name — those still merge onto one root.
-Give each service its own `--app-name` if they share a database.
+is derived from the pair (`--namespace`, `--app-name`). Services with the same raw application name
+remain distinct in different namespaces. Services selecting the same pair merge onto the same root.
 
 **Polyglot ids.** The `/java/` segment is what makes a code node this analyzer's. Three id families
 deliberately omit it and are therefore **language-neutral, shared merge targets**: `:Artifact`,
 `:ConfigKey` and `@external` symbols. A sibling analyzer over the same `<app>` mints byte-identical
 ids for them, so a `pom.xml`, a config key or `java.util.Map#get` is *one* node in a merged graph
 rather than a per-language duplicate. That sharing is the point, and its cost is accepted: two
 analyzers' notions of a library symbol are not necessarily the same thing, and merging them says
-they are. The consequence for writes: because these shared nodes sit inside `can://<app>/`, a Cypher
+they are. The consequence for writes: because these shared nodes sit inside `can://<namespace>/<app>/`, a Cypher
 snapshot's prefix wipe rebuilds them, so a cross-language edge into a shared `:Artifact` is dropped
 by one analyzer's snapshot and restored on the other's next push.
 
 **Configuration reads.** `DEFINES_CONFIG` says which artifact declares a key; `J_USES_CONFIG` says
 which code reads one. Its source is whichever node the read was attributed to — a `:JBodyNode` for
 a call site (`System.getenv("X")`, `env.getProperty("X")`), or the `:JField` / `:JCallable` /
 `:JType` carrying a `@Value("${x}")` or `@ConfigurationProperties` annotation — so a consumer must
 not assume it is always a body node. A read that matched no declared key is kept as
 `J_READS_CONFIG_UNRESOLVED` rather than dropped, so a read nobody can trace stays as visible as one
 that resolves. The literal tier runs at every level; `-a 3` and `-a 4` widen it over the dataflow
@@ -307,51 +309,51 @@ under-approximates by design, so an empty `frameworks_detected` next to a popula
 what distinguishes "this application has no entrypoints" from "the pass found nothing".
 
 ### 4.1. Cypher snapshot (no database required)
 
 ```sh
 codeanalyzer -i /path/to/project -a 2 --emit neo4j -o ./out
 # → writes ./out/graph.cypher  (a self-contained, re-runnable script)
 cypher-shell -u neo4j -p <password> < ./out/graph.cypher
 ```
 
-The snapshot is **not** incremental: it constraints, scopes-wipes this application's prior subgraph,
-then `UNWIND … MERGE`-loads the full truth. The wipe is everything under `can://<app>/`, plus a
-containment traversal that also replaces a prior v1 (pre-`3.0.0`) graph of the same application.
+Offline snapshots validate incoming identity metadata; they do not inspect an existing database. Execute them only as part of explicit regeneration. The snapshot is **not** incremental: it constraints, scopes-wipes this application's prior subgraph,
+then `UNWIND … MERGE`-loads the full truth. The wipe is everything under `can://<namespace>/<app>/`, plus a
+containment traversal scoped to the selected canonical application. Legacy roots are not retired automatically.
 That scope **includes** this application's `:Artifact` and `:ConfigKey` nodes — the snapshot rebuilds
 them, rather than leaving stale ones to accumulate with nothing ever cleaning them up. The one
 consequence: a sibling-language analyzer's edge into a shared `:Artifact` is dropped by a Java
 snapshot and restored on that analyzer's next push. The Bolt writer is narrower; see §4.2.
 
 ### 4.2. Live incremental push over Bolt
 
 ```sh
 codeanalyzer -i /path/to/project -a 2 --emit neo4j \
   --neo4j-uri bolt://localhost:7687 --neo4j-user neo4j --neo4j-password <password>
 ```
 
-The Bolt writer reads the database's current state and updates **only what changed**: it diffs each
+The Bolt writer checks the selected existing anchor's identity marker and raw names before DDL or writes, then updates **only what changed**: it diffs each
 compilation unit's `content_hash`, replaces just the changed units' subgraphs (idempotent
 `MERGE` upserts), and — on a full run — prunes units whose source file vanished. Combine with
 `--target-files` for a targeted, partial re-push (orphan pruning is then skipped).
 
 On a full run it also reconciles the application's artifacts, so a deleted or renamed file, a
-removed dependency, or re-keying under `--workspace-root` leaves nothing stale:
+or removed dependency leaves nothing stale within the selected namespace/application:
 
 - Java-owned artifact edges are rebuilt from the run: `HAS_ARTIFACT`, `DECLARES_DEPENDENCY`/`LOCKS`
   to `pkg:maven/…`, and code reads of them (`J_USES_CONFIG`, `J_DISPATCHES_TO`,
   `J_READS_CONFIG_UNRESOLVED`), so a config-only change updates them too.
 - An `:Artifact`/`:ConfigKey` the run no longer emits loses its `:JCanNode` label. An artifact is
   then deleted only if no other analyzer's `HAS_ARTIFACT` still points at it; a config key only if
   no other analyzer's marker (`:PyCanNode`, `:TSCanNode`) still claims it. A sibling's edges are
   never removed.
-- Artifacts written before 3.1.1 (`can://artifact/<app>/…`) are reconciled the same way.
+- Legacy artifacts require explicit retirement; reconciliation never falls back to a legacy root.
 
 ### 4.3. Schema contract
 
 ```sh
 codeanalyzer --emit schema -o ./out   # → ./out/schema.neo4j.json (no project analysis needed)
 codeanalyzer --emit schema            # → prints the contract to stdout
 ```
 
 ### 4.4. Verifying the writers
 
diff --git a/docs/design/specs/2026-10-24-workspace-root.md b/docs/design/specs/2026-10-24-workspace-root.md
index 8c9f792e..6dbf1244 100644
--- a/docs/design/specs/2026-10-24-workspace-root.md
+++ b/docs/design/specs/2026-10-24-workspace-root.md
@@ -1,177 +1,28 @@
-# `--workspace-root`: repo-relative file keys
-
-**Status:** accepted · 2026-10-24 · tracks [#274](https://github.com/codellm-devkit/codeanalyzer-java/issues/274)
-
-## Problem
-
-Every v2 file key is relative to `--input`. When the analyzed project sits inside a larger
-repository (`services/orders/` in a monorepo), keys read `src/main/java/.../App.java` rather than
-the repository path `services/orders/src/main/java/.../App.java`. Tooling that speaks repository
-paths — git, IDEs, PR diffs, scanners — cannot join on them without knowing and re-adding the
-prefix.
-
-## Contract-impact triage
-
-| Question | Answer |
-| --- | --- |
-| Changes `analysis.json` v2 shape? | No. No node, edge or field is added, removed or renamed. |
-| Changes v2 id/key meaning? | Yes, opt-in: with `--workspace-root` the `<file>` segment is relative to the workspace root instead of `--input`. Default output is byte-identical. |
-| Changes CLI? | Yes — one new optional flag. Additive → **minor, 3.4.0**. |
-| Repos touched | `codeanalyzer-java` (this spec's PR). |
-
-## Decisions (user-approved 2026-10-24)
-
-1. **New optional flag `--workspace-root <dir>`.** When set, every path-derived v2 key is computed
-   relative to it rather than to `--input`:
-   - `application.symbol_table` keys (`L1Extractor.fileKey`);
-   - `module.id` and every durable id below it (`can://<app>/java/<file>/…`), since they are built
-     from the file key;
-   - artifact keys and ids (`can://<app>/artifact/<rel>`, `ArtifactDiscovery`).
-
-   Unset, behavior is unchanged: the root is `--input`.
-2. **The app segment does not move.** `can://<app>` stays `--app-name`, else the `--input`
-   directory name. Only the `<file>` segment changes, so the L1 cache key, the Neo4j `can://<app>/`
-   prefix wipe/prune and `@external` ids keep their current scoping.
-3. **`--input` must be inside the workspace root.** Both are resolved to absolute, normalized
-   paths; if `--input` is not the root or a descendant of it, exit non-zero at argument validation.
-   This keeps the schema invariant intact: keys are relative, never absolute, never `..`.
-4. **v2 only.** v1 keys are absolute paths, so there is nothing to relativize. `--workspace-root`
-   with `--schema v1` is a hard argument error.
-5. **No new schema field.** Consumers read source text from `module.source` and never resolve a
-   key against the filesystem, so the output need not record which root keys are relative to.
-6. **Language-neutral semantics.** Artifact and `@external` ids are deliberately shared across
-   sibling analyzers over the same `<app>`. Sibling analyzers that adopt a workspace root are
-   expected to use these same semantics (decisions 1–4), so a repository-relative artifact id is
-   the same node whichever analyzer emitted it.
-
-## Implementation notes
-
-- Thread one `keyRoot` path (workspace root if set, else `--input`) to the two relativization
-  sites: `L1Extractor.fileKey` (via `extractAll`) and `ArtifactDiscovery.discover`. Source
-  discovery, builds and dependency download still run against `--input`.
-- `CanId.moduleId` strips leading `[./]+` from the key. Decision 3 makes `..` keys unreachable;
-  pin that with a test rather than relying on the strip.
-- `L3WalaOverlays.deriveApplicationId` recovers the app id by stripping the file key off a module
-  id; it is key-shape agnostic, but cover it with a nested-root fixture.
-- Incremental cache: keys change when the flag is toggled, so a cache written without the flag
-  simply misses for a run with it. No migration; document it.
-
-## Verification
-
-- Unit: nested fixture (`<tmp>/repo/services/app/…`) run with `--workspace-root <tmp>/repo` —
-  every `symbol_table` key, module id and artifact id starts with `services/app/`; no key is
-  absolute or contains `..`.
-- Unit: without the flag, output is byte-identical to today's.
-- CLI: `--input` outside the root → non-zero exit with a clear message; `--workspace-root` with
-  `--schema v1` → non-zero exit.
-- L2/L3 on the nested fixture: call-graph `src`/`dst` and L3 overlay ids carry the same
-  repo-relative module ids.
-- Neo4j: an incremental push with the flag wipes/prunes only that app's nodes.
-
-## Release plan
-
-Ships in **codeanalyzer-java 3.4.0** as an opt-in flag; default output is unchanged, so no
-consumer needs to move in lockstep. README documents the flag, the repo-relative keys it produces,
-and the cache miss on toggling it.
-
-## Addendum: Bolt artifact reconciliation (user-approved 2026-10-28)
-
-### Problem
-
-The Bolt writer never deletes an `:Artifact` or `:ConfigKey`. They carry no `_module`, so they
-are treated as shared nodes: MERGE-upserted, never purged. Toggling `--workspace-root` on an app
-that already has a graph changes every artifact id (`can://<app>/artifact/pom.xml` becomes
-`can://<app>/artifact/services/app/pom.xml`), so the old-keyed artifacts survive alongside the
-new ones. Each still hangs off `:JApplication` via `HAS_ARTIFACT` and still declares its
-`:Package`s. The same leak exists without the flag, for any deleted or renamed artifact, and
-for the outgoing edges of an artifact whose content changed (a dependency removed from
-`pom.xml` keeps its `DECLARES_DEPENDENCY` edge; a removed yaml key keeps its `:ConfigKey`).
-The Cypher snapshot does not have this problem, because its `can://<app>/` prefix wipe
-rebuilds artifacts from scratch.
-
-### Triage
-
-| Question | Answer |
-| --- | --- |
-| Changes `analysis.json` / `schema.neo4j.json` shape? | No. Write semantics only. |
-| Changes cross-analyzer graph semantics? | Yes, narrowly: a Java Bolt full run now removes Java's own claim on artifacts and config keys it no longer emits, and deletes a node only when no other analyzer claims it. Sibling-owned nodes and edges are never touched. |
-| Repos touched | `codeanalyzer-java` now. `codeanalyzer-python` (`neo4j/bolt.py`) and `codeanalyzer-typescript` (`build/neo4j/bolt.ts`) have the same gap; tracked, filed when picked up. |
-
-### Ownership: what is Java's
-
-The artifact layer's vocabulary is shared (`:Artifact`, `:ConfigKey`, `:Package`,
-`HAS_ARTIFACT`, `DEFINES_CONFIG`, `DECLARES_DEPENDENCY`, `LOCKS` are unprefixed and identical in
-all three analyzers), but the facts each analyzer writes under it are not: Java parses Maven and
-Gradle manifests and its own set of config formats; Python writes `pkg:pypi` dependencies and
-toml/ini/json config keys; TypeScript writes `pkg:npm`. Ownership is recoverable without a new
-property:
-
-| Fact | Java's when |
-| --- | --- |
-| an `:Artifact` / `:ConfigKey` node | it carries `:JCanNode` (every `can://` node Java writes gets it, `RowBuilder.node`) |
-| `HAS_ARTIFACT` | its source is this app's `:JApplication` |
-| `DECLARES_DEPENDENCY` / `LOCKS` | its target `:Package` id starts with `pkg:maven/` |
-| `DEFINES_CONFIG` | shared fact; kept while any analyzer still claims the key |
-
-A node claimed by another analyzer carries that analyzer's marker (`:PyCanNode`, `:TSCanNode`),
-so "claimed by someone else" is `any(l IN labels(x) WHERE l ENDS WITH 'CanNode' AND
-l <> 'JCanNode')`.
-
-### Decisions
-
-1. **Release, don't delete.** On a full Bolt run, Java first drops its own edges, then releases
-   `:JCanNode` from each `:JCanNode` artifact/config key under `can://<app>/artifact/` (and the
-   pre-3.1.1 `can://artifact/<app>/`) that the run no longer emits. Deletion then depends on the
-   node type:
-   - **Artifact:** deleted when no `HAS_ARTIFACT` edge is left. Every analyzer emits `HAS_ARTIFACT`
-     from its own app root for every artifact it inventories, and has since it first wrote
-     artifacts, so a remaining edge means another analyzer still holds it. This works whether or
-     not that analyzer marks the node.
-   - **Config key:** deleted with its artifact, unless another `*CanNode` label still claims the
-     key. A vanished key on a surviving artifact is also deleted when no other `*CanNode` label
-     claims it. A sibling version that does not mark keys loses such a key until its next push.
-
-   A node that never carried `:JCanNode` was not written by Java and is not matched.
-2. **Java-owned artifact edges are rebuilt on every full run.** `sha256` is one property every
-   writer `SET`s, so a sibling's push can make a changed manifest look unchanged to Java; a sha
-   diff is therefore unsound on shared nodes. Instead, each full run deletes this app's
-   Java-owned artifact edges (`HAS_ARTIFACT` from its `:JApplication`;
-   `DECLARES_DEPENDENCY`/`LOCKS` from its artifacts to `pkg:maven/` packages) and re-upserts
-   them from the run. That also covers `LOCKS` going stale when a manifest changes and the lock
-   file does not. Artifact edges number tens to hundreds, so the cost is negligible. Java's
-   code-to-artifact edges (`J_USES_CONFIG`, `J_DISPATCHES_TO`, `J_READS_CONFIG_UNRESOLVED`) are
-   rebuilt the same way, because a config or template change alters them while every module's
-   `content_hash` stays the same.
-3. **Batched.** The release runs as `CALL { … } IN TRANSACTIONS`: a toggle on a large repository
-   releases one node per non-source file, which a single transaction cannot hold. Partial failure
-   is safe, since the next full push finishes the reconciliation.
-4. **Full runs only.** Releasing and rebuilding run only when `fullRun`. v2 is always a full run
-   (`--target-files` is rejected), so this covers every v2 push.
-5. **Ordering.** Edge purge, then release/delete, then nodes and edges are upserted as today.
-   The ids to keep come from the run's rows, not the DB.
-6. **Non-goals.** `:Package` nodes left with no edges are not deleted (they sit outside the app
-   prefix and are shared across apps). The Cypher snapshot keeps its broader wipe, which
-   `DETACH DELETE`s every `:JCanNode` under the app, sibling-shared artifacts included. Aligning
-   it with decision 1 is a recorded follow-up.
-
-### Verification
-
-- Bolt (Testcontainers), failing before the fix: push without `--workspace-root`, then push the
-  same project with it; assert every `:Artifact`/`:ConfigKey` under `can://<app>/artifact/`
-  carries the repo-relative id, no old-keyed artifact remains, and `:JApplication` has exactly
-  as many `HAS_ARTIFACT` edges as the run emitted.
-- Bolt: change a manifest (drop a dependency, drop a config key); re-push; assert the dropped
-  `DECLARES_DEPENDENCY` edge and `:ConfigKey` are gone.
-- Bolt, polyglot: seed a sibling-shaped artifact (`:Artifact:PyCanNode`, a `pkg:pypi`
-  `DECLARES_DEPENDENCY`, a `:ConfigKey:PyCanNode`) on an id Java also emits and on one it does
-  not; after Java's re-push both survive with their sibling edges, and the shared one keeps
-  `:PyCanNode`.
-- Bolt: a second application in the same database keeps all its artifacts.
-
-### Docs
-
-README §4.2: the Bolt writer reconciles this app's artifacts on a full run. It releases Java's
-claim on artifacts and config keys it no longer emits, deletes them only when no other analyzer
-claims them, and rebuilds Java-owned artifact edges. §4.1: state that the snapshot's wipe is
-broader. Update the `BoltWriter` / `CypherWriter.DESCENDANTS` comments that say Bolt never
-deletes artifacts. Releases with 3.4.0; no lockstep with siblings.
+# Application identity namespaces (supersedes draft workspace-root design)
+
+The unmerged `--workspace-root` proposal is withdrawn. File keys, module suffixes and artifact
+paths remain relative to the selected `--input` directory. No path prefix rekeying or URI
+translation is performed.
+
+`application_name` is the supplied `--app-name`, otherwise the input basename. `identity_namespace`
+is the supplied `--namespace`, otherwise the resolved application name. Both segments are always
+present: `can://<namespace>/<application>`, including `can://inventory/inventory`.
+
+Names retain case and Unicode spelling. UTF-8 bytes outside ASCII letters/digits/`-._~` are
+percent-encoded with uppercase escapes. Empty or whitespace-only names, controls, unpaired
+surrogates, slashes/backslashes and whole-name `.`/`..` are invalid. Explicit invalid flags never
+fall back to defaults. Legacy schema v1 rejects `--namespace`.
+
+The existing schema family remains `2.0.0`. The analysis envelope and graph application anchors
+carry `identity_version: 2`; anchors retain raw `application_name` and `identity_namespace`.
+Missing persisted metadata is unsupported, not defaulted. Regenerate from source and retire legacy
+outputs explicitly. Cache identity includes the canonical namespace/application root and marker.
+
+Java keeps its existing `/java/<file>/<type>/<signature>` suffixes and body ordinals. External
+symbols and artifacts share the canonical application root; `pkg:` identities remain unchanged.
+Canonical-parent builders forward their root unchanged. No mutable global namespace is used.
+
+Bolt checks the selected existing application anchor before DDL or data writes. Incremental hashes,
+module purges, orphan pruning and artifact reconciliation stay within that selected application.
+Shared-artifact retention rules remain intact. Offline snapshots validate incoming metadata but
+cannot inspect the target database; execution is an explicit regeneration operation.
diff --git a/schema.neo4j.json b/schema.neo4j.json
index 54a5897d..c0130713 100644
--- a/schema.neo4j.json
+++ b/schema.neo4j.json
@@ -6,20 +6,23 @@
     "JCanNode"
   ],
   "node_labels": [
     {
       "label": "JApplication",
       "merge_label": "JApplication",
       "key": "id",
       "properties": {
         "id": "string",
         "name": "string",
+        "application_name": "string",
+        "identity_namespace": "string",
+        "identity_version": "integer",
         "schema_version": "string",
         "analyzer_name": "string",
         "analyzer_version": "string",
         "entrypoint_frameworks": "string[]",
         "entrypoint_report_json": "string"
       }
     },
     {
       "label": "JModule",
       "merge_label": "JModule",
diff --git a/src/main/java/com/ibm/cldk/CodeAnalyzer.java b/src/main/java/com/ibm/cldk/CodeAnalyzer.java
index 412f5a90..698160fd 100644
--- a/src/main/java/com/ibm/cldk/CodeAnalyzer.java
+++ b/src/main/java/com/ibm/cldk/CodeAnalyzer.java
@@ -24,20 +24,21 @@ import com.google.gson.JsonParser;
 import com.ibm.cldk.artifacts.ArtifactDiscovery;
 import com.ibm.cldk.artifacts.ConfigKeys;
 import com.ibm.cldk.artifacts.ConfigUses;
 import com.ibm.cldk.artifacts.DependencyView;
 import com.ibm.cldk.artifacts.ViewDispatches;
 import com.ibm.cldk.entities.JavaCompilationUnit;
 import com.ibm.cldk.javaee.EntrypointScan;
 import com.ibm.cldk.neo4j.BoltConfig;
 import com.ibm.cldk.neo4j.Neo4jEmitter;
 import com.ibm.cldk.schema.Analysis;
+import com.ibm.cldk.schema.CanId;
 import com.ibm.cldk.schema.JArtifact;
 import com.ibm.cldk.schema.JDependency;
 import com.ibm.cldk.schema.JEntrypointReport;
 import com.ibm.cldk.schema.JModule;
 import com.ibm.cldk.schema.V2Emitter;
 import com.ibm.cldk.schema.V2Json;
 import com.ibm.cldk.syntactic_analysis.L1Cache;
 import com.ibm.cldk.syntactic_analysis.L1Extractor;
 import com.ibm.cldk.syntactic_analysis.L2CallGraph;
 import com.ibm.cldk.syntactic_analysis.dataflow.SdgPortEdges;
@@ -139,24 +140,22 @@ public class CodeAnalyzer implements Runnable {
 
     @Option(names = { "--neo4j-database" }, description = "Neo4j database name (env: NEO4J_DATABASE, default: server default).")
     private static String neo4jDatabase;
 
     @Option(names = {
             "--schema" }, description = "Output schema: v2 (canonical CPG, default) | v1 (legacy).")
     // Deliberately an INSTANCE field: the pre-existing options on this class are static, which leaks
     // values between CommandLine instances in the same JVM. New flags do not add to that.
     private String schema = "v2";
 
-    @Option(names = {
-            "--workspace-root" }, description = "Directory that file keys, module ids and artifact ids are "
-                    + "relative to (default: --input). Must contain --input. Not supported with --schema v1.")
-    private String workspaceRoot;
+    @Option(names = "--namespace", description = "Identity namespace (defaults to application name)")
+    private String namespace;
 
     @Option(names = {"-c",
             "--cache-dir" }, description = "Directory holding the incremental analysis cache. When set, "
                     + "unchanged files are reused from analysis_cache.json instead of being reparsed.")
     private String cacheDir;
 
     @Option(names = {
             "--eager" }, description = "Ignore any cached modules and rebuild everything (default: lazy).")
     private boolean eager = false;
 
@@ -259,24 +258,24 @@ public class CodeAnalyzer implements Runnable {
         // The Neo4j schema contract is a static artifact — no project analysis required.
         if ("schema".equalsIgnoreCase(emit)) {
             Neo4jEmitter.emitSchema(output);
             return;
         }
 
         if (isV2Schema()) {
             analyzeV2();
             return;
         }
-        if (workspaceRoot != null) {
+        if (namespace != null) {
             // v1 keys are absolute paths, so there is nothing for a workspace root to relativize.
             throw new ParameterException(spec.commandLine(),
-                    "error: --workspace-root is not supported with --schema v1");
+                    "error: --namespace is not supported with --schema v1");
         }
 
         JsonObject combinedJsonObject = new JsonObject();
         Map<String, JavaCompilationUnit> symbolTable;
         projectRootPom = projectRootPom == null ? input : projectRootPom;
         // First of all if, sourceAnalysis is provided, we will analyze the source code
         // instead of the project.
         if (sourceAnalysis != null) {
             // Construct symbol table for source code
             Log.debug("Single file analysis.");
@@ -460,34 +459,31 @@ public class CodeAnalyzer implements Runnable {
                     "error: unknown --l3-engine '" + l3Engine + "'; use ast or wala");
         }
         if (sourceAnalysis != null || targetFiles != null) {
             throw new ParameterException(spec.commandLine(),
                     "error: --schema v2 supports whole-project analysis only "
                             + "(not --source-analysis or --target-files)");
         }
         if (input == null) {
             throw new ParameterException(spec.commandLine(), "error: --input is required");
         }
-        // What every emitted file key, module id and artifact id is relative to. Discovery, builds and
-        // dependency download still run against --input; only the key changes.
         Path inputRoot = Paths.get(input).toAbsolutePath().normalize();
-        Path keyRoot = workspaceRoot == null ? inputRoot : Paths.get(workspaceRoot).toAbsolutePath().normalize();
-        if (!inputRoot.startsWith(keyRoot)) {
-            // Relativizing would yield `..` keys, which the schema forbids (relative, never absolute or `..`).
-            throw new ParameterException(spec.commandLine(),
-                    "error: --input " + inputRoot + " is not inside --workspace-root " + keyRoot);
+        Path keyRoot = inputRoot;
+        String application = spec.commandLine().getParseResult().hasMatchedOption("--app-name")
+                ? appName : inputRoot.getFileName().toString();
+        String applicationId;
+        try {
+            applicationId = CanId.applicationId(application, namespace);
+        } catch (IllegalArgumentException e) {
+            throw new ParameterException(spec.commandLine(), "error: invalid --app-name or --namespace: " + e.getMessage());
         }
 
-        String application = appName != null && !appName.isBlank()
-                ? appName
-                : Paths.get(input).toAbsolutePath().normalize().getFileName().toString();
-
         // Always attempt library type resolution: without the dependency jars on the solver's path,
         // third-party types degrade to bare spellings (`Model` rather than `org.springframework.ui.Model`)
         // and consumers lose the qualified names they join on. A failure here only thins resolution, so
         // it is a warning rather than a fatal error.
         projectRootPom = projectRootPom == null ? input : projectRootPom;
         Path dependencyDir = null;
         try {
             if (BuildProject.downloadLibraryDependencies(input, projectRootPom)) {
                 dependencyDir = BuildProject.libDownloadPath;
             } else {
@@ -499,33 +495,33 @@ public class CodeAnalyzer implements Runnable {
         }
 
         // Lazy by default: reuse modules whose files are byte-for-byte unchanged. `--eager` forces a
         // full rebuild, which is also how a caller recovers from a cache they distrust.
         Path cache = cacheDir == null ? null : Paths.get(cacheDir);
         String version = analyzerVersion();
         // L3 runs at parse time and needs the AST that a warm cache hit would skip; the cache is also an
         // L1 artifact that must not carry L3 overlays. So bypass the cache entirely at level >= 3.
         Map<String, JModule> cached = (eager || analysisLevel >= 3)
                 ? new java.util.LinkedHashMap<>()
-                : L1Cache.load(cache, application, version);
+                : L1Cache.load(cache, applicationId, version);
 
         Map<String, JModule> modules;
         List<L2CallGraph.RtaEndpoint> rtaEndpoints = null;
         WalaAnalysis wala = null;
         // Run-scoped: the finders' failures accumulate across every file of one extraction.
         JEntrypointReport entrypointReport = new JEntrypointReport();
         // Overlays that were requested but could not be produced. Warned about either way; `--strict`
         // is what turns them into a non-zero exit for a caller that cannot read stderr.
         List<String> degraded = new ArrayList<>();
         try {
-            modules = L1Extractor.extractAll(
-                    Paths.get(input), keyRoot, application, dependencyDir, cached,
+            modules = L1Extractor.extractAllForApplication(
+                    Paths.get(input), applicationId, dependencyDir, cached,
                     analysisLevel, graphFieldDepth, l3Engine, entrypointReport);
             // The WALA L3 engine needs the RTA build; --no-rta suppresses it, so a level-3 wala run with
             // --no-rta would silently carry no overlays. Warn rather than degrade without a signal.
             if (analysisLevel >= 3 && noRta && "wala".equalsIgnoreCase(l3Engine)) {
                 Log.warn("--l3-engine wala requires the RTA build that --no-rta suppresses; "
                         + "no L3 overlays will be produced (L1/L2 output is unaffected)");
             }
             // The RTA overlay wants those same dependency jars in WALA's scope, so build it here, before
             // the finally cleans them. `declared` edges need no build, so level 2 never fails for want of
             // one: a build failure (or --no-rta) leaves rta absent and declared edges intact.
@@ -573,29 +569,29 @@ public class CodeAnalyzer implements Runnable {
                     degraded.add("L4 semantic ddg: WALA build failed, no points-to ddg edges");
                 }
             }
         } finally {
             BuildProject.cleanLibraryDependencies();
         }
         // Save the L1 tree before the L2 pass mutates it: the cache is an L1 artifact, so `callee`
         // (an L2 refinement) must not be persisted into it. At level >= 3 the tree carries L3 overlays,
         // which are not an L1 artifact, so the cache is not written.
         if (analysisLevel < 3) {
-            L1Cache.save(cache, application, version, modules);
+            L1Cache.save(cache, applicationId, version, modules);
         }
 
         // The repository-artifact layer (build manifests, config files, declared dependencies) sits
         // beside the call-graph/SDG assembly below because both are application-scope data built once
         // -- but unlike them it is L1 data and runs at EVERY analysis level, so it is computed here,
         // ahead of the level gate, rather than inside either branch of it.
         Map<String, JArtifact> artifacts =
-                ArtifactDiscovery.discover(inputRoot, keyRoot, application, artifactText, artifactTextMaxBytes);
+                ArtifactDiscovery.discover(inputRoot, application, artifactText, artifactTextMaxBytes, namespace);
         List<JDependency> dependencies = DependencyView.build(keyRoot, artifacts);
         for (JArtifact a : artifacts.values()) {
             if (ConfigKeys.isEligible(a)) {
                 // Re-read from disk: `source` may be truncated or suppressed, and extraction
                 // must not silently degrade with a capture flag.
                 ConfigKeys.Result r = ConfigKeys.extract(a, readFully(keyRoot, a), artifactText);
                 a.setConfigKeys(r.keys);
                 // A pre-existing "partial" from the dependency pass is never overwritten.
                 if (!r.ok) {
                     a.setExtraction("partial");
@@ -603,39 +599,39 @@ public class CodeAnalyzer implements Runnable {
                     a.setExtraction("full");
                 }
             }
         }
 
         // maxLevel reports the requested level: the L1-L3 passes above always run to that level (or
         // degrade a specific overlay with a warning), and the L4 vertices/param edges below are
         // engine-free, so they run whenever analysisLevel >= 4 regardless of the WALA build's fate.
         Analysis analysis;
         if (analysisLevel >= 2) {
-            L2CallGraph.Result l2 = L2CallGraph.build(application, modules, rtaEndpoints, externalCalls);
+            L2CallGraph.Result l2 = L2CallGraph.buildForApplication(applicationId, modules, rtaEndpoints, externalCalls);
             // SdgVertices needs the callee ids L2CallGraph.build just backfilled onto call body nodes,
             // and no dependency jars, so it runs here rather than inside the try block above.
             SdgVertices.Result sdg = null;
             if (analysisLevel >= 4) {
                 sdg = SdgVertices.apply(modules);
                 // Summaries read the vertices SdgVertices just added, so this must follow it.
                 SummaryPass.apply(modules, l2.callGraph(), graphFieldDepth);
                 // Joins those vertices to the statement ddg (#227). Strictly last: summaries are
                 // computed from the statement-level ddg alone, as they always were.
                 SdgPortEdges.apply(modules);
             }
             analysis = V2Emitter.emit(application, analysisLevel, modules, version,
                     l2.callGraph(), l2.externalSymbols(),
                     sdg == null ? null : sdg.paramIn, sdg == null ? null : sdg.paramOut,
-                    artifacts, dependencies);
+                    artifacts, dependencies, namespace);
         } else {
             analysis = V2Emitter.emit(application, analysisLevel, modules, version,
-                    null, null, null, null, artifacts, dependencies);
+                    null, null, null, null, artifacts, dependencies, namespace);
         }
 
         // Enforced here, after every overlay pass has had its chance and before anything is written:
         // a strict run must not leave a half-written payload that looks like a complete one.
         if (strict && !degraded.isEmpty()) {
             throw new ParameterException(spec.commandLine(),
                     "error: analysis degraded and --strict was requested:\n  - "
                             + String.join("\n  - ", degraded)
                             + "\nBuild the project (or drop --no-build) to get these overlays, or rerun"
                             + " without --strict to accept the degraded output.");
@@ -643,32 +639,32 @@ public class CodeAnalyzer implements Runnable {
 
         // frameworks_detected is a union over the BUILT tree, so it must run after the modules are
         // final -- and it is correct on a warm cache for the same reason, where a tally kept during
         // the walk would not be.
         EntrypointScan.completeReport(entrypointReport, modules);
         analysis.getApplication().setEntrypointReport(entrypointReport);
 
         // Config reads join the L1 tree to the artifact layer's declared keys, so it runs after both
         // exist and at every analysis level -- the literal tier needs no call graph. Absence means
         // "no fact", so an empty result leaves both keys off the envelope.
-        ConfigUses.Result configReads = ConfigUses.detect(application, modules, artifacts,
+        ConfigUses.Result configReads = ConfigUses.detectForApplication(applicationId, modules, artifacts,
                 analysisLevel, analysis.getApplication().getCallGraph());
         if (!configReads.uses.isEmpty()) {
             analysis.getApplication().setConfigUses(configReads.uses);
         }
         if (!configReads.unresolved.isEmpty()) {
             analysis.getApplication().setConfigReadsUnresolved(configReads.unresolved);
         }
 
         // View dispatches (#259) join dispatch sites to the artifact layer's view templates -- the
         // same shape as config reads, at every level, with the dataflow tiers widening from -a 3.
-        ViewDispatches.Result views = ViewDispatches.detect(application, modules, artifacts,
+        ViewDispatches.Result views = ViewDispatches.detectForApplication(applicationId, modules, artifacts,
                 analysisLevel, analysis.getApplication().getCallGraph());
         if (!views.dispatches.isEmpty()) {
             analysis.getApplication().setViewDispatches(views.dispatches);
         }
         if (!views.unresolved.isEmpty()) {
             analysis.getApplication().setViewDispatchesUnresolved(views.unresolved);
         }
 
         if ("neo4j".equalsIgnoreCase(emit)) {
             // The RESOLVED name, not the raw --app-name: the payload and the root's can:// id are
diff --git a/src/main/java/com/ibm/cldk/artifacts/ArtifactDiscovery.java b/src/main/java/com/ibm/cldk/artifacts/ArtifactDiscovery.java
index 909ae48b..565cc579 100644
--- a/src/main/java/com/ibm/cldk/artifacts/ArtifactDiscovery.java
+++ b/src/main/java/com/ibm/cldk/artifacts/ArtifactDiscovery.java
@@ -129,34 +129,29 @@ public final class ArtifactDiscovery {
      * @param captureText when {@code false}, every {@code source} is empty and no file is
      *     truncated, but classification and hashing are unaffected — the inventory is identical
      *     either way, only the captured text differs
      * @param textMaxBytes byte cap on captured text for a decodable file; a {@code
      *     dependency-manifest} is exempt (always captured whole when {@code captureText} is on)
      *     so the complete manifest text appears in the emitted JSON payload for consumers, not
      *     truncated by the cap
      */
     public static Map<String, JArtifact> discover(
             Path projectDir, String appName, boolean captureText, int textMaxBytes) throws IOException {
-        return discover(projectDir, projectDir, appName, captureText, textMaxBytes);
+        return discover(projectDir, appName, captureText, textMaxBytes, null);
     }
 
-    /**
-     * As above, with each artifact's key, {@code path} and id relative to {@code keyRoot} rather than
-     * {@code projectDir} — {@code --workspace-root}. Ignore rules and classification still see the
-     * {@code projectDir}-relative path, so a rule like {@code gradle/libs.versions.toml} matches the
-     * same files whatever the key root is. {@code projectDir} must be {@code keyRoot} or inside it.
-     */
+    /** Discover application-relative artifacts in the selected identity namespace. */
     public static Map<String, JArtifact> discover(
-            Path projectDir, Path keyRoot, String appName, boolean captureText, int textMaxBytes)
+            Path projectDir, String appName, boolean captureText, int textMaxBytes, String namespace)
             throws IOException {
         Path root = projectDir.toAbsolutePath().normalize();
-        Path keyBase = keyRoot.toAbsolutePath().normalize();
+        Path keyBase = projectDir.toAbsolutePath().normalize();
         List<Path> files;
         try (Stream<Path> walk = Files.walk(root)) {
             files = walk.filter(Files::isRegularFile).sorted().collect(Collectors.toList());
         }
 
         Map<String, JArtifact> artifacts = new TreeMap<>();
         for (Path file : files) {
             Path relative = root.relativize(file);
             if (isIgnored(relative)) {
                 continue;
@@ -180,21 +175,21 @@ public final class ArtifactDiscovery {
             } else if (rule != null) {
                 format = rule.format;
                 roles = rule.roles;
             } else {
                 format = "text";
                 roles = (!name.contains(".") && text.startsWith("#!")) ? List.of("script") : List.of("unknown");
             }
 
             String keyPosix = keyBase.relativize(file).toString().replace('\\', '/');
             JArtifact artifact = new JArtifact();
-            artifact.setId(CanId.artifactId(appName, keyPosix));
+            artifact.setId(CanId.artifactId(appName, keyPosix, namespace));
             artifact.setPath(keyPosix);
             artifact.setFormat(format);
             artifact.setRoles(roles);
             // sha256/sizeBytes always describe the whole file, independent of capture/truncation
             // below -- this is the invariant a consumer relies on to detect a truncated source.
             artifact.setSizeBytes(raw.length);
             artifact.setSha256(sha256Hex(raw));
 
             if (decodable && captureText) {
                 int cap = roles.contains("dependency-manifest") ? raw.length : textMaxBytes;
diff --git a/src/main/java/com/ibm/cldk/artifacts/ConfigUses.java b/src/main/java/com/ibm/cldk/artifacts/ConfigUses.java
index cca7b1ed..0f976b2a 100644
--- a/src/main/java/com/ibm/cldk/artifacts/ConfigUses.java
+++ b/src/main/java/com/ibm/cldk/artifacts/ConfigUses.java
@@ -181,20 +181,25 @@ public final class ConfigUses {
      * the intra tier at {@code >= 3} (the callable's own DDG) and the interprocedural tier at
      * {@code >= 4} (that plus {@code callGraph}).
      *
      * <p>Additive by construction: a read the literal tier closed is never handed to a tier, and a
      * tier only ever converts an unresolved read into an edge. So
      * {@code config_uses(-a 1) ⊆ config_uses(-a 3) ⊆ config_uses(-a 4)}, the same contract the DDG's
      * own {@code ssa} → {@code points-to} widening keeps.
      */
     public static Result detect(String appName, Map<String, JModule> modules,
             Map<String, JArtifact> artifacts, int analysisLevel, List<JCallEdge> callGraph) {
+        return detectForApplication(CanId.applicationId(appName), modules, artifacts, analysisLevel, callGraph);
+    }
+
+    public static Result detectForApplication(String appName, Map<String, JModule> modules,
+            Map<String, JArtifact> artifacts, int analysisLevel, List<JCallEdge> callGraph) {
         Map<String, List<JConfigKey>> keysByNamespace = keysByNamespace(artifacts);
 
         List<Read> reads = new ArrayList<>();
         Map<String, DataflowTiers.Owner> owners = new LinkedHashMap<>();
         if (modules != null) {
             for (JModule module : modules.values()) {
                 collectTypes(appName, module.getTypes(), module.getSource(), reads, owners);
             }
         }
         return resolve(reads, keysByNamespace, owners, analysisLevel, callGraph);
@@ -284,21 +289,21 @@ public final class ConfigUses {
             String literal = Literals.stringLiteral(arg);
             // The bare name a dataflow tier can trace. Only a plain identifier qualifies: a field
             // access or any compound expression has no single local for the DDG to close over.
             String keyName = literal == null && arg != null && IDENTIFIER.matcher(arg).matches()
                     ? arg
                     : null;
             String signature = node.getCalleeSignature() != null
                     ? node.getCalleeSignature()
                     : node.getMethodName();
             reads.add(new Read(CanId.ordinalId(callableId, localId),
-                    CanId.externalId(appName, rule.declaringType, signature),
+                    CanId.externalIdForApplication(appName, rule.declaringType, signature),
                     literal, rule.namespaces, false, callableId, localId, keyName));
             return;
         }
     }
 
     // ----------------------------------------------------------------------------------------
     // Resolution
     // ----------------------------------------------------------------------------------------
 
     private static Result resolve(List<Read> reads, Map<String, List<JConfigKey>> keysByNamespace,
@@ -479,13 +484,13 @@ public final class ConfigUses {
             for (String arg : args) {
                 if (arg.startsWith(name + "=")) {
                     return Literals.stringLiteral(arg.substring(name.length() + 1));
                 }
             }
         }
         return args.size() == 1 && args.get(0).indexOf('=') < 0 ? Literals.stringLiteral(args.get(0)) : null;
     }
 
     private static String ghost(String appName, String annotationType) {
-        return CanId.externalId(appName, annotationType, "value()");
+        return CanId.externalIdForApplication(appName, annotationType, "value()");
     }
 }
diff --git a/src/main/java/com/ibm/cldk/artifacts/ViewDispatches.java b/src/main/java/com/ibm/cldk/artifacts/ViewDispatches.java
index b32711e2..ddde7a96 100644
--- a/src/main/java/com/ibm/cldk/artifacts/ViewDispatches.java
+++ b/src/main/java/com/ibm/cldk/artifacts/ViewDispatches.java
@@ -103,20 +103,25 @@ public final class ViewDispatches {
         }
     }
 
     public static Result detect(String appName, Map<String, JModule> modules,
             Map<String, JArtifact> artifacts) {
         return detect(appName, modules, artifacts, 1, null);
     }
 
     public static Result detect(String appName, Map<String, JModule> modules,
             Map<String, JArtifact> artifacts, int analysisLevel, List<JCallEdge> callGraph) {
+        return detectForApplication(CanId.applicationId(appName), modules, artifacts, analysisLevel, callGraph);
+    }
+
+    public static Result detectForApplication(String appName, Map<String, JModule> modules,
+            Map<String, JArtifact> artifacts, int analysisLevel, List<JCallEdge> callGraph) {
         List<Site> sites = new ArrayList<>();
         if (modules != null) {
             for (JModule module : modules.values()) {
                 collectTypes(appName, module.getTypes(), sites);
             }
         }
         return resolve(sites, artifacts, modules, analysisLevel, callGraph);
     }
 
     // ----------------------------------------------------------------------------------------
@@ -188,21 +193,21 @@ public final class ViewDispatches {
             via = method;
             target = dispatcherArgument(node.getReceiverExpr());
         } else if ("sendRedirect".equals(method) && RESPONSE_TYPES.contains(receiver)) {
             via = "redirect";
             target = arg0;
         } else {
             return null;
         }
         String signature = node.getCalleeSignature() != null ? node.getCalleeSignature() : method;
         return new Site(CanId.ordinalId(callableId, localId),
-                CanId.externalId(appName, receiver, signature), via, target, callableId, localId);
+                CanId.externalIdForApplication(appName, receiver, signature), via, target, callableId, localId);
     }
 
     /**
      * The argument of the {@code getRequestDispatcher(...)} / {@code getNamedDispatcher(...)} call
      * that produced a dispatcher, read off the dispatching call's receiver expression — the chain
      * {@code ctx.getRequestDispatcher("/x.jsp")} ends at that call. A receiver that is not such a
      * chain (a dispatcher held in a local) has no target to read here.
      */
     // ponytail: a dispatcher stored in a local (`rd.forward(...)`) is non-literal; trace `rd` to its
     // `getRequestDispatcher` initializer if that shape shows up in real code.
diff --git a/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java b/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java
index 63685f58..28961b9b 100644
--- a/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java
+++ b/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java
@@ -69,38 +69,27 @@ public final class BoltWriter implements BoltSink {
      */
     static final String PURGE_MODULE_EDGES_V2 =
             "MATCH (x:" + RowBuilder.CAN_NODE + ") WHERE x.id = $mid OR x.id STARTS WITH $pre "
                     + "MATCH (x)-[r]->() DELETE r";
 
     /** @see #PURGE_MODULE_EDGES_V2 */
     static final String PURGE_VANISHED_NODES_V2 =
             "MATCH (x:" + RowBuilder.CAN_NODE + ") WHERE (x.id = $mid OR x.id STARTS WITH $pre) "
                     + "AND NOT x.id IN $keys DETACH DELETE x";
 
-    /**
-     * The orphan prune: matches the application root by its {@code can://} {@code id} when it is a
-     * v2 root (exact, unique-constrained), OR by {@code name} when it is a legacy v1 root --
-     * identifiable because v1 never writes {@code id} (see {@code GraphProjector.java}). An
-     * id-only match would orphan a prior v1 graph instead of pruning it; an ungated
-     * {@code a.name =} disjunct would reach every v2 root carrying that display name -- including
-     * roots this analyzer never minted -- since {@code name} stopped being unique-constrained once
-     * the root was re-keyed. Hence the {@code a.id IS NULL} guard, which confines the name branch
-     * to legacy roots.
-     *
-     * <p>This does <b>not</b> separate two distinct applications sharing an {@code --app-name}:
-     * {@link com.ibm.cldk.schema.CanId#applicationId} is {@code "can://" + appName}, so they share
-     * an id byte-for-byte and are one node. Distinct services need distinct {@code --app-name}
-     * values; no predicate here can recover a distinction the id never encoded.
-     */
+    /** Hashes and orphan pruning are confined to the selected canonical application anchor. */
+    static final String MODULE_HASHES_V2 = "MATCH (a:JApplication {id: $appId})-[:J_HAS_MODULE]->(c:JModule) "
+            + "RETURN c.file_key AS k, c.content_hash AS h";
+
     static final String PRUNE_VANISHED_UNITS_V2 =
             "MATCH (a:JApplication)-[:J_HAS_UNIT|J_HAS_MODULE]->(c) "
-                    + "WHERE (a.id = $appId OR (a.id IS NULL AND a.name = $appName)) "
+                    + "WHERE a.id = $appId "
                     + "AND NOT c.file_key IN $present "
                     + "OPTIONAL MATCH (c)-" + CypherWriter.DESCENDANTS + "->(x) "
                     + "DETACH DELETE x, c RETURN count(c) AS pruned";
 
     /**
      * Drop every Java-owned edge on this app's artifacts and config keys so the run rebuilds them:
      * {@code HAS_ARTIFACT} from a {@code :JApplication}, {@code DECLARES_DEPENDENCY}/{@code LOCKS}
      * to {@code pkg:maven/}, and incoming {@code J_} edges ({@code J_USES_CONFIG},
      * {@code J_DISPATCHES_TO}). Not sha-diffed: siblings overwrite the shared {@code sha256}, and a
      * config change alters code edges while every module's hash stays put.
@@ -128,27 +117,23 @@ public final class BoltWriter implements BoltSink {
     static final String RELEASE_VANISHED_ARTIFACTS =
             "UNWIND $pres AS pre "
                     + "MATCH (n:" + RowBuilder.CAN_NODE + ") WHERE n.id STARTS WITH pre AND (n:Artifact OR n:ConfigKey) "
                     + "AND NOT n.id IN $keep "
                     + "CALL { WITH n REMOVE n:" + RowBuilder.CAN_NODE + " "
                     + "WITH n WHERE (n:Artifact AND NOT ()-[:HAS_ARTIFACT]->(n)) "
                     + "OR (n:ConfigKey AND none(l IN labels(n) WHERE l ENDS WITH 'CanNode')) "
                     + "DETACH DELETE n } IN TRANSACTIONS OF 1000 ROWS "
                     + "RETURN count(*) AS released";
 
-    /**
-     * Where this app's artifacts live: {@code can://<app>/artifact/}, and {@code
-     * can://artifact/<app>/} for those written before 3.1.1 moved the app outermost. Both are
-     * separator-terminated, so {@code app} never reaches {@code apps}.
-     */
+    /** Only the selected application's artifacts; legacy output requires explicit retirement. */
     static List<String> artifactPrefixes(String appId, String appName) {
-        return List.of(appId + "/artifact/", CanId.SCHEME + "artifact/" + appName + "/");
+        return List.of(appId + "/artifact/");
     }
 
     /**
      * The prefix that matches a module's declarations but not a sibling module whose path merely
      * starts the same way. The separator is the whole point: {@code can://app/java/src/Foo.java}
      * is also a prefix of {@code can://app/java/src/Foo.javaX}, so a bare {@code STARTS WITH} on
      * the module id would purge a different module's nodes. The module itself is matched by
      * equality instead, since its own id does not end in a separator.
      */
     static String descendantPrefix(String moduleId) {
@@ -165,20 +150,35 @@ public final class BoltWriter implements BoltSink {
             if (n.labels.contains("JModule") && RowBuilder.isCanId(n.value)) {
                 return n.value;
             }
         }
         return null;
     }
 
 
     private static final int BATCH = 1000;
 
+    static void requireCompatibleApplicationIdentity(String id, Map<String, Object> incoming, Map<String, Object> stored) {
+        Object name = incoming.get("application_name");
+        Object namespace = incoming.get("identity_namespace");
+        Object version = incoming.get("identity_version");
+        Object storedVersion = stored.get("identity_version");
+        if (!(name instanceof String) || !(namespace instanceof String)
+                || (!(version instanceof Integer) && !(version instanceof Long)) || ((Number) version).longValue() != 2
+                || !id.equals(CanId.applicationId((String) name, (String) namespace))
+                || (!(storedVersion instanceof Integer) && !(storedVersion instanceof Long)) || ((Number) storedVersion).longValue() != 2
+                || !name.equals(stored.get("application_name"))
+                || !namespace.equals(stored.get("identity_namespace"))) {
+            throw new IllegalArgumentException("Incompatible existing application identity; regenerate graph explicitly");
+        }
+    }
+
     /** Public no-arg constructor: {@link Neo4jEmitter} instantiates this reflectively via {@link BoltSink}. */
     public BoltWriter() {}
 
     @Override
     public void write(GraphRows rows, BoltConfig cfg, boolean fullRun) {
         try (Driver driver = GraphDatabase.driver(cfg.uri, AuthTokens.basic(cfg.user, cfg.password))) {
             new Runner(driver, cfg.database).run(rows, fullRun);
         }
     }
 
@@ -191,20 +191,33 @@ public final class BoltWriter implements BoltSink {
             this.database = database;
         }
 
         private Session session() {
             return database != null
                     ? driver.session(SessionConfig.forDatabase(database))
                     : driver.session();
         }
 
         void run(GraphRows rows, boolean fullRun) {
+            // Validate the selected canonical anchor before any schema or data mutation.
+            for (NodeRow node : rows.nodes) {
+                if (!node.labels.contains("JApplication") || !RowBuilder.isCanId(node.value)) continue;
+                requireCompatibleApplicationIdentity(node.value, node.props, node.props);
+                try (Session s = session()) {
+                    var records = s.run("MATCH (a:JApplication {id: $id}) RETURN a.identity_version AS identity_version, "
+                                    + "a.application_name AS application_name, a.identity_namespace AS identity_namespace",
+                            Values.parameters("id", node.value)).list();
+                    for (var record : records) {
+                        requireCompatibleApplicationIdentity(node.value, node.props, record.asMap());
+                    }
+                }
+            }
             // 1. schema (DDL runs in its own autocommit transactions). Migrations run FIRST: a
             // constraint an older release created on a property this generation no longer keys on
             // is still live and enforcing, and would fail the very first push (see Schema.MIGRATIONS).
             try (Session s = session()) {
                 for (String stmt : Schema.MIGRATIONS) {
                     s.run(stmt);
                 }
                 for (String stmt : Schema.CONSTRAINTS) {
                     s.run(stmt);
                 }
@@ -223,22 +236,23 @@ public final class BoltWriter implements BoltSink {
                     unitOf.put(n.value, n.moduleKey);
                 } else {
                     shared.add(n);
                 }
             }
 
             // 2. diff content_hash. Both generations key their per-file node on file_key: v1
             // :JCompilationUnit and v2 :JModule.
             Map<String, String> dbHash = new HashMap<>();
             try (Session s = session()) {
-                s.run("MATCH (c) WHERE c:JCompilationUnit OR c:JModule "
-                                + "RETURN c.file_key AS k, c.content_hash AS h").list()
+                boolean v2 = rows.nodes.stream().anyMatch(n -> n.labels.contains("JApplication") && RowBuilder.isCanId(n.value));
+                String query = v2 ? MODULE_HASHES_V2 : "MATCH (c:JCompilationUnit) RETURN c.file_key AS k, c.content_hash AS h";
+                s.run(query, Values.parameters("appId", applicationIdOf(rows))).list()
                         .forEach(rec -> dbHash.put(rec.get("k").asString(null), rec.get("h").asString(null)));
             }
             Set<String> changed = new HashSet<>();
             for (Map.Entry<String, List<NodeRow>> e : byUnit.entrySet()) {
                 String unit = e.getKey();
                 String rowHash = hashOf(e.getValue(), unit);
                 if (!dbHash.containsKey(unit) || rowHash == null || !rowHash.equals(dbHash.get(unit))) {
                     changed.add(unit);
                 }
             }
@@ -298,33 +312,23 @@ public final class BoltWriter implements BoltSink {
                 }
             }
             upsertEdges(edges);
 
             // 6. orphan prune — only safe on a full run. Reaches both generations' per-file nodes
             // through the shared application anchor, so a v2 push also prunes a prior v1 graph's
             // units (and other applications in the database are never touched).
             if (fullRun) {
                 List<String> present = new ArrayList<>(byUnit.keySet());
                 String appName = appNameOf(rows);
-                String appId = CanId.applicationId(appName);
-                // Checked against the same hazard as the _module purges above (#213) and found
-                // sound, so deliberately left alone: this traversal never leaves java's own graph.
-                // It enters at :JApplication (java-owned, and scoped to this app by its unique
-                // can:// id when the root is v2, or by name when it is a legacy v1 root that never
-                // got an id -- see PRUNE_VANISHED_UNITS_V2's javadoc), hops a java-owned
-                // relationship type, and expands only through DESCENDANTS -- every member of which
-                // is J_-prefixed containment. `c` and `x` are unlabelled but unreachable except
-                // along those edges, and DESCENDANTS deliberately excludes HAS_ARTIFACT, so no
-                // cross-language :Artifact/:ConfigKey and no shared :JPackage/:JAnnotation can be
-                // reached. Do not add a non-containment type to DESCENDANTS without re-checking that.
-                //
-                // Artifacts belong to no unit; reconcileArtifacts (step 3) handles them.
+                String appId = applicationIdOf(rows);
+                // Only Java containment under this exact anchor is traversed. Shared artifacts
+                // are reconciled separately and sibling namespaces are never fallback matches.
                 try (Session s = session()) {
                     long pruned = s.run(PRUNE_VANISHED_UNITS_V2,
                             Values.parameters("present", present, "appId", appId, "appName", appName))
                             .single().get("pruned").asLong(0);
                     Log.info("neo4j(bolt): pruned " + pruned + " vanished unit(s)");
                 }
             } else {
                 Log.info("neo4j(bolt): targeted run — orphan pruning skipped (deleted files not removed)");
             }
         }
@@ -341,21 +345,21 @@ public final class BoltWriter implements BoltSink {
                     keep.add(n.value);
                 }
             }
             if (appId == null) {
                 return;
             }
             Map<String, Object> args = new LinkedHashMap<>();
             args.put("appId", appId);
             args.put("pres", artifactPrefixes(appId, appNameOf(rows)));
             args.put("keep", keep);
-            // Auto-commit, batched: a --workspace-root toggle releases one node per non-source file.
+            // Auto-commit and batched to bound full-run artifact reconciliation.
             // A partial failure is safe; the next full push finishes it.
             try (Session s = session()) {
                 s.run(PURGE_ARTIFACT_EDGES, args).consume();
                 s.run(PURGE_UNRESOLVED_CONFIG_READS, args).consume();
                 long released = s.run(RELEASE_VANISHED_ARTIFACTS, args).single().get("released").asLong(0);
                 Log.info("neo4j(bolt): released " + released + " vanished artifact/config node(s)");
             }
         }
 
         private void upsertNodes(List<NodeRow> nodes) {
@@ -430,20 +434,27 @@ public final class BoltWriter implements BoltSink {
             return null;
         }
 
         /**
          * The application anchor's display name — read from the {@code name} property rather than
          * {@link NodeRow#value}, because that merge value is generation-dependent (the raw name
          * for v1, the {@code can://} id for v2 since Task 3). The {@code name} property is set
          * identically by both generations, so this always yields the true app name to re-derive
          * the id from.
          */
+        private static String applicationIdOf(GraphRows rows) {
+            for (NodeRow n : rows.nodes) {
+                if (n.labels.contains("JApplication") && RowBuilder.isCanId(n.value)) return n.value;
+            }
+            return CanId.applicationId(appNameOf(rows));
+        }
+
         private static String appNameOf(GraphRows rows) {
             for (NodeRow n : rows.nodes) {
                 if (n.labels.get(0).equals("JApplication")) {
                     Object name = n.props.get("name");
                     return name != null ? name.toString() : n.value;
                 }
             }
             return "application";
         }
     }
diff --git a/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java b/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java
index 274afbcc..88cb359f 100644
--- a/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java
+++ b/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java
@@ -27,44 +27,21 @@ import java.util.Map;
  * it (e.g. {@code cypher-shell < graph.cypher}) rebuilds this project's subgraph from scratch —
  * constraints, a scoped wipe of the prior version, then batched {@code UNWIND … MERGE} for nodes
  * and edges.
  *
  * <p>This artifact is intentionally NOT incremental: a static script has no view of the live DB, so
  * it expresses the full truth. Incremental updates are the {@link BoltWriter}'s job.
  */
 public final class CypherWriter {
 
     private static final int BATCH = 500;
-    /**
-     * Every containment relationship either graph generation emits — v1 (unit-rooted) and v2
-     * (module-rooted) together, so a v2 push wipes/prunes a prior v1 graph of the same app and vice
-     * versa (spec: one app name = one graph, latest push wins).
-     *
-     * <p>This traversal is the <b>only</b> thing that reaches a v1 graph, and that is why
-     * {@link #wipe}'s {@code can://} prefix sweep cannot replace it: v1 ids are fully-qualified
-     * names carrying no application segment, and {@code GraphProjector.java} keys
-     * {@code :JApplication} on {@code name}, so no prefix predicate sees a single v1 node. Folding
-     * the two into one prefix sweep was tried on this branch and reverted; it orphans every v1
-     * graph.
-     *
-     * <p>{@code HAS_ARTIFACT} (and the {@code :Package} edges {@code DECLARES_DEPENDENCY} /
-     * {@code LOCKS}) stay out of this list — but no longer because the artifact subtree is
-     * untouchable. {@link #wipe}'s prefix sweep now <i>does</i> reach this application's
-     * {@code :Artifact}/{@code :ConfigKey} nodes, deliberately; see its javadoc. They stay out of
-     * {@code DESCENDANTS} because this constant is shared with
-     * {@link BoltWriter#PRUNE_VANISHED_UNITS_V2}, whose unit of deletion is one vanished
-     * compilation unit, not the application: an app-level {@code :Artifact} is not a descendant of
-     * any one unit and must not die with one (Bolt reconciles artifacts separately, see
-     * {@link BoltWriter#RELEASE_VANISHED_ARTIFACTS}). {@code :Package} ({@code pkg:} purls) is outside both
-     * — it is not under the app prefix either — as are the shared {@code :JPackage}/
-     * {@code :JAnnotation} merge targets.
-     */
+    /** Java containment relationships; traversed only below the selected application anchor. */
     static final String DESCENDANTS = "[:J_DECLARES_TYPE|J_HAS_NESTED_TYPE|J_HAS_CALLABLE|J_HAS_FIELD|J_HAS_PARAMETER"
             + "|J_HAS_CALLSITE|J_DECLARES_VAR|J_HAS_ENUM_CONSTANT|J_HAS_RECORD_COMPONENT|J_HAS_INIT_BLOCK"
             + "|J_HAS_CRUD_OPERATION|J_HAS_CRUD_QUERY|J_HAS_COMMENT"
             + "|J_DECLARES|J_HAS_METHOD|J_HAS_BODY_NODE*1..]";
 
     private CypherWriter() {}
 
     /**
      * Render the whole script into a {@code String}. Convenience for callers holding a small graph
      * (tests, diagnostics); it delegates to {@link #writeCypher} so the two can never drift.
@@ -108,21 +85,21 @@ public final class CypherWriter {
         for (String stmt : Schema.CONSTRAINTS) {
             s.add(stmt + ";");
         }
         for (String stmt : Schema.INDEXES) {
             s.add(stmt + ";");
         }
 
         s.add("");
         s.add("// ── wipe this project's prior subgraph (packages/annotations are shared and survive; "
                 + "artifacts/config keys are inside the app prefix and get rebuilt) ──");
-        s.add(wipe(appName));
+        s.add(wipe(applicationIdOf(rows, appName)));
 
         s.add("");
         s.add("// ── nodes ──");
         writeNodeStatements(s, rows.nodes);
 
         s.add("");
         s.add("// ── relationships ──");
         writeEdgeStatements(s, rows.edges);
 
         s.add("");
@@ -159,72 +136,38 @@ public final class CypherWriter {
     static String applicationPrefix(String appName) {
         if (appName == null || appName.trim().isEmpty()) {
             throw new IllegalArgumentException(
                     "neo4j: refusing a destructive statement without an application id");
         }
         // The trailing separator is not cosmetic: a bare `STARTS WITH 'can://app'` would also match
         // `can://appX`, a different application.
         return CanId.applicationId(appName) + "/";
     }
 
-    /**
-     * The application root by equality plus everything under {@code can://<app>/}, then the same
-     * application's prior <b>v1</b> graph by containment, then the orphan sweep.
-     *
-     * <p><b>Statement 1, the prefix sweep.</b> Scoped by id, so it is one application by
-     * construction: a second java app sharing a source path, and a sibling analyzer's own
-     * {@code can://} graph under a different app, are outside it. {@code :Package} nodes
-     * ({@code pkg:} purls) stay outside too — they are not under the app prefix. Two things moved
-     * with the app-outermost grammar: the root is matched by its {@code can://<app>} id rather than
-     * by the free-text {@code --app-name}, so the id the graph is actually keyed on is the id the
-     * wipe uses; and this application's {@code :Artifact}/{@code :ConfigKey} nodes are now
-     * <i>inside</i> the prefix, so the snapshot rebuilds them instead of leaving them to accumulate
-     * forever with nothing ever cleaning them up. That is deliberate, and it is the one behavioural
-     * widening here: a cross-language edge into a shared {@code :Artifact} is dropped by a java
-     * snapshot and restored on that analyzer's next push.
-     *
-     * <p><b>Statement 2, the containment traversal.</b> Not redundant with the sweep above and not
-     * foldable into it — see {@link #DESCENDANTS}. v1 ids are fully-qualified names, so the prefix
-     * predicate cannot reach a v1 node; this hop is what makes "one app name = one graph, latest
-     * push wins" hold across generations. The unit hop is unlabeled and lists both generations' rel
-     * types (v1 {@code J_HAS_UNIT} → {@code :JCompilationUnit}, v2 {@code J_HAS_MODULE} →
-     * {@code :JModule}) so either generation's push replaces whichever the DB currently holds. The
-     * root is matched by id when it is v2 (exact, unique-constrained) OR by name when it is a legacy
-     * v1 root — identifiable because v1 never writes {@code id}. An id-only match would orphan a
-     * prior v1 graph instead of replacing it, breaking the very cross-generation guarantee this
-     * exists for. The {@code a.id IS NULL} guard confines the name branch to those legacy roots; an
-     * ungated {@code a.name =} disjunct would additionally reach every v2 root carrying this display
-     * name, including roots this analyzer never minted, so do not widen it.
-     *
-     * <p><b>Statement 3, the orphan sweep.</b> Fully-isolated {@code :JSymbol} nodes the containment
-     * traversal cannot reach — v1's import-materialized bodyless {@code :JType} stubs hang off units
-     * via {@code J_IMPORTS} only, so the deletes above orphan them. Degree-0 symbols are
-     * unreferencable junk in any generation, and a symbol another application still uses keeps its
-     * edges and survives.
-     *
-     * <p>What none of this does — and must not be documented as doing — is separate two distinct
-     * applications sharing an {@code --app-name}. {@code CanId.applicationId} is
-     * {@code "can://" + appName}, so they share an id byte-for-byte and are ONE node; there is
-     * nothing here to tell apart. Distinct services need distinct {@code --app-name} values, not a
-     * wider predicate.
-     */
-    private static String wipe(String appName) {
-        String appId = cypherValue(CanId.applicationId(appName));
+    /** Canonical roots come from projected rows, preserving the selected namespace. */
+    private static String applicationIdOf(GraphRows rows, String appName) {
+        for (NodeRow n : rows.nodes) {
+            if (n.labels.contains("JApplication") && RowBuilder.isCanId(n.value)) return n.value;
+        }
+        return CanId.applicationId(appName);
+    }
+
+    private static String wipe(String applicationId) {
+        String appId = cypherValue(applicationId);
         return "MATCH (x:" + RowBuilder.CAN_NODE + ") WHERE x.id = " + appId
-                + " OR x.id STARTS WITH " + cypherValue(applicationPrefix(appName)) + "\n"
+                + " OR x.id STARTS WITH " + cypherValue(applicationId + "/") + "\n"
                 + "CALL { WITH x DETACH DELETE x } IN TRANSACTIONS OF 1000 ROWS;\n"
                 + "MATCH (a:JApplication) WHERE a.id = " + appId
-                + " OR (a.id IS NULL AND a.name = " + cypherValue(appName) + ")\n"
+                + "\n"
                 + "OPTIONAL MATCH (a)-[:J_HAS_UNIT|J_HAS_MODULE]->(c)\n"
                 + "OPTIONAL MATCH (c)-" + DESCENDANTS + "->(x)\n"
-                + "DETACH DELETE x, c, a;\n"
-                + "MATCH (s:JSymbol) WHERE NOT (s)--() DELETE s;";
+                + "DETACH DELETE x, c, a;\n";
     }
 
     // ----------------------------------------------------------------------------------------------
     // Nodes — grouped by their full label set + key property, batched into UNWIND lists.
     // ----------------------------------------------------------------------------------------------
 
     private static void writeNodeStatements(Statements out, List<NodeRow> nodes) throws IOException {
         Map<String, List<NodeRow>> groups = new LinkedHashMap<>();
         for (NodeRow n : nodes) {
             String k = String.join(":", n.labels) + "|" + n.keyProp;
diff --git a/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java b/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java
index 9f39bfb9..e11e9242 100644
--- a/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java
+++ b/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java
@@ -60,27 +60,38 @@ public final class RowBuilder {
             }
             if (v instanceof List && ((List<?>) v).isEmpty()) {
                 continue;
             }
             out.put(e.getKey(), v);
         }
         return out;
     }
 
     /**
-     * Upsert a node. Re-seeing the same {@code (labels[0], value)} merges props (last write wins)
-     * and unions labels.
+     * Upsert a node. Canonical ids deduplicate across labels, unioning labels and compatible
+     * properties. Conflicting canonical properties are rejected. Legacy keys retain label scope.
      */
     public NodeRef node(List<String> labels, String keyProp, String value, Map<String, Object> props) {
-        String id = labels.get(0) + " " + value;
+        String id = isCanId(value) ? value : labels.get(0) + " " + value;
         NodeRow existing = nodes.get(id);
         if (existing != null) {
+            if (isCanId(value)) {
+                if (!existing.keyProp.equals(keyProp)) {
+                    throw new IllegalArgumentException("Conflicting canonical entity key: " + value);
+                }
+                for (var entry : props.entrySet()) {
+                    if (existing.props.containsKey(entry.getKey())
+                            && !java.util.Objects.equals(existing.props.get(entry.getKey()), entry.getValue())) {
+                        throw new IllegalArgumentException("Conflicting canonical entity property " + entry.getKey() + ": " + value);
+                    }
+                }
+            }
             existing.props.putAll(props);
             for (String l : labels) {
                 if (!existing.labels.contains(l)) {
                     existing.labels.add(l);
                 }
             }
             // putAll may have re-introduced the lifted property; strip it again on the v2 path only,
             // so a re-merged v1 node keeps the property its contract still includes.
             if (isCanId(value)) {
                 existing.props.remove(MODULE_PROP);
@@ -158,32 +169,36 @@ public final class RowBuilder {
 
     public void edgeToSymbol(String type, NodeRef from, String targetId) {
         edgeToSymbol(type, from, targetId, RowBuilder.props());
     }
 
     /** An edge kept only if BOTH endpoints were emitted as nodes (used for CALLS). */
     public void edgeIfBothResolved(String type, NodeRef from, NodeRef to, Map<String, Object> props) {
         deferred.add(new EdgeRow(type, from, to, props));
     }
 
+    private static String endpointKey(NodeRef ref) {
+        return isCanId(ref.value) ? ref.value : ref.label + ":" + ref.value;
+    }
+
     public GraphRows finish() {
         for (EdgeRow e : deferred) {
             if (keys.contains(e.from.value) && keys.contains(e.to.value)) {
                 edges.add(e);
             }
         }
         // Dedupe edges the way Neo4j's MERGE would: one relationship per
         // (type, source, target[, _k]), last-write-wins on props (mirrors `MERGE (a)-[r]->(b) SET r += p`).
         Map<String, EdgeRow> uniqueEdges = new LinkedHashMap<>();
         for (EdgeRow e : edges) {
-            uniqueEdges.put(e.type + "|" + e.from.label + ":" + e.from.value
-                    + "|" + e.to.label + ":" + e.to.value
+            uniqueEdges.put(e.type + "|" + endpointKey(e.from)
+                    + "|" + endpointKey(e.to)
                     + (e.key == null ? "" : "|" + e.key), e);
         }
 
         List<NodeRow> nodeList = new ArrayList<>(nodes.values());
         nodeList.sort((a, b) ->
                 (a.labels.get(0) + " " + a.value).compareTo(b.labels.get(0) + " " + b.value));
         List<EdgeRow> edgeList = new ArrayList<>(uniqueEdges.values());
         edgeList.sort((a, b) ->
                 (a.type + " " + a.from.value + " " + a.to.value + " " + (a.key == null ? "" : a.key))
                         .compareTo(b.type + " " + b.from.value + " " + b.to.value + " "
diff --git a/src/main/java/com/ibm/cldk/neo4j/V2GraphProjector.java b/src/main/java/com/ibm/cldk/neo4j/V2GraphProjector.java
index ecfa9bfd..22094a72 100644
--- a/src/main/java/com/ibm/cldk/neo4j/V2GraphProjector.java
+++ b/src/main/java/com/ibm/cldk/neo4j/V2GraphProjector.java
@@ -66,31 +66,43 @@ import java.util.Map;
  */
 public final class V2GraphProjector {
 
     private V2GraphProjector() {}
 
     private static final List<String> SYMBOL_TYPE = Arrays.asList("JSymbol", "JType");
     private static final List<String> SYMBOL_CALLABLE = Arrays.asList("JSymbol", "JCallable");
     private static final List<String> SYMBOL_EXTERNAL = Arrays.asList("JSymbol", "JExternal");
 
     public static GraphRows project(Analysis analysis, String appName) {
+        if (!Integer.valueOf(2).equals(analysis.getIdentityVersion())) {
+            throw new IllegalArgumentException("Unsupported identity_version; regenerate analysis from source");
+        }
+        String rawName = analysis.getApplication().getApplicationName();
+        String namespace = analysis.getApplication().getIdentityNamespace();
+        if (rawName == null || namespace == null
+                || !CanId.applicationId(rawName, namespace).equals(analysis.getApplication().getId())) {
+            throw new IllegalArgumentException("Missing or incompatible application identity; regenerate from source");
+        }
         RowBuilder b = new RowBuilder();
         Map<String, JModule> symbolTable = analysis.getApplication().getSymbolTable();
 
         // Unguarded this yields `MERGE (:JApplication {id: null})` -- an unkeyed root that every
         // id-scoped wipe and prune misses. Unreachable via CodeAnalyzer (V2Emitter always stamps
         // it), but this is a public entry point.
         String appId = java.util.Objects.requireNonNull(analysis.getApplication().getId(),
                 "application.id is null -- the can:// root id must be stamped by V2Emitter before projection");
         Map<String, Object> appProps = RowBuilder.props();
         appProps.put("id", appId);
-        appProps.put("name", appName);
+        appProps.put("name", rawName);
+        appProps.put("application_name", rawName);
+        appProps.put("identity_namespace", namespace);
+        appProps.put("identity_version", 2);
         appProps.put("schema_version", V2SchemaCatalog.SCHEMA_VERSION);
         if (analysis.getAnalyzer() != null) {
             appProps.put("analyzer_name", analysis.getAnalyzer().getName());
             appProps.put("analyzer_version", analysis.getAnalyzer().getVersion());
         }
         // Set unconditionally, and deliberately BEFORE prune: the entrypoint pass under-approximates,
         // so a consumer must be able to tell "no entrypoints" from "the pass found nothing". An empty
         // frameworks list next to a populated `rulesets` in the report is exactly that signal, and
         // pruning the empty list away would erase it. Mirrors :PyApplication (codeanalyzer-python #177).
         JEntrypointReport entrypointReport = analysis.getApplication().getEntrypointReport() != null
diff --git a/src/main/java/com/ibm/cldk/neo4j/V2SchemaCatalog.java b/src/main/java/com/ibm/cldk/neo4j/V2SchemaCatalog.java
index f863d83a..75f59065 100644
--- a/src/main/java/com/ibm/cldk/neo4j/V2SchemaCatalog.java
+++ b/src/main/java/com/ibm/cldk/neo4j/V2SchemaCatalog.java
@@ -122,21 +122,22 @@ public final class V2SchemaCatalog {
 
     private static List<NodeLabel> buildNodeLabels() {
         List<NodeLabel> n = new ArrayList<>();
 
         // `entrypoint_frameworks` / `entrypoint_report_json` (#234) are ALWAYS set, even when empty:
         // the entrypoint pass under-approximates by design, so a consumer must be able to tell "this
         // application has no entrypoints" from "the pass found nothing". An absent report and an empty
         // one reading the same is the failure this record exists to prevent. Mirrors what
         // codeanalyzer-python projects onto :PyApplication.
         n.add(node("JApplication", "JApplication", "id",
-                new P().put("id", "string").put("name", "string").put("schema_version", "string")
+                new P().put("id", "string").put("name", "string").put("application_name", "string").put("identity_namespace", "string")
+                        .put("identity_version", "integer").put("schema_version", "string")
                         .put("analyzer_name", "string").put("analyzer_version", "string")
                         .put("entrypoint_frameworks", "string[]")
                         .put("entrypoint_report_json", "string").done()));
 
         // `source` is the whole file, matching `analysis.json`'s required `module.source`. It is the
         // primary text under canonical decision D1 (per-callable `code` was dropped from the JSON on
         // the grounds that the SDK slices `module.source[span.bytes]`), so the graph must carry it or
         // no span narrower than a callable can be resolved to text at all.
         n.add(node("JModule", "JModule", "id",
                 new P().put("id", "string").put("file_key", "string").put("package", "string")
diff --git a/src/main/java/com/ibm/cldk/schema/Analysis.java b/src/main/java/com/ibm/cldk/schema/Analysis.java
index dd3aaa40..d7716d5f 100644
--- a/src/main/java/com/ibm/cldk/schema/Analysis.java
+++ b/src/main/java/com/ibm/cldk/schema/Analysis.java
@@ -2,16 +2,17 @@ package com.ibm.cldk.schema;
 
 import lombok.Data;
 
 /**
  * The canonical schema v2 payload root (the envelope): manifest fields plus the {@code application}
  * tree node. Serialized with Gson's {@code LOWER_CASE_WITH_UNDERSCORES} policy, so
  * {@code schemaVersion} → {@code schema_version}, {@code maxLevel} → {@code max_level}, etc.
  */
 @Data
 public class Analysis {
+    private Integer identityVersion;
     private String schemaVersion;
     private String language;
     private int maxLevel;
     private JAnalyzerInfo analyzer;
     private JApplication application;
 }
diff --git a/src/main/java/com/ibm/cldk/schema/CanId.java b/src/main/java/com/ibm/cldk/schema/CanId.java
index e29acfdd..33f570ab 100644
--- a/src/main/java/com/ibm/cldk/schema/CanId.java
+++ b/src/main/java/com/ibm/cldk/schema/CanId.java
@@ -1,82 +1,129 @@
 package com.ibm.cldk.schema;
 
 /**
  * Canonical {@code can://} id construction for schema v2.
  *
  * <p>Durable ids (&ge; callable) are containment paths
- * {@code can://<app>/java/<file>/<type>/<callable-signature>}; ordinal ids (&lt; callable) are
+ * {@code can://<namespace>/<app>/java/<file>/<type>/<callable-signature>}; ordinal ids (&lt; callable) are
  * {@code <callable-id>@<tag>} where {@code <tag>} is a source position {@code line:col} (real
  * nodes) or a synthetic tag (e.g. {@code entry}). Pure functions; ids are opaque handles (the
  * {@code <file>} segment itself may contain {@code /}).
  */
 public final class CanId {
 
     private CanId() {}
 
     /** The scheme prefix. The language is no longer part of it — see {@link #LANG}. */
     public static final String SCHEME = "can://";
 
     /** This analyzer's language segment, which now sits INSIDE the app rather than above it. */
     public static final String LANG = "java";
 
-    /** {@code can://<app>} — the application root, and the prefix every id below it shares. */
+    /** {@code can://<namespace>/<app>} — the application root, and the prefix every id below it shares. */
     public static String applicationId(String appName) {
-        return SCHEME + appName;
+        return applicationId(appName, null);
+    }
+
+    public static String applicationId(String appName, String namespace) {
+        return SCHEME + encodeName(namespace == null ? appName : namespace) + "/" + encodeName(appName);
+    }
+
+    private static String encodeName(String value) {
+        if (value == null || value.isEmpty() || value.equals(".") || value.equals("..")) {
+            throw new IllegalArgumentException("Invalid identity name");
+        }
+        boolean whitespace = true;
+        for (int i = 0; i < value.length();) {
+            int cp = value.codePointAt(i);
+            if (Character.isISOControl(cp) || cp == '/' || cp == '\\'
+                    || cp >= 0xD800 && cp <= 0xDFFF) {
+                throw new IllegalArgumentException("Invalid identity name");
+            }
+            whitespace &= Character.isWhitespace(cp) || Character.isSpaceChar(cp);
+            i += Character.charCount(cp);
+        }
+        if (whitespace) {
+            throw new IllegalArgumentException("Identity name must not be whitespace-only");
+        }
+        StringBuilder out = new StringBuilder();
+        for (byte b : value.getBytes(java.nio.charset.StandardCharsets.UTF_8)) {
+            int c = b & 255;
+            if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9'
+                    || c == '-' || c == '.' || c == '_' || c == '~') {
+                out.append((char) c);
+            } else {
+                out.append('%').append("0123456789ABCDEF".charAt(c >>> 4))
+                        .append("0123456789ABCDEF".charAt(c & 15));
+            }
+        }
+        return out.toString();
     }
 
     /** {@code <applicationId>/java/<relative-file-key>} (separators normalized to {@code /}). */
     public static String moduleId(String applicationId, String fileKey) {
         String rel = fileKey.replace("\\", "/").replaceFirst("^[./]+", "");
         return applicationId + "/" + LANG + "/" + rel;
     }
 
     /** {@code <parentId>/<segment>} — one downward step in the containment path. */
     public static String childId(String parentId, String segment) {
         return parentId + "/" + segment;
     }
 
     /** {@code <callableId>@<tag>} — an ordinal id for a body node within a callable. */
     public static String ordinalId(String callableId, String tag) {
         return callableId + "@" + tag;
     }
 
     /**
-     * {@code can://<app>/@external/<binary-type>/<signature>} — a callable outside the project. The
+     * {@code can://<namespace>/<app>/@external/<binary-type>/<signature>} — a callable outside the project. The
      * type is a <em>binary</em> name ({@code java.util.Map$Entry}) so the id is unambiguous and joins
      * WALA natively.
      *
      * <p>Language-NEUTRAL, like {@link #artifactId}: {@code @external} sits in the position the
      * language occupies for code nodes, so sibling analyzers over the same {@code <app>} name a
      * library symbol identically and it is one node in a merged graph. The cost is real and was
      * accepted deliberately — two analyzers' notions of {@code java.util.Map#get} are not necessarily
      * the same thing, and merging them says they are. codeanalyzer-typescript's form;
      * codeanalyzer-python follows it, and so does this.
      *
      * <p>Consequently an external id does <em>not</em> match the {@code canId} shape
-     * ({@code ^can://[^/]+/java/}): the analysis schema's {@code externalCanId} is a separate
+     * ({@code ^can://[^/]+/[^/]+/java/}): the analysis schema's {@code externalCanId} is a separate
      * definition, and the two sites that hold either — a call edge's {@code dst} and a body node's
      * {@code callee} — {@code $ref} the union, not a widened {@code canId}.
      */
     public static String externalId(String appName, String binaryType, String signature) {
-        return applicationId(appName) + "/@external/" + binaryType + "/" + signature;
+        return externalId(appName, binaryType, signature, null);
+    }
+
+    public static String externalId(String appName, String binaryType, String signature, String namespace) {
+        return externalIdForApplication(applicationId(appName, namespace), binaryType, signature);
+    }
+
+    public static String externalIdForApplication(String applicationId, String binaryType, String signature) {
+        return applicationId + "/@external/" + binaryType + "/" + signature;
     }
 
     /**
-     * {@code can://<app>/artifact/<rel-path>} — a language-neutral artifact id, nested under the app
+     * {@code can://<namespace>/<app>/artifact/<rel-path>} — a language-neutral artifact id, nested under the app
      * rather than under a language. The {@code artifact} segment is deliberately chosen over
      * {@code java} so a sibling-language analyzer scanning the same repository lands on the same
      * node rather than a duplicate. {@code CypherWriter.DESCENDANTS} cites that sharing by name as
      * the reason the artifact/config-key subtree stays outside every wipe.
      */
     public static String artifactId(String appName, String relPath) {
-        return applicationId(appName) + "/artifact/" + relPath;
+        return artifactId(appName, relPath, null);
+    }
+
+    public static String artifactId(String appName, String relPath, String namespace) {
+        return applicationId(appName, namespace) + "/artifact/" + relPath;
     }
 
     /**
      * {@code <artifactId>@key/<dotted.key>} — a configuration key nested under its defining artifact,
      * making it discoverable and addressable as a sub-node.
      */
     public static String configKeyId(String artifactId, String dottedKey) {
         return artifactId + "@key/" + dottedKey;
     }
 
diff --git a/src/main/java/com/ibm/cldk/schema/JApplication.java b/src/main/java/com/ibm/cldk/schema/JApplication.java
index ceb1d491..85b61aa6 100644
--- a/src/main/java/com/ibm/cldk/schema/JApplication.java
+++ b/src/main/java/com/ibm/cldk/schema/JApplication.java
@@ -2,20 +2,22 @@ package com.ibm.cldk.schema;
 
 import java.util.LinkedHashMap;
 import java.util.List;
 import java.util.Map;
 import lombok.Data;
 
 /** The root {@code application} node of the v2 CPG. */
 @Data
 public class JApplication {
     private String id;
+    private String applicationName;
+    private String identityNamespace;
     private String kind = "application";
     private Map<String, JModule> symbolTable = new LinkedHashMap<>();
 
     /**
      * The L2 {@code call_graph}: one edge per {@code (src, dst)} callable pair. Left {@code null} at L1
      * so the key is omitted (absence means "no fact", never an empty array).
      */
     private List<JCallEdge> callGraph;
 
     /**
diff --git a/src/main/java/com/ibm/cldk/schema/V2Emitter.java b/src/main/java/com/ibm/cldk/schema/V2Emitter.java
index 34401be1..df6af7ae 100644
--- a/src/main/java/com/ibm/cldk/schema/V2Emitter.java
+++ b/src/main/java/com/ibm/cldk/schema/V2Emitter.java
@@ -65,22 +65,32 @@ public final class V2Emitter {
             String appName,
             int maxLevel,
             Map<String, JModule> modules,
             String analyzerVersion,
             List<JCallEdge> callGraph,
             Map<String, JExternalSymbol> externalSymbols,
             List<JIdEdge> paramIn,
             List<JIdEdge> paramOut,
             Map<String, JArtifact> artifacts,
             List<JDependency> dependencies) {
+        return emit(appName, maxLevel, modules, analyzerVersion, callGraph, externalSymbols,
+                paramIn, paramOut, artifacts, dependencies, null);
+    }
+
+    public static Analysis emit(String appName, int maxLevel, Map<String, JModule> modules,
+            String analyzerVersion, List<JCallEdge> callGraph, Map<String, JExternalSymbol> externalSymbols,
+            List<JIdEdge> paramIn, List<JIdEdge> paramOut, Map<String, JArtifact> artifacts,
+            List<JDependency> dependencies, String namespace) {
         JApplication application = new JApplication();
-        application.setId(CanId.applicationId(appName));
+        application.setId(CanId.applicationId(appName, namespace));
+        application.setApplicationName(appName);
+        application.setIdentityNamespace(namespace == null ? appName : namespace);
 
         // Sort file keys so output is deterministic (the -j gate).
         Map<String, JModule> sorted = new LinkedHashMap<>();
         for (String fileKey : new TreeSet<>(modules.keySet())) {
             sorted.put(fileKey, modules.get(fileKey));
         }
         application.setSymbolTable(sorted);
         // Absence means "no fact": an empty overlay is omitted, not emitted as [] / {}. This is what
         // lets --external-calls off match v1 (no external_symbols key at all) rather than an empty map.
         if (callGraph != null && !callGraph.isEmpty()) {
@@ -96,20 +106,21 @@ public final class V2Emitter {
             application.setParamOut(paramOut);
         }
         if (artifacts != null && !artifacts.isEmpty()) {
             application.setArtifacts(artifacts);
         }
         if (dependencies != null && !dependencies.isEmpty()) {
             application.setDependencies(dependencies);
         }
 
         Analysis analysis = new Analysis();
+        analysis.setIdentityVersion(2);
         analysis.setSchemaVersion("2.0.0");
         analysis.setLanguage("java");
         analysis.setMaxLevel(maxLevel);
         if (analyzerVersion != null) {
             JAnalyzerInfo analyzer = new JAnalyzerInfo();
             analyzer.setVersion(analyzerVersion);
             analysis.setAnalyzer(analyzer);
         }
         analysis.setApplication(application);
         return analysis;
diff --git a/src/main/java/com/ibm/cldk/syntactic_analysis/L1Cache.java b/src/main/java/com/ibm/cldk/syntactic_analysis/L1Cache.java
index 8e7eb498..68c51ace 100644
--- a/src/main/java/com/ibm/cldk/syntactic_analysis/L1Cache.java
+++ b/src/main/java/com/ibm/cldk/syntactic_analysis/L1Cache.java
@@ -27,20 +27,21 @@ import lombok.Data;
  */
 public final class L1Cache {
 
     private L1Cache() {}
 
     private static final String FILE_NAME = "analysis_cache.json";
 
     /** What is persisted: the modules plus the settings they were built under. */
     @Data
     static class Envelope {
+        private Integer identityVersion;
         private String schemaVersion;
         private String analyzerVersion;
         private String appName;
         private Map<String, JModule> modules = new LinkedHashMap<>();
     }
 
     public static Path fileIn(Path cacheDir) {
         return cacheDir.resolve(FILE_NAME);
     }
 
@@ -55,41 +56,42 @@ public final class L1Cache {
         Path path = fileIn(cacheDir);
         if (!Files.isRegularFile(path)) {
             return new LinkedHashMap<>();
         }
         try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
             Envelope envelope =
                     V2Json.cache().fromJson(reader, new TypeToken<Envelope>() {}.getType());
             if (envelope == null || envelope.getModules() == null) {
                 return new LinkedHashMap<>();
             }
-            boolean sameSettings = "2.0.0".equals(envelope.getSchemaVersion())
+            boolean sameSettings = Integer.valueOf(2).equals(envelope.getIdentityVersion()) && "2.0.0".equals(envelope.getSchemaVersion())
                     && java.util.Objects.equals(appName, envelope.getAppName())
                     && java.util.Objects.equals(analyzerVersion, envelope.getAnalyzerVersion());
             if (!sameSettings) {
                 Log.debug("Ignoring cache built under different settings: " + path);
                 return new LinkedHashMap<>();
             }
             return envelope.getModules();
         } catch (IOException | JsonSyntaxException e) {
             Log.debug("Ignoring unreadable cache " + path + ": " + e.getMessage());
             return new LinkedHashMap<>();
         }
     }
 
     /** Persist the built modules. A write failure is reported but does not fail the analysis. */
     public static void save(
             Path cacheDir, String appName, String analyzerVersion, Map<String, JModule> modules) {
         if (cacheDir == null) {
             return;
         }
         Envelope envelope = new Envelope();
+        envelope.setIdentityVersion(2);
         envelope.setSchemaVersion("2.0.0");
         envelope.setAnalyzerVersion(analyzerVersion);
         envelope.setAppName(appName);
         envelope.setModules(modules);
         try {
             Files.createDirectories(cacheDir);
             try (Writer writer = Files.newBufferedWriter(fileIn(cacheDir), StandardCharsets.UTF_8)) {
                 V2Json.cache().toJson(envelope, writer);
             }
         } catch (IOException e) {
diff --git a/src/main/java/com/ibm/cldk/syntactic_analysis/L1Extractor.java b/src/main/java/com/ibm/cldk/syntactic_analysis/L1Extractor.java
index cb431c9e..975d901c 100644
--- a/src/main/java/com/ibm/cldk/syntactic_analysis/L1Extractor.java
+++ b/src/main/java/com/ibm/cldk/syntactic_analysis/L1Extractor.java
@@ -114,31 +114,27 @@ public final class L1Extractor {
      * — an IN parameter rather than a second return value, so the map-returning signature above stays
      * the one every caller already uses. It records only what happened in THIS run: a module served
      * from the cache runs no finders, so it contributes nothing here (its per-node
      * {@code entrypoint_frameworks} still carries the attribution, which is why the application-level
      * {@code frameworks_detected} is a union over the tree rather than a tally kept here).
      */
     public static Map<String, JModule> extractAll(
             Path projectRoot, String appName, Path dependencyDir, Map<String, JModule> cached,
             int analysisLevel, int graphFieldDepth, String l3Engine, JEntrypointReport entrypointReport)
             throws IOException {
-        return extractAll(projectRoot, projectRoot, appName, dependencyDir, cached, analysisLevel,
+        return extractAllForApplication(projectRoot, CanId.applicationId(appName), dependencyDir, cached, analysisLevel,
                 graphFieldDepth, l3Engine, entrypointReport);
     }
 
-    /**
-     * As above, with file keys (and so every module id below them) relative to {@code keyRoot} rather
-     * than {@code projectRoot} — {@code --workspace-root}. Source discovery still runs over
-     * {@code projectRoot}, which the caller guarantees is {@code keyRoot} or inside it.
-     */
-    public static Map<String, JModule> extractAll(
-            Path projectRoot, Path keyRoot, String appName, Path dependencyDir, Map<String, JModule> cached,
+    /** Extract application-relative modules under an already validated canonical application root. */
+    public static Map<String, JModule> extractAllForApplication(
+            Path projectRoot, String applicationId, Path dependencyDir, Map<String, JModule> cached,
             int analysisLevel, int graphFieldDepth, String l3Engine, JEntrypointReport entrypointReport)
             throws IOException {
         // JavaParser's collection strategy silently finds zero source roots for a path with a `.`
         // element (`-i .` arrives here as exactly that), so normalize before discovery.
         projectRoot = projectRoot.toAbsolutePath().normalize();
         ParserConfiguration discovery = parserConfiguration();
         ProjectRoot root = new ParserCollectionStrategy(discovery).collect(projectRoot);
 
         List<SourceRoot> sourceRoots = new ArrayList<>();
         for (SourceRoot sourceRoot : root.getSourceRoots()) {
@@ -146,26 +142,25 @@ public final class L1Extractor {
                 sourceRoots.add(sourceRoot);
             }
         }
 
         ParserConfiguration config = parserConfiguration()
                 .setSymbolResolver(new JavaSymbolSolver(typeSolver(sourceRoots, dependencyDir, discovery)));
 
         // Collect into a sorted map first: directory listings are not ordered, and output must not
         // depend on traversal order.
         Map<String, JModule> modules = new TreeMap<>();
-        String applicationId = CanId.applicationId(appName);
         JavaParser parser = new JavaParser(config);
         int reused = 0;
         for (SourceRoot sourceRoot : sourceRoots) {
             for (Path path : javaFilesUnder(sourceRoot.getRoot())) {
-                String fileKey = fileKey(keyRoot, path);
+                String fileKey = fileKey(projectRoot, path);
                 // Read the file's own text rather than printing the AST: `span.bytes` must index the
                 // real file, byte for byte.
                 String source = Files.readString(path, StandardCharsets.UTF_8);
                 L1BuildContext ctx = new L1BuildContext(
                         applicationId, fileKey, source, analysisLevel, graphFieldDepth, l3Engine,
                         entrypointReport);
 
                 // Reuse the cached module when the file is byte-for-byte what it was last time. This
                 // skips the parse as well as the build, which is where the cost is.
                 JModule cachedModule = cached.get(fileKey);
diff --git a/src/main/java/com/ibm/cldk/syntactic_analysis/L2CallGraph.java b/src/main/java/com/ibm/cldk/syntactic_analysis/L2CallGraph.java
index c1f2644d..135535c0 100644
--- a/src/main/java/com/ibm/cldk/syntactic_analysis/L2CallGraph.java
+++ b/src/main/java/com/ibm/cldk/syntactic_analysis/L2CallGraph.java
@@ -126,20 +126,24 @@ public final class L2CallGraph {
      * overlay, and home out-of-project targets.
      *
      * <p>{@code includeExternal} gates the external targets. When {@code false}, a call resolving outside
      * the project is dropped — no {@code callee}, no edge, no {@code external_symbols} entry — matching
      * v1's application-only call graph; the CLI defaults this off and {@code --external-calls} opts in.
      * When {@code true} (the design's §2 posture) they are homed so no edge dangles. The overlay never
      * mutates {@code callee} — that is a declared-analysis refinement.
      */
     public static Result build(
             String appName, Map<String, JModule> modules, List<RtaEndpoint> rtaEdges, boolean includeExternal) {
+        return buildForApplication(CanId.applicationId(appName), modules, rtaEdges, includeExternal);
+    }
+
+    public static Result buildForApplication(String appName, Map<String, JModule> modules, List<RtaEndpoint> rtaEdges, boolean includeExternal) {
         // The type index (named types only) and the set of every callable id in the tree. The latter
         // turns no-dangling, the signature-miss case, and the RTA drop rules into O(1) membership checks.
         Map<String, String> typeIdByBinaryName = new HashMap<>();
         Set<String> callableIds = new HashSet<>();
         for (JModule module : modules.values()) {
             String pkg = module.getPackageName();
             for (Map.Entry<String, JType> entry : module.getTypes().entrySet()) {
                 if (entry.getKey().startsWith("$")) {
                     continue; // synthetic body types have no computable binary name (never at top level)
                 }
@@ -272,21 +276,21 @@ public final class L2CallGraph {
         String signature = node.getCalleeSignature();
         if (signature == null) {
             return null; // resolved the type but not a signature to compose
         }
         if (index.containsKey(hint)) {
             return inProjectId(hint, signature, index, callableIds); // in-project hit (case 2) or signature-miss
         }
         if (!includeExternal) {
             return null; // case 4 gated off: match v1's application-only graph
         }
-        String externalId = CanId.externalId(appName, hint, signature); // case 4
+        String externalId = CanId.externalIdForApplication(appName, hint, signature); // case 4
         externalSymbols.computeIfAbsent(externalId, k -> externalSymbol(signature, hint, node.isConstructorCall()));
         return externalId;
     }
 
     /**
      * Join one WALA RTA edge. The src must be an in-project callable that exists in the tree, or the
      * edge is unattributable and dropped. An in-project dst that maps to no tree callable is dropped
      * (the overlay never fabricates an in-project node); a library dst is homed external.
      */
     private static void joinRtaEdge(
@@ -307,21 +311,21 @@ public final class L2CallGraph {
         String dst;
         if (edge.dstAppClass) {
             dst = inProjectId(edge.dstType, edge.dstSignature, index, callableIds);
             if (dst == null) {
                 return; // in-project but absent from the tree — drop rather than fabricate
             }
         } else {
             if (!includeExternal) {
                 return; // external target gated off: match v1's application-only graph
             }
-            dst = CanId.externalId(appName, edge.dstType, edge.dstSignature);
+            dst = CanId.externalIdForApplication(appName, edge.dstType, edge.dstSignature);
             externalSymbols.computeIfAbsent(
                     dst, k -> externalSymbol(edge.dstSignature, edge.dstType, edge.dstSignature.startsWith("<init>")));
         }
         rtaWeights.computeIfAbsent(src, k -> new TreeMap<>()).merge(dst, 1, Integer::sum);
     }
 
     /** The in-project callable id for a binary type + signature, or {@code null} if absent from the tree. */
     private static String inProjectId(
             String binaryType, String signature, Map<String, String> index, Set<String> callableIds) {
         String typeId = index.get(binaryType);
diff --git a/src/test/java/com/ibm/cldk/CodeAnalyzerV2CliTest.java b/src/test/java/com/ibm/cldk/CodeAnalyzerV2CliTest.java
index 361b866c..eddbe4dc 100644
--- a/src/test/java/com/ibm/cldk/CodeAnalyzerV2CliTest.java
+++ b/src/test/java/com/ibm/cldk/CodeAnalyzerV2CliTest.java
@@ -797,118 +797,184 @@ class CodeAnalyzerV2CliTest {
     /** Every key in {@code keys} is repo-relative under {@code prefix}: never absolute, never {@code ..}. */
     private static void assertRepoRelative(Set<String> keys, String prefix) {
         assertFalse(keys.isEmpty(), "precondition: something was emitted");
         for (String key : keys) {
             assertTrue(key.startsWith(prefix), "expected the " + prefix + " prefix, got: " + key);
             assertFalse(key.startsWith("/") || key.contains(".."), "keys stay relative: " + key);
         }
     }
 
     @Test
-    void workspaceRootMakesSymbolTableKeysAndIdsRepoRelative(@TempDir Path tmp) throws IOException {
+    void namespaceKeepsSymbolTableKeysApplicationRelative(@TempDir Path tmp) throws IOException {
         Path repo = tmp.resolve("repo");
         Path in = project(repo.resolve("services/app"));
         Path out = tmp.resolve("out");
         assertEquals(0, run("-i", in.toString(), "-o", out.toString(), "-a", "2",
-                "--workspace-root", repo.toString(), "--app-name", "widgets"));
+                "--namespace", "team", "--app-name", "widgets"));
 
         JsonObject app = application(out);
-        assertEquals(CanId.applicationId("widgets"), app.get("id").getAsString(),
+        assertEquals(CanId.applicationId("widgets", "team"), app.get("id").getAsString(),
                 "the app segment does not move with the workspace root");
         JsonObject symbolTable = app.getAsJsonObject("symbol_table");
-        assertRepoRelative(symbolTable.keySet(), "services/app/");
-        String key = "services/app/src/main/java/com/example/Widget.java";
+        assertRepoRelative(symbolTable.keySet(), "src/");
+        String key = "src/main/java/com/example/Widget.java";
         assertTrue(symbolTable.has(key), "got: " + symbolTable.keySet());
-        assertEquals(CanId.moduleId(CanId.applicationId("widgets"), key),
+        assertEquals(CanId.moduleId(CanId.applicationId("widgets", "team"), key),
                 symbolTable.getAsJsonObject(key).get("id").getAsString());
 
-        String moduleId = CanId.moduleId(CanId.applicationId("widgets"), key);
+        String moduleId = CanId.moduleId(CanId.applicationId("widgets", "team"), key);
         JsonArray callGraph = app.getAsJsonArray("call_graph");
         assertFalse(callGraph.isEmpty(), "precondition: size() -> count() is an in-project edge");
         for (JsonElement e : callGraph) {
             assertTrue(e.getAsJsonObject().get("src").getAsString().startsWith(moduleId + "/"),
                     "call-graph ids carry the repo-relative module id: " + e);
         }
         assertConformsToV2Schema(out);
     }
 
     @Test
-    void workspaceRootCarriesIntoLevelThreeOverlayIds(@TempDir Path tmp) throws IOException {
+    void namespaceCarriesIntoLevelThreeOverlayIds(@TempDir Path tmp) throws IOException {
         Path repo = tmp.resolve("repo");
         Path in = project(repo.resolve("services/app"));
         Path out = tmp.resolve("out");
         assertEquals(0, run("-i", in.toString(), "-o", out.toString(), "-a", "3",
-                "--workspace-root", repo.toString(), "--app-name", "widgets"));
+                "--namespace", "team", "--app-name", "widgets"));
 
-        String moduleId = CanId.moduleId(CanId.applicationId("widgets"),
-                "services/app/src/main/java/com/example/Widget.java");
+        String moduleId = CanId.moduleId(CanId.applicationId("widgets", "team"),
+                "src/main/java/com/example/Widget.java");
         String json = Files.readString(out.resolve("analysis.json"));
         assertTrue(json.contains("\"cfg\""), "precondition: level 3 lays the cfg overlay");
-        java.util.regex.Matcher ids = java.util.regex.Pattern.compile("\"(can://widgets/java/[^\"]*)\"").matcher(json);
+        java.util.regex.Matcher ids = java.util.regex.Pattern.compile("\"(can://team/widgets/java/[^\"]*)\"").matcher(json);
         int seen = 0;
         while (ids.find()) {
             assertTrue(ids.group(1).startsWith(moduleId),
                     "every code id, overlay endpoints included, is under the repo-relative module: " + ids.group(1));
             seen++;
         }
         assertTrue(seen > 0, "precondition: ids were emitted");
         assertConformsToV2Schema(out);
     }
 
     @Test
-    void workspaceRootPrefixesArtifactKeysWithoutChangingClassification(@TempDir Path tmp) throws IOException {
+    void namespaceKeepsArtifactKeysAndClassification(@TempDir Path tmp) throws IOException {
         Path repo = tmp.resolve("repo");
         Path in = artifactProject(repo.resolve("services/app"));
         Path out = tmp.resolve("out");
         assertEquals(0, run("-i", in.toString(), "-o", out.toString(),
-                "--workspace-root", repo.toString(), "--app-name", "widgets"));
+                "--namespace", "team", "--app-name", "widgets"));
 
         JsonObject app = application(out);
         JsonObject artifacts = app.getAsJsonObject("artifacts");
-        assertRepoRelative(artifacts.keySet(), "services/app/");
+        assertRepoRelative(artifacts.keySet(), "");
 
-        JsonObject pom = artifacts.getAsJsonObject("services/app/pom.xml");
+        JsonObject pom = artifacts.getAsJsonObject("pom.xml");
         assertNotNull(pom, "got: " + artifacts.keySet());
-        assertEquals("services/app/pom.xml", pom.get("path").getAsString());
-        assertEquals(CanId.artifactId("widgets", "services/app/pom.xml"), pom.get("id").getAsString());
+        assertEquals("pom.xml", pom.get("path").getAsString());
+        assertEquals(CanId.artifactId("widgets", "pom.xml", "team"), pom.get("id").getAsString());
         assertEquals("full", pom.get("extraction").getAsString(),
                 "the manifest is still read from disk under the repo-relative key");
         assertFalse(app.getAsJsonArray("dependencies").isEmpty(), "and its dependency still extracted");
 
-        JsonArray propsKeys = artifacts.getAsJsonObject("services/app/application.properties")
+        JsonArray propsKeys = artifacts.getAsJsonObject("application.properties")
                 .getAsJsonArray("config_keys");
         assertEquals(1, propsKeys.size(), "config keys are still extracted");
         assertConformsToV2Schema(out);
     }
 
     @Test
-    void workspaceRootEqualToInputChangesNothing(@TempDir Path tmp) throws IOException {
+    void explicitDefaultNamespaceChangesNothing(@TempDir Path tmp) throws IOException {
         Path in = artifactProject(tmp.resolve("app"));
         Path without = tmp.resolve("without");
         Path with = tmp.resolve("with");
         assertEquals(0, run("-i", in.toString(), "-o", without.toString(), "--app-name", "widgets"));
         assertEquals(0, run("-i", in.toString(), "-o", with.toString(), "--app-name", "widgets",
-                "--workspace-root", in.toString()));
+                "--namespace", "widgets"));
         assertEquals(application(without).get("symbol_table").toString(),
                 application(with).get("symbol_table").toString());
         assertEquals(application(without).get("artifacts").toString(),
                 application(with).get("artifacts").toString());
     }
 
     @Test
-    void workspaceRootMustContainTheInput(@TempDir Path tmp) throws IOException {
+    void removedWorkspaceRootIsRejected(@TempDir Path tmp) throws IOException {
         Path in = project(tmp.resolve("app"));
         Path elsewhere = Files.createDirectories(tmp.resolve("elsewhere"));
         assertNotEquals(0, run("-i", in.toString(), "-o", tmp.resolve("out").toString(),
                         "--workspace-root", elsewhere.toString()),
                 "an input outside the workspace root would need absolute or .. keys");
         assertFalse(Files.exists(tmp.resolve("out/analysis.json")), "and nothing is written");
     }
 
     @Test
-    void workspaceRootIsRejectedWithSchemaV1(@TempDir Path tmp) throws IOException {
+    void namespaceIsRejectedWithSchemaV1(@TempDir Path tmp) throws IOException {
         Path in = project(tmp.resolve("app"));
         assertNotEquals(0, run("-i", in.toString(), "-o", tmp.resolve("out").toString(),
-                        "--schema", "v1", "--workspace-root", tmp.toString()),
+                        "--schema", "v1", "--namespace", "team"),
                 "v1 keys are absolute: the flag has nothing to relativize");
     }
+    @Test
+    void omittedIdentityFlagsDoNotReusePreviousInvocation(@TempDir Path tmp) throws Exception {
+        Path in = project(tmp.resolve("inventory"));
+        assertEquals(0, run("-i", in.toString(), "-o", tmp.resolve("first").toString(), "--app-name", "other", "--namespace", "team"));
+        assertEquals(0, run("-i", in.toString(), "-o", tmp.resolve("second").toString()));
+        assertEquals("can://inventory/inventory", application(tmp.resolve("second")).get("id").getAsString());
+    }
+
+    @Test
+    void namespaceScopesReferencesAndCache(@TempDir Path tmp) throws Exception {
+        Path in = project(tmp.resolve("repo/services/app"));
+        Files.writeString(in.resolve("application.properties"), "port=8080\n");
+        for (String ns : new String[] {"team one", "team two"}) {
+            Path out = tmp.resolve(ns);
+            assertEquals(0, run("-i", in.toString(), "-o", out.toString(), "-a", "2", "--no-build", "--no-rta",
+                    "--external-calls", "--namespace", ns, "--app-name", "widgets", "--cache-dir", tmp.resolve("cache").toString()));
+            JsonObject app = application(out);
+            assertEquals(CanId.applicationId("widgets", ns), app.get("id").getAsString());
+            assertEquals("widgets", app.get("application_name").getAsString());
+            assertEquals(ns, app.get("identity_namespace").getAsString());
+            assertTrue(app.getAsJsonObject("symbol_table").has("src/main/java/com/example/Widget.java"));
+            assertTrue(app.getAsJsonObject("artifacts").has("application.properties"));
+            assertTrue(app.has("external_symbols"));
+            assertOwnedReferences(app, CanId.applicationId("widgets", ns));
+            var analysis = com.ibm.cldk.schema.V2Json.compact().fromJson(
+                    Files.readString(out.resolve("analysis.json")), com.ibm.cldk.schema.Analysis.class);
+            var rows = com.ibm.cldk.neo4j.V2GraphProjector.project(analysis, "widgets");
+            String root = CanId.applicationId("widgets", ns);
+            for (var node : rows.nodes) {
+                if (node.value.startsWith("can://")) assertTrue(node.value.equals(root) || node.value.startsWith(root + "/"));
+            }
+            for (var edge : rows.edges) {
+                for (String id : new String[] {edge.from.value, edge.to.value}) {
+                    if (id.startsWith("can://")) assertTrue(id.equals(root) || id.startsWith(root + "/"));
+                }
+            }
+
+            assertConformsToV2Schema(out);
+        }
+    }
+
+    private static void assertOwnedReferences(JsonElement element, String root) {
+        if (element.isJsonObject()) {
+            for (var e : element.getAsJsonObject().entrySet()) {
+                if (e.getKey().startsWith("can://")) assertTrue(e.getKey().startsWith(root + "/"));
+                assertOwnedReferences(e.getValue(), root);
+            }
+        } else if (element.isJsonArray()) {
+            for (var e : element.getAsJsonArray()) assertOwnedReferences(e, root);
+        } else if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
+            String value = element.getAsString();
+            if (value.startsWith("can://")) assertTrue(value.equals(root) || value.startsWith(root + "/"), value);
+        }
+    }
+
+    @Test
+    void invalidExplicitIdentityNeverDefaults(@TempDir Path tmp) throws Exception {
+        Path in = project(tmp.resolve("app"));
+        for (String flag : new String[] {"--app-name", "--namespace"}) {
+            for (String value : new String[] {"", " ", "a/b", ".."}) {
+                assertNotEquals(0, run("-i", in.toString(), "-o", tmp.resolve("out").toString(), flag, value));
+                assertFalse(Files.exists(tmp.resolve("out/analysis.json")));
+            }
+        }
+    }
+
 }
diff --git a/src/test/java/com/ibm/cldk/L3WalaOverlaysTest.java b/src/test/java/com/ibm/cldk/L3WalaOverlaysTest.java
index f3f78f53..586646ee 100644
--- a/src/test/java/com/ibm/cldk/L3WalaOverlaysTest.java
+++ b/src/test/java/com/ibm/cldk/L3WalaOverlaysTest.java
@@ -21,13 +21,13 @@ public class L3WalaOverlaysTest {
     public void deriveApplicationIdFallsBackToCanUnknownWhenTheModuleHasNoId() throws Exception {
         // A module map from which no applicationId can be derived (its one module's id is unset)
         // must fall back to "can://unknown" -- not "can:///unknown" (the old SCHEME + "/" + "unknown"
         // spelling, back when SCHEME was "can://java") and not "can://java/unknown" (the pre-Task-1
         // shape).
         Map<String, JModule> modules = new LinkedHashMap<>();
         modules.put("src/A.java", new JModule());
 
         String applicationId = invokeDeriveApplicationId(modules);
 
-        assertEquals("can://unknown", applicationId);
+        assertEquals("can://unknown/unknown", applicationId);
     }
 }
diff --git a/src/test/java/com/ibm/cldk/WorkspaceRootNeo4jPushTest.java b/src/test/java/com/ibm/cldk/WorkspaceRootNeo4jPushTest.java
index 0c487799..fdc8d8c3 100644
--- a/src/test/java/com/ibm/cldk/WorkspaceRootNeo4jPushTest.java
+++ b/src/test/java/com/ibm/cldk/WorkspaceRootNeo4jPushTest.java
@@ -22,21 +22,21 @@ import org.junit.jupiter.api.Test;
 import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
 import org.junit.jupiter.api.io.TempDir;
 import org.neo4j.driver.AuthTokens;
 import org.neo4j.driver.Driver;
 import org.neo4j.driver.GraphDatabase;
 import org.neo4j.driver.Session;
 import org.neo4j.driver.Values;
 import org.testcontainers.containers.Neo4jContainer;
 
 /**
- * {@code --workspace-root} against a live Neo4j: the incremental push's wipe and orphan prune are
+ * Namespace identity against a live Neo4j: the incremental push's wipe and orphan prune are
  * scoped by the app's {@code can://<app>/} prefix and each module's own id, so repo-relative module
  * ids must still be pruned when their file vanishes, and must not reach another application's graph.
  *
  * <p>Needs a container runtime, so it is opt-in like {@code Neo4jBoltWriterTest}: it runs only when
  * {@code RUN_CONTAINER_TESTS} is set.
  */
 @EnabledIfEnvironmentVariable(named = "RUN_CONTAINER_TESTS", matches = ".+")
 class WorkspaceRootNeo4jPushTest {
 
     private static final String PASSWORD = "testpassword123";
@@ -85,25 +85,25 @@ class WorkspaceRootNeo4jPushTest {
     private static void writeClass(Path srcRoot, String name) throws IOException {
         Path pkg = Files.createDirectories(srcRoot.resolve("src/main/java/com/example"));
         Files.writeString(pkg.resolve(name + ".java"),
                 "package com.example;\npublic class " + name + " {\n  public int m() { return 1; }\n}\n",
                 StandardCharsets.UTF_8);
     }
 
     private static int push(Path in, Path repo, String app, Path out) {
         return new picocli.CommandLine(new CodeAnalyzer()).execute(
                 "-i", in.toString(), "-o", out.toString(), "--emit", "neo4j", "--no-build",
-                "--workspace-root", repo.toString(), "--app-name", app,
+                "--namespace", repo.getFileName().toString(), "--app-name", app,
                 "--neo4j-uri", CONTAINER.getBoltUrl(), "--neo4j-user", "neo4j", "--neo4j-password", PASSWORD);
     }
 
-    /** As {@link #push}, without {@code --workspace-root}: keys are relative to {@code in}. */
+    /** As {@link #push}, with the default namespace: keys remain relative to {@code in}. */
     private static int pushUnrooted(Path in, String app, Path out) {
         return new picocli.CommandLine(new CodeAnalyzer()).execute(
                 "-i", in.toString(), "-o", out.toString(), "--emit", "neo4j", "--no-build",
                 "--app-name", app,
                 "--neo4j-uri", CONTAINER.getBoltUrl(), "--neo4j-user", "neo4j", "--neo4j-password", PASSWORD);
     }
 
     private static long count(String cypher, Object... params) {
         try (Session s = driver.session()) {
             return s.run(cypher, Values.parameters(params)).single().get(0).asLong();
@@ -137,52 +137,41 @@ class WorkspaceRootNeo4jPushTest {
     private static void writeConfig(Path project, String... keys) throws IOException {
         Path res = Files.createDirectories(project.resolve("src/main/resources"));
         StringBuilder props = new StringBuilder();
         for (String k : keys) {
             props.append(k).append("=v\n");
         }
         Files.writeString(res.resolve("application.properties"), props.toString(), StandardCharsets.UTF_8);
     }
 
     @Test
-    void togglingWorkspaceRootLeavesNoOldKeyedArtifacts(@TempDir Path tmp) throws IOException {
+    void changingNamespacePreservesPreviousApplicationAndUsesInputRelativeKeys(@TempDir Path tmp) throws IOException {
         Path repo = tmp.resolve("repo");
         Path app = repo.resolve("services/app");
         writeClass(app, "Main");
         writeArtifacts(app, "org.example:lib");
         writeConfig(app, "server.port");
-
         assertEquals(0, pushUnrooted(app, "toggle", tmp.resolve("o1")));
         String oldPom = CanId.artifactId("toggle", "pom.xml");
-        assertEquals(1, count("MATCH (a:Artifact {id: $id}) RETURN count(a)", "id", oldPom),
-                "precondition: the unrooted push keys the artifact on its input-relative path");
-        assertTrue(count("MATCH (k:ConfigKey) WHERE k.id STARTS WITH $p RETURN count(k)",
-                "p", oldPom.replace("pom.xml", "src/main/resources/application.properties")) > 0,
-                "precondition: the config file minted a key");
-
+        assertEquals(1, count("MATCH (a:Artifact {id: $id}) RETURN count(a)", "id", oldPom));
         assertEquals(0, push(app, repo, "toggle", tmp.resolve("o2")));
-
-        String rooted = artifactPrefix("toggle") + "services/app/";
-        assertEquals(0, count("MATCH (a:Artifact) WHERE a.id STARTS WITH $p AND NOT a.id STARTS WITH $r "
-                + "RETURN count(a)", "p", artifactPrefix("toggle"), "r", rooted),
-                "no artifact keyed on the old input-relative path survives");
-        assertEquals(0, count("MATCH (k:ConfigKey) WHERE k.id STARTS WITH $p AND NOT k.id STARTS WITH $r "
-                + "RETURN count(k)", "p", artifactPrefix("toggle"), "r", rooted),
-                "no config key keyed on the old input-relative path survives");
-        long artifacts = count("MATCH (a:Artifact) WHERE a.id STARTS WITH $r RETURN count(a)", "r", rooted);
-        assertTrue(artifacts > 0, "the rooted push wrote its artifacts");
-        assertEquals(artifacts, count("MATCH (:JApplication {id: $app})-[r:HAS_ARTIFACT]->() RETURN count(r)",
-                "app", CanId.applicationId("toggle")), "one HAS_ARTIFACT per artifact the run emitted");
-        assertEquals(1, count("MATCH (a:Artifact)-[r:DECLARES_DEPENDENCY]->(:Package {id: $pkg}) "
-                + "WHERE a.id STARTS WITH $p RETURN count(r)",
-                "p", artifactPrefix("toggle"), "pkg", CanId.purlMaven("org.example", "lib")),
-                "the dependency is declared once, by the rooted manifest");
+        assertEquals(1, count("MATCH (a:Artifact {id: $id}) RETURN count(a)", "id", oldPom),
+                "the prior namespace is outside reconciliation scope");
+        String root = CanId.applicationId("toggle", "repo");
+        String pom = CanId.artifactId("toggle", "pom.xml", "repo");
+        assertEquals(1, count("MATCH (:JApplication {id: $app})-[:HAS_ARTIFACT]->(:Artifact {id: $pom}) RETURN count(*)",
+                "app", root, "pom", pom));
+        String module = CanId.moduleId(root, "src/main/java/com/example/Main.java");
+        assertEquals(1, count("MATCH (:JModule {id: $id}) RETURN count(*)", "id", module),
+                "same-file content hashes in another namespace cannot suppress module insertion");
+        assertEquals(1, count("MATCH (:Artifact {id: $id})-[:DECLARES_DEPENDENCY]->(:Package {id: $pkg}) RETURN count(*)",
+                "id", pom, "pkg", CanId.purlMaven("org.example", "lib")));
     }
 
     @Test
     void aChangedManifestDropsItsRemovedDependencyAndConfigKey(@TempDir Path tmp) throws IOException {
         Path app = tmp.resolve("app");
         writeClass(app, "Main");
         writeArtifacts(app, "org.example:kept", "org.example:dropped");
         writeConfig(app, "kept.key", "dropped.key");
         assertEquals(0, pushUnrooted(app, "edit", tmp.resolve("o1")));
 
@@ -214,21 +203,21 @@ class WorkspaceRootNeo4jPushTest {
         writeClass(app, "Main");
         writeArtifacts(app, "org.example:lib");
         assertEquals(0, pushUnrooted(app, "poly", tmp.resolve("o1")));
 
         // Seed what codeanalyzer-python would have written: a claim on the shared pom.xml (with a
         // pypi dependency edge), plus an artifact and config key Java never emits.
         String pom = CanId.artifactId("poly", "pom.xml");
         String pyOnly = CanId.artifactId("poly", "pyproject.toml");
         String pyKey = CanId.configKeyId(pyOnly, "tool.name");
         run("MATCH (a:Artifact {id: $pom}) SET a:PyCanNode "
-                + "MERGE (app:PyApplication {id: 'can://poly'}) MERGE (app)-[:HAS_ARTIFACT]->(a) "
+                + "MERGE (app:PyApplication {id: 'can://poly/poly'}) MERGE (app)-[:HAS_ARTIFACT]->(a) "
                 + "MERGE (p:Package {id: 'pkg:pypi/requests'}) MERGE (a)-[:DECLARES_DEPENDENCY {_k: 'main'}]->(p) "
                 + "MERGE (o:Artifact:PyCanNode {id: $py}) MERGE (app)-[:HAS_ARTIFACT]->(o) "
                 + "MERGE (k:ConfigKey:PyCanNode {id: $key}) MERGE (o)-[:DEFINES_CONFIG]->(k) "
                 + "MERGE (o)-[:DECLARES_DEPENDENCY {_k: 'main'}]->(p)",
                 "pom", pom, "py", pyOnly, "key", pyKey);
 
         // Java now stops emitting pom.xml: it releases its claim but must not delete a node Python holds.
         Files.delete(app.resolve("pom.xml"));
         assertEquals(0, pushUnrooted(app, "poly", tmp.resolve("o2")));
 
@@ -269,21 +258,21 @@ class WorkspaceRootNeo4jPushTest {
     @Test
     void aConfigKeyAnotherAnalyzerClaimsSurvivesJavaDroppingIt(@TempDir Path tmp) throws IOException {
         Path app = tmp.resolve("app");
         writeClass(app, "Main");
         writeConfig(app, "shared.key", "other");
         assertEquals(0, pushUnrooted(app, "ckshare", tmp.resolve("o1")));
 
         String props = CanId.artifactId("ckshare", "src/main/resources/application.properties");
         String key = CanId.configKeyId(props, "shared.key");
         run("MATCH (k:ConfigKey {id: $key}) SET k:PyCanNode "
-                + "MERGE (b:PyBodyNode {id: 'can://ckshare/python/x.py/f@1:1'}) MERGE (b)-[:PY_USES_CONFIG]->(k)",
+                + "MERGE (b:PyBodyNode {id: 'can://ckshare/ckshare/python/x.py/f@1:1'}) MERGE (b)-[:PY_USES_CONFIG]->(k)",
                 "key", key);
 
         writeConfig(app, "other");
         assertEquals(0, pushUnrooted(app, "ckshare", tmp.resolve("o2")));
 
         assertEquals(1, count("MATCH (k:ConfigKey:PyCanNode {id: $id}) WHERE NOT k:JCanNode RETURN count(k)",
                 "id", key), "the key survives with Python's claim and without Java's");
         assertEquals(1, count("MATCH (:Artifact {id: $a})-[:DEFINES_CONFIG]->(:ConfigKey {id: $k}) RETURN count(*)",
                 "a", props, "k", key), "its DEFINES_CONFIG stays");
         assertEquals(1, count("MATCH ()-[r:PY_USES_CONFIG]->(:ConfigKey {id: $k}) RETURN count(r)", "k", key),
@@ -292,21 +281,21 @@ class WorkspaceRootNeo4jPushTest {
 
     @Test
     void anArtifactAnUnmarkedSiblingInventoriesSurvivesJavaDroppingIt(@TempDir Path tmp) throws IOException {
         Path app = tmp.resolve("app");
         writeClass(app, "Main");
         writeArtifacts(app, "org.example:lib");
         assertEquals(0, pushUnrooted(app, "oldsib", tmp.resolve("o1")));
 
         // A pre-1.5.0 codeanalyzer-python: inventories the file via HAS_ARTIFACT, puts no marker on it.
         String pom = CanId.artifactId("oldsib", "pom.xml");
-        run("MATCH (a:Artifact {id: $pom}) MERGE (p:PyApplication {id: 'can://oldsib'}) "
+        run("MATCH (a:Artifact {id: $pom}) MERGE (p:PyApplication {id: 'can://oldsib/oldsib'}) "
                 + "MERGE (p)-[:HAS_ARTIFACT]->(a)", "pom", pom);
 
         Files.delete(app.resolve("pom.xml"));
         assertEquals(0, pushUnrooted(app, "oldsib", tmp.resolve("o2")));
 
         assertEquals(1, count("MATCH (:PyApplication)-[:HAS_ARTIFACT]->(a:Artifact {id: $id}) "
                 + "WHERE NOT a:JCanNode RETURN count(a)", "id", pom),
                 "the artifact and the sibling's HAS_ARTIFACT survive; only Java's claim is released");
     }
 
@@ -314,30 +303,30 @@ class WorkspaceRootNeo4jPushTest {
     void codeEdgesIntoConfigFollowAConfigOnlyChange(@TempDir Path tmp) throws IOException {
         Path app = tmp.resolve("app");
         Path pkg = Files.createDirectories(app.resolve("src/main/java/com/example"));
         Files.writeString(pkg.resolve("Main.java"), "package com.example;\npublic class Main {\n"
                 + "  public String port() { return System.getenv(\"PORT\"); }\n}\n", StandardCharsets.UTF_8);
         Files.writeString(app.resolve(".env"), "OTHER=1\n", StandardCharsets.UTF_8);
         assertEquals(0, pushUnrooted(app, "cfguse", tmp.resolve("o1")));
         String env = CanId.artifactId("cfguse", ".env");
         assertEquals(0, count("MATCH ()-[r:J_USES_CONFIG]->(k) WHERE k.id STARTS WITH $p RETURN count(r)",
                 "p", env), "precondition: PORT is undeclared");
-        assertEquals(1, count("MATCH (:JApplication {id: 'can://cfguse'})-[r:J_READS_CONFIG_UNRESOLVED {key: 'PORT'}]->() "
+        assertEquals(1, count("MATCH (:JApplication {id: 'can://cfguse/cfguse'})-[r:J_READS_CONFIG_UNRESOLVED {key: 'PORT'}]->() "
                 + "RETURN count(r)"), "precondition: the read is unresolved");
 
         // Only the config changes; Main.java's content_hash is identical.
         Files.writeString(app.resolve(".env"), "PORT=8080\n", StandardCharsets.UTF_8);
         assertEquals(0, pushUnrooted(app, "cfguse", tmp.resolve("o2")));
 
         assertEquals(1, count("MATCH ()-[r:J_USES_CONFIG]->(:ConfigKey {id: $k}) RETURN count(r)",
                 "k", CanId.configKeyId(env, "PORT")), "the newly declared key gains its read");
-        assertEquals(0, count("MATCH (:JApplication {id: 'can://cfguse'})-[r:J_READS_CONFIG_UNRESOLVED {key: 'PORT'}]->() "
+        assertEquals(0, count("MATCH (:JApplication {id: 'can://cfguse/cfguse'})-[r:J_READS_CONFIG_UNRESOLVED {key: 'PORT'}]->() "
                 + "RETURN count(r)"), "the stale unresolved read is gone");
 
         Files.writeString(app.resolve(".env"), "OTHER=1\n", StandardCharsets.UTF_8);
         assertEquals(0, pushUnrooted(app, "cfguse", tmp.resolve("o3")));
         assertEquals(0, count("MATCH ()-[r:J_USES_CONFIG]->(k) WHERE k.id STARTS WITH $p RETURN count(r)",
                 "p", env), "removing the key drops its read");
     }
 
     @Test
     void aLockEdgeFollowsAManifestChangeWithAnUnchangedLockfile(@TempDir Path tmp) throws IOException {
@@ -377,35 +366,35 @@ class WorkspaceRootNeo4jPushTest {
         long before = count(snapshot);
 
         assertEquals(0, pushUnrooted(app, "idem", tmp.resolve("o2")));
 
         assertEquals(before, count(snapshot), "a re-push with no change leaves node and edge counts unchanged");
         assertEquals(1, count("MATCH (:Artifact {id: $a})-[r:DECLARES_DEPENDENCY]->() RETURN count(r)",
                 "a", CanId.artifactId("idem", "pom.xml")), "no keyed edge is doubled");
     }
 
     @Test
-    void preRekeyArtifactsAreReleasedToo(@TempDir Path tmp) throws IOException {
+    void legacyArtifactsRequireExplicitRetirement(@TempDir Path tmp) throws IOException {
         Path app = tmp.resolve("app");
         writeClass(app, "Main");
         writeArtifacts(app, "org.example:lib");
         // What a 3.0.x-3.1.0 push left behind: the artifact keyed `can://artifact/<app>/...`.
         String legacy = "can://artifact/legacy/pom.xml";
         run("MERGE (a:Artifact:JCanNode {id: $id}) MERGE (k:ConfigKey:JCanNode {id: $key}) "
                 + "MERGE (a)-[:DEFINES_CONFIG]->(k) "
                 + "MERGE (p:Package {id: 'pkg:maven/org.example/lib'}) MERGE (a)-[:DECLARES_DEPENDENCY {_k: 'main'}]->(p)",
                 "id", legacy, "key", legacy + "@key/x");
 
         assertEquals(0, pushUnrooted(app, "legacy", tmp.resolve("o1")));
 
-        assertEquals(0, count("MATCH (n) WHERE n.id STARTS WITH 'can://artifact/legacy/' RETURN count(n)"),
-                "the pre-re-key artifact and its config key are gone");
+        assertEquals(2, count("MATCH (n) WHERE n.id STARTS WITH 'can://artifact/legacy/' RETURN count(n)"),
+                "legacy data is outside the selected canonical application");
         assertEquals(1, count("MATCH (n:Artifact {id: $id}) RETURN count(n)",
                 "id", CanId.artifactId("legacy", "pom.xml")), "the current artifact is written");
     }
 
     @Test
     void aV1PushLeavesV2ArtifactsAlone(@TempDir Path tmp) throws IOException {
         Path app = tmp.resolve("app");
         writeClass(app, "Main");
         writeArtifacts(app, "org.example:lib");
         assertEquals(0, pushUnrooted(app, "gen", tmp.resolve("o1")));
@@ -453,34 +442,34 @@ class WorkspaceRootNeo4jPushTest {
         Path repo = tmp.resolve("repo");
         Path orders = repo.resolve("services/orders");
         Path billing = repo.resolve("services/billing");
         writeClass(orders, "Keep");
         writeClass(orders, "Gone");
         writeClass(billing, "Gone");
 
         assertEquals(0, push(orders, repo, "orders", tmp.resolve("o1")));
         assertEquals(0, push(billing, repo, "billing", tmp.resolve("o2")));
 
-        String key = "services/orders/src/main/java/com/example/";
-        String gone = CanId.moduleId(CanId.applicationId("orders"), key + "Gone.java");
-        String keep = CanId.moduleId(CanId.applicationId("orders"), key + "Keep.java");
-        String billingGone = CanId.moduleId(CanId.applicationId("billing"),
-                "services/billing/src/main/java/com/example/Gone.java");
+        String key = "src/main/java/com/example/";
+        String gone = CanId.moduleId(CanId.applicationId("orders", "repo"), key + "Gone.java");
+        String keep = CanId.moduleId(CanId.applicationId("orders", "repo"), key + "Keep.java");
+        String billingGone = CanId.moduleId(CanId.applicationId("billing", "repo"),
+                "src/main/java/com/example/Gone.java");
         assertEquals(1, count("MATCH (m:JModule {id: $id}) RETURN count(m)", "id", gone),
                 "precondition: the module is pushed under its repo-relative id");
         long billingNodes = count("MATCH (n) WHERE n.id STARTS WITH $p RETURN count(n)",
-                "p", CanId.applicationId("billing") + "/");
+                "p", CanId.applicationId("billing", "repo") + "/");
         assertTrue(billingNodes > 0, "precondition: the other app is in the same database");
 
         Files.delete(orders.resolve("src/main/java/com/example/Gone.java"));
         assertEquals(0, push(orders, repo, "orders", tmp.resolve("o3")));
 
         assertEquals(0, count("MATCH (n) WHERE n.id = $id OR n.id STARTS WITH $p RETURN count(n)",
                 "id", gone, "p", gone + "/"), "the vanished module and its declarations are pruned");
         assertEquals(1, count("MATCH (m:JModule {id: $id}) RETURN count(m)", "id", keep),
                 "the surviving module stays");
         assertEquals(1, count("MATCH (m:JModule {id: $id}) RETURN count(m)", "id", billingGone),
                 "a same-named file in another app is a different node and is not touched");
         assertEquals(billingNodes, count("MATCH (n) WHERE n.id STARTS WITH $p RETURN count(n)",
-                "p", CanId.applicationId("billing") + "/"), "the other app's graph is unchanged");
+                "p", CanId.applicationId("billing", "repo") + "/"), "the other app's graph is unchanged");
     }
 }
diff --git a/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java b/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java
index 097010e3..107ba941 100644
--- a/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java
+++ b/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java
@@ -18,20 +18,42 @@ import org.junit.jupiter.api.Test;
  * <p>Scoping on the module's own {@code can://} id fixes both at once, because the id is a path —
  * {@code can://<app>/java/<file>} — so a prefix match is language-, application- and module-scoped
  * simultaneously.
  *
  * <p>Asserted on the statement text rather than through a live database: that path needs Docker and
  * does not run everywhere, while the property that makes the fix correct is entirely in the
  * predicate.
  */
 class BoltWriterPurgeTest {
 
+    @Test
+    void existingAnchorMustHaveExactMarkerAndRawIdentity() {
+        var identity = java.util.Map.<String, Object>of("identity_version", 2,
+                "application_name", "app", "identity_namespace", "team");
+        BoltWriter.requireCompatibleApplicationIdentity("can://team/app", identity, identity);
+        for (var legacy : java.util.List.of(java.util.Map.<String, Object>of(),
+                java.util.Map.<String, Object>of("identity_version", 2.5, "application_name", "app", "identity_namespace", "team"),
+                java.util.Map.<String, Object>of("identity_version", 1, "application_name", "app", "identity_namespace", "team"),
+                java.util.Map.<String, Object>of("identity_version", 2, "application_name", "app", "identity_namespace", "other"))) {
+            org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
+                    () -> BoltWriter.requireCompatibleApplicationIdentity("can://team/app", identity, legacy));
+        }
+        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
+                () -> BoltWriter.requireCompatibleApplicationIdentity("can://team/app", java.util.Map.of(), identity));
+    }
+
+    @Test
+    void incrementalHashesAreScopedToSelectedApplication() {
+        assertTrue(BoltWriter.MODULE_HASHES_V2.contains("{id: $appId}"));
+        assertTrue(BoltWriter.MODULE_HASHES_V2.contains("J_HAS_MODULE"));
+    }
+
     @Test
     void thePurgeIsScopedByCanIdPrefixAndNotByTheRetiredProperty() {
         for (String stmt : new String[] {BoltWriter.PURGE_MODULE_EDGES_V2, BoltWriter.PURGE_VANISHED_NODES_V2}) {
             assertFalse(stmt.contains("_module"),
                     "the purge must not reference the retired property: " + stmt);
             assertTrue(stmt.contains("x.id = $mid"),
                     "the module itself is matched by equality: " + stmt);
             assertTrue(stmt.contains("STARTS WITH $pre"),
                     "its declarations are matched by id prefix: " + stmt);
         }
@@ -56,40 +78,26 @@ class BoltWriterPurgeTest {
         String moduleId = CanId.moduleId(app, "src/Foo.java");
         String prefix = BoltWriter.descendantPrefix(moduleId);
         assertTrue(prefix.endsWith("/"), prefix);
         assertFalse((moduleId + "X").startsWith(prefix),
                 "a sibling module whose path merely starts the same way must not match");
         assertTrue(CanId.childId(CanId.childId(moduleId, "Foo"), "m()").startsWith(prefix),
                 "a real declaration of this module must match");
     }
 
     @Test
-    void theOrphanPruneMatchesAV2RootByIdAndALegacyV1RootByNameButNotAnotherApplication() {
-        // v2 roots are keyed on `id` -- unique-constrained and exact -- but legacy v1 roots
-        // (GraphProjector.java) never write `id`, only `name`. An id-only match orphans a prior v1
-        // graph instead of pruning it; an ungated `a.name =` disjunct reaches every v2 root
-        // carrying that display name, including roots this analyzer never minted, since `name`
-        // stopped being unique once the id re-key landed. Note this is scoping hygiene, not
-        // disambiguation: CanId.applicationId is "can://" + appName, so two services sharing an
-        // --app-name share an id and are one node either way.
+    void orphanPruneNeverFallsBackToLegacyName() {
         String stmt = BoltWriter.PRUNE_VANISHED_UNITS_V2;
-        assertTrue(stmt.contains("a.id = $appId"),
-                "must reach a v2 root of THIS app by its unique id: " + stmt);
-        assertTrue(stmt.contains("a.id IS NULL AND a.name = $appName"),
-                "must reach a legacy v1 root (no id) by name, guarded by id IS NULL: " + stmt);
-        // Every `a.name =` must sit inside the `a.id IS NULL` guard: an unguarded one reaches v2
-        // roots this analyzer never minted that merely carry the same display name.
-        assertFalse(stmt.replace("a.id IS NULL AND a.name = $appName", "").contains("a.name ="),
-                "a.name must never be matched outside the a.id IS NULL guard -- that would reach "
-                        + "any v2 root carrying this display name, not just this app's: " + stmt);
-        assertFalse(stmt.contains("{name:"),
-                "the prune must not property-match :JApplication by its no-longer-unique name: " + stmt);
+        assertTrue(stmt.contains("a.id = $appId"));
+        assertFalse(stmt.contains("a.name"));
+        org.junit.jupiter.api.Assertions.assertEquals(java.util.List.of("can://team/app/artifact/"),
+                BoltWriter.artifactPrefixes("can://team/app", "app"));
     }
 
     @Test
     void aCanIdIsRecognizedAndAVersionOneIdIsNot() {
         // What selects the purge path at all: v1 ids are FQN-shaped and carry no application
         // segment, so there is nothing to prefix and the purge is skipped rather than mis-scoped.
         assertTrue(RowBuilder.isCanId(CanId.moduleId(CanId.applicationId("app"), "src/Foo.java")));
         assertFalse(RowBuilder.isCanId("com.l4.Arity#caller(int, int)@22:16-22:25"));
         assertFalse(RowBuilder.isCanId(null));
     }
diff --git a/src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java b/src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java
new file mode 100644
index 00000000..2ee7b680
--- /dev/null
+++ b/src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java
@@ -0,0 +1,49 @@
+package com.ibm.cldk.neo4j;
+
+import static org.junit.jupiter.api.Assertions.assertEquals;
+
+import com.google.gson.JsonParser;
+import java.io.InputStreamReader;
+import java.nio.charset.StandardCharsets;
+import java.util.List;
+import java.util.Map;
+import org.junit.jupiter.api.Test;
+
+class CanonicalIdentityRowsTest {
+    @Test
+    void conflictingCanonicalEntityPropertiesAreRejected() {
+        RowBuilder builder = new RowBuilder();
+        String id = "can://team/app/java/Foo.java/Foo";
+        builder.node(List.of("JSymbol"), "id", id, Map.of("kind", "class"));
+        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
+                () -> builder.node(List.of("JType"), "id", id, Map.of("kind", "method")));
+    }
+
+    @Test
+    void canonicalIdsDeduplicateAcrossLabelsWithoutCollapsingEdgeKindsOrSites() throws Exception {
+        var fixture = JsonParser.parseReader(new InputStreamReader(
+                getClass().getResourceAsStream("/identity/namespaces.json"), StandardCharsets.UTF_8))
+                .getAsJsonObject().getAsJsonObject("duplicate_module_rows");
+        RowBuilder builder = new RowBuilder();
+        GraphRows.NodeRef first = null;
+        GraphRows.NodeRef second = null;
+        for (var row : fixture.getAsJsonArray("rows")) {
+            String id = row.getAsJsonObject().get("module_id").getAsString();
+            var ref = builder.node(List.of("JModule"), "id", id, Map.of("id", id));
+            if (first == null) first = ref;
+            else if (!first.value.equals(id)) second = ref;
+        }
+        assertEquals(fixture.get("expected_unique_id_count").getAsInt(), builder.finish().nodes.size());
+        var alternate = builder.node(List.of("JSymbol"), "id", first.value, Map.of("id", first.value));
+        builder.keyedEdge("J_CALLS", first, second, Map.of(), "site1");
+        builder.keyedEdge("J_CALLS", alternate, second, Map.of(), "site1");
+        builder.keyedEdge("J_CALLS", first, second, Map.of(), "site2");
+        builder.keyedEdge("J_RESOLVES_TO", first, second, Map.of(), "site1");
+        var rows = builder.finish();
+        assertEquals(2, rows.nodes.size());
+        assertEquals(3, rows.edges.size());
+        org.junit.jupiter.api.Assertions.assertTrue(rows.nodes.stream()
+                .filter(n -> n.value.equals(alternate.value)).findFirst().orElseThrow()
+                .labels.containsAll(List.of("JModule", "JSymbol", "JCanNode")));
+    }
+}
diff --git a/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java b/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java
index 84964c45..326aa544 100644
--- a/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java
+++ b/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java
@@ -141,39 +141,33 @@ class CypherWriterStreamingTest {
         // v2 roots are keyed on `id`, which is unique-constrained and exact -- but legacy v1 roots
         // (GraphProjector.java) never write `id` at all, only `name`. An id-only match would orphan
         // a prior v1 graph of the same app instead of replacing it; an ungated `a.name =` disjunct
         // reaches every v2 root carrying that display name, including roots this analyzer never
         // minted, since `name` stopped being unique once the id re-key landed. The predicate must
         // do both without regressing either: `a.id = <id> OR (a.id IS NULL AND a.name = <name>)`.
         // It does not separate two services sharing an --app-name -- CanId.applicationId is
         // "can://" + appName, so those share an id and are one node regardless.
         String out = CypherWriter.renderCypher(new RowBuilder().finish(), "app");
 
-        assertTrue(out.contains("a.id = 'can://app'"),
+        assertTrue(out.contains("a.id = 'can://app/app'"),
                 "must reach a v2 root of THIS app by its unique id, got: " + out);
-        assertTrue(out.contains("a.id IS NULL AND a.name = 'app'"),
-                "must reach a legacy v1 root (no id) by name, guarded by id IS NULL, got: " + out);
-        // Every `a.name =` in the predicate must be inside the `a.id IS NULL AND ...` guard: an
-        // unguarded one reaches v2 roots this analyzer never minted that carry the same name.
-        assertFalse(out.replace("a.id IS NULL AND a.name = 'app'", "").contains("a.name ="),
-                "a.name must never be matched outside the a.id IS NULL guard -- that would reach "
-                        + "any v2 root carrying this display name, not just this app's, got: " + out);
+        assertFalse(out.contains("a.name ="), "legacy roots require explicit retirement");
         assertFalse(out.contains("JApplication {name:"),
                 "the wipe must not property-match :JApplication by its no-longer-unique name: " + out);
     }
 
     @Test
     void anEmptyApplicationNameIsRefusedRatherThanEmittingAnUnscopedWipe() {
         // `STARTS WITH ''` matches every node in the database, so an empty --app-name would turn
         // the prefix sweep into "delete every can:// node any analyzer ever wrote". There is no
         // sane statement to emit here, so refuse to emit one at all (same call as
         // codeanalyzer-python's application_prefix). Blank is empty with extra steps.
         for (String name : new String[] {"", "   ", null}) {
             assertThrows(IllegalArgumentException.class,
                     () -> CypherWriter.renderCypher(new RowBuilder().finish(), name),
                     "an unscoped destructive statement must never be rendered, app name: " + name);
         }
         // ... and the guard lives on the prefix itself, so every future caller inherits it.
-        assertEquals("can://app/", CypherWriter.applicationPrefix("app"),
+        assertEquals("can://app/app/", CypherWriter.applicationPrefix("app"),
                 "the swept prefix must end in the separator, or `can://appX` is in scope too");
     }
 }
diff --git a/src/test/java/com/ibm/cldk/neo4j/V2Neo4jSchemaConformanceTest.java b/src/test/java/com/ibm/cldk/neo4j/V2Neo4jSchemaConformanceTest.java
index ec93318d..5d674a13 100644
--- a/src/test/java/com/ibm/cldk/neo4j/V2Neo4jSchemaConformanceTest.java
+++ b/src/test/java/com/ibm/cldk/neo4j/V2Neo4jSchemaConformanceTest.java
@@ -251,30 +251,30 @@ public class V2Neo4jSchemaConformanceTest {
         }
         assertTrue(sawCfg, "no J_CFG_NEXT edges — the L3 cfg overlay did not project");
         assertTrue(sawHasBody, "no J_HAS_BODY_NODE edges");
     }
 
     @Test
     public void wipeCoversBothGenerationsSoV2ReplacesAPriorV1Graph() {
         String cypher = CypherWriter.renderCypher(rows, APP_NAME);
         assertTrue(cypher.contains("J_HAS_UNIT|J_HAS_MODULE"),
                 "the wipe must traverse both generations' unit relationship");
-        assertTrue(cypher.contains("MATCH (s:JSymbol) WHERE NOT (s)--() DELETE s"),
+        assertFalse(cypher.contains("MATCH (s:JSymbol) WHERE NOT (s)--() DELETE s"),
                 "the wipe must sweep orphaned symbols (v1 import-materialized type stubs)");
         // The v1 path is NOT reachable by the can:// prefix sweep -- v1 ids are FQNs and v1 roots
         // carry no `id` at all -- so replacing the containment traversal with the sweep orphans
         // every prior v1 graph. That was tried on this branch and reverted; both must be present.
         assertTrue(cypher.contains("OPTIONAL MATCH (a)-[:J_HAS_UNIT|J_HAS_MODULE]->(c)")
                         && cypher.contains("OPTIONAL MATCH (c)-" + CypherWriter.DESCENDANTS + "->(x)")
                         && cypher.contains("DETACH DELETE x, c, a;"),
                 "the v1-reaching containment traversal must survive alongside the prefix sweep: " + cypher);
-        assertTrue(cypher.contains("a.id IS NULL AND a.name = '" + APP_NAME + "'"),
+        assertFalse(cypher.contains("a.id IS NULL AND a.name = '" + APP_NAME + "'"),
                 "a legacy v1 root has no id and is reachable only by the guarded name branch: " + cypher);
         for (String rel : new String[] {"J_HAS_CALLSITE", "J_HAS_COMMENT", "J_HAS_PARAMETER",
                 "J_DECLARES", "J_HAS_METHOD", "J_HAS_BODY_NODE"}) {
             assertTrue(CypherWriter.DESCENDANTS.contains(rel),
                     "wipe/prune descendant traversal must include " + rel);
         }
     }
 
     @Test
     void l4OverlayProjectsParamAndSummaryEdges() {
@@ -463,23 +463,23 @@ public class V2Neo4jSchemaConformanceTest {
     @Test
     void theWipeReachesThisAppsArtifactsAndConfigKeysButNeverAPackage() {
         // The deliberate widening (#244), mirroring codeanalyzer-python: :Artifact/:ConfigKey are
         // under `can://<app>/` now that the app is the outermost id segment, so the snapshot's
         // prefix sweep rebuilds them instead of letting stale ones accumulate forever with nothing
         // ever cleaning them up. The accepted cost is one behavioural widening: a sibling-language
         // analyzer's edge into a shared :Artifact is dropped by a Java snapshot and restored on that
         // analyzer's next push. :Package (a `pkg:` purl) sits under no application, so it stays out
         // by construction -- assert that, because it is the only thing left holding the line.
         String cypher = CypherWriter.renderCypher(rows, APP_NAME);
-        String prefix = "can://" + APP_NAME + "/";
+        String prefix = CanId.applicationId(APP_NAME) + "/";
 
-        assertTrue(cypher.contains("MATCH (x:" + RowBuilder.CAN_NODE + ") WHERE x.id = 'can://" + APP_NAME
+        assertTrue(cypher.contains("MATCH (x:" + RowBuilder.CAN_NODE + ") WHERE x.id = '" + CanId.applicationId(APP_NAME)
                         + "' OR x.id STARTS WITH '" + prefix + "'"),
                 "the wipe must sweep the whole app prefix, rooted on the label-anchored index: " + cypher);
         assertTrue(cypher.contains("CALL { WITH x DETACH DELETE x } IN TRANSACTIONS OF 1000 ROWS;"),
                 "the prefix sweep must batch, or a large app's wipe is one unbounded transaction: " + cypher);
 
         // Not "an id that looks like an artifact id" -- the actual rows the projector emitted.
         int artifacts = 0;
         int configKeys = 0;
         int packages = 0;
         for (NodeRow n : rows.nodes) {
diff --git a/src/test/java/com/ibm/cldk/schema/CanIdTest.java b/src/test/java/com/ibm/cldk/schema/CanIdTest.java
index 38f0cb47..02d8f9a1 100644
--- a/src/test/java/com/ibm/cldk/schema/CanIdTest.java
+++ b/src/test/java/com/ibm/cldk/schema/CanIdTest.java
@@ -6,76 +6,97 @@ import static org.junit.jupiter.api.Assertions.assertTrue;
 import java.util.List;
 import org.junit.jupiter.api.Test;
 
 /**
  * Tests for canonical schema v2 {@code can://} id construction (see the design spec,
  * decision D8: {@code can://<app>/java/<file>/<type>/<signature>} with {@code @<tag>} ordinals,
  * app outermost).
  */
 class CanIdTest {
 
+    @Test
+    void namespaceFixtureAndInvalidNames() throws Exception {
+        var fixture = com.google.gson.JsonParser.parseReader(new java.io.InputStreamReader(
+                getClass().getResourceAsStream("/identity/namespaces.json"), java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject();
+        for (var row : fixture.getAsJsonArray("roots")) {
+            var r = row.getAsJsonObject();
+            String ns = r.get("namespace").isJsonNull() ? null : r.get("namespace").getAsString();
+            assertEquals(r.get("expected_root").getAsString(), CanId.applicationId(r.get("application_name").getAsString(), ns));
+        }
+        for (var row : fixture.getAsJsonArray("invalid")) {
+            String value = row.getAsJsonObject().get("value").getAsString();
+            org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> CanId.applicationId(value));
+            org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> CanId.applicationId("app", value));
+        }
+        assertEquals("can://team/%21%27%28%29%2A~", CanId.applicationId("!'()*~", "team"));
+        for (String value : List.of("\u00a0", "\u2007", "\u202f", "\u0085")) {
+            org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> CanId.applicationId(value));
+        }
+        assertEquals("can://team/%F0%9F%98%80", CanId.applicationId("😀", "team"));
+    }
+
     @Test
     void applicationIdPutsTheAppOutermost() {
-        assertEquals("can://daytrader8", CanId.applicationId("daytrader8"));
+        assertEquals("can://daytrader8/daytrader8", CanId.applicationId("daytrader8"));
     }
 
     @Test
     void moduleIdNestsTheLanguageUnderTheApp() {
         String app = CanId.applicationId("daytrader8");
-        assertEquals("can://daytrader8/java/src/Foo.java", CanId.moduleId(app, "src/Foo.java"));
+        assertEquals("can://daytrader8/daytrader8/java/src/Foo.java", CanId.moduleId(app, "src/Foo.java"));
     }
 
     @Test
     void moduleId_normalizesBackslashesAndLeadingDotSlash() {
         String app = CanId.applicationId("myapp");
         assertEquals(
-                "can://myapp/java/a/b/C.java", CanId.moduleId(app, "./a\\b\\C.java"));
+                "can://myapp/myapp/java/a/b/C.java", CanId.moduleId(app, "./a\\b\\C.java"));
     }
 
     @Test
     void moduleId_keepsARepoRelativeKeyWhole() {
         // --workspace-root keys carry the path from the repository root; the leading-[./] strip must
         // only drop a `./`, never eat into the key's own first segment.
         String app = CanId.applicationId("myapp");
-        assertEquals("can://myapp/java/services/app/src/Foo.java",
+        assertEquals("can://myapp/myapp/java/services/app/src/Foo.java",
                 CanId.moduleId(app, "services/app/src/Foo.java"));
-        assertEquals("can://myapp/java/services/app/src/Foo.java",
+        assertEquals("can://myapp/myapp/java/services/app/src/Foo.java",
                 CanId.moduleId(app, "./services/app/src/Foo.java"));
     }
 
     @Test
     void childId_appendsSegmentWithSlash() {
         assertEquals(
-                "can://myapp/java/src/Foo.java/com.example.Foo",
-                CanId.childId("can://myapp/java/src/Foo.java", "com.example.Foo"));
+                "can://myapp/myapp/java/src/Foo.java/com.example.Foo",
+                CanId.childId("can://myapp/myapp/java/src/Foo.java", "com.example.Foo"));
     }
 
     @Test
     void ordinalId_appendsTagAfterAt() {
-        String callableId = "can://myapp/java/src/Foo.java/com.example.Foo/bar(int)";
+        String callableId = "can://myapp/myapp/java/src/Foo.java/com.example.Foo/bar(int)";
         assertEquals(callableId + "@15:2", CanId.ordinalId(callableId, "15:2"));
         assertEquals(callableId + "@entry", CanId.ordinalId(callableId, "entry"));
     }
 
     @Test
     void externalIdIsLanguageNeutralUnderTheApp() {
         // No `/java/` segment: @external sits where the language sits for code nodes, so a sibling
         // analyzer over the same app mints the same id and merges onto the same node (#244).
         assertEquals(
-                "can://daytrader8/@external/java.util.Map/get(java.lang.Object)",
+                "can://daytrader8/daytrader8/@external/java.util.Map/get(java.lang.Object)",
                 CanId.externalId("daytrader8", "java.util.Map", "get(java.lang.Object)"));
     }
 
     @Test
     void artifactIdNestsUnderTheAppInsteadOfAParallelScheme() {
         // Was can://artifact/<app>/<path> — a third outermost shape. Now one rule.
-        assertEquals("can://daytrader8/artifact/pom.xml", CanId.artifactId("daytrader8", "pom.xml"));
+        assertEquals("can://daytrader8/daytrader8/artifact/pom.xml", CanId.artifactId("daytrader8", "pom.xml"));
     }
 
     @Test
     void everyIdSharesTheApplicationPrefix() {
         // This is what makes the prefix-scoped delete correct, so assert it directly.
         String app = CanId.applicationId("daytrader8");
         for (String id :
                 List.of(
                         CanId.moduleId(app, "src/Foo.java"),
                         CanId.externalId("daytrader8", "java.util.Map", "get(java.lang.Object)"),
diff --git a/src/test/java/com/ibm/cldk/schema/L2SchemaOracleTest.java b/src/test/java/com/ibm/cldk/schema/L2SchemaOracleTest.java
index c0eb77b1..0b61e752 100644
--- a/src/test/java/com/ibm/cldk/schema/L2SchemaOracleTest.java
+++ b/src/test/java/com/ibm/cldk/schema/L2SchemaOracleTest.java
@@ -37,25 +37,27 @@ class L2SchemaOracleTest {
     private static final String A_TYPE = CanId.childId(CanId.moduleId(APP_ID, "A.java"), "A");
     private static final String A_F = A_TYPE + "/f()";
     private static final String A_G = A_TYPE + "/g()";
     private static final String STRING_VALUE_OF = CanId.externalId("myapp", "java.lang.String", "valueOf(int)");
     private static final String STRING_CASE_ORDER =
             CanId.externalId("myapp", "java.lang.String", "CASE_INSENSITIVE_ORDER");
 
     /** Wrap application-level members in an otherwise-minimal conformant envelope. */
     private static String payload(String applicationMembers) {
         return "{"
+                + "\"identity_version\":2,"
                 + "\"schema_version\":\"2.0.0\","
                 + "\"language\":\"java\","
                 + "\"max_level\":2,"
                 + "\"application\":{"
                 + "\"id\":\"" + APP_ID + "\","
+                + "\"application_name\":\"myapp\",\"identity_namespace\":\"myapp\","
                 + "\"kind\":\"application\","
                 + "\"symbol_table\":{}"
                 + (applicationMembers.isEmpty() ? "" : "," + applicationMembers)
                 + "}}";
     }
 
     private static Set<ValidationMessage> validate(String json) throws IOException {
         try (InputStream in = L2SchemaOracleTest.class.getResourceAsStream("/schema/analysis.v2.schema.json")) {
             assertNotNull(in, "the canonical v2 schema must be on the test classpath");
             JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V202012).getSchema(in);
diff --git a/src/test/java/com/ibm/cldk/schema/L3SchemaOracleTest.java b/src/test/java/com/ibm/cldk/schema/L3SchemaOracleTest.java
index 83be68ee..38c31b36 100644
--- a/src/test/java/com/ibm/cldk/schema/L3SchemaOracleTest.java
+++ b/src/test/java/com/ibm/cldk/schema/L3SchemaOracleTest.java
@@ -45,25 +45,27 @@ class L3SchemaOracleTest {
         String type = "{"
                 + "\"id\":\"" + TYPE_ID + "\","
                 + "\"kind\":\"class\","
                 + "\"callables\":{\"m()\":" + callable + "}}";
         String module = "{"
                 + "\"id\":\"" + MODULE_ID + "\","
                 + "\"kind\":\"module\","
                 + "\"source\":\"\","
                 + "\"types\":{\"Foo\":" + type + "}}";
         return "{"
+                + "\"identity_version\":2,"
                 + "\"schema_version\":\"2.0.0\","
                 + "\"language\":\"java\","
                 + "\"max_level\":3,"
                 + "\"application\":{"
                 + "\"id\":\"" + APP_ID + "\","
+                + "\"application_name\":\"myapp\",\"identity_namespace\":\"myapp\","
                 + "\"kind\":\"application\","
                 + "\"symbol_table\":{\"Foo.java\":" + module + "}}}";
     }
 
     private static Set<ValidationMessage> validate(String json) throws IOException {
         try (InputStream in = L3SchemaOracleTest.class.getResourceAsStream("/schema/analysis.v2.schema.json")) {
             assertNotNull(in, "the canonical v2 schema must be on the test classpath");
             JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V202012).getSchema(in);
             return schema.validate(MAPPER.readTree(json));
         }
diff --git a/src/test/java/com/ibm/cldk/schema/L4SchemaOracleTest.java b/src/test/java/com/ibm/cldk/schema/L4SchemaOracleTest.java
index ef26b345..3a199025 100644
--- a/src/test/java/com/ibm/cldk/schema/L4SchemaOracleTest.java
+++ b/src/test/java/com/ibm/cldk/schema/L4SchemaOracleTest.java
@@ -46,25 +46,27 @@ class L4SchemaOracleTest {
         String type = "{"
                 + "\"id\":\"" + TYPE_ID + "\","
                 + "\"kind\":\"class\","
                 + "\"callables\":{\"m()\":" + callable + "}}";
         String module = "{"
                 + "\"id\":\"" + MODULE_ID + "\","
                 + "\"kind\":\"module\","
                 + "\"source\":\"\","
                 + "\"types\":{\"Foo\":" + type + "}}";
         return "{"
+                + "\"identity_version\":2,"
                 + "\"schema_version\":\"2.0.0\","
                 + "\"language\":\"java\","
                 + "\"max_level\":4,"
                 + "\"application\":{"
                 + "\"id\":\"" + APP_ID + "\","
+                + "\"application_name\":\"myapp\",\"identity_namespace\":\"myapp\","
                 + "\"kind\":\"application\","
                 + "\"symbol_table\":{\"Foo.java\":" + module + "}}}";
     }
 
     private static Set<ValidationMessage> validate(String json) throws IOException {
         try (InputStream in = L4SchemaOracleTest.class.getResourceAsStream("/schema/analysis.v2.schema.json")) {
             assertNotNull(in, "the canonical v2 schema must be on the test classpath");
             JsonSchema schema = JsonSchemaFactory.getInstance(SpecVersion.VersionFlag.V202012).getSchema(in);
             return schema.validate(MAPPER.readTree(json));
         }
diff --git a/src/test/java/com/ibm/cldk/schema/V2JsonTest.java b/src/test/java/com/ibm/cldk/schema/V2JsonTest.java
index 4c644786..5f1a5db3 100644
--- a/src/test/java/com/ibm/cldk/schema/V2JsonTest.java
+++ b/src/test/java/com/ibm/cldk/schema/V2JsonTest.java
@@ -39,20 +39,33 @@ class V2JsonTest {
                         new ParserConfiguration().setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_21))
                 .parse(SOURCE)
                 .getResult()
                 .orElseThrow();
         L1BuildContext ctx = new L1BuildContext(CanId.applicationId("myapp"), FILE_KEY, SOURCE);
         Map<String, JModule> modules = new LinkedHashMap<>();
         modules.put(FILE_KEY, new ModuleBuilder(ctx).build(cu));
         return V2Json.compact().toJsonTree(V2Emitter.emit("myapp", 1, modules)).getAsJsonObject();
     }
 
+    @Test
+    void identityMetadataIsRequiredAndNotDefaultedWhenReadingOldPayloads() {
+        JsonObject json = payload();
+        assertEquals(2, json.get("identity_version").getAsInt());
+        assertEquals("myapp", json.getAsJsonObject("application").get("application_name").getAsString());
+        assertEquals("myapp", json.getAsJsonObject("application").get("identity_namespace").getAsString());
+        json.remove("identity_version");
+        Analysis legacy = V2Json.compact().fromJson(json, Analysis.class);
+        assertNull(legacy.getIdentityVersion());
+        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
+                () -> com.ibm.cldk.neo4j.V2GraphProjector.project(legacy, "myapp"));
+    }
+
     private static JsonObject module() {
         return payload().getAsJsonObject("application").getAsJsonObject("symbol_table").getAsJsonObject(FILE_KEY);
     }
 
     private static JsonObject fooType() {
         return module().getAsJsonObject("types").getAsJsonObject("Foo");
     }
 
     /** The one callable whose kind is {@code method} (the constructor is the other entry). */
     private static JsonObject theMethod() {
diff --git a/src/test/java/com/ibm/cldk/syntactic_analysis/L1CacheTest.java b/src/test/java/com/ibm/cldk/syntactic_analysis/L1CacheTest.java
index 2631f2f4..46155a2f 100644
--- a/src/test/java/com/ibm/cldk/syntactic_analysis/L1CacheTest.java
+++ b/src/test/java/com/ibm/cldk/syntactic_analysis/L1CacheTest.java
@@ -47,18 +47,28 @@ class L1CacheTest {
         Map<String, JModule> modules = new LinkedHashMap<>();
         modules.put(FILE_KEY, module);
         return modules;
     }
 
     private static String hintOf(Map<String, JModule> modules) {
         return modules.get(FILE_KEY).getTypes().get("Foo").getCallables().get("m()")
                 .getBody().get("4:5").getDeclaringTypeHint();
     }
 
+    @Test
+    void missingIdentityMarkerCannotReuseOldCache(@TempDir Path cacheDir) throws Exception {
+        L1Cache.save(cacheDir, APP, VERSION, modulesWithHint("hint"));
+        Path path = L1Cache.fileIn(cacheDir);
+        String json = java.nio.file.Files.readString(path).replace("\"identity_version\":2,", "");
+        java.nio.file.Files.writeString(path, json);
+        org.junit.jupiter.api.Assertions.assertTrue(L1Cache.load(cacheDir, APP, VERSION).isEmpty());
+        assertEquals(json, java.nio.file.Files.readString(path), "incompatible persisted input remains read-only");
+    }
+
     @Test
     void save_thenLoad_preservesTheDeclaringTypeHint(@TempDir Path cacheDir) {
         L1Cache.save(cacheDir, APP, VERSION, modulesWithHint("java.util.Map$Entry"));
         Map<String, JModule> loaded = L1Cache.load(cacheDir, APP, VERSION);
         assertEquals("java.util.Map$Entry", hintOf(loaded),
                 "the hint must round-trip through the cache; losing it regresses the backfill on -c runs");
     }
 }
diff --git a/src/test/resources/schema/analysis.v2.schema.json b/src/test/resources/schema/analysis.v2.schema.json
index 18107ffa..efcd4e41 100644
--- a/src/test/resources/schema/analysis.v2.schema.json
+++ b/src/test/resources/schema/analysis.v2.schema.json
@@ -1,45 +1,46 @@
 {
   "$schema": "https://json-schema.org/draft/2020-12/schema",
   "$id": "https://codellm-devkit.info/schema/java/analysis.v2.schema.json",
   "title": "CLDK canonical analysis schema v2 (Java, level 1)",
   "description": "Conformance oracle for codeanalyzer-java's v2 output. Encodes the canonical CPG shape: an envelope carrying one application node, whose containment tree is named maps down to callable depth, with body nodes keyed by local id. Strict (additionalProperties: false) so an accidentally renamed or stray key fails the gate rather than silently reaching consumers. Replace with the SDK's v2 models once they exist.",
   "type": "object",
   "additionalProperties": false,
-  "required": ["schema_version", "language", "max_level", "application"],
+  "required": ["identity_version", "schema_version", "language", "max_level", "application"],
   "properties": {
+    "identity_version": { "const": 2 },
     "schema_version": { "const": "2.0.0" },
     "language": { "const": "java" },
     "max_level": { "type": "integer", "minimum": 1, "maximum": 4 },
     "k_limit": { "type": "integer", "minimum": 1 },
     "analyzer": { "$ref": "#/$defs/analyzer" },
     "application": { "$ref": "#/$defs/application" }
   },
   "$defs": {
     "analyzer": {
       "type": "object",
       "additionalProperties": false,
       "required": ["name"],
       "properties": {
         "name": { "type": "string", "minLength": 1 },
         "version": { "type": "string" }
       }
     },
 
     "canId": {
       "type": "string",
-      "pattern": "^can://[^/]+/java/",
+      "pattern": "^can://[^/]+/[^/]+/java/",
       "description": "Durable id for nodes at or above callable depth: can://<app>/java/..."
     },
     "applicationCanId": {
       "type": "string",
-      "pattern": "^can://[^/]+$",
+      "pattern": "^can://[^/]+/[^/]+$",
       "description": "Id of the application root node: can://<app>, no trailing segment."
     },
 
     "localId": {
       "type": "string",
       "pattern": "^(\\d+:\\d+(/actual_in:\\d+|/actual_out)?|@[A-Za-z0-9_:.$/-]+)$",
       "description": "Body-node id within a callable: a line:col position, an @tag for a synthetic vertex (@entry, @exit, @formal_in:<i>, @formal_out), or — at level 4 — a call site's own line:col suffixed with the actual it carries (<line:col>/actual_in:<i>, <line:col>/actual_out). The two compound forms are enumerated rather than admitted by a looser character class, so an id no builder emits is still rejected."
     },
 
     "span": {
@@ -98,23 +99,25 @@
         "is_static": { "type": "boolean" },
         "is_wildcard": { "type": "boolean" }
       }
     },
 
     "stringList": { "type": "array", "items": { "type": "string" } },
 
     "application": {
       "type": "object",
       "additionalProperties": false,
-      "required": ["id", "kind", "symbol_table"],
+      "required": ["id", "kind", "symbol_table", "application_name", "identity_namespace"],
       "properties": {
         "id": { "$ref": "#/$defs/applicationCanId" },
+        "application_name": { "type": "string", "minLength": 1 },
+        "identity_namespace": { "type": "string", "minLength": 1 },
         "kind": { "const": "application" },
         "symbol_table": {
           "type": "object",
           "propertyNames": {
             "pattern": "^(?!/)(?!.*\\.\\.).*$",
             "description": "Keys are project-relative paths: never absolute, never escaping the root."
           },
           "additionalProperties": { "$ref": "#/$defs/module" }
         },
         "call_graph": { "type": "array", "items": { "$ref": "#/$defs/callEdge" } },
@@ -273,21 +276,21 @@
           "type": "array",
           "items": { "enum": ["ssa", "points-to"] },
           "minItems": 1,
           "description": "Analysis provenance for this def-use edge. 'ssa' = syntactic scalar dep; 'points-to' = RTA heap dep (first produced by the WALA engine). A closed enum: L4 may extend it further."
         }
       }
     },
 
     "externalCanId": {
       "type": "string",
-      "pattern": "^can://[^/]+/@external/",
+      "pattern": "^can://[^/]+/[^/]+/@external/",
       "description": "Id of a symbol outside the project, so an in-project id landing in the external map fails the gate instead of validating happily. Language-NEUTRAL like artifactCanId: @external sits where the language segment sits for code nodes, so sibling analyzers over the same <app> name a library symbol identically. It therefore does NOT match canId."
     },
 
     "externalSymbol": {
       "type": "object",
       "additionalProperties": false,
       "required": ["kind", "signature", "declaring_type"],
       "properties": {
         "kind": { "enum": ["method", "constructor"] },
         "signature": { "type": "string", "minLength": 1 },
@@ -299,21 +302,21 @@
       }
     },
 
     "codeOrExternalCanId": {
       "anyOf": [{ "$ref": "#/$defs/canId" }, { "$ref": "#/$defs/externalCanId" }],
       "description": "A call target: an in-project canId, or an externalCanId when --external-calls homed it out of project. externalCanId is language-neutral and so does not match canId; this union is the fix, rather than loosening canId to admit ids that are not this analyzer's."
     },
 
     "artifactCanId": {
       "type": "string",
-      "pattern": "^can://[^/]+/artifact/",
+      "pattern": "^can://[^/]+/[^/]+/artifact/",
       "description": "Id of a repository-artifact node: nested under the app, language-neutral."
     },
 
     "artifact": {
       "type": "object",
       "additionalProperties": false,
       "required": ["id", "kind", "path", "format", "roles", "size_bytes", "sha256", "source", "extraction", "config_keys"],
       "properties": {
         "id": { "$ref": "#/$defs/artifactCanId" },
         "kind": { "const": "artifact" },
# codeanalyzer-java: dcef0a6dcc32dbcb97295eb9de06e7e86b191eda..e35d7dcab8c62119a8bdeb4288e9d7cda523fb2e
