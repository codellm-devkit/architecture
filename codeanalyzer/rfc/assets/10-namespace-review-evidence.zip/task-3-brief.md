### Task 3: Repurpose TypeScript/JavaScript PR #220

**Files:**
- Modify: `codeanalyzer-typescript/src/{cli.ts,core.ts,options/options.ts}`.
- Modify: `codeanalyzer-typescript/src/schema/{ids.ts,assignIds.ts,emit.ts,schema.ts,checker.ts}`.
- Modify: `codeanalyzer-typescript/src/build/neo4j/{project.ts,schema.ts,bolt.ts}` and generated `schema.neo4j.json`.
- Replace: `codeanalyzer-typescript/test/workspace-root.test.ts` with `test/namespace.test.ts`.
- Extend: `test/{ids.test.ts,body-ids.test.ts,schema-v2.test.ts,neo4j-prefix-scope.test.ts,neo4j-artifact-reconcile.test.ts}` and `README.md` in that repo.

**Interfaces:**
- Consumes: Task 1 fixture and TypeScript helper signatures above.
- Produces: `AnalysisOptions.namespace?: string`, `--namespace`, both language views under one application root, version/identity metadata identical to Task 2.

- [ ] **Step 1: Write failing fixture and emission tests.** Pin `.js -> javascript` and `.ts -> typescript`; assert module/body/artifact/external references share the namespace/application root and input-relative keys. Include empty namespace, a `%` input, repeated finalize/emission under different namespaces, and a dependency `declared_in` reference (currently reconstructed by fixed slash slicing).
- [ ] **Step 2: Verify failure.** Run `bun test test/ids.test.ts test/namespace.test.ts` from the repo; expect unsupported namespace/wrong-root failures.
- [ ] **Step 3: Implement the TypeScript contract.** Remove workspace-prefix arguments and published map re-keying. Thread namespace through ID assignment and finalization; replace fixed slash slicing with an ownership-aware artifact reference helper. Stamp the marker and raw identity metadata on output and graph anchors. Keep artifact reconciliation and existing local signatures unchanged.
- [ ] **Step 4: Verify.** Run `bun run typecheck`, focused tests listed above, then `bun test`. Regenerate the graph schema using `bun run gen:schema` and verify no stale root grammar. Container reconciliation tests run with the existing `test:container` command when Docker is available.
- [ ] **Step 5: Commit on the existing PR branch.** Use `feat: qualify TypeScript analysis identities by namespace`; retain JavaScript coverage explicitly in the PR description.

