# Task 6: SDK namespace configuration and scoped resolution

Status: implementation and final verification complete.
Base: `7633dd2a61e20a603463946442705db817dbfebe`, branch `feat/application-identity-namespaces`.
No push, dependency-release pin changes, aliases, persisted-ID translation, or graph writes.

## Implementation

- Added frozen `ApplicationIdentity(namespace, application_name, application_id)` and `resolve_identity`; defaults derive from the absolute normalized selected root, including `Path('.')`. Names retain raw case/Unicode/percent characters and encode root UTF-8 exactly once. Invalid or explicit empty names fail; a missing graph selection raises the existing configuration exception.
- Added keyword-only local configuration identity fields and keyword-only Neo4j namespace. Existing `PyCodeAnalyzerConfig(cache_dir, use_ray)` and `TSCodeAnalyzerConfig(cache_dir, tsc_only)` positional calls remain valid. Reusing a config does not fill its absent identity fields.
- Bound all four facades/local analyzers/Neo4j backends. Local Python options and raw attached Java/TS/Go CLI flags carry the selected namespace and app. Anchors use the complete root, descendants append `/`, and TS continues to cover TS plus JS.
- Local models and boundary checks require marker 2, raw ownership metadata and matching canonical app root. Python application markers cannot be synthesized from model defaults. Java's application JSON legitimately omits the repeated app marker. Graph attachment checks selected anchor metadata read-only.
- Cache directories include an application-ID digest beneath the language directory. Existing direct local cache readers also validate raw metadata before reuse and regenerate mismatched outputs. Malformed/legacy/foreign cache metadata is not trusted; Java's pre-schema-v2 cache refusal remains explicit.
- `resolve_module_key` accepts exact/normalized relative keys, full module URIs verified against a bound owner and actual module-ID mapping, and absolute paths under an existing bound source root. Foreign owner/language URIs fail before fallback. Unrestricted suffix resolution was removed; unknown relative keys keep existing diagnostics.
- Python graph module projections retain returned canonical IDs for URI resolution and scoped query parameters. Unknown locate positions retain `file_not_in_graph` diagnostics instead of indexing a missing module ID. Go strips its `/go/` segment from graph module keys and rejects foreign owner/language point IDs before querying.
- Minimal reviewed-current-producer compatibility: Go's explicit `defined` type kind; Python dataclass `PyCallsite` cloning via `dataclasses.replace`; optional TS application `name` for lossless current-output round trips. These were approved by the controller; no arbitrary type widening or API redesign.

## Source-derived positive fixtures

Regenerated tracked TS levels 1–4, Go litestream, Java Daytrader L1 and pruned L4 directly from source. Java gzip output has `mtime=0`. No old persisted JSON was relabeled or translated. Authored fake projections/expectations were updated explicitly.

Reproducible generator: `tests/resources/regenerate_identity_fixtures.py`; producer source SHAs, source ZIP SHA-256 values, commands and measured counts are in each fixture README. Reviewed local artifact provenance is also in this SDD directory's `local-artifacts.json`.

Java initially emitted engine-free degraded L4 because Maven was absent. Those trial outputs were superseded. After Maven 3.9.16 provisioning, strict full L4 compiled source successfully; strict pruned L4 logs verified 118 WALA-visited callables and 320 points-to edges. Final pruned corpus: 4 modules, 247 calls, 258 param-in and 97 param-out edges. L1: 138 modules. Current producer entrypoint/rule/param-var assertions were remeasured; authored absent-var coverage is preserved separately.

Go current reviewed main: 55 modules, 3,082 call edges, 8 `defined` types. TS: 5 modules at each level. Local metadata version strings are verification-artifact versions, not fabricated dependency release pins.

Exact generating argv/log evidence is retained under `/private/tmp/task6-fixtures/` (`commands.json`, `java-a4-compiled-command.json`, `java-compiled-commands.json`, corresponding logs). The checked-in generator expresses the reproducible final commands and source pruning without depending on those transient paths.

## RED evidence

- Missing identity module: collection failed for the absent interface, not an optional producer dependency.
- CLI tests: 3 failures showing missing namespace/raw-app forwarding.
- Graph binding tests: 4 failures showing unsupported namespace arguments.
- Go module keys: 1 failure returning `go/src/main.go` instead of application-relative `src/main.go`.
- Python marker default: 1 failure accepting a synthesized application marker.
- Current Go corpus: literal validation rejected 8 `defined` types before the approved compatibility update.
- Raw app marker and malformed cache tests failed before boundary validation; malformed-cache RED was 3 failures.
- Actual-returned Python module-ID test failed before authoritative mapping was retained.
- Existing external-symbol tests exposed `PyCallsite.model_copy` on a dataclass; existing locate tests exposed missing-key indexing after mapping retention. Both were corrected, retaining the intended semantics.

## Verification

All commands use `.venv/bin/python` directly after sourcing `/private/tmp/namespace-toolchains/sdk-env.sh`; `uv run` was intentionally avoided because it would restore stale published producer pins.

- Identity tests: 34 passed.
- Actual local producers (Python, TS, Java, Go), each with raw hyphen-leading app, Unicode and percent values: 4 passed (3.29 s).
- Latest focused commons + all four multi-application scope suites: 399 passed, 2 skipped (7.49 s), before the final additional common regressions.
- Current source-derived corpus/actual binary checks: 107 passed, with a stale release-pin assertion subsequently updated to the reviewed local fixture version.
- Java semantics/addressing/entrypoints: 206 passed (3.68 s).
- Targeted cache/models: 74 passed, 2 skipped (1.63 s).
- Last three locate regression fixes plus shared identity tests: 92 passed (0.28 s).
- Initial full legacy-fixture run (superseded): 298 failed, 1081 passed, 412 skipped, 523 errors in 143.56 s. This exposed the positive snapshot/fixture migration surface.
- First final broad run (superseded): 3 failed, 1910 passed, 421 skipped, 85.26% coverage in 63.20 s. All three locate failures were fixed and verified above.
- Final full SDK result: **1913 passed, 421 skipped, 20 warnings**, **85.09% coverage**, **71.18 s**. Wrapper returned exit 0 in 71.86 s under the 240 s cap. Command: `CLDK_SKIP_JAVA_E2E=1 .venv/bin/python -m pytest tests -q` after sourcing the SDK environment. Log: `/private/tmp/task6-full-green.log`.
- `git diff --check`: clean. Focused F821/F811/F401 checks on changed shared/local/graph implementation files: clean. New generator `--help` and compilation checks succeeded.

Broad SDK execution has a 240 s subprocess cap and uses the existing `CLDK_SKIP_JAVA_E2E=1` gate for slow native Java tests. Docker/live Neo4j is unavailable; fake-driver read-only scope tests and actual local producer outputs provide the available coverage. Native Java fixture generation ran separately with strict compiled WALA, not an engine-free success claim.

## Commits

`315eeae8e3c9028d1404d2150f00e01e36f6c42b` — `feat: bind SDK URI resolution to namespace and application`.

## Concerns and handoff

- Live Neo4j/Docker coverage was not run; no claims are made about a live deployment.
- Reviewed local producers are ahead of published dependency pins. This change deliberately does not invent a release version; verification requires the recorded reviewed artifacts until real releases are published.
- Task 7 canonical-ID index/dedup work remains separate. This task preserves ownership when carrying module IDs; it does not implement the canonical entity join/index helper or claim private downstream integration coverage.
- No subagents/reviewers were spawned and no push was performed.

## Changed files

- `cldk/analysis/commons/backend_config.py`
- `cldk/analysis/commons/keys.py`
- `cldk/analysis/go/codeanalyzer/codeanalyzer.py`
- `cldk/analysis/go/go_analysis.py`
- `cldk/analysis/go/neo4j/neo4j_backend.py`
- `cldk/analysis/java/backend.py`
- `cldk/analysis/java/codeanalyzer/codeanalyzer.py`
- `cldk/analysis/java/java_analysis.py`
- `cldk/analysis/java/neo4j/neo4j_backend.py`
- `cldk/analysis/python/codeanalyzer/codeanalyzer.py`
- `cldk/analysis/python/neo4j/neo4j_backend.py`
- `cldk/analysis/python/python_analysis.py`
- `cldk/analysis/typescript/codeanalyzer/codeanalyzer.py`
- `cldk/analysis/typescript/neo4j/neo4j_backend.py`
- `cldk/analysis/typescript/typescript_analysis.py`
- `cldk/core.py`
- `cldk/models/go/models.py`
- `cldk/models/java/models.py`
- `cldk/models/typescript/models.py`
- `tests/analysis/commons/test_lifted_helpers.py`
- `tests/analysis/go/test_go_analysis.py`
- `tests/analysis/go/test_go_e2e.py`
- `tests/analysis/java/conftest.py`
- `tests/analysis/java/test_java_addressing.py`
- `tests/analysis/java/test_java_analysis.py`
- `tests/analysis/java/test_java_dataflow.py`
- `tests/analysis/java/test_java_degradation.py`
- `tests/analysis/java/test_java_e2e.py`
- `tests/analysis/java/test_java_entrypoints.py`
- `tests/analysis/java/test_java_neo4j_lookup_miss.py`
- `tests/analysis/java/test_java_neo4j_multi_application_scope.py`
- `tests/analysis/java/test_java_public_surface.py`
- `tests/analysis/java/test_java_schema_probe.py`
- `tests/analysis/java/test_java_v1_accessors.py`
- `tests/analysis/java/test_java_view_dispatches.py`
- `tests/analysis/java/test_jcodeanalyzer.py`
- `tests/analysis/python/conftest.py`
- `tests/analysis/python/test_artifacts.py`
- `tests/analysis/python/test_bodies.py`
- `tests/analysis/python/test_entrypoints.py`
- `tests/analysis/python/test_external_symbols.py`
- `tests/analysis/python/test_locate.py`
- `tests/analysis/python/test_module_key_of.py`
- `tests/analysis/python/test_neo4j_multi_application_scope.py`
- `tests/analysis/python/test_python_analysis.py`
- `tests/analysis/python/test_python_method_lookup.py`
- `tests/analysis/python/test_python_neo4j_selection.py`
- `tests/analysis/python/test_python_taint.py`
- `tests/analysis/python/test_resolution_probe.py`
- `tests/analysis/python/test_resolve.py`
- `tests/analysis/python/test_scoping_keywords.py`
- `tests/analysis/typescript/conftest.py`
- `tests/analysis/typescript/test_typescript_addressing.py`
- `tests/analysis/typescript/test_typescript_analysis.py`
- `tests/analysis/typescript/test_typescript_bulk_accessors.py`
- `tests/analysis/typescript/test_typescript_dataflow.py`
- `tests/analysis/typescript/test_typescript_e2e.py`
- `tests/analysis/typescript/test_typescript_e2e_neo4j_live.py`
- `tests/analysis/typescript/test_typescript_entrypoints.py`
- `tests/analysis/typescript/test_typescript_external_reconstruct.py`
- `tests/analysis/typescript/test_typescript_get_method_functions.py`
- `tests/analysis/typescript/test_typescript_neo4j_backend.py`
- `tests/analysis/typescript/test_typescript_neo4j_bulk.py`
- `tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py`
- `tests/analysis/typescript/test_typescript_neo4j_selection.py`
- `tests/analysis/typescript/test_typescript_taint.py`
- `tests/models/go/test_go_models.py`
- `tests/models/java/test_java_models.py`
- `tests/models/python/test_python_models.py`
- `tests/models/typescript/test_ts_v2_models.py`
- `tests/resources/go/analysis.json`
- `tests/resources/go/analysis_json/v2/README.md`
- `tests/resources/java/analysis_json/v2/README.md`
- `tests/resources/java/analysis_json/v2/a1/analysis.json.gz`
- `tests/resources/java/analysis_json/v2/a4/analysis.json.gz`
- `tests/resources/typescript/analysis_json/v2/README.md`
- `tests/resources/typescript/analysis_json/v2/a1/analysis.json`
- `tests/resources/typescript/analysis_json/v2/a2/analysis.json`
- `tests/resources/typescript/analysis_json/v2/a3/analysis.json`
- `tests/resources/typescript/analysis_json/v2/a4/analysis.json`
- `cldk/analysis/commons/identity.py`
- `tests/analysis/commons/test_identity.py`
- `tests/analysis/commons/test_identity_local_producers.py`
- `tests/analysis/go/test_go_neo4j_multi_application_scope.py`
- `tests/resources/regenerate_identity_fixtures.py`

## Review fix round 1 — Important: stale TypeScript live anchors

Base: `315eeae8e3c9028d1404d2150f00e01e36f6c42b`. Fixed only the Important finding in `task-6-review.md`; the Minor marker strictness and duplicate Python setup remain reserved for the final fix wave.

Both TypeScript live suites now obtain `APP_ID` from `resolve_identity(APP_NAME, None).application_id` and derive descendant prefixes from that exact canonical anchor. This fixes the read-suite presence gate, raw-name escaping, anchor-based expectations and write-suite cleanup's anchor parameter together. No product code or dependency pins changed.

Added offline `test_typescript_live_identity_contract.py` coverage that invokes the actual presence-gate and cleanup helpers through a fake driver. It verifies canonical query parameters, descendant/anchor consistency, driver closure, and a raw hyphen-leading app containing Unicode and a literal percent. The loader clears URI environment variables before importing the live modules, so collection cannot contact a real server; test calls then use only the fake driver. An absent optional Neo4j driver skips these checks cleanly.

RED: `.venv/bin/python -m pytest tests/analysis/typescript/test_typescript_live_identity_contract.py --no-cov -q` — **3 failed in 1.35 s**. Both valid canonical-anchor presence gates returned false and cleanup carried the legacy one-segment anchor. Log: `/private/tmp/task6-review-round1-red.log`.

GREEN: `.venv/bin/python -m pytest tests/analysis/typescript/test_typescript_live_identity_contract.py tests/analysis/typescript/test_typescript_e2e_neo4j_live.py tests/analysis/typescript/test_typescript_neo4j_backend.py --no-cov -q` — **3 passed, 49 skipped in 1.28 s**. Only the genuinely live tests are skipped for unavailable configured servers; the new gate/cleanup assertions execute offline. Log: `/private/tmp/task6-review-round1-green.log`. `git diff --check` is clean. No broad suite rerun for this test-constant correction.

Round-1 commit: `1f3948976c2d14fb45a7585bcc5b05f07d9b2b15`. No subagents or push.
