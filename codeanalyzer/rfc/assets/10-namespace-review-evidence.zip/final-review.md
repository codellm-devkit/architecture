# Final integration review

Reviewed the exact five repository ranges in `final-review-manifest.json`, the RFC, global constraints, contract decisions, bounded product diffs and selected current sources/tests, scoped reports/reviews, verification handoff, smoke script, and prepared PR bodies. This is one cross-component review, not a rerun of the independently reviewed task suites. Product checkouts and Git state were not modified. Only this requested review artifact was written.

## Strengths

- All four producer root helpers and the SDK agree on raw namespace/application ownership, UTF-8 percent encoding, repeated default roots and application-relative suffixes. Namespace is forwarded through facade configuration, local invocation, graph selection and cache identity.
- SDK graph module indexes retain canonical IDs before deriving relative lookup keys. Foreign module URIs fail before suffix normalization; JavaScript retains its own language view through the TypeScript facade. The currency/payment fake-driver regression retains both owners and both real call sites.
- Existing artifact reconciliation and sibling-language protection were retained. Java's previous v1 cleanup regression was explicitly corrected without introducing v2 legacy-name fallback.
- Handoff clearly distinguishes native local producer builds from published releases, SDK fake-driver tests from live Neo4j, and SDK canonical-join regressions from absent private integration changes. The documented user SDK snippet uses real `get_modules`, `locate`, and `LocateResult.node_id` APIs.

## Issues

### Critical

None established.

### Important — fix before approving affected code

1. **Python Bolt pushes do not validate the existing selected application anchor.** `codeanalyzer-python/codeanalyzer/neo4j/bolt.py:302` (streaming path) and `:352` (nonstreaming path). Both paths begin DDL and module-hash work without reading the selected anchor's identity marker or raw namespace/application metadata. They subsequently upsert the anchor and can reuse unchanged module hashes. An existing incompatible or incomplete anchor is therefore silently overwritten while its old descendants may be retained, rather than rejected before mutation. Incoming analysis validation in `neo4j/emit.py` does not validate persisted database state. This also contradicts the connected-Bolt validation assertion in `architecture/codeanalyzer/rfc/assets/10-namespace-verification.md:133`. Add the same read-only exact-anchor compatibility check used by Java/TS before DDL or data mutation on both Python paths; reject missing/noninteger/wrong markers and mismatched/missing raw names on an existing anchor, while permitting a genuinely absent anchor. Cover both writer paths and assert no mutation occurs on rejection.

2. **Go's existing-anchor guard validates only the marker, not raw ownership metadata.** `codeanalyzer-go/internal/neo4j/bolt.go:212`. `storedAppStale` reads schema, level and identity version but never reads `application_name` or `identity_namespace`. An anchor with version 2 and missing or conflicting raw owner fields is accepted and overwritten, although SDK readers reject it and Java/TS writers reject it. The incoming `validateIdentity` check in `internal/neo4j/cypher.go` cannot establish the validity of stored metadata. Fetch both raw fields and compare them to the validated incoming identity before DDL/writes; preserve the first-push case. Add fake-driver cases for missing and conflicting raw fields and a no-mutation assertion.

### Minor — include in the coordinated cleanup

3. **SDK model parsing coerces float identity markers before validation.** `python-sdk/cldk/models/typescript/models.py:740`, `:765`; `cldk/models/go/models.py:241`, `:256`; `cldk/models/java/models.py:953`; downstream check at `cldk/analysis/commons/identity.py:47`. The local readers parse into Pydantic models before calling `validate_identity`; `Literal[2]` converts `2.0` into integer 2. A bounded read-only probe constructed minimal TS, Go and Java envelopes with float markers and each passed model parsing plus `validate_identity`, printing an integer model field. Raw cache validation rejects the same input, and Python producer parsing has a before-validator, so acceptance depends on the entry path. Validate integer type before model coercion. This is a low-impact strict-contract defect, not demonstrated cross-service misattribution. The smoke at `architecture/codeanalyzer/rfc/assets/10-namespace-smoke.py:37` checks a model dump, so its integer assertion alone does not prove raw wire integer fidelity.

4. **Repeated CLI identity options in sample regeneration instructions.** `codeanalyzer-python/docs/handoff/README.md:140`–`:144` repeats the identical app-name/namespace pair three times on each command. Keep one pair per command. The same-value repetition is not evidence of incorrect generated artifacts, but makes the documented regeneration invocation misleading.

5. **Duplicate Python scope fixture setup.** `python-sdk/tests/analysis/python/test_neo4j_multi_application_scope.py:263`–`:268` imports `resolve_identity` and assigns the same identity twice. Remove the duplicate import/assignment; no behavior change is required.

6. **Delivery wording must keep external integration tracking open.** SDD `pr-bodies/python-sdk.md:7` says `Closes #435` while that issue also tracks the still-absent downstream joins. Use a non-closing reference unless those remaining obligations are tracked independently. `pr-bodies/codeanalyzer-go.md:3` incorrectly describes Go as replacing the workspace-root option; Go had no such precursor option. Tailor that sentence. These are handoff corrections, not product-code blockers. Refresh final reviewed-source/provenance and companion links after the fix/delivery commits; the current verification table's SDK hash predates the manifest head.

## Java property-refinement triage

`codeanalyzer-java/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java:81`–`:85` rejects any differing property on a repeated canonical ID, whereas its class documentation describes last-write-wins refinement and Go retains that policy. The public builder would reject a straightforward repeated node whose display property is refined. However, inspection of current projector calls, including L2 external-symbol emission and `externalGhost`, did not establish an actual ordinary source input that reaches conflicting values. Therefore **no additional Java code blocker is asserted**. Treat this as a minor contract/documentation inconsistency: preferably preserve ordinary non-identity property refinement while retaining key/identity safeguards, or explicitly document and test the stricter contract. Do not claim a demonstrated user-facing Java regression from this review.

## Verification and review limits

- Reused the recorded producer suites, 20-case actual-native L2 smoke and final 1926-pass SDK evidence; did not rerun broad suites. The only new execution was the small TS/Go/Java float-marker model probe above, with bytecode writing disabled.
- Examined root/default/namespace plumbing, embedded-reference construction boundaries, SDK model/raw compatibility, cache binding, exact graph anchors/prefixes, module indexing and row identity in bounded passes across all five products. Did not mechanically re-review every previously reviewed task or every generated JSON snapshot.
- Existing edge-site/context behavior was checked at row-builder/projector and SDK reconstruction boundaries; no additional independent-fact loss was established. This is not proof against every possible pre-existing suffix collision or every graph runtime behavior.
- Live Docker/Neo4j remains unavailable. No live Cypher execution, cleanup preservation or database equality-join success is independently certified here. Fake-driver coverage cannot replace that gate.
- Current published SDK producer pins remain incompatible. Reviewed editable/native/local-wheel validation is not installed-package release validation. SDK must remain Draft/release blocked until real producer releases, package-workflow pin/lock updates and installed-package validation.

## Declined to judge

- Private integration filename indexes and finding joins: repositories absent; explicitly external work, not an end-to-end fix claim.
- Production regeneration and rollback execution: not performed or authorized as part of this local implementation review; the handoff states the requirement.
- Live database runtime semantics and shared-data preservation: environment unavailable; retain explicit runtime verification gate rather than claiming a pass.
- New package/occurrence modeling, namespace-wide search, suffix redesign and producer lifecycle redesign: explicitly outside this first-iteration RFC.
- Java arbitrary-property refinement as a proven source-level failure: stricter builder behavior is visible, but no concrete production trigger established; minor contract risk recorded above rather than invented blocker.
- Full re-audit of generated corpus bodies and unrelated pre-existing functionality: independently scoped reviews/evidence provide coverage; this pass focuses on integration boundaries.

## Assessment

**Spec compliance:** Changes required for Python/Go persisted-anchor validation; small strict-marker mismatch also remains. The namespace, ownership, SDK lookup and canonical module-index architecture otherwise aligns with the first-iteration contract.

**Code quality:** With fixes. Shared identity helpers and explicit scoped APIs are coherent; persisted-state validation needs consistent treatment across producers.

**Ready to merge? With fixes for producer code; No for SDK release/merge until its explicit release dependency gate is satisfied.** The two Important writer defects require correction and focused regression evidence. Afterwards, producer code can proceed through its normal CI/live-test gates; SDK delivery remains a Draft, with unavailable live verification and external integration work disclosed separately. No private end-to-end resolution is certified.
