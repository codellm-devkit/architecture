Namespace/application ownership now produces `can://<namespace>/<application>/…` roots, including the repeated default monolith root. Raw inputs are validated and UTF-8 encoded consistently; integer `identity_version: 2` and raw owner metadata reject incompatible persisted outputs. Existing suffixes and application-relative keys are retained.

SDK configuration forwards explicit namespace/application bindings to reviewed local producers and scopes every graph query to one application/language. Canonical-ID module indexes preserve same-filename services, reject conflicts, and prevent currency findings from joining payment callables. Attachment stays read-only; foreign URIs fail before path fallback.

**Draft / release blocked:** current published producer pins remain unchanged. Validation uses reviewed local builds; do not merge/release as installed-package compatible until namespace-ready producer releases exist, the pins and lockfile are updated through the package workflow, and installed-package validation passes. SDK PR #439 remains separate and does not satisfy this dependency.

Related: https://github.com/codellm-devkit/python-sdk/issues/435. Downstream integration joins remain open.

Coordinated tracking: [codeanalyzer-python #236](https://github.com/codellm-devkit/codeanalyzer-python/issues/236), [codeanalyzer-typescript #221](https://github.com/codellm-devkit/codeanalyzer-typescript/issues/221), [codeanalyzer-java #276](https://github.com/codellm-devkit/codeanalyzer-java/issues/276), [codeanalyzer-go #40](https://github.com/codellm-devkit/codeanalyzer-go/issues/40).

Existing producer PRs: [Python #235](https://github.com/codellm-devkit/codeanalyzer-python/pull/235), [TS/JS #220](https://github.com/codellm-devkit/codeanalyzer-typescript/pull/220), [Java #275](https://github.com/codellm-devkit/codeanalyzer-java/pull/275). Companion PRs: [Go #41](https://github.com/codellm-devkit/codeanalyzer-go/pull/41), [SDK #440 (Draft)](https://github.com/codellm-devkit/python-sdk/pull/440).

Validation: Final SDK: 1949 passed, 422 skipped, 10 warnings; 85.34% coverage in 74.60s (75.22s runner, 240s cap). Canonical join regression: 596 passed, 2 skipped. Cross-repository native L2 smoke: 20 cases / 60 canonical endpoint references; explicit sibling services, defaults and raw punctuation/Unicode passed. Shared six-copy golden fixture hash matches; diff checks clean.

Docker/live Neo4j unavailable; no live integration success claimed. Fake-driver ownership/read-only/query/join evidence is retained. Downstream canonical-index/finding-join adoption remains separately required; no private integration fix is claimed.

Final review validation: Strict marker/scope focused: 142 passed, 1 skipped. Fresh model and cache rejection agree on float markers.

The tiny Java L2 smoke used declared-edge fallback; strict compiled WALA was validated separately.
