Namespace/application ownership now produces `can://<namespace>/<application>/…` roots, including the repeated default monolith root. Raw inputs are validated and UTF-8 encoded consistently; integer `identity_version: 2` and raw owner metadata reject incompatible persisted outputs. Existing suffixes and application-relative keys are retained.

The namespace option replaces the unmerged workspace-root option. Embedded references, graph scopes, cache compatibility and selected-root reconciliation follow the canonical owner while retaining unrelated existing branch fixes. Legacy output must be regenerated from source.

Closes https://github.com/codellm-devkit/codeanalyzer-python/issues/236.

Coordinated tracking: [python-sdk #435](https://github.com/codellm-devkit/python-sdk/issues/435), [codeanalyzer-typescript #221](https://github.com/codellm-devkit/codeanalyzer-typescript/issues/221), [codeanalyzer-java #276](https://github.com/codellm-devkit/codeanalyzer-java/issues/276), [codeanalyzer-go #40](https://github.com/codellm-devkit/codeanalyzer-go/issues/40).

Existing producer PRs: [Python #235](https://github.com/codellm-devkit/codeanalyzer-python/pull/235), [TS/JS #220](https://github.com/codellm-devkit/codeanalyzer-typescript/pull/220), [Java #275](https://github.com/codellm-devkit/codeanalyzer-java/pull/275). Companion PRs: [Go #41](https://github.com/codellm-devkit/codeanalyzer-go/pull/41), [SDK #440 (Draft)](https://github.com/codellm-devkit/python-sdk/pull/440).

Validation: Broad suite: 548 passed, 27 skipped, 5 heavyweight CLI cases deselected; focused identity/schema/projection: 77 passed, 25 container skips. Cross-repository native L2 smoke: 20 cases / 60 canonical endpoint references; explicit sibling services, defaults and raw punctuation/Unicode passed. Shared six-copy golden fixture hash matches; diff checks clean.

Docker/live Neo4j unavailable; no live integration success claimed. Fake-driver ownership/read-only/query/join evidence is retained. Downstream canonical-index/finding-join adoption remains separately required; no private integration fix is claimed.

Final review validation: Final persisted-anchor fix: 34 focused Bolt/scope/artifact/schema tests passed; both Bolt paths reject legacy/contradictory metadata before any write.
