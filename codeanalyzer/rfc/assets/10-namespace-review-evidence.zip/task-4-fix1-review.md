# Task 4 fix1 scoped review

Scope: `e35d7dca..cbfbd01dd9ed3f5bfca51237487d0273f4eff4ec`, the four-file fix diff and appended RED/GREEN evidence. No suites rerun; no implementation mutations or broad re-review.

## Per-finding verdicts

- **V1 snapshot replacement: addressed.** `CypherWriter.java:95` selects legacy cleanup from the actual incoming name-keyed `JApplication` (`legacyApplicationName`, line 148), rather than from a display-name fallback. `wipeLegacy` at line 157 requires `a.id IS NULL AND a.name = <selected-name>`, traverses `J_HAS_UNIT` and Java containment, and removes the old anchor/units/descendants before node upserts. Canonical-v2 same-name anchors have non-null ids and cannot match. V2 rows continue through the unchanged exact canonical-root wipe.
- **V1 full-run Bolt orphan pruning: addressed.** `BoltWriter.java:90` adds the id-less/name-scoped legacy query with the existing present-file exclusion. `orphanPruneQuery` at line 97 uses the same actual incoming schema-family selector, and the full-run branch calls it at line 337. V2 continues to use the unchanged `a.id = $appId` predicate, without a legacy-name fallback. Targeted-run behavior is unchanged.

## New breakage

None found in this fix diff. The shared selector matches the real legacy projector's `name` merge key and does not classify canonical projector rows as legacy. No canonical prefix sweep is performed for v1, and no v2-to-v1 cleanup fallback is reintroduced.

## Evidence and overall verdict

Reported focused verification covers real v1 and v2 projector outputs with a shared display name, emitted cleanup ordering/containment, query selection and the id-less protection. The appended evidence records initial missing-selector compilation RED, then 16 tests with exactly the two new behavioral failures, followed by GREEN/BUILD SUCCESSFUL for all 16 targeted tests. These are query-generation/selection checks; live database execution remains unavailable without Docker.

**Overall: approve this scoped fix. Both original findings are resolved; spec compliance and code quality pass for the reviewed repair.**
