### Task 4: Repurpose Java PR #275

**Files:**
- Modify: `codeanalyzer-java/src/main/java/com/ibm/cldk/CodeAnalyzer.java`.
- Modify: `codeanalyzer-java/src/main/java/com/ibm/cldk/schema/{CanId.java,Analysis.java,JApplication.java,V2Emitter.java}`.
- Modify: `codeanalyzer-java/src/main/java/com/ibm/cldk/syntactic_analysis/L1Extractor.java`, `artifacts/ArtifactDiscovery.java`, and `neo4j/{GraphProjector.java,V2GraphProjector.java,BoltWriter.java,CypherWriter.java}` under the same Java package root.
- Extend: `src/test/java/com/ibm/cldk/{CodeAnalyzerV2CliTest.java,schema/CanIdTest.java,schema/V2JsonTest.java,neo4j/BoltWriterPurgeTest.java}` in that repo.
- Adapt/remove workspace-only expectations: `src/test/java/com/ibm/cldk/WorkspaceRootNeo4jPushTest.java` and `docs/design/specs/2026-10-24-workspace-root.md`.
- Update: `src/test/resources/schema/analysis.v2.schema.json`, `schema.neo4j.json`, and `README.md` in that repo.

**Interfaces:**
- Consumes: Task 1 fixture and Java overloads above.
- Produces: CLI namespace input, application-relative module keys, unchanged Java symbol suffixes, and the shared marker/identity metadata.

- [ ] **Step 1: Write failing root/CLI tests.** Load fixture roots, test invalid explicit names, and assert repeated root segments for default monoliths. Emit a small no-build Java application with an artifact; check canonical module/type/callable/body/external/artifact references and their graph endpoints.
- [ ] **Step 2: Verify failure.** Run `./gradlew test --tests 'com.ibm.cldk.schema.CanIdTest' --tests 'com.ibm.cldk.CodeAnalyzerV2CliTest'`. Expect namespace API/option failures.
- [ ] **Step 3: Implement the Java contract.** Replace the workspace-root option, remove key-root-dependent identity, and thread namespace through the emitter/artifact helpers. Preserve the PR's unrelated graph reconciliation changes. Add identity marker and raw scope metadata; update JSON and graph validators. For explicit legacy schema-v1 mode, reject `--namespace` clearly rather than silently emitting unqualified IDs.
- [ ] **Step 4: Verify.** Run the focused tests above plus `V2JsonTest` and `BoltWriterPurgeTest`, then `./gradlew test`. Include shared-artifact retention coverage from the existing PR; document any external-service exclusions.
- [ ] **Step 5: Commit on the existing PR branch.** Use `feat: qualify Java analysis identities by namespace`.

