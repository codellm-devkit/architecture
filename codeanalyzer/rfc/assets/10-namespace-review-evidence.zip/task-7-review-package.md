72f14d7 fix: preserve canonical module identity during deduplication
 cldk/analysis/commons/identity.py                  | 30 ++++++++++++++
 cldk/analysis/go/neo4j/neo4j_backend.py            |  8 +++-
 cldk/analysis/java/neo4j/neo4j_backend.py          |  7 +++-
 cldk/analysis/python/neo4j/neo4j_backend.py        |  5 ++-
 cldk/analysis/typescript/neo4j/neo4j_backend.py    |  5 ++-
 .../analysis/commons/test_module_identity_index.py | 48 ++++++++++++++++++++++
 .../typescript/test_typescript_neo4j_bulk.py       | 25 +++++++++++
 ...est_typescript_neo4j_multi_application_scope.py | 32 +++++++++++++++
 8 files changed, 152 insertions(+), 8 deletions(-)
diff --git a/cldk/analysis/commons/identity.py b/cldk/analysis/commons/identity.py
index f60d84b..cdcf4aa 100644
--- a/cldk/analysis/commons/identity.py
+++ b/cldk/analysis/commons/identity.py
@@ -11,20 +11,21 @@
 # distributed under the License is distributed on an "AS IS" BASIS,
 # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 # See the License for the specific language governing permissions and
 # limitations under the License.
 ################################################################################
 
 """Validated raw application identity and canonical URI ownership."""
 
 import json
 import unicodedata
+from collections.abc import Iterable, Mapping
 from dataclasses import dataclass
 from pathlib import Path
 from urllib.parse import quote
 
 from cldk.utils.exceptions import CodeanalyzerExecutionException
 
 
 @dataclass(frozen=True)
 class ApplicationIdentity:
     namespace: str
@@ -75,10 +76,39 @@ def validate_identity(payload, identity: ApplicationIdentity, *, envelope: bool
         raise CodeanalyzerExecutionException("Analysis identity metadata is missing, incompatible, or outside the requested application scope.")
     return payload
 
 
 def cache_matches(path: Path, identity: ApplicationIdentity) -> bool:
     try:
         validate_identity(json.loads(path.read_text(encoding="utf-8")), identity)
         return True
     except (OSError, ValueError, CodeanalyzerExecutionException):
         return False
+
+
+def index_module_rows(rows: Iterable[Mapping[str, str]]) -> dict[str, dict[str, str]]:
+    """Collapse repeated module projections by canonical identity, never by filename."""
+    index: dict[str, dict[str, str]] = {}
+    for row in rows:
+        module_id, file_key = row["module_id"], row["file_key"]
+        if module_id in index and index[module_id]["file_key"] != file_key:
+            raise ValueError(f"Conflicting file keys for canonical module {module_id}: {index[module_id]['file_key']!r} and {file_key!r}")
+        index[module_id] = {"module_id": module_id, "file_key": file_key}
+    return index
+
+
+def scoped_module_keys(index: Mapping[str, Mapping[str, str]], application_id: str, languages: tuple[str, ...]) -> dict[str, str]:
+    """Derive the relative-key API only after validating owner and language.
+
+    Candidate IDs remain in the primary index; an ambiguous relative key cannot silently
+    select whichever module happened to be projected last.
+    """
+    candidates: dict[str, set[str]] = {}
+    prefixes = tuple(f"{application_id}/{language}/" for language in languages)
+    for module_id, row in index.items():
+        if not module_id.startswith(prefixes):
+            raise ValueError(f"Module URI is outside the bound application/language scope: {module_id}")
+        candidates.setdefault(row["file_key"], set()).add(module_id)
+    for key, ids in candidates.items():
+        if len(ids) != 1:
+            raise ValueError(f"Ambiguous module file key {key!r}: {sorted(ids)}")
+    return {key: next(iter(ids)) for key, ids in candidates.items()}
diff --git a/cldk/analysis/go/neo4j/neo4j_backend.py b/cldk/analysis/go/neo4j/neo4j_backend.py
index 8c97954..6bf9590 100644
--- a/cldk/analysis/go/neo4j/neo4j_backend.py
+++ b/cldk/analysis/go/neo4j/neo4j_backend.py
@@ -38,21 +38,21 @@ emitting it, those six flip to querying the graph for real.
 """
 
 from __future__ import annotations
 
 import json
 from functools import cached_property
 from typing import Any, Dict, List
 
 import networkx as nx
 
-from cldk.analysis.commons.identity import resolve_identity, validate_identity
+from cldk.analysis.commons.identity import index_module_rows, resolve_identity, scoped_module_keys, validate_identity
 from cldk.analysis.go.backend import ARTIFACT_LAYER_UNAVAILABLE, GoAnalysisBackend
 from cldk.analysis.go.neo4j import reconstruct as R
 from cldk.models.go import GoApplication, GoCallable, GoCallGraphEdge, GoField, GoModule, GoParam, GoType
 from cldk.models.python import PyArtifact, PyConfigKey, PyConfigRead, PyConfigUseEdge, PyDependency
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
 #: Relationship types a Go graph must carry to be a codeanalyzer-go projection at all.
 _REQUIRED_RELS = {"GO_HAS_MODULE", "GO_DECLARES", "GO_HAS_METHOD", "GO_CALLS"}
 
 
@@ -181,21 +181,25 @@ class GoNeo4jBackend(GoAnalysisBackend):
 
     def _build_symbol_table(self) -> Dict[str, GoModule]:
         """Rebuild every module with its types, functions, methods and fields from the containment
         relationships. This is the expensive whole-program path; point accessors below never call
         it."""
         modules: Dict[str, GoModule] = {}
         mod_rows = self._run(
             "MATCH (:GoApplication {id: $app_id})-[:GO_HAS_MODULE]->(m:GoModule) RETURN properties(m) AS p ORDER BY m.id",
             app_id=self._app_id,
         )
-        for mr in mod_rows:
+        self._module_index = index_module_rows({"module_id": r["p"]["id"], "file_key": self._module_file_key(r["p"]["id"])} for r in mod_rows)
+        scoped_module_keys(self._module_index, self._app_id, ("go",))
+        module_props = {r["p"]["id"]: r["p"] for r in mod_rows}
+        for module_id in self._module_index:
+            mr = {"p": module_props[module_id]}
             mod = R.module(mr["p"])
             # package-level functions
             for fr in self._run(
                 "MATCH (m:GoModule {id: $mid})-[:GO_DECLARES]->(c:GoCallable) RETURN properties(c) AS p ORDER BY c.signature",
                 mid=mod.id,
             ):
                 fn = R.callable_(fr["p"])
                 mod.functions[fn.signature] = fn
             # types + their methods and fields
             for tr in self._run(
diff --git a/cldk/analysis/java/neo4j/neo4j_backend.py b/cldk/analysis/java/neo4j/neo4j_backend.py
index db9c7a6..e5a63e3 100644
--- a/cldk/analysis/java/neo4j/neo4j_backend.py
+++ b/cldk/analysis/java/neo4j/neo4j_backend.py
@@ -112,21 +112,21 @@ from __future__ import annotations
 
 import json
 import logging
 import re
 from collections import defaultdict
 from functools import cached_property
 from typing import Any, Dict, FrozenSet, Iterable, List, Mapping, Sequence, Tuple
 
 import networkx as nx
 
-from cldk.analysis.commons.identity import resolve_identity, validate_identity
+from cldk.analysis.commons.identity import index_module_rows, resolve_identity, scoped_module_keys, validate_identity
 from cldk.analysis.commons.bounds import DEFAULT_PAGE_SIZE, EdgeOrder, check_page_size, cursor_params, encode_cursor, keyset_where
 from cldk.analysis.commons.graphs import flow_path, sdg_path_query, sdg_taint_query, slice_resolved
 from cldk.analysis.commons.results import Diagnostic, EdgePage, FlowPath, FlowPaths, Slice, SliceNode
 from cldk.analysis.java.backend import (
     CDG_ORDER,
     CFG_ORDER,
     CRUD_UNAVAILABLE,
     DDG_ORDER,
     SDG_REL_PATTERN,
     VIA,
@@ -384,21 +384,24 @@ class JNeo4jBackend(JavaAnalysisBackend):
         """
         if "J_RESOLVES_TO" not in self._relationship_types:
             return False
         return bool(self._run(f"MATCH (b:JBodyNode)-[:J_RESOLVES_TO]->() WHERE {_scoped('b')} RETURN b LIMIT 1", prefix=self._scope_prefix))
 
     def _load_modules(self) -> Dict[str, Dict[str, Any]]:
         """``file_key -> module properties`` for the application's modules."""
         rows = self._run(
             "MATCH (:JApplication {id: $app_id})-[:J_HAS_MODULE]->(m:JModule) RETURN m.file_key AS k, properties(m) AS p ORDER BY m.file_key", app_id=self._application_id
         )
-        return {r["k"]: r["p"] for r in rows}
+        self._module_index = index_module_rows({"module_id": r["p"]["id"], "file_key": r["k"]} for r in rows)
+        keys = scoped_module_keys(self._module_index, self._application_id, ("java",))
+        props = {r["p"]["id"]: r["p"] for r in rows}
+        return {key: props[mid] for key, mid in keys.items()}
 
     # =====================================================================================
     # Reconstruction: ten statements (eight on a 3.0.x graph), then the canonical JApplication.
     # =====================================================================================
     #: The whole containment subtree beneath the application's modules, in one statement: the
     #: ``*0..`` walk reaches every module, type (nested and local), callable and field, and the last
     #: hop yields each one's children as ``(parent id, relationship, child)`` rows. Anchored on the
     #: application, so it cannot leave it. ``J_HAS_FIELD`` is in the walk as well as in the child
     #: hop because a field is itself an annotation target (``J_ANNOTATED_BY`` runs from a type, a
     #: callable *or* a field), so it has to be reachable as a parent.
diff --git a/cldk/analysis/python/neo4j/neo4j_backend.py b/cldk/analysis/python/neo4j/neo4j_backend.py
index 12bbbda..08b90a2 100644
--- a/cldk/analysis/python/neo4j/neo4j_backend.py
+++ b/cldk/analysis/python/neo4j/neo4j_backend.py
@@ -94,21 +94,21 @@ from collections import defaultdict
 from contextlib import contextmanager
 from functools import cached_property
 from typing import Any, Callable, Dict, FrozenSet, List, Mapping, Sequence, Tuple
 
 import networkx as nx
 from codeanalyzer.schema import model_dump_json
 from codeanalyzer.schema.ids import module_id
 from codeanalyzer.schema.py_schema import PyEntrypointReport
 
 from cldk.analysis.commons.keys import module_scope
-from cldk.analysis.commons.identity import resolve_identity, validate_identity
+from cldk.analysis.commons.identity import index_module_rows, resolve_identity, scoped_module_keys, validate_identity
 from cldk.analysis.commons.backend import semver as _semver
 from cldk.analysis.commons.graphs import path_order, sdg_path_query, sdg_taint_query
 from cldk.analysis.commons.keys import module_key_of
 from cldk.analysis.commons.resolve import CallableCandidate, body_node_kind, resolve_callable_signature, resolve_value_name, resolve_within, value_candidate
 from cldk.analysis.commons.results import (
     BodyRef,
     CallableRef,
     Diagnostic,
     EdgePage,
     EntrypointCoverage,
@@ -623,21 +623,22 @@ class PyNeo4jBackend(PythonAnalysisBackend):
         except Exception:
             self._close_session()
             raise
 
     def _load_module_keys(self) -> List[str]:
         """The application's module ``file_key``s — the scope key for every other query."""
         rows = self._run(
             "MATCH (:PyApplication {id: $app_id})-[:PY_HAS_MODULE]->(m:PyModule) RETURN m.file_key AS k, m.id AS id",
             app_id=self._application_id,
         )
-        self._module_ids = {r["k"]: r["id"] for r in rows}
+        self._module_index = index_module_rows({"module_id": r["id"], "file_key": r["k"]} for r in rows)
+        self._module_ids = scoped_module_keys(self._module_index, self._application_id, ("python",))
         return list(self._module_ids)
 
     # =====================================================================================
     # Reconstruction helpers — fetch a node's children over Cypher, then assemble via R.
     #
     # Rebuilding a module walks module → class → method → nested-anything, and each child
     # collection below used to cost one round trip **per parent node**: 73,669 of them to rebuild
     # a 1,626-module application (45.3 per module at ~4.9 ms each, ~363 s wall clock) — a textbook
     # N+1 against a database answering every individual query in five milliseconds. Inside
     # :meth:`_bulk` each collection is instead fetched **once for the whole application** and
diff --git a/cldk/analysis/typescript/neo4j/neo4j_backend.py b/cldk/analysis/typescript/neo4j/neo4j_backend.py
index 9707146..9f7e96e 100644
--- a/cldk/analysis/typescript/neo4j/neo4j_backend.py
+++ b/cldk/analysis/typescript/neo4j/neo4j_backend.py
@@ -111,21 +111,21 @@ now that a signature is no longer unique, and they cost nothing.
 from __future__ import annotations
 
 import logging
 from collections import defaultdict
 from functools import cached_property
 from typing import Any, Dict, FrozenSet, List, Mapping, Sequence, Set, Tuple
 
 import networkx as nx
 
 from cldk.analysis.commons.keys import module_scope
-from cldk.analysis.commons.identity import resolve_identity, validate_identity
+from cldk.analysis.commons.identity import index_module_rows, resolve_identity, scoped_module_keys, validate_identity
 from cldk.analysis.commons import artifacts as shared  # the artifact layer every analyzer projects identically
 from cldk.analysis.commons.backend import semver
 from cldk.analysis.commons.bounds import (
     DEFAULT_DEPTH,
     DEFAULT_MAX_NODES,
     DEFAULT_MAX_PATHS,
     DEFAULT_PAGE_SIZE,
     EdgeOrder,
     check_depth,
     check_distinct_endpoints,
@@ -489,21 +489,22 @@ class TSNeo4jBackend(TSAnalysisBackend):
             floor = ".".join(str(n) for n in self._QUANTIFIED_PATH_MIN_SERVER)
             raise CodeanalyzerExecutionException(
                 f"{accessor} compiles to a quantified path pattern, which needs Neo4j server {floor} or newer; the attached "
                 f"server reports {got}. Only the hop-scoped call-graph walks (reaches, backward_cone) need the newer "
                 "pattern; every other accessor on this backend runs on any 5.x."
             )
 
     def _load_module_keys(self) -> Dict[str, str]:
         """``file key -> module id`` for the application's modules (``TSModule.name`` holds the key)."""
         rows = self._run("MATCH (:Application {id: $app_id})-[:TS_HAS_MODULE]->(m:TSModule) RETURN m.name AS k, m.id AS id", app_id=self._app_id)
-        return {r["k"]: r["id"] for r in rows}
+        self._module_index = index_module_rows({"module_id": r["id"], "file_key": r["k"]} for r in rows)
+        return scoped_module_keys(self._module_index, self._app_id, ("typescript", "javascript"))
 
     #: One statement, three carriers OR-ed, asked of **this application's own data** -- exactly as
     #: leg 3 asks Java's SDG whether its ports carry dependence, and never of ``analyzer_version``:
     #: the refusal below is a statement about what was emitted, so a graph re-emitted by a newer
     #: analyzer must start answering with no change here. Three carriers because each is ``null``
     #: when empty on its own node, and an emitter writes all of them or none: any application with
     #: an import, an ``export`` statement or a parameter trips at least one.
     _BINDINGS_PRESENT = (
         f"RETURN EXISTS {{ MATCH (m:TSModule)-[:TS_IMPORTS]->() WHERE {_scoped('m')} }} "
         f"OR EXISTS {{ MATCH (m:TSModule) WHERE {_scoped('m')} AND m.exports_json IS NOT NULL }} "
diff --git a/tests/analysis/commons/test_module_identity_index.py b/tests/analysis/commons/test_module_identity_index.py
new file mode 100644
index 0000000..e016dc6
--- /dev/null
+++ b/tests/analysis/commons/test_module_identity_index.py
@@ -0,0 +1,48 @@
+"""Canonical module joins must retain owners and reject inconsistent projections."""
+from collections import defaultdict
+
+import pytest
+
+from cldk.analysis.commons import identity
+
+
+ROWS = [
+    {"module_id": "can://shop/currency/javascript/server.js", "file_key": "server.js"},
+    {"module_id": "can://shop/payment/javascript/server.js", "file_key": "server.js"},
+    {"module_id": "can://shop/currency/javascript/server.js", "file_key": "server.js"},
+]
+
+
+def test_index_preserves_canonical_owners_independent_of_order():
+    expected = {row["module_id"]: row for row in ROWS}
+    assert identity.index_module_rows(ROWS) == expected
+    assert identity.index_module_rows(reversed(ROWS)) == expected
+    secondary = defaultdict(set)
+    for module_id, row in identity.index_module_rows(ROWS).items():
+        secondary[row["file_key"]].add(module_id)
+    assert secondary == {"server.js": set(expected)}
+    assert len([mid for mid in expected if mid == ROWS[0]["module_id"]]) == 1
+
+
+def test_index_rejects_conflicting_file_keys():
+    with pytest.raises(ValueError, match="Conflicting file keys.*can://shop/currency/javascript/server.js"):
+        identity.index_module_rows([ROWS[0], {**ROWS[0], "file_key": "other.js"}])
+
+
+@pytest.mark.parametrize("module_id", [
+    "can://shop/payment/javascript/server.js",
+    "can://shop/currency/python/server.js",
+    "can://shop/currency-other/javascript/server.js",
+])
+def test_relative_index_rejects_foreign_owner_or_language(module_id):
+    index = identity.index_module_rows([{"module_id": module_id, "file_key": "server.js"}])
+    with pytest.raises(ValueError, match="outside the bound application/language scope"):
+        identity.scoped_module_keys(index, "can://shop/currency", ("javascript", "typescript"))
+
+
+def test_relative_index_rejects_two_language_candidates_for_one_filename():
+    rows = [ROWS[0], {"module_id": "can://shop/currency/typescript/server.js", "file_key": "server.js"}]
+    index = identity.index_module_rows(rows)
+    assert len(index) == 2
+    with pytest.raises(ValueError, match="Ambiguous module file key"):
+        identity.scoped_module_keys(index, "can://shop/currency", ("javascript", "typescript"))
diff --git a/tests/analysis/typescript/test_typescript_neo4j_bulk.py b/tests/analysis/typescript/test_typescript_neo4j_bulk.py
index 35c1523..59e65c3 100644
--- a/tests/analysis/typescript/test_typescript_neo4j_bulk.py
+++ b/tests/analysis/typescript/test_typescript_neo4j_bulk.py
@@ -278,10 +278,35 @@ def test_callsites_for_query_shape_and_scope():
         return []
 
     backend = _backend()
     with patch.object(TSNeo4jBackend, "_run", side_effect=_run):
         assert backend.get_callsites_for(["sig-a"]) == {}
     assert "TS_HAS_BODY_NODE]->(s:TSBodyNode {kind: 'call'})" in captured["query"]
     assert "TS_RESOLVES_TO" in captured["query"]
     assert "coalesce(t.signature, t.module + '.' + t.name) AS callee" in captured["query"]
     assert captured["sigs"] == ["sig-a"]
     assert captured["p"] == PREFIX
+
+
+def test_module_loader_rejects_conflicting_canonical_rows():
+    import pytest
+    backend = _backend()
+    rows = [{"k": "server.js", "id": CODE_PREFIX + "server.js"}, {"k": "other.js", "id": CODE_PREFIX + "server.js"}]
+    with patch.object(TSNeo4jBackend, "_run", return_value=rows):
+        with pytest.raises(ValueError, match="Conflicting file keys"):
+            backend._load_module_keys()
+
+
+def test_duplicate_module_cleanup_preserves_two_call_sites_to_same_target():
+    backend = _backend()
+    mid = CODE_PREFIX + "server.js"
+    owner = "server.main"
+    modules = [{"k": "server.js", "id": mid}] * 2
+    sites = [
+        {"owner": owner, "p": {"id": mid + f"/main@{line}:1", "kind": "call", "start_line": line, "end_line": line}, "callee": "server.target"}
+        for line in (28, 31)
+    ]
+    with patch.object(TSNeo4jBackend, "_run", side_effect=[modules, sites]):
+        assert backend._load_module_keys() == {"server.js": mid}
+        assert len(backend._module_index) == 1
+        result = backend.get_callsites_for([owner])[owner]
+    assert [(site.start_line, site.callee_signature) for site in result] == [(28, "server.target"), (31, "server.target")]
diff --git a/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py b/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py
index 77f814b..2cadb11 100644
--- a/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py
+++ b/tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py
@@ -1446,10 +1446,42 @@ def test_seek_labels_follow_the_measured_rule():
         s = _render(statement)  # a template's `{{id:$x}}` is an id point lookup; judge what runs
         for m in re.finditer(r"\(\w*:([\w:|]+) ?\{id ?: ?\$\w+\}\)", s):
             assert m.group(1).startswith("CanNode:") or m.group(1) in ("Application",), f"{name}: id point lookup without :CanNode -- {m.group(0)}"
         # ``.id IN $srcs`` (leg 4b's ``_TAINT``) is the same unique-index seek as ``{id: $src}``, once
         # per value -- which is why ``_MATCHES_BY_ID`` already treats the three spellings alike. The
         # measurement this rule rests on is about a ``STARTS WITH`` *range* seek being what finds the
         # anchor; a statement that pins its anchors by id has nothing to range-seek, however many ids
         # it pins.
         if _is_scoped(s) and not re.search(r"\{id ?: ?\$\w+\}|\.id (?:=|IN) \$", s):
             assert "CanNode" not in s, f"{name}: a prefix-scoped statement names :CanNode (measured: bare 1.62 ms vs 32.35 ms) -- {s[:120]!r}"
+
+
+@pytest.mark.parametrize("order", [("currency", "payment"), ("payment", "currency")])
+def test_currency_scanner_position_never_attaches_payment_constructor(monkeypatch, order):
+    from cldk.analysis.commons.identity import index_module_rows
+
+    graph = _Graph()
+    rows = []
+    for app, name, start, end in (("currency", "_loadProto", 91, 110), ("payment", "constructor", 24, 34)):
+        aid = graph.node(f"can://shop/{app}", ["Application", "TSApplication"], identity_version=2, application_name=app, identity_namespace="shop", analyzer_version="1.5.2")
+        mid = graph.node(aid + "/javascript/server.js", ["TSModule"], kind="module", name="server.js", start_line=1, end_line=150)
+        graph.edge(aid, "TS_HAS_MODULE", mid)
+        cid = graph.node(mid + "/" + name, ["TSCallable"], kind="function", name=name, signature="server." + name, start_line=start, end_line=end, code="function() {}")
+        graph.edge(mid, "TS_DECLARES", cid)
+        rows.append({"module_id": mid, "file_key": "server.js"})
+    monkeypatch.setattr(__import__(__name__, fromlist=["GRAPH"]), "GRAPH", graph)
+    backends = {app: TSNeo4jBackend._from_driver(FakeDriver(responder=fake_cypher), application_name=app, namespace="shop") for app in order}
+    # Simulate a downstream scanner joining its canonical module ID to SDK modules.
+    # Backend iteration order and duplicate projections must not choose the owner.
+    projected = [row for app in order for row in rows if row["module_id"].startswith(f"can://shop/{app}/")]
+    index = index_module_rows(projected + projected[:1])
+    finding_module = "can://shop/currency/javascript/server.js"
+    matches = [row for mid, row in index.items() if mid == finding_module]
+    assert matches == [{"module_id": finding_module, "file_key": "server.js"}]
+    owners = [backend for backend in backends.values() if finding_module.startswith(backend.identity.application_id + "/")]
+    assert len(owners) == 1
+    result = owners[0].locate(matches[0]["file_key"], 28)
+    assert result.callable is None
+    assert backends["currency"].locate("server.js", 91).callable.name == "_loadProto"
+    assert backends["payment"].locate("server.js", 28).callable.name == "constructor"
+    index = index_module_rows(rows + rows[:1])
+    assert list(mid for mid in index if mid == "can://shop/currency/javascript/server.js") == ["can://shop/currency/javascript/server.js"]
# python-sdk: 1f3948976c2d14fb45a7585bcc5b05f07d9b2b15..72f14d7d9a6997019ff4ac079838505631df7540
