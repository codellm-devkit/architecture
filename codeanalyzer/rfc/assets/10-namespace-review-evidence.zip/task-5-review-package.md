8fabbf6 feat: qualify Go analysis identities by namespace
 README.md                                          | 49 +++++++++------
 cmd/codeanalyzer/main.go                           | 31 +++++++---
 cmd/codeanalyzer/main_test.go                      | 52 +++++++++++++++-
 internal/core/analyzer.go                          | 36 ++++++++++-
 internal/core/analyzer_test.go                     | 41 ++++++++++++-
 internal/dataflow/run_test.go                      | 17 +++++-
 internal/metamorphic/run.go                        |  3 +-
 internal/neo4j/bolt.go                             | 17 ++++--
 internal/neo4j/bolt_session_test.go                | 43 +++++++++++--
 internal/neo4j/bolt_test.go                        | 18 +++---
 internal/neo4j/cypher.go                           | 46 +++++++++++++-
 internal/neo4j/cypher_test.go                      | 58 ++++++++++++++----
 internal/neo4j/emit.go                             |  8 ++-
 internal/neo4j/project.go                          |  4 +-
 internal/neo4j/project_test.go                     | 32 ++++++++--
 internal/neo4j/rows.go                             | 39 +++++++++---
 internal/neo4j/rows_test.go                        | 67 ++++++++++++++------
 internal/neo4j/schema.go                           |  2 +-
 internal/options/options.go                        |  4 +-
 internal/schema/v2/ids.go                          | 62 ++++++++++++++++---
 internal/schema/v2/ids_test.go                     | 30 ++++-----
 internal/schema/v2/namespace_test.go               | 62 +++++++++++++++++++
 internal/schema/v2/schema.go                       | 22 ++++---
 .../v2emit/determinism_freshbuild_test.go          |  2 +-
 .../syntactic_analysis/v2emit/determinism_test.go  | 10 +--
 internal/syntactic_analysis/v2emit/emit.go         | 37 +++++------
 internal/syntactic_analysis/v2emit/emit_l4_test.go |  2 +-
 internal/syntactic_analysis/v2emit/emit_test.go    | 26 +++++---
 .../v2emit/gate_l2_inits_test.go                   |  2 +-
 internal/syntactic_analysis/v2emit/gate_l2_test.go | 26 ++++----
 internal/syntactic_analysis/v2emit/gate_l3_test.go |  4 +-
 .../syntactic_analysis/v2emit/gate_l4_done_test.go |  8 +--
 internal/syntactic_analysis/v2emit/gate_l4_test.go | 71 +++++++++++++++++++---
 internal/syntactic_analysis/v2emit/gate_test.go    | 18 +++---
 34 files changed, 735 insertions(+), 214 deletions(-)
diff --git a/README.md b/README.md
index 11f93f5..8481ee6 100644
--- a/README.md
+++ b/README.md
@@ -51,21 +51,21 @@ The binary is fully self-contained: a single static executable with no runtime d
 - [Architecture & Tooling](#architecture--tooling)
 - [Development](#development)
 - [License](#license)
 
 ## Features
 
 - **Symbol table** — packages, structs, interfaces, fields, methods, package-level functions,
   imports, struct tags, and generic type parameters, with precise source spans.
 - **Call graph** — a resolver-based call graph via `go/types`: each call site is resolved to its
   full import-path signature. Level 2 emits edges to project callees and to library callees
-  (homed in `application.external_symbols` under `can://<app>/@external/<import-path>/<sig>`).
+  (homed in `application.external_symbols` under `can://<namespace>/<app>/@external/<import-path>/<sig>`).
   Level 3 (`-a 3`) adds per-callable `cfg`, `cdg` and `ddg`. Level 4 (`-a 4`) adds the
   interprocedural system dependence graph (SDG): parameter vertices, `param_in` / `param_out`,
   call-site `summary` edges, VTA dispatch targets and library stand-ins — what the SDK's
   slicing and `taint()` walk.
 - **Generics-aware** — Go 1.18+ generics (`Set[T]`, union-constraint interfaces, multi-type-param
   functions) are modeled in the unified type/callable schema.
 - **Self-contained binary** — a single static executable (`go build`, `CGO_ENABLED=0`); no runtime
   dependencies for SDK users.
 - **CLDK canonical schema** — output is spine-compatible with the Java/Python/TypeScript analyzers,
   loadable directly by the Python SDK.
@@ -244,21 +244,21 @@ module. Write the output to a directory with `-o`; `cango` names the file
 # Level 2 (symbol table + call graph):
 cango -i /path/to/go/app -a 2 -o /path/to/output/
 # → writes /path/to/output/analysis.json
 ```
 
 > **Schema.** `cango` emits the **canonical CLDK v2** tree (the shape the Python SDK's v2
 > loader and the sections below describe). Omit `-o` to stream the JSON to stdout instead
 > of writing a file.
 
 **3. (Optional) name the application anchor.** `--app-name` sets the `<app>` in every
-`can://<app>/…` id and defaults to the input directory's base name. Set it when the
+`can://<namespace>/<app>/…` id and defaults to the input directory's base name. Set it when the
 directory name isn't the identity you want:
 
 ```bash
 cango -i /path/to/go/app -a 2 --app-name myapp -o ./out/
 ```
 
 **4. Verify.** A successful run exits `0` and produces a JSON document whose envelope
 carries `"schema_version": "2.0.0"`, `"language": "go"`, `"max_level": 2`, and an
 `application` tree under `application.symbol_table`:
 
@@ -351,111 +351,115 @@ subset of `-a 4` output, and `-j 1` and `-j N` output are byte-identical.
 **Level 2** adds a resolver pass: for each call site, `go/types` resolves the callee to its full import-path signature (`pkgImportPath.TypeName.MethodName`). A project callee becomes an edge to its callable; a **library callee** (stdlib, a dependency, or a package vendored under `vendor/`) becomes an edge to an `@external` symbol, recorded once in `application.external_symbols`. A callee that is neither (an interface method of a project type, a conversion, a builtin, a call through a function value) gets no edge. Every resolved call node's `callee` is backfilled.
 
 ## Output schema
 
 `cango` emits the **canonical CLDK v2** shape — the shape the v2 Python SDK loader consumes
 and the [step-by-step section above](#generating-analysisjson-for-a-go-app) produces.
 
 ### Canonical v2 shape
 
 The document is a manifest envelope wrapping one `application` containment tree. Every
-node carries a `can://<app>/…` `id`, a `kind`, and a `span`:
+node carries a `can://<namespace>/<app>/…` `id`, a `kind`, and a `span`:
 
 ```json
 {
+  "identity_version": 2,
   "schema_version": "2.0.0",
   "language": "go",
   "max_level": 2,
   "analyzer": { "name": "codeanalyzer-go", "version": "0.1.0" },
   "application": {
-    "id": "can://myapp",
+    "id": "can://myapp/myapp",
+    "identity_version": 2,
+    "application_name": "myapp",
+    "identity_namespace": "myapp",
     "kind": "application",
     "symbol_table": {
       "pkg/greeter/greeter.go": {
-        "id": "can://myapp/go/pkg/greeter/greeter.go",
+        "id": "can://myapp/myapp/go/pkg/greeter/greeter.go",
         "kind": "module",
         "package": "greeter",
         "span": { "start": [1, 1], "end": [40, 2], "bytes": [0, 812] },
         "source": "package greeter\n\n...",
         "content_hash": "…",
         "imports": [ { "name": "fmt", "path": "fmt", "span": {…} } ],
         "types": {
           "Greeter": {
-            "id": "can://myapp/go/pkg/greeter/greeter.go/example.com/pkg/greeter.Greeter",
+            "id": "can://myapp/myapp/go/pkg/greeter/greeter.go/example.com/pkg/greeter.Greeter",
             "kind": "struct",
             "span": { "start": [5, 1], "end": [7, 2], "bytes": [17, 63] },
             "fields": {
               "Prefix": { "id": "…/Prefix", "kind": "field", "type": "string", "span": {…} }
             },
             "callables": {
               "example.com/pkg/greeter.Greeter.Greet": {
-                "id": "can://myapp/go/pkg/greeter/greeter.go/example.com/pkg/greeter.Greeter/example.com/pkg/greeter.Greeter.Greet",
+                "id": "can://myapp/myapp/go/pkg/greeter/greeter.go/example.com/pkg/greeter.Greeter/example.com/pkg/greeter.Greeter.Greet",
                 "kind": "method",
                 "signature": "example.com/pkg/greeter.Greeter.Greet",
                 "span": { "start": [9, 1], "end": [11, 2], "bytes": [65, 140] },
                 "parameters": [ { "name": "name", "type": "string", "span": {…} } ],
                 "return_type": "string",
                 "error_channel": ["error"],
                 "metrics": { "cyclomatic": 1 },
                 "body": {
                   "10:2": {
                     "kind": "call",
-                    "id": "can://myapp/go/pkg/greeter/greeter.go/…/example.com/pkg/greeter.Greeter.Greet@10:2",
+                    "id": "can://myapp/myapp/go/pkg/greeter/greeter.go/…/example.com/pkg/greeter.Greeter.Greet@10:2",
                     "span": { "start": [10, 2], "end": [10, 30], "bytes": [90, 118] },
-                    "callee": "can://myapp/go/pkg/greeter/greeter.go/…/example.com/pkg/greeter.format"
+                    "callee": "can://myapp/myapp/go/pkg/greeter/greeter.go/…/example.com/pkg/greeter.format"
                   }
                 }
               }
             }
           }
         },
         "functions": {
           "example.com/main.main": { "id": "…", "kind": "function", "signature": "…", "body": {…} }
         }
       }
     },
     "call_graph": [
       {
-        "src": "can://myapp/go/main.go/…/example.com/main.main",
-        "dst": "can://myapp/go/pkg/greeter/greeter.go/…/example.com/pkg/greeter.Greeter.Greet",
+        "src": "can://myapp/myapp/go/main.go/…/example.com/main.main",
+        "dst": "can://myapp/myapp/go/pkg/greeter/greeter.go/…/example.com/pkg/greeter.Greeter.Greet",
         "prov": ["go/types"],
         "weight": 1
       }
     ]
   }
 }
 ```
 
 Key v2 schema properties:
 - **Envelope** — `schema_version` (`"2.0.0"`), `language` (`"go"`), `max_level` (1–4),
   `k_limit` (L3+: the `--graph-field-depth` value), `degraded[]` (L4, only when something
   degraded) and `analyzer{name,version}` wrap a single `application` node.
 - **One containment tree** — `application → module → type → callable → body`, keyed as
   `symbol_table` (modules, by **project-relative file path**), `types`, `callables`, `body`.
-- **`id`** — every node carries a durable `can://<app>/go/<file>/<type>/<signature>` id;
+- **`id`** — every node carries a durable `can://<namespace>/<app>/go/<file>/<type>/<signature>` id;
   `<app>` is the `--app-name` anchor. A body node is keyed by `line:col` in its callable's `body`
   map and carries `id` = `<callable-id>@<key>` at every level, from `-a 1` on.
 - **`kind`** — `module` · `type` kinds `struct | interface | alias | defined` (collapses v1's
   `is_interface`) · `callable` kinds `function | method | lambda` · body `call`.
 - **`base_types: []`** (type, optional) — embedded type ids (struct/interface embedding — the
   explicit spine), as opposed to interfaces the type is *computed* to satisfy.
 - **`span`** — `{start:[line,col], end:[line,col], bytes:[from,to]}`; `bytes` are **UTF-8 byte
   offsets** into the owning `module.source` (source is stored once per module, every node slices it).
 - **`source_file`** (callable, optional) — set when a method is declared in a *different file*
   than its receiver type, and on every closure (nested ones too) inside such a method; the
   callable stays nested under the type, and its `span.bytes` (and its body nodes' spans) index
   `symbol_table[source_file].source` instead of the nesting module's.
 - **`error_channel: []`** — populated from `error`-typed returns (the returns also stay in
   `return_type`). **Closures** nest as `callables{}` on the enclosing callable.
 - **`body` call nodes** — `callee` is the sanctioned `null → id` slot: `null` at L1; at L2 a
   project callable's `can://` id, or for a library (stdlib or dependency) callee its
-  `can://<app>/@external/<import-path>/<sig>` id, a key of `external_symbols`. It stays `null`
+  `can://<namespace>/<app>/@external/<import-path>/<sig>` id, a key of `external_symbols`. It stays `null`
   for conversions, builtins, calls through function values and unresolved sites. `is_goroutine` / `is_deferred`
   are boolean flags emitted **only when true** (a plain call omits them), for `go f()` / `defer f()`.
 - **`call_graph` edges** — `{src, dst, prov, weight}`; `src` is a callable id in the tree and
   `dst` a callable id or an `external_symbols` key (never a raw signature); `prov` is resolver
   provenance, e.g. `["go/types"]`.
 - **`external_symbols`** (application, L2, optional) — one entry per library callee, keyed by
   its `@external` id: `{id, kind: "external", name, module, signature, parameters[], return_type}`
   (parameters carry no span). Absent when no library call was resolved.
 - **L3 (`-a 3`)** — `body` gains `statement` / `branch` / `loop` / `switch` / `return` nodes
   and the synthetic `@entry` / `@exit` (which have no `span`). Every body node carries `id`
@@ -469,37 +473,37 @@ Key v2 schema properties:
   `<capture>:<name>`, `<global>:<pkgpath>::<Name>`); actuals carry `parent` = the call key.
   `ddg` gains `prov: ["reaching-defs"]` (port wiring) and `["points-to"]` edges; a callable gains
   `summary[] {src, dst}` (local keys); the application gains `param_in[]` / `param_out[]`
   `{src, dst, var}` (global body-node ids, `var` = the callee formal's `of`); an external gains
   `receiver {name, type}` and a stand-in `body` of its formal vertices (ids
   `<external-id>@formal_in:<i>`).
 
 ## Neo4j projection (`--emit neo4j`)
 
 `--emit neo4j` projects the **same v2 envelope** into a Neo4j property graph. It is a *second
-projection of the identical analysis* — JSON nodes and graph nodes carry the same `can://<app>/…`
+projection of the identical analysis* — JSON nodes and graph nodes carry the same `can://<namespace>/<app>/…`
 ids, so the two join on one string and are never recomposed. The graph vocabulary is `Go`-prefixed
 labels (`:GoModule`, `:GoType`, `:GoCallable`, `:GoField`, `:GoBodyNode`, `:GoExternal`, plus the
 shared merge label `:GoSymbol` and marker `:GoCanNode`) and `GO_`-prefixed relationships
 (`GO_HAS_MODULE`, `GO_DECLARES`, `GO_HAS_METHOD`, `GO_HAS_FIELD`, `GO_CALLS`, `GO_RESOLVES_TO`,
 `GO_IMPORTS`, `GO_EMBEDS`, `GO_SATISFIES`, …).
 
 There are two output paths, chosen by whether `--neo4j-uri` is set:
 
 | | `--neo4j-uri` unset | `--neo4j-uri` set |
 |---|---|---|
 | **What happens** | Writes a replayable `graph.cypher` snapshot | Pushes the graph live over Bolt into a running Neo4j |
 | **Where** | `<-o dir>/graph.cypher` (or stdout) | The target database |
 | **Use for** | Review, diffing, loading on your own schedule, CI | A DB you already have running |
 
 Both paths are **scoped to one application**: every destructive statement is anchored on
-`:GoCanNode` and the `can://<app>/` id prefix, so it never touches another app (or a
+`:GoCanNode` and the `can://<namespace>/<app>/` id prefix, so it never touches another app (or a
 sibling-language graph) in the same database. The projection is **deterministic** — a second emit
 is byte-identical.
 
 What a re-emit replaces depends on the path:
 
 - **`graph.cypher` snapshot** and **`--eager` Bolt push**: the app's subgraph is purged and
   rebuilt, so re-emitting replaces exactly that app's subgraph.
 - **Default (lazy) Bolt push**: purely additive. Changed modules are MERGE-upserted and nothing is
   deleted. After source edits, nodes and edges that the new analysis no longer emits stay in the
   database. For L3 this includes `:GoBodyNode`s and their `GO_CFG_NEXT` / `GO_CDG` / `GO_DDG`
@@ -595,21 +599,21 @@ Always **scope by the `can://` id prefix** (an index-backed seek via the `gocann
 never by a bare label scan — replace `<app>` with your `--app-name`:
 
 ```cypher
 // Node counts by label.
 MATCH (n:GoCanNode) RETURN labels(n)[0] AS label, count(*) AS n ORDER BY n DESC;
 
 // Relationship counts by type.
 MATCH ()-[r]->() RETURN type(r) AS rel, count(*) AS n ORDER BY n DESC;
 
 // Everything owned by one application (prefix seek).
-MATCH (n:GoCanNode) WHERE n.id STARTS WITH 'can://<app>/' RETURN count(n) AS app_nodes;
+MATCH (n:GoCanNode) WHERE n.id STARTS WITH 'can://<namespace>/<app>/' RETURN count(n) AS app_nodes;
 
 // Types ranked by method count (the "god struct" finder).
 MATCH (t:GoType) OPTIONAL MATCH (t)-[:GO_HAS_METHOD]->(m)
 RETURN t.kind AS kind, t.signature AS type, count(m) AS methods ORDER BY methods DESC;
 
 // Most-called callables (in-degree) — the hot utilities.
 MATCH (:GoCallable)-[:GO_CALLS]->(b:GoCallable)
 RETURN b.signature AS callee, count(*) AS called_by ORDER BY called_by DESC LIMIT 15;
 
 // Everything Command.Execute reaches, transitively (any depth).
@@ -638,22 +642,22 @@ for file_path, go_file in analysis.get_symbol_table().items():
 
 The SDK locates the analyzer via the `codeanalyzer-go` command on `PATH` (installed by any of the
 methods above, including `pip install codeanalyzer-go`). See
 [python-sdk](https://github.com/codellm-devkit/python-sdk) for full API documentation.
 
 ## Upgrading
 
 This release changes the output contract. If you consume `analysis.json` or the Neo4j graph,
 check the following.
 
-- **Ids are app-outermost.** `can://go/<app>/<file>/…` is now `can://<app>/go/<file>/…`. Library
-  callees are `can://<app>/@external/<import-path>/<sig>`.
+- **Ids are app-outermost.** `can://go/<app>/<file>/…` is now `can://<namespace>/<app>/go/<file>/…`. Library
+  callees are `can://<namespace>/<app>/@external/<import-path>/<sig>`.
 - **Body nodes carry `id` at every level.** Each body node has `id` = `<callable-id>@<local-key>`,
   from `-a 1` on, not only at `-a 3`.
 - **L2 includes library calls.** The call graph now has edges to library (stdlib and dependency)
   callees, and `application.external_symbols` describes them. A library call's `callee` is its
   external id instead of `null`. A type conversion is still a call node, but its `callee` stays
   `null`; it is no longer resolved to a `<Type>.__new__` pseudo-callee.
 - **L1 records more.**
   - A type's `kind` can now be `alias` or `defined`, not only `struct` or `interface`.
   - Deferred calls carry `is_deferred: true`.
   - Chained calls that start at the same position, such as `s.A().B()`, are now separate call
@@ -774,10 +778,19 @@ cross-compiles the `cango` binary for all supported platforms and publishes:
 2. platform-tagged wheels to **PyPI** as `codeanalyzer-go` (via Trusted Publishing/OIDC), and
 3. a **Homebrew** formula pushed to `codellm-devkit/homebrew-tap`.
 
 The version is injected into the binary at build time via `-ldflags "-X main.version=<tag>"`, so
 `cango --version`, the wheel version, and the git tag always stay in lockstep. See
 [packaging/](packaging/) for the build scripts.
 
 ## License
 
 Apache 2.0 — see [LICENSE](./LICENSE).
+
+Application identity uses `--namespace` (default: resolved application name) and
+`--app-name` (default: input directory basename). Both segments are always present,
+for example `can://team/inventory` or `can://inventory/inventory`. Names are raw,
+case-sensitive Unicode strings; reserved UTF-8 bytes are percent encoded. Empty,
+whitespace-only, control-containing names, slashes, backslashes, `.` and `..` are
+rejected. Explicit empty flags are errors. Outputs and graph anchors carry integer
+`identity_version: 2`; regenerate legacy outputs from source. The graph writer
+rejects incompatible selected anchors before any DDL or graph write.
diff --git a/cmd/codeanalyzer/main.go b/cmd/codeanalyzer/main.go
index 9e0a941..e855f31 100644
--- a/cmd/codeanalyzer/main.go
+++ b/cmd/codeanalyzer/main.go
@@ -1,18 +1,19 @@
 // codeanalyzer-go is the CLI entry point for the Go language analyzer.
 //
 // It exposes the standard CLDK CLI surface (cli-contract.md) so the Python SDK
 // facade can shell out to it uniformly alongside Java and Python backends.
 package main
 
 import (
 	"fmt"
+	v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 	"os"
 	"path/filepath"
 	"runtime"
 
 	"github.com/spf13/cobra"
 
 	"github.com/codellm-devkit/codeanalyzer-go/internal/core"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/neo4j"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/options"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/syntactic_analysis/v2emit"
@@ -31,20 +32,21 @@ func main() {
 	}
 }
 
 func rootCmd() *cobra.Command {
 	var (
 		inputPath     string
 		outputDir     string
 		format        string
 		emit          string
 		appName       string
+		namespace     string
 		level         int
 		fieldDepth    int
 		strict        bool
 		libraryModels string
 		targetFiles   []string
 		skipTests     bool
 		eager         bool
 		cacheDir      string
 		jobs          int
 		verbosity     int
@@ -135,30 +137,42 @@ via CLDK(language="go").analysis(project_path=...).`,
 			utils.SetVerbosity(verbosity)
 
 			if cacheDir == "" {
 				home, _ := os.UserHomeDir()
 				cacheDir = home + "/.cldk/go-cache"
 			}
 			if jobs < 1 {
 				jobs = runtime.NumCPU()
 			}
 			// application anchor: explicit flag > input dir base name.
-			if appName == "" {
-				appName = filepath.Base(filepath.Clean(inputPath))
+			if !cmd.Flags().Changed("app-name") {
+				root, err := filepath.Abs(inputPath)
+				if err != nil {
+					return err
+				}
+				appName = filepath.Base(filepath.Clean(root))
 			}
 
+			var ns *string
+			if cmd.Flags().Changed("namespace") {
+				ns = &namespace
+			}
+			identity, err := v2.ResolveIdentity(appName, ns)
+			if err != nil {
+				return err
+			}
 			opts := options.AnalysisOptions{
-				InputPath:       inputPath,
-				OutputDir:       outputDir,
-				Format:          format,
-				Emit:            options.EmitTarget(emit),
-				AppName:         appName,
+				InputPath: inputPath,
+				OutputDir: outputDir,
+				Format:    format,
+				Emit:      options.EmitTarget(emit),
+				AppName:   appName, Namespace: ns,
 				Level:           options.AnalysisLevel(level),
 				Strict:          strict,
 				LibraryModels:   libraryModels,
 				AnalyzerVersion: version,
 				TargetFiles:     targetFiles,
 				SkipTests:       skipTests,
 				Eager:           eager,
 				CacheDir:        cacheDir,
 				Jobs:            jobs,
 				Verbose:         verbosity > 0,
@@ -172,21 +186,21 @@ via CLDK(language="go").analysis(project_path=...).`,
 			analyzer := core.New(opts)
 			app, err := analyzer.Analyze()
 			if err != nil {
 				return err
 			}
 
 			// Neo4j projection: build the canonical v2 payload (the SAME tree the
 			// JSON path emits) and project it. --neo4j-uri set → live Bolt push;
 			// absent → a graph.cypher snapshot in the output dir.
 			if emitTarget == options.EmitNeo4j {
-				payload := v2emit.Emit(app, opts.AppName, opts.InputPath, int(opts.Level), opts.AnalyzerVersion, core.KLimit(opts), analyzer.L3(), analyzer.L4())
+				payload := v2emit.Emit(app, identity, opts.InputPath, int(opts.Level), opts.AnalyzerVersion, core.KLimit(opts), analyzer.L3(), analyzer.L4())
 				boltCfg := neo4j.BoltConfig{
 					URI:      opts.Neo4jURI,
 					User:     opts.Neo4jUser,
 					Password: opts.Neo4jPassword,
 					Database: opts.Neo4jDatabase,
 					Eager:    opts.Eager,
 					FullRun:  len(opts.TargetFiles) == 0,
 				}
 				msg, err := neo4j.EmitNeo4j(cmd.Context(), payload, outputDir, boltCfg)
 				if err != nil {
@@ -204,20 +218,21 @@ via CLDK(language="go").analysis(project_path=...).`,
 			}
 			return core.WriteOutput(app, analyzer.L3(), analyzer.L4(), opts)
 		},
 	}
 
 	f := cmd.Flags()
 	f.StringVarP(&inputPath, "input", "i", "", "Project root to analyze (required)")
 	f.StringVarP(&outputDir, "output", "o", "", "Output directory for analysis.json (default: stdout)")
 	f.StringVarP(&format, "format", "f", "json", "Output format: json|msgpack")
 	f.StringVar(&emit, "emit", "json", "Output projection: json|neo4j|schema")
+	f.StringVar(&namespace, "namespace", "", "Identity namespace (default: application name)")
 	f.StringVar(&appName, "app-name", "",
 		"Application anchor name for can:// ids and Neo4j :Application (default: input dir name)")
 	f.IntVarP(&level, "analysis-level", "a", 1,
 		"Analysis level: 1=symbol table, 2=+call graph, 3=+intraprocedural cfg/cdg/ddg, 4=+interprocedural SDG")
 	f.IntVar(&fieldDepth, "graph-field-depth", 3,
 		"Field-path depth bound for L3 dataflow nodes (k limit; applies at -a 3 and -a 4)")
 	f.BoolVar(&strict, "strict", false, "Fail non-zero on any L4 degradation (default: degrade and record it)")
 	f.StringVar(&libraryModels, "library-models", "",
 		"JSON file of library stand-in flows overriding the all-to-all default (-a 4 and --emit neo4j only)")
 	f.StringSliceVarP(&targetFiles, "target-files", "t", nil,
diff --git a/cmd/codeanalyzer/main_test.go b/cmd/codeanalyzer/main_test.go
index 7da9999..e7f6813 100644
--- a/cmd/codeanalyzer/main_test.go
+++ b/cmd/codeanalyzer/main_test.go
@@ -271,22 +271,22 @@ func TestRootCmd_EmitsCanonicalV2(t *testing.T) {
 	}
 	if jsonErr := json.Unmarshal([]byte(out), &v); jsonErr != nil {
 		t.Fatalf("stdout is not valid JSON: %v", jsonErr)
 	}
 	if v.SchemaVersion != "2.0.0" {
 		t.Errorf("schema_version = %q, want 2.0.0", v.SchemaVersion)
 	}
 	if v.Language != "go" {
 		t.Errorf("language = %q, want go", v.Language)
 	}
-	if v.Application.ID != "can://greeter" {
-		t.Errorf("application.id = %q, want can://greeter", v.Application.ID)
+	if v.Application.ID != "can://greeter/greeter" {
+		t.Errorf("application.id = %q, want can://greeter/greeter", v.Application.ID)
 	}
 }
 
 // ── --skip-tests ─────────────────────────────────────────────────────────────
 
 func TestRootCmd_SkipTestsFalseIncludesTestFiles(t *testing.T) {
 	td := cliTestdataDir()
 
 	out, _, err := runCmd(
 		"--input", filepath.Join(td, "multipackage"),
@@ -772,10 +772,58 @@ func TestCLI_LibraryModelsBadFileErrors(t *testing.T) {
 			"--input", filepath.Join(td, "greeter"),
 			"--analysis-level", "4",
 			"--library-models", path,
 			"--cache-dir", t.TempDir(),
 		)
 		if err == nil || !strings.Contains(err.Error(), path) {
 			t.Errorf("%s: error = %v, want one naming %s", name, err, path)
 		}
 	}
 }
+
+func TestNamespaceExplicitEmptyRejected(t *testing.T) {
+	for _, flag := range []string{"--namespace", "--app-name"} {
+		_, _, err := runCmd("--input", filepath.Join(cliTestdataDir(), "greeter"), flag, "", "--cache-dir", t.TempDir())
+		if err == nil {
+			t.Fatalf("accepted empty %s", flag)
+		}
+	}
+}
+func TestNamespaceExplicitScope(t *testing.T) {
+	out, _, err := runCmd("--input", filepath.Join(cliTestdataDir(), "greeter"), "--namespace", "team space", "--app-name", "billing", "--cache-dir", t.TempDir())
+	if err != nil {
+		t.Fatal(err)
+	}
+	var a struct {
+		IdentityVersion int `json:"identity_version"`
+		Application     struct {
+			ID        string `json:"id"`
+			Namespace string `json:"identity_namespace"`
+			Name      string `json:"application_name"`
+		}
+	}
+	if err = json.Unmarshal([]byte(out), &a); err != nil {
+		t.Fatal(err)
+	}
+	if a.IdentityVersion != 2 || a.Application.ID != "can://team%20space/billing" || a.Application.Namespace != "team space" || a.Application.Name != "billing" {
+		t.Fatalf("%+v", a)
+	}
+}
+
+func TestNamespaceDefaultUsesNormalizedInput(t *testing.T) {
+	t.Chdir(filepath.Join(cliTestdataDir(), "greeter"))
+	out, _, err := runCmd("--input", ".", "--cache-dir", t.TempDir())
+	if err != nil {
+		t.Fatal(err)
+	}
+	var a struct {
+		Application struct {
+			ID string `json:"id"`
+		}
+	}
+	if err = json.Unmarshal([]byte(out), &a); err != nil {
+		t.Fatal(err)
+	}
+	if a.Application.ID != "can://greeter/greeter" {
+		t.Fatal(a.Application.ID)
+	}
+}
diff --git a/internal/core/analyzer.go b/internal/core/analyzer.go
index 2d541bf..9618e27 100644
--- a/internal/core/analyzer.go
+++ b/internal/core/analyzer.go
@@ -8,23 +8,25 @@
 //  1. Project materialization (go mod download)
 //  2. Symbol table construction  (syntactic_analysis)
 //  3. Resolver-based call graph  (semantic_analysis) — if level >= 2
 //  4. Pass pipeline              (analysis/registry)
 //  5. Intraprocedural dataflow   (dataflow) — if level >= 3
 //  6. System dependence graph    (sdg) — if level >= 4
 package core
 
 import (
 	"bufio"
+	"crypto/sha256"
 	"encoding/json"
 	"errors"
 	"fmt"
+	v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 	"io"
 	"io/fs"
 	"math/rand/v2"
 	"os"
 	"os/exec"
 	"path/filepath"
 	"strconv"
 	"strings"
 
 	"github.com/codellm-devkit/codeanalyzer-go/internal/analysis"
@@ -60,27 +62,47 @@ func (a *Analyzer) L4() *sdg.Result { return a.l4 }
 
 // KLimit is the access-path bound used at L3 and L4: opts.FieldDepth, or the
 // --graph-field-depth default of 3 when a non-CLI caller left it 0.
 func KLimit(opts options.AnalysisOptions) int {
 	if opts.FieldDepth > 0 {
 		return opts.FieldDepth
 	}
 	return 3
 }
 
-// New creates an Analyzer for the given options.
+// resolveIdentity preserves the default input basename for programmatic callers.
+func resolveIdentity(opts options.AnalysisOptions) (v2.Identity, error) {
+	name := opts.AppName
+	if name == "" {
+		root, err := filepath.Abs(opts.InputPath)
+		if err != nil {
+			return v2.Identity{}, err
+		}
+		name = filepath.Base(filepath.Clean(root))
+	}
+	return v2.ResolveIdentity(name, opts.Namespace)
+}
+
+// New creates an Analyzer with a cache isolated by canonical application identity.
 func New(opts options.AnalysisOptions) *Analyzer {
+	if identity, err := resolveIdentity(opts); err == nil && opts.CacheDir != "" {
+		key := sha256.Sum256([]byte(identity.ApplicationID))
+		opts.CacheDir = filepath.Join(opts.CacheDir, fmt.Sprintf("identity-v2-%x", key))
+	}
 	return &Analyzer{opts: opts}
 }
 
 // Analyze runs the full analysis pipeline and returns a GoApplication.
 func (a *Analyzer) Analyze() (*schema.GoApplication, error) {
+	if _, err := resolveIdentity(a.opts); err != nil {
+		return nil, err
+	}
 	// Resolve to absolute path so filepath.Rel works correctly in all cases.
 	abs, err := filepath.Abs(a.opts.InputPath)
 	if err != nil {
 		return nil, fmt.Errorf("resolving input path: %w", err)
 	}
 	a.opts.InputPath = abs
 	utils.Info("analyzing project: %s", a.opts.InputPath)
 
 	// The L4 library models are read first, so a bad file fails the run
 	// before any analysis (also under --emit neo4j -t, which runs at L3).
@@ -285,32 +307,40 @@ func checkFormat(opts options.AnalysisOptions) error {
 // streaming StreamJSON / WriteOutput paths are byte-identical to; the CLI
 // streams instead, so the document never exists in memory at once.
 //
 // l3 is the Analyzer's L3() side table (nil below level 3) and l4 its L4()
 // result (nil below level 4). At level 3 the envelope carries k_limit =
 // KLimit(opts) whether or not l3 is set.
 func RenderJSON(app *schema.GoApplication, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result, opts options.AnalysisOptions) ([]byte, error) {
 	if err := checkFormat(opts); err != nil {
 		return nil, err
 	}
-	payload := v2emit.Emit(app, opts.AppName, opts.InputPath, int(opts.Level), opts.AnalyzerVersion, KLimit(opts), l3, l4)
+	identity, err := resolveIdentity(opts)
+	if err != nil {
+		return nil, err
+	}
+	payload := v2emit.Emit(app, identity, opts.InputPath, int(opts.Level), opts.AnalyzerVersion, KLimit(opts), l3, l4)
 	return json.Marshal(payload)
 }
 
 // StreamJSON writes the bytes RenderJSON returns to w, emitting and encoding
 // one module at a time (v2emit.EmitTo) through a buffered writer.
 func StreamJSON(w io.Writer, app *schema.GoApplication, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result, opts options.AnalysisOptions) error {
 	if err := checkFormat(opts); err != nil {
 		return err
 	}
+	identity, err := resolveIdentity(opts)
+	if err != nil {
+		return err
+	}
 	bw := bufio.NewWriterSize(w, 1<<20)
-	if err := v2emit.EmitTo(bw, app, opts.AppName, opts.InputPath, int(opts.Level), opts.AnalyzerVersion, KLimit(opts), l3, l4); err != nil {
+	if err := v2emit.EmitTo(bw, app, identity, opts.InputPath, int(opts.Level), opts.AnalyzerVersion, KLimit(opts), l3, l4); err != nil {
 		return err
 	}
 	return bw.Flush()
 }
 
 // WriteOutput streams the analysis to outputDir/analysis.json, or to stdout
 // when outputDir is empty. The file is written beside its destination and
 // renamed into place, so a failed run never leaves a truncated analysis.json.
 func WriteOutput(app *schema.GoApplication, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result, opts options.AnalysisOptions) error {
 	if err := checkFormat(opts); err != nil {
diff --git a/internal/core/analyzer_test.go b/internal/core/analyzer_test.go
index a7198dd..52330ec 100644
--- a/internal/core/analyzer_test.go
+++ b/internal/core/analyzer_test.go
@@ -282,38 +282,38 @@ func TestCaching_CacheFileWritten(t *testing.T) {
 	cacheDir := t.TempDir()
 	opts := options.AnalysisOptions{
 		InputPath: greeterDir(t),
 		Level:     options.LevelSymbolTable,
 		SkipTests: true,
 		CacheDir:  cacheDir,
 	}
 	if _, err := core.New(opts).Analyze(); err != nil {
 		t.Fatalf("Analyze: %v", err)
 	}
-	if _, err := os.Stat(filepath.Join(cacheDir, "analysis_cache.json")); err != nil {
+	if _, err := os.Stat(identityCacheFile(t, cacheDir)); err != nil {
 		t.Fatalf("analysis_cache.json not written to CacheDir: %v", err)
 	}
 }
 
 func TestCaching_CacheContentsRoundTrip(t *testing.T) {
 	cacheDir := t.TempDir()
 	opts := options.AnalysisOptions{
 		InputPath: greeterDir(t),
 		Level:     options.LevelSymbolTable,
 		SkipTests: true,
 		CacheDir:  cacheDir,
 	}
 	app, err := core.New(opts).Analyze()
 	if err != nil {
 		t.Fatalf("Analyze: %v", err)
 	}
-	data, err := os.ReadFile(filepath.Join(cacheDir, "analysis_cache.json"))
+	data, err := os.ReadFile(identityCacheFile(t, cacheDir))
 	if err != nil {
 		t.Fatalf("reading analysis_cache.json: %v", err)
 	}
 	var cached schema.GoApplication
 	if err := json.Unmarshal(data, &cached); err != nil {
 		t.Fatalf("cache JSON round-trip failed: %v", err)
 	}
 	if len(cached.SymbolTable) != len(app.SymbolTable) {
 		t.Errorf("cache symbol table key count %d != in-memory %d",
 			len(cached.SymbolTable), len(app.SymbolTable))
@@ -324,21 +324,21 @@ func TestCaching_EagerForcesRebuild(t *testing.T) {
 	cacheDir := t.TempDir()
 	opts := options.AnalysisOptions{
 		InputPath: greeterDir(t),
 		Level:     options.LevelSymbolTable,
 		SkipTests: true,
 		CacheDir:  cacheDir,
 	}
 	if _, err := core.New(opts).Analyze(); err != nil {
 		t.Fatalf("first run: %v", err)
 	}
-	cachePath := filepath.Join(cacheDir, "analysis_cache.json")
+	cachePath := identityCacheFile(t, cacheDir)
 	info1, err := os.Stat(cachePath)
 	if err != nil {
 		t.Fatalf("cache not written after first run: %v", err)
 	}
 
 	// Backdate the cache file so the mtime delta is unambiguous — no sleep needed.
 	past := info1.ModTime().Add(-time.Second)
 	if err := os.Chtimes(cachePath, past, past); err != nil {
 		t.Fatalf("backdating cache mtime: %v", err)
 	}
@@ -383,10 +383,45 @@ func allSignatures(app *schema.GoApplication) map[string]bool {
 	return sigs
 }
 
 func keys[K comparable, V any](m map[K]V) []K {
 	out := make([]K, 0, len(m))
 	for k := range m {
 		out = append(out, k)
 	}
 	return out
 }
+
+func identityCacheFile(t *testing.T, dir string) string {
+	t.Helper()
+	files, err := filepath.Glob(filepath.Join(dir, "identity-v2-*", "analysis_cache.json"))
+	if err != nil || len(files) != 1 {
+		t.Fatalf("identity cache files: %v %v", files, err)
+	}
+	return files[0]
+}
+func TestCaching_NamespaceIsolation(t *testing.T) {
+	dir := t.TempDir()
+	for _, ns := range []string{"team-a", "team-b"} {
+		opts := options.AnalysisOptions{InputPath: greeterDir(t), AppName: "greeter", Namespace: &ns, Level: options.LevelSymbolTable, SkipTests: true, CacheDir: dir}
+		if _, err := core.New(opts).Analyze(); err != nil {
+			t.Fatal(err)
+		}
+	}
+	files, err := filepath.Glob(filepath.Join(dir, "identity-v2-*", "analysis_cache.json"))
+	if err != nil || len(files) != 2 {
+		t.Fatalf("cache scopes: %v %v", files, err)
+	}
+}
+
+func TestAnalyzeInvalidNamespaceReadOnly(t *testing.T) {
+	ns := ""
+	dir := t.TempDir()
+	opts := options.AnalysisOptions{InputPath: greeterDir(t), AppName: "greeter", Namespace: &ns, Level: options.LevelSymbolTable, CacheDir: dir}
+	if _, err := core.New(opts).Analyze(); err == nil {
+		t.Fatal("accepted empty namespace")
+	}
+	entries, err := os.ReadDir(dir)
+	if err != nil || len(entries) != 0 {
+		t.Fatalf("cache changed: %v %v", entries, err)
+	}
+}
diff --git a/internal/dataflow/run_test.go b/internal/dataflow/run_test.go
index 619963f..6576041 100644
--- a/internal/dataflow/run_test.go
+++ b/internal/dataflow/run_test.go
@@ -1,15 +1,16 @@
 package dataflow_test
 
 import (
 	"bytes"
 	"encoding/json"
+	v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 	"go/ast"
 	"go/importer"
 	"go/parser"
 	"go/token"
 	"go/types"
 	"io"
 	"os"
 	"path/filepath"
 	"reflect"
 	"runtime"
@@ -43,21 +44,27 @@ func TestRun_JobsDeterminism(t *testing.T) {
 	units := b.L3Units(st)
 	if len(units) < 100 {
 		t.Fatalf("chi yields only %d L3 units", len(units))
 	}
 
 	emit := func(jobs int) []byte {
 		l3 := dataflow.Run(b.Fset(), units, 3, jobs)
 		if len(l3) != len(units) {
 			t.Errorf("-j %d: %d results for %d units", jobs, len(l3), len(units))
 		}
-		data, err := json.Marshal(v2emit.Emit(app, "chi", dir, 3, "det", 3, l3, nil))
+		data, err := json.Marshal(v2emit.Emit(app, func() v2.Identity {
+			i, e := v2.ResolveIdentity("chi", nil)
+			if e != nil {
+				panic(e)
+			}
+			return i
+		}(), dir, 3, "det", 3, l3, nil))
 		if err != nil {
 			t.Fatal(err)
 		}
 		return data
 	}
 	one, eight, again := emit(1), emit(8), emit(8)
 	if !bytes.Equal(one, eight) {
 		t.Error("-j 1 and -j 8 outputs differ")
 	}
 	if !bytes.Equal(eight, again) {
@@ -402,21 +409,27 @@ func TestResult_ReleaseDropsASTs(t *testing.T) {
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatal(err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
 	out := dataflow.Run(b.Fset(), b.L3Units(st), 3, 4)
 	emit := func() []byte {
-		data, err := json.Marshal(v2emit.Emit(app, "dataflow", dir, 3, "rel", 3, out, nil))
+		data, err := json.Marshal(v2emit.Emit(app, func() v2.Identity {
+			i, e := v2.ResolveIdentity("dataflow", nil)
+			if e != nil {
+				panic(e)
+			}
+			return i
+		}(), dir, 3, "rel", 3, out, nil))
 		if err != nil {
 			t.Fatal(err)
 		}
 		return data
 	}
 	before := emit()
 	stmts := 0
 	for _, r := range out {
 		for _, n := range r.Nodes {
 			if n.Stmt != nil {
diff --git a/internal/metamorphic/run.go b/internal/metamorphic/run.go
index 8c96d98..cb4208b 100644
--- a/internal/metamorphic/run.go
+++ b/internal/metamorphic/run.go
@@ -1,20 +1,21 @@
 // Package metamorphic holds the metamorphic relations (MRs) over the L3/L4
 // analysis: source transforms that must leave the analysis unchanged up to a
 // known renaming (the exact oracle), or must keep every flow the original had
 // (the one-way reachability oracle). Fixtures only catch an invariance or
 // soundness bug when someone writes that exact case; the relations check it
 // on any module, real apps included (spec §8, Metamorphic relations).
 package metamorphic
 
 import (
 	"fmt"
+	v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 	"io"
 	"path/filepath"
 	"sort"
 
 	"github.com/codellm-devkit/codeanalyzer-go/internal/analysis"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/dataflow"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/schema"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/sdg"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/semantic_analysis"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/syntactic_analysis"
@@ -71,21 +72,21 @@ func Analyze(dir string, level int, targets []string) (*Run, error) {
 		r.ApplyTo(app)
 		l4 = &r
 	} else {
 		res = dataflow.Run(b.Fset(), units, k, jobs)
 	}
 	dataflow.ReleaseAll(res)
 	// The payload is streamed (EmitTo) into the view one module at a time,
 	// so a large app's tree never exists in memory at once.
 	pr, pw := io.Pipe()
 	go func() {
-		pw.CloseWithError(v2emit.EmitTo(pw, app, AppName, dir, level, "metamorphic", k, res, l4))
+		pw.CloseWithError(v2emit.EmitTo(pw, app, func() v2.Identity { i, _ := v2.ResolveIdentity(AppName, nil); return i }(), dir, level, "metamorphic", k, res, l4))
 	}()
 	v, err := Collect(pr)
 	pr.CloseWithError(err)
 	if err != nil {
 		return nil, err
 	}
 	return &Run{View: v, Errors: errs}, nil
 }
 
 // realDir is dir with symlinks resolved: go/packages reports resolved file
diff --git a/internal/neo4j/bolt.go b/internal/neo4j/bolt.go
index 60d2916..201df06 100644
--- a/internal/neo4j/bolt.go
+++ b/internal/neo4j/bolt.go
@@ -34,41 +34,44 @@ import (
 //
 // D5 (spec §4.11): L4 facts are not module-local — editing a callee changes
 // its callers' summary edges, actual vertices and even formal_in indices —
 // so the content_hash diff gates the L1–L3 rows only. A lazy push upserts
 // every L4 row on every push: the vertex nodes (step 7), the stand-in
 // bodies among them, and the GO_PARAM_IN / GO_PARAM_OUT / GO_SUMMARY rows
 // and the port GO_DDG rows (prov ≠ ssa) with every other edge (step 8). It
 // is additive: a stale L4 row stays until an --eager push.
 //
 // A push NEVER deletes by default (#171): steps 4/6/8 run under --eager only.
-// Every destructive statement is scoped on the can://<app>/ id prefix (#173),
+// Every destructive statement is scoped on the can://<namespace>/<app>/ id prefix (#173),
 // anchored on :GoCanNode so it seeks an index.
 
 // BoltConfig carries the connection + behavior knobs (populated by the facade
 // from AnalysisOptions).
 type BoltConfig struct {
 	URI      string
 	User     string
 	Password string
 	Database string
 	// Eager enables the destructive reconciliation steps. Default (lazy) is
 	// purely additive: MERGE-upsert, nothing removed.
 	Eager bool
 	// FullRun is true when the analysis saw every file (not a --target-files
 	// subset); orphan pruning only runs on a full, eager run.
 	FullRun bool
 }
 
 // WriteBolt pushes rows into the live DB per BoltConfig. appID scopes every
 // destructive statement; it must be the application root id.
 func WriteBolt(ctx context.Context, rows GraphRows, appID string, cfg BoltConfig) error {
+	if err := validateIdentity(rows, appID); err != nil {
+		return err
+	}
 	driver, err := neo4j.NewDriverWithContext(cfg.URI, neo4j.BasicAuth(cfg.User, cfg.Password, ""))
 	if err != nil {
 		return fmt.Errorf("neo4j driver: %w", err)
 	}
 	defer func() { _ = driver.Close(ctx) }()
 	if err := driver.VerifyConnectivity(ctx); err != nil {
 		return fmt.Errorf("neo4j connectivity: %w", err)
 	}
 
 	session := driver.NewSession(ctx, neo4j.SessionConfig{DatabaseName: cfg.Database})
@@ -80,34 +83,34 @@ func WriteBolt(ctx context.Context, rows GraphRows, appID string, cfg BoltConfig
 
 type boltWriter struct {
 	ctx     context.Context
 	session neo4j.SessionWithContext
 	rows    GraphRows
 	appID   string
 	cfg     BoltConfig
 }
 
 func (w *boltWriter) run() error {
-	if err := w.ensureDDL(); err != nil {
-		return err
-	}
 
 	// Stored-application gate: a producer/consumer version mismatch, or a
 	// graph pushed at a lower level, forces a full re-upsert (it never
 	// deletes). The upsert path below is already a full MERGE of every
 	// current node, so it simply means we don't trust the per-module
 	// content_hash diff and upsert everything.
 	forceFull, err := w.storedAppStale()
 	if err != nil {
 		return err
 	}
 
+	if err := w.ensureDDL(); err != nil {
+		return err
+	}
 	root, scoped := applicationPrefix(w.appID)
 	if w.shouldEagerPurge(scoped) {
 		if err := w.eagerPurge(root); err != nil {
 			return err
 		}
 	}
 
 	// Partition nodes by owning module; shared nodes (module == "") and L4
 	// vertex nodes are always upserted.
 	byModule, shared, l4 := partitionNodes(w.rows.Nodes)
@@ -199,26 +202,30 @@ func (w *boltWriter) ensureDDL() error {
 //     so the push fails safe.
 //
 // No stored application (first push) forces nothing beyond the normal
 // upsert, nor does a stored level at or above this push's.
 func (w *boltWriter) storedAppStale() (bool, error) {
 	var stored string
 	var storedLevel int64
 	haveLevel, badLevel := false, false
 	err := w.read(func(tx neo4j.ManagedTransaction) error {
 		res, err := tx.Run(w.ctx,
-			"MATCH (a:GoApplication {id: $id}) RETURN a.schema_version AS v, a.max_level AS l",
+			"MATCH (a:GoApplication {id: $id}) RETURN a.schema_version AS v, a.max_level AS l, a.identity_version AS iv",
 			map[string]any{"id": w.appID})
 		if err != nil {
 			return err
 		}
 		if res.Next(w.ctx) {
+			iv, _ := res.Record().Get("iv")
+			if n, ok := iv.(int64); !ok || n != 2 {
+				return fmt.Errorf("incompatible stored identity_version: %v", iv)
+			}
 			if v, ok := res.Record().Get("v"); ok && v != nil {
 				stored, _ = v.(string)
 			}
 			if l, ok := res.Record().Get("l"); ok && l != nil {
 				storedLevel, haveLevel = l.(int64)
 				badLevel = !haveLevel
 			}
 		}
 		return res.Err()
 	})
diff --git a/internal/neo4j/bolt_session_test.go b/internal/neo4j/bolt_session_test.go
index 1cc8d6f..3e51d31 100644
--- a/internal/neo4j/bolt_session_test.go
+++ b/internal/neo4j/bolt_session_test.go
@@ -28,26 +28,26 @@ func (s *recordingSession) ExecuteWrite(context.Context, neo4j.ManagedTransactio
 }
 
 type consumedResult struct{ neo4j.ResultWithContext }
 
 func (consumedResult) Consume(context.Context) (neo4j.ResultSummary, error) { return nil, nil }
 
 // TestEagerPurge_RunsAsImplicitTransaction: Neo4j 5 rejects CALL { … } IN
 // TRANSACTIONS inside an explicit transaction (what ExecuteWrite opens), so
 // the batched eager purge must go through the session's implicit Run path.
 func TestEagerPurge_RunsAsImplicitTransaction(t *testing.T) {
-	if q, _ := eagerPurgeQuery("can://app"); !strings.Contains(q, "IN TRANSACTIONS") {
+	if q, _ := eagerPurgeQuery("can://app/app"); !strings.Contains(q, "IN TRANSACTIONS") {
 		t.Fatalf("eagerPurgeQuery is not batched: %q", q)
 	}
 	s := &recordingSession{}
 	w := &boltWriter{ctx: context.Background(), session: s}
-	if err := w.eagerPurge("can://app"); err != nil {
+	if err := w.eagerPurge("can://app/app"); err != nil {
 		t.Fatal(err)
 	}
 	if s.explicit != 0 {
 		t.Errorf("eagerPurge opened %d explicit transaction(s)", s.explicit)
 	}
 	if len(s.autoCommit) != 1 || !strings.Contains(s.autoCommit[0], "IN TRANSACTIONS") {
 		t.Errorf("eagerPurge auto-commit statements = %q, want the one batched purge", s.autoCommit)
 	}
 }
 
@@ -77,22 +77,24 @@ func TestEagerPurge_OnlyOnFullRun(t *testing.T) {
 // answer the stored-application gate with SchemaVersion and level (when
 // non-zero; else no stored level) and the content_hash diff with
 // hashes[module id] (an unchanged module when it equals the local hash);
 // every write statement is recorded with its parameters.
 type fakeDB struct {
 	neo4j.SessionWithContext
 	hashes map[string]string
 	level  int64
 	// rawLevel, when non-nil, is the stored max_level returned verbatim
 	// (any type), overriding level.
-	rawLevel any
-	writes   []fakeStmt
+	missingIdentity bool
+	rawIdentity     any
+	rawLevel        any
+	writes          []fakeStmt
 }
 
 type fakeStmt struct {
 	q      string
 	params map[string]any
 }
 
 type fakeTx struct {
 	neo4j.ManagedTransaction
 	db *fakeDB
@@ -114,21 +116,28 @@ func (s *fakeDB) ExecuteRead(ctx context.Context, work neo4j.ManagedTransactionW
 func (tx fakeTx) Run(_ context.Context, q string, params map[string]any) (neo4j.ResultWithContext, error) {
 	switch {
 	case strings.Contains(q, "a.schema_version"):
 		var lvl any
 		if tx.db.level != 0 {
 			lvl = tx.db.level
 		}
 		if tx.db.rawLevel != nil {
 			lvl = tx.db.rawLevel
 		}
-		return &fakeResult{rec: &neo4j.Record{Keys: []string{"v", "l"}, Values: []any{SchemaVersion, lvl}}}, nil
+		identity := any(int64(2))
+		if tx.db.missingIdentity {
+			identity = nil
+		}
+		if tx.db.rawIdentity != nil {
+			identity = tx.db.rawIdentity
+		}
+		return &fakeResult{rec: &neo4j.Record{Keys: []string{"v", "l", "iv"}, Values: []any{SchemaVersion, lvl, identity}}}, nil
 	case strings.Contains(q, "m.content_hash"):
 		h, ok := tx.db.hashes[params["id"].(string)]
 		if !ok {
 			return &fakeResult{}, nil
 		}
 		return &fakeResult{rec: &neo4j.Record{Keys: []string{"h"}, Values: []any{h}}}, nil
 	}
 	tx.db.writes = append(tx.db.writes, fakeStmt{q, params})
 	return &fakeResult{}, nil
 }
@@ -379,10 +388,34 @@ func TestBolt_CleanPushClearsDegradedJSON(t *testing.T) {
 	rows := Project(a)
 	for i, n := range rows.Nodes {
 		if n.Labels[0] == LabelApplication {
 			rows.Nodes[i].Props = Props{"degraded_json": `[{"code":"no_vta"}]`, "max_level": int64(4)}
 		}
 	}
 	if v := appProps(rows)["degraded_json"]; v != `[{"code":"no_vta"}]` {
 		t.Errorf("degraded push: degraded_json = %v, want the JSON string", v)
 	}
 }
+
+func TestIncompatibleIdentityReadOnly(t *testing.T) {
+	for _, iv := range []any{int64(1), "2", float64(2), true} {
+		db := &fakeDB{rawIdentity: iv}
+		w := &boltWriter{ctx: context.Background(), session: db, appID: "can://team/app"}
+		if err := w.run(); err == nil {
+			t.Errorf("accepted %v", iv)
+		}
+		if len(db.writes) != 0 {
+			t.Fatal("wrote before identity gate")
+		}
+	}
+}
+
+func TestMissingStoredIdentityReadOnly(t *testing.T) {
+	db := &fakeDB{missingIdentity: true}
+	w := &boltWriter{ctx: context.Background(), session: db, appID: "can://team/app"}
+	if err := w.run(); err == nil {
+		t.Fatal("accepted legacy anchor")
+	}
+	if len(db.writes) != 0 {
+		t.Fatal("wrote before rejecting legacy anchor")
+	}
+}
diff --git a/internal/neo4j/bolt_test.go b/internal/neo4j/bolt_test.go
index cd6972f..87065a9 100644
--- a/internal/neo4j/bolt_test.go
+++ b/internal/neo4j/bolt_test.go
@@ -7,62 +7,62 @@ import (
 
 // M5 unit gate (DB-free): the pure pieces of the Bolt writer — node
 // partitioning, module-hash extraction, param marshalling, and the critical
 // invariant that every destructive query is scoped on :GoCanNode + the can://
 // prefix (never an unqualified DELETE). The live-DB behavior (diff, additive
 // vs eager) is exercised by bolt_integration_test.go behind the `neo4j_it`
 // build tag.
 
 func TestPartitionNodes_SharedHaveNoModule(t *testing.T) {
 	b := NewRowBuilder()
-	b.Node([]string{LabelModule, MarkerLabel}, "id", "can://app/go/x.go", Props{"content_hash": "h1"}, "x.go")
-	b.Node([]string{LabelCallable, SymbolLabel, MarkerLabel}, "id", "can://app/go/x.go/f", nil, "x.go")
-	b.Node([]string{SymbolLabel, LabelExternal, MarkerLabel}, "id", "can://app/@external/fmt", nil, "") // shared
+	b.Node([]string{LabelModule, MarkerLabel}, "id", "can://app/app/go/x.go", Props{"content_hash": "h1"}, "x.go")
+	b.Node([]string{LabelCallable, SymbolLabel, MarkerLabel}, "id", "can://app/app/go/x.go/f", nil, "x.go")
+	b.Node([]string{SymbolLabel, LabelExternal, MarkerLabel}, "id", "can://app/app/@external/fmt", nil, "") // shared
 	rows := b.Finish()
 
 	byModule, shared, l4 := partitionNodes(rows.Nodes)
 	if len(byModule["x.go"]) != 2 {
 		t.Errorf("module x.go should own 2 nodes, got %d", len(byModule["x.go"]))
 	}
 	if len(shared) != 1 {
 		t.Errorf("expected 1 shared (no-module) node, got %d", len(shared))
 	}
 	if len(l4) != 0 {
 		t.Errorf("expected no L4 node, got %d", len(l4))
 	}
 }
 
 func TestModuleHash_ReadsModuleNode(t *testing.T) {
 	nodes := []NodeRow{
-		{Labels: []string{LabelCallable}, Value: "can://app/go/x.go/f"},
-		{Labels: []string{LabelModule}, Value: "can://app/go/x.go", Props: Props{"content_hash": "abc123"}},
+		{Labels: []string{LabelCallable}, Value: "can://app/app/go/x.go/f"},
+		{Labels: []string{LabelModule}, Value: "can://app/app/go/x.go", Props: Props{"content_hash": "abc123"}},
 	}
 	if got := moduleHash(nodes); got != "abc123" {
 		t.Errorf("moduleHash = %q, want abc123", got)
 	}
 	if got := moduleHash(nodes[:1]); got != "" {
 		t.Errorf("moduleHash with no module node = %q, want empty", got)
 	}
 }
 
 func TestDestructiveQueries_AreScopedAndAnchored(t *testing.T) {
 	// Both destructive queries MUST filter on :GoCanNode and bind the prefix as a
 	// parameter — never an unqualified DETACH DELETE.
-	eq, ep := eagerPurgeQuery("can://app")
+	eq, ep := eagerPurgeQuery("can://app/app")
 	assertScoped(t, "eagerPurge", eq, ep)
-	if ep["p"] != "can://app/" || ep["root"] != "can://app" {
+	if ep["p"] != "can://app/app/" || ep["root"] != "can://app/app" {
 		t.Errorf("eagerPurge params not the app prefix+root: %v", ep)
 	}
 
-	pq, pp := purgeModuleQuery("can://app/go/x.go")
+	pq, pp := purgeModuleQuery("can://app/app/go/x.go")
 	assertScoped(t, "purgeModule", pq, pp)
-	if pp["p"] != "can://app/go/x.go/" || pp["m"] != "can://app/go/x.go" {
+	if pp["p"] != "can://app/app/go/x.go/" || pp["m"] != "can://app/app/go/x.go" {
 		t.Errorf("purgeModule params not the module prefix+id: %v", pp)
 	}
 }
 
 func assertScoped(t *testing.T, name, q string, params map[string]any) {
 	t.Helper()
 	if !strings.Contains(q, "DETACH DELETE") {
 		t.Fatalf("%s: not a destructive query?", name)
 	}
 	if !strings.Contains(q, ":GoCanNode") {
diff --git a/internal/neo4j/cypher.go b/internal/neo4j/cypher.go
index 548886b..8370558 100644
--- a/internal/neo4j/cypher.go
+++ b/internal/neo4j/cypher.go
@@ -1,42 +1,82 @@
 package neo4j
 
 import (
 	"fmt"
+	v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 	"sort"
 	"strings"
 )
 
 // Milestone M4: the snapshot writer. RenderCypher turns a GraphRows bag into a
 // self-contained, idempotent graph.cypher script. Running it (e.g.
 // `cypher-shell < graph.cypher`) rebuilds this application's subgraph from
 // scratch. Block order:
 //
 //  1. constraints + indexes (IF NOT EXISTS) — first, so MERGE seeks an index;
 //  2. scoped wipe of this app's prior subgraph — anchored on :GoCanNode and the
-//     can://<app>/ id prefix, with the root id matched separately (the root is
+//     can://<namespace>/<app>/ id prefix, with the root id matched separately (the root is
 //     outside its own descendant prefix). Rows with no proper application root
 //     emit NO wipe (refused visibly), so a hand-built bag can't delete anything;
 //  3. batched UNWIND … MERGE for nodes, grouped by full label set + key prop;
 //  4. batched UNWIND … MERGE for edges, grouped by (type, endpoint labels/keys,
 //     keyed?).
 //
 // A static script has no view of the live DB, so it expresses the FULL truth;
 // incremental updates are the Bolt writer's job (M5). Determinism: identical
 // GraphRows → byte-identical script (RowBuilder.Finish already sorted the bag).
 
 // batchSize is the UNWIND batch size (parity with the siblings' 500).
 const batchSize = 500
 
 // RenderCypher renders the full snapshot script. appID is the application root
 // id used to scope the wipe; it is normally rows' application node value.
-func RenderCypher(rows GraphRows, appID string) string {
+func validateIdentity(rows GraphRows, appID string) error {
+	for _, n := range rows.Nodes {
+		if n.Value != appID {
+			continue
+		}
+		for _, label := range n.Labels {
+			if label != LabelApplication {
+				continue
+			}
+			version, ok := n.Props["identity_version"].(int)
+			if !ok || version != 2 {
+				return fmt.Errorf("incompatible identity_version")
+			}
+			name, ok := n.Props["application_name"].(string)
+			if !ok {
+				return fmt.Errorf("missing application_name")
+			}
+			ns, ok := n.Props["identity_namespace"].(string)
+			if !ok {
+				return fmt.Errorf("missing identity_namespace")
+			}
+			identity, err := v2.ResolveIdentity(name, &ns)
+			if err != nil {
+				return err
+			}
+			if identity.ApplicationID != appID {
+				return fmt.Errorf("application root does not match metadata")
+			}
+			return nil
+		}
+	}
+	return fmt.Errorf("missing application anchor")
+}
+func RenderCypher(rows GraphRows, appID string) (string, error) {
+	if err := validateIdentity(rows, appID); err != nil {
+		return "", err
+	}
+	return renderCypher(rows, appID), nil
+}
+func renderCypher(rows GraphRows, appID string) string {
 	var b strings.Builder
 
 	writeDDL(&b)
 	writeScopedWipe(&b, appID)
 	writeNodeBatches(&b, rows.Nodes)
 	writeEdgeBatches(&b, rows.Edges)
 
 	return b.String()
 }
 
@@ -59,21 +99,21 @@ func writeDDL(b *strings.Builder) {
 // sibling analyzer's :Go* graph (they lack :GoCanNode), never a second Go app
 // sharing a module path.
 func writeScopedWipe(b *strings.Builder, appID string) {
 	root, ok := applicationPrefix(appID)
 	if !ok {
 		b.WriteString("// ─── scoped wipe SKIPPED: no bare application root id ───\n\n")
 		return
 	}
 	desc := descendantPrefix(root)
 	b.WriteString("// ─── scoped wipe (this application only) ───\n")
-	// Descendants: everything under can://<app>/.
+	// Descendants: everything under can://<namespace>/<app>/.
 	fmt.Fprintf(b, "MATCH (n:%s) WHERE n.id STARTS WITH %s DETACH DELETE n;\n",
 		MarkerLabel, cypherString(desc))
 	// The root itself is outside its own descendant prefix.
 	fmt.Fprintf(b, "MATCH (n:%s) WHERE n.id = %s DETACH DELETE n;\n",
 		MarkerLabel, cypherString(root))
 	b.WriteByte('\n')
 }
 
 // ─── node batches ─────────────────────────────────────────────────────────────
 
diff --git a/internal/neo4j/cypher_test.go b/internal/neo4j/cypher_test.go
index 74140de..8e829db 100644
--- a/internal/neo4j/cypher_test.go
+++ b/internal/neo4j/cypher_test.go
@@ -1,82 +1,91 @@
 package neo4j
 
 import (
+	"context"
+	"os"
+	"path/filepath"
 	"strings"
 	"testing"
 )
 
 // M4 gate: the snapshot writer. The DDL + scoped wipe + batched node/edge MERGE
 // blocks are present, deterministic, and prefix-scoped; a bag with no proper
 // application root emits no destructive statement.
 
 func renderFixture(t *testing.T) string {
 	t.Helper()
 	a := buildMultipackageL2(t)
 	rows := Project(a)
-	return RenderCypher(rows, a.Application.ID)
+	script, err := RenderCypher(rows, a.Application.ID)
+	if err != nil {
+		t.Fatal(err)
+	}
+	return script
 }
 
 func TestCypher_HasDDLWipeAndBatches(t *testing.T) {
 	script := renderFixture(t)
 	for _, want := range []string{
 		"CREATE CONSTRAINT",
 		"CREATE INDEX gocannode_id",
 		"DETACH DELETE",
 		"UNWIND [",
 		"MERGE (n:",
 		"MERGE (a)-[r:GO_",
 	} {
 		if !strings.Contains(script, want) {
 			t.Errorf("script missing %q", want)
 		}
 	}
 }
 
 func TestCypher_Deterministic(t *testing.T) {
 	a := buildMultipackageL2(t)
-	s1 := RenderCypher(Project(a), a.Application.ID)
-	s2 := RenderCypher(Project(a), a.Application.ID)
+	s1, err := RenderCypher(Project(a), a.Application.ID)
+	if err != nil {
+		t.Fatal(err)
+	}
+	s2, err := RenderCypher(Project(a), a.Application.ID)
+	if err != nil {
+		t.Fatal(err)
+	}
 	if s1 != s2 {
 		t.Error("graph.cypher is not byte-identical across runs")
 	}
 }
 
 func TestCypher_WipeIsPrefixScopedAndAnchored(t *testing.T) {
 	script := renderFixture(t)
 	// The wipe must match on the :GoCanNode marker and the can://<app>/ prefix,
 	// never a bare label like (:GoModule) or the whole store.
-	if !strings.Contains(script, "MATCH (n:GoCanNode) WHERE n.id STARTS WITH 'can://multipackage/'") {
+	if !strings.Contains(script, "MATCH (n:GoCanNode) WHERE n.id STARTS WITH 'can://multipackage/multipackage/'") {
 		t.Errorf("wipe not anchored on :GoCanNode + descendant prefix:\n%s", wipeBlock(script))
 	}
-	if !strings.Contains(script, "MATCH (n:GoCanNode) WHERE n.id = 'can://multipackage'") {
+	if !strings.Contains(script, "MATCH (n:GoCanNode) WHERE n.id = 'can://multipackage/multipackage'") {
 		t.Errorf("wipe does not match the root id separately:\n%s", wipeBlock(script))
 	}
 	// A destructive statement must never be unscoped.
 	for _, line := range strings.Split(script, "\n") {
 		if strings.Contains(line, "DETACH DELETE") && !strings.Contains(line, "WHERE") {
 			t.Errorf("unscoped DETACH DELETE: %q", line)
 		}
 	}
 }
 
 func TestCypher_NoRootEmitsNoWipe(t *testing.T) {
 	// A hand-built bag with no bare application id must emit NO destructive
 	// statement — the applicationPrefix refusal in action.
 	b := NewRowBuilder()
-	b.Node([]string{LabelCallable, SymbolLabel}, "id", "can://app/go/x.go/f", nil, "x.go")
-	script := RenderCypher(b.Finish(), "can://app/go/x.go/f") // not a bare app id
-	if strings.Contains(script, "DETACH DELETE") {
-		t.Errorf("a bag with no bare application root must emit no wipe:\n%s", script)
-	}
-	if !strings.Contains(script, "scoped wipe SKIPPED") {
-		t.Error("the skipped wipe should be visible in a comment")
+	b.Node([]string{LabelCallable, SymbolLabel}, "id", "can://app/app/go/x.go/f", nil, "x.go")
+	if _, err := RenderCypher(b.Finish(), "can://app/app/go/x.go/f"); err == nil {
+		t.Fatal("accepted missing anchor")
 	}
 }
 
 func TestCypher_SymbolFamilyMergesOnSharedLabel(t *testing.T) {
 	// Nodes in the symbol family (labels[0]=GoSymbol) must MERGE on :GoSymbol and
 	// SET the specific kind as an extra label.
 	script := renderFixture(t)
 	if !strings.Contains(script, "MERGE (n:GoSymbol {id: row.k})") {
 		t.Error("symbol-family nodes must MERGE on the shared :GoSymbol label")
 	}
@@ -90,10 +99,35 @@ func wipeBlock(script string) string {
 	start := strings.Index(script, "scoped wipe")
 	if start < 0 {
 		return "(no wipe block)"
 	}
 	end := strings.Index(script[start:], "// ─── nodes")
 	if end < 0 {
 		end = len(script) - start
 	}
 	return script[start : start+end]
 }
+
+func TestCypherRejectsInvalidIdentity(t *testing.T) {
+	a := buildMultipackageL2(t)
+	a.IdentityVersion = 0
+	if _, err := RenderCypher(Project(a), a.Application.ID); err == nil {
+		t.Fatal("accepted missing identity marker")
+	}
+}
+
+func TestEmitNeo4jInvalidIdentityLeavesOutput(t *testing.T) {
+	a := buildMultipackageL2(t)
+	a.Application.IdentityVersion = 1
+	dir := t.TempDir()
+	path := filepath.Join(dir, GraphFileName)
+	if err := os.WriteFile(path, []byte("original"), 0600); err != nil {
+		t.Fatal(err)
+	}
+	if _, err := EmitNeo4j(context.Background(), a, dir, BoltConfig{}); err == nil {
+		t.Fatal("accepted mismatched app marker")
+	}
+	b, err := os.ReadFile(path)
+	if err != nil || string(b) != "original" {
+		t.Fatalf("output changed: %s %v", b, err)
+	}
+}
diff --git a/internal/neo4j/emit.go b/internal/neo4j/emit.go
index e5c682a..c627b41 100644
--- a/internal/neo4j/emit.go
+++ b/internal/neo4j/emit.go
@@ -16,38 +16,44 @@ import (
 
 // GraphFileName is the snapshot script written when no --neo4j-uri is given.
 const GraphFileName = "graph.cypher"
 
 // EmitNeo4j projects the v2 Analysis into GraphRows and writes it. The projection
 // is pure and shared; only the write target differs. When cfg.URI is set it
 // pushes over Bolt (incremental, additive unless cfg.Eager); otherwise it writes
 // a self-contained graph.cypher snapshot into outputDir (default: current dir).
 // It returns a short human-readable description of what was written.
 func EmitNeo4j(ctx context.Context, a *v2.Analysis, outputDir string, cfg BoltConfig) (string, error) {
+	if a == nil || a.IdentityVersion != 2 || a.Application.IdentityVersion != 2 {
+		return "", fmt.Errorf("incompatible identity_version")
+	}
 	rows := Project(a)
 	appID := a.Application.ID
 
 	if cfg.URI != "" {
 		if err := WriteBolt(ctx, rows, appID, cfg); err != nil {
 			return "", err
 		}
 		return fmt.Sprintf("pushed %d nodes, %d relationships to %s", len(rows.Nodes), len(rows.Edges), cfg.URI), nil
 	}
 
+	script, err := RenderCypher(rows, appID)
+	if err != nil {
+		return "", err
+	}
 	if outputDir == "" {
 		outputDir = "."
 	}
 	if err := os.MkdirAll(outputDir, 0o755); err != nil {
 		return "", fmt.Errorf("create output dir %q: %w", outputDir, err)
 	}
 	path := filepath.Join(outputDir, GraphFileName)
-	script := RenderCypher(rows, appID)
 	if err := os.WriteFile(path, []byte(script), 0o644); err != nil {
 		return "", fmt.Errorf("write %s: %w", path, err)
 	}
 	return "wrote " + path, nil
 }
 
 // SchemaFileName is the machine-readable graph contract written by --emit schema.
 const SchemaFileName = "schema.neo4j.json"
 
 // EmitSchema serializes the static graph contract (BuildSchemaDocument) to
diff --git a/internal/neo4j/project.go b/internal/neo4j/project.go
index 9584338..78fde41 100644
--- a/internal/neo4j/project.go
+++ b/internal/neo4j/project.go
@@ -16,21 +16,21 @@ import (
 // the graph and analysis.json join on one string (two-projection agreement).
 // Node ids are can:// ids; the application segment is the outermost prefix of
 // every id the app owns, which is what makes prefix scoping exact.
 //
 // Walk order (spine): application → per module (types → callables → fields →
 // body nodes and the L3/L4 intra-callable overlay) → call_graph → imports →
 // stand-in bodies → param edges. Every endpoint resolves to a declared node or
 // an id-keyed :GoExternal ghost — nothing dangles.
 
 // Project is the pure (tree) → GraphRows function. appID is analysis.Application.ID
-// (the can://<app> root); it is read from the envelope, never recomposed.
+// (the can://<namespace>/<app> root); it is read from the envelope, never recomposed.
 func Project(a *v2.Analysis) GraphRows {
 	p := &projector{
 		b:        NewRowBuilder(),
 		analysis: a,
 		// Index of every emitted callable/type id, so call_graph endpoints and
 		// body callees can tell a declared target from an external one.
 		declared: collectDeclaredIDs(a),
 	}
 	p.projectApplication()
 	for _, mod := range a.Application.SymbolTable {
@@ -49,21 +49,21 @@ type projector struct {
 }
 
 // ─── application ─────────────────────────────────────────────────────────────
 
 func (p *projector) projectApplication() {
 	a := p.analysis
 	p.b.Node(
 		[]string{LabelApplication, MarkerLabel},
 		"id", a.Application.ID,
 		Props{
-			"schema_version":   a.SchemaVersion,
+			"identity_version": a.IdentityVersion, "application_name": a.Application.ApplicationName, "identity_namespace": a.Application.IdentityNamespace, "schema_version": a.SchemaVersion,
 			"language":         a.Language,
 			"max_level":        a.MaxLevel,
 			"analyzer_name":    a.Analyzer.Name,
 			"analyzer_version": a.Analyzer.Version,
 			"degraded_json":    degradedJSON(a.Degraded),
 		},
 		"", // the application root belongs to no single module
 	)
 }
 
diff --git a/internal/neo4j/project_test.go b/internal/neo4j/project_test.go
index cebe5f9..04a9a4b 100644
--- a/internal/neo4j/project_test.go
+++ b/internal/neo4j/project_test.go
@@ -32,21 +32,27 @@ func buildMultipackageL2(t *testing.T) *v2.Analysis {
 		t.Fatalf("resolving fixture dir: %v", err)
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
-	return v2emit.Emit(app, "multipackage", dir, 2, "neo4j-gate", 0, nil, nil)
+	return v2emit.Emit(app, func() v2.Identity {
+		i, e := v2.ResolveIdentity("multipackage", nil)
+		if e != nil {
+			panic(e)
+		}
+		return i
+	}(), dir, 2, "neo4j-gate", 0, nil, nil)
 }
 
 func TestProject_NoDanglingEndpoints(t *testing.T) {
 	for _, c := range []struct {
 		name string
 		a    func(*testing.T) *v2.Analysis
 	}{
 		{"multipackage L2", buildMultipackageL2},
 		{"dataflow L4", buildDataflowL4},
 	} {
@@ -233,24 +239,36 @@ func buildDataflowAt(t *testing.T, level int) *v2.Analysis {
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
 	if level < 3 {
-		return v2emit.Emit(app, "dataflow", dir, level, "neo4j-gate", 3, nil, nil)
+		return v2emit.Emit(app, func() v2.Identity {
+			i, e := v2.ResolveIdentity("dataflow", nil)
+			if e != nil {
+				panic(e)
+			}
+			return i
+		}(), dir, level, "neo4j-gate", 3, nil, nil)
 	}
 	res := dataflow.Run(b.Fset(), b.L3Units(st), 3, 4)
-	return v2emit.Emit(app, "dataflow", dir, level, "neo4j-gate", 3, res, nil)
+	return v2emit.Emit(app, func() v2.Identity {
+		i, e := v2.ResolveIdentity("dataflow", nil)
+		if e != nil {
+			panic(e)
+		}
+		return i
+	}(), dir, level, "neo4j-gate", 3, res, nil)
 }
 
 // walkCallables visits every callable (methods and nested closures included).
 func walkCallables(a *v2.Analysis, visit func(c v2.Callable)) {
 	var walk func(c v2.Callable)
 	walk = func(c v2.Callable) {
 		visit(c)
 		for _, in := range c.Callables {
 			walk(in)
 		}
@@ -552,21 +570,27 @@ func buildDataflowL4(t *testing.T) *v2.Analysis {
 		cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 		edges := cg.Build(st)
 		app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
 		units := b.L3Units(st)
 		res := dataflow.RunWithSideTables(b.Fset(), units, 3, 4)
 		l4 := sdg.Run(sdg.Input{
 			Fset: b.Fset(), Pkgs: b.Pkgs(), ProjectDir: dir, SymbolTable: st,
 			Externals: app.Externals, CallGraph: app.CallGraph, Units: units, L3: res, K: 3, Jobs: 4,
 		})
 		l4.ApplyTo(app)
-		l4Analysis = v2emit.Emit(app, "dataflow", dir, 4, "neo4j-gate", 3, res, &l4)
+		l4Analysis = v2emit.Emit(app, func() v2.Identity {
+			i, e := v2.ResolveIdentity("dataflow", nil)
+			if e != nil {
+				panic(e)
+			}
+			return i
+		}(), dir, 4, "neo4j-gate", 3, res, &l4)
 	})
 	if l4Analysis == nil {
 		t.Fatal("L4 fixture build failed")
 	}
 	return l4Analysis
 }
 
 func isVertex(kind string) bool {
 	switch kind {
 	case "formal_in", "formal_out", "actual_in", "actual_out":
diff --git a/internal/neo4j/rows.go b/internal/neo4j/rows.go
index 5bdf384..fc96985 100644
--- a/internal/neo4j/rows.go
+++ b/internal/neo4j/rows.go
@@ -1,13 +1,14 @@
 package neo4j
 
 import (
+	"encoding/json"
 	"fmt"
 	"sort"
 	"strings"
 )
 
 // Milestone M2: the output-agnostic row IR and the RowBuilder. GraphRows is a
 // deterministic, deduped bag of nodes and edges with NO I/O and NO driver; both
 // writers (cypher.go, bolt.go) consume the identical bag. The RowBuilder is the
 // in-memory analog of Neo4j MERGE semantics — it mirrors MERGE … SET += props
 // before any writer runs, so each writer just replays a clean, deduped result.
@@ -60,46 +61,49 @@ type EdgeRow struct {
 
 // GraphRows is the finished, deterministic bag.
 type GraphRows struct {
 	Nodes []NodeRow
 	Edges []EdgeRow
 }
 
 // ─── RowBuilder ──────────────────────────────────────────────────────────────
 
 // RowBuilder accumulates nodes and edges with in-memory MERGE semantics. Nodes
-// dedup on (labels[0], value); edges are append-only (per-pair facts that must
-// not duplicate need an explicit guard in the projector). Edges whose target
+// dedup on canonical ID; exact edge facts dedup while preserving kind, site,
+// key and properties. Edges whose target
 // may be external/library code are DEFERRED and kept at finish() only if the
 // target node was actually emitted — the edge-only-when-resolved rule, so an
 // unresolved target degrades to a source-node property instead of a dangling edge.
 type RowBuilder struct {
-	nodeIndex map[string]int // (labels[0] + "\x00" + value) -> index into nodes
+	nodeIndex map[string]int // canonical ID (label/value for non-can nodes) -> row
 	nodes     []NodeRow
 	edges     []EdgeRow
 	deferred  []EdgeRow
 }
 
 // NewRowBuilder returns an empty builder.
 func NewRowBuilder() *RowBuilder {
 	return &RowBuilder{nodeIndex: make(map[string]int)}
 }
 
-// Node upserts a node keyed on (labels[0], value). Re-seeing the same identity
+// Node upserts a node keyed on canonical ID (label/value for non-can nodes). Re-seeing the same identity
 // MERGES props (last-write-wins) and UNIONs labels — a hot external symbol
 // collapses to one row. Returns a NodeRef edges can address it by. nil props
 // are pruned on the way in.
 func (b *RowBuilder) Node(labels []string, keyProp, value string, props Props, module string) NodeRef {
 	if len(labels) == 0 {
 		panic("neo4j: Node requires at least one label (labels[0] is the MERGE label)")
 	}
 	k := labels[0] + "\x00" + value
+	if strings.HasPrefix(value, "can://") {
+		k = value
+	}
 	if i, ok := b.nodeIndex[k]; ok {
 		existing := &b.nodes[i]
 		existing.Labels = unionLabels(existing.Labels, labels)
 		for pk, pv := range prune(props) {
 			if existing.Props == nil {
 				existing.Props = Props{}
 			}
 			existing.Props[pk] = pv
 		}
 		if existing.Module == "" {
@@ -112,21 +116,21 @@ func (b *RowBuilder) Node(labels []string, keyProp, value string, props Props, m
 		Labels:  append([]string(nil), labels...),
 		KeyProp: keyProp,
 		Value:   value,
 		Props:   prune(props),
 		Module:  module,
 	})
 	return NodeRef{Label: labels[0], KeyProp: keyProp, Value: value}
 }
 
 // Edge appends a relationship whose endpoints are known to exist this run.
-// Append-only — not deduped.
+// Exact duplicate facts are collapsed at Finish.
 func (b *RowBuilder) Edge(relType string, from, to NodeRef, props Props, key string) {
 	b.edges = append(b.edges, EdgeRow{Type: relType, From: from, To: to, Props: prune(props), Key: key})
 }
 
 // EdgeToSymbol defers a relationship whose target (addressed by its can:// id)
 // may be library/external code not present in the graph. At finish() the edge
 // is kept ONLY if a node with that (label, value) was emitted — so EXTENDS/
 // SATISFIES/RESOLVES_TO never dangle. targetLabel is the MERGE label the target
 // would carry if present (e.g. SymbolLabel).
 func (b *RowBuilder) EdgeToSymbol(relType string, from NodeRef, targetLabel, targetKey, targetValue string, props Props, key string) {
@@ -138,63 +142,78 @@ func (b *RowBuilder) EdgeToSymbol(relType string, from NodeRef, targetLabel, tar
 		Key:   key,
 	})
 }
 
 // Finish resolves deferred edges (keeping only those whose target was emitted),
 // sorts nodes and edges by a stable key, and returns the GraphRows. Determinism
 // matters: identical input must yield byte-identical output downstream.
 func (b *RowBuilder) Finish() GraphRows {
 	emitted := make(map[string]bool, len(b.nodes))
 	for _, n := range b.nodes {
-		emitted[n.Labels[0]+"\x00"+n.Value] = true
+		for _, label := range n.Labels {
+			emitted[label+"\x00"+n.Value] = true
+		}
 	}
 	for _, e := range b.deferred {
 		if emitted[e.To.Label+"\x00"+e.To.Value] {
 			b.edges = append(b.edges, e)
 		}
 	}
 
+	seenEdges := map[string]bool{}
+	unique := b.edges[:0]
+	for _, e := range b.edges {
+		props, _ := json.Marshal(e.Props)
+		key := e.Type + "\x00" + e.From.Value + "\x00" + e.To.Value + "\x00" + e.Key + "\x00" + string(props)
+		if !seenEdges[key] {
+			seenEdges[key] = true
+			unique = append(unique, e)
+		}
+	}
+	b.edges = unique
 	sort.Slice(b.nodes, func(i, j int) bool {
 		if b.nodes[i].Labels[0] != b.nodes[j].Labels[0] {
 			return b.nodes[i].Labels[0] < b.nodes[j].Labels[0]
 		}
 		return b.nodes[i].Value < b.nodes[j].Value
 	})
 	sort.Slice(b.edges, func(i, j int) bool {
 		return edgeSortKey(b.edges[i]) < edgeSortKey(b.edges[j])
 	})
 
 	return GraphRows{Nodes: b.nodes, Edges: b.edges}
 }
 
 // edgeSortKey is the total order for edges: type, then endpoints, then the _k
 // discriminant (so parallel edges per pair order stably).
 func edgeSortKey(e EdgeRow) string {
-	return strings.Join([]string{e.Type, e.From.Label, e.From.Value, e.To.Label, e.To.Value, e.Key}, "\x00")
+	props, _ := json.Marshal(e.Props)
+	return strings.Join([]string{e.Type, e.From.Label, e.From.Value, e.To.Label, e.To.Value, e.Key, string(props)}, "\x00")
 }
 
 // ─── scoping helpers ──────────────────────────────────────────────────────────
 
 // applicationPrefix returns the bare application id used to scope destructive
-// statements. It REFUSES anything that is not a bare can://<app> id (an
+// statements. It REFUSES anything that is not a canonical can://<namespace>/<app> id (an
 // empty or deeper id would silently widen or narrow the blast radius): it
 // returns ("", false) so a hand-built GraphRows with no proper application root
 // gets NO destructive statement. The app segment is the outermost, so one
 // prefix spans every module the app owns and nothing another app owns.
 func applicationPrefix(appID string) (string, bool) {
 	const scheme = "can://"
 	if !strings.HasPrefix(appID, scheme) {
 		return "", false
 	}
 	rest := strings.TrimPrefix(appID, scheme)
-	// A bare app id is exactly <app> — one non-empty segment, no deeper.
-	if rest == "" || strings.Contains(rest, "/") {
+	// A bare app id is exactly two non-empty encoded segments, no deeper.
+	parts := strings.Split(rest, "/")
+	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
 		return "", false
 	}
 	return appID, true
 }
 
 // descendantPrefix appends "/" to a can:// id so a STARTS WITH predicate matches
 // strict descendants only — "foo.go" is not treated as a prefix of "foo.go2",
 // and the app root id itself (can://app) is outside its own descendant
 // prefix (can://app/), so a wipe must match the root separately.
 func descendantPrefix(canID string) string {
diff --git a/internal/neo4j/rows_test.go b/internal/neo4j/rows_test.go
index 707ea15..4266406 100644
--- a/internal/neo4j/rows_test.go
+++ b/internal/neo4j/rows_test.go
@@ -4,21 +4,21 @@ import (
 	"reflect"
 	"testing"
 )
 
 // M2 gate: the RowBuilder's in-memory MERGE semantics, the edge-only-when-
 // resolved rule, pruning, deterministic finish(), scoping-helper refusal, and
 // Cypher-literal rendering.
 
 func TestRowBuilder_NodeMergeDedupsAndUnionsLabels(t *testing.T) {
 	b := NewRowBuilder()
-	id := "can://app/go/x.go/T"
+	id := "can://app/app/go/x.go/T"
 	b.Node([]string{SymbolLabel, LabelType}, "id", id, Props{"kind": "struct"}, "x.go")
 	// Re-see the same identity with an extra label + an extra prop.
 	b.Node([]string{SymbolLabel, MarkerLabel}, "id", id, Props{"signature": "T"}, "x.go")
 
 	rows := b.Finish()
 	if len(rows.Nodes) != 1 {
 		t.Fatalf("re-seeing an identity must dedup to one node; got %d", len(rows.Nodes))
 	}
 	n := rows.Nodes[0]
 	// Labels unioned, MERGE label first.
@@ -27,44 +27,44 @@ func TestRowBuilder_NodeMergeDedupsAndUnionsLabels(t *testing.T) {
 		t.Errorf("labels = %v, want %v", n.Labels, want)
 	}
 	// Props merged (last-write-wins union).
 	if n.Props["kind"] != "struct" || n.Props["signature"] != "T" {
 		t.Errorf("props not merged across re-see: %v", n.Props)
 	}
 }
 
 func TestRowBuilder_PropLastWriteWins(t *testing.T) {
 	b := NewRowBuilder()
-	id := "can://app/go/x.go/T"
+	id := "can://app/app/go/x.go/T"
 	b.Node([]string{LabelType}, "id", id, Props{"kind": "struct"}, "")
 	b.Node([]string{LabelType}, "id", id, Props{"kind": "interface"}, "")
 	rows := b.Finish()
 	if rows.Nodes[0].Props["kind"] != "interface" {
 		t.Errorf("last write must win: kind = %v, want interface", rows.Nodes[0].Props["kind"])
 	}
 }
 
 func TestRowBuilder_DeferredEdgeDroppedWhenTargetAbsent(t *testing.T) {
 	b := NewRowBuilder()
-	src := b.Node([]string{SymbolLabel, LabelType}, "id", "can://app/go/x.go/T", nil, "x.go")
+	src := b.Node([]string{SymbolLabel, LabelType}, "id", "can://app/app/go/x.go/T", nil, "x.go")
 	// Target never emitted as a node.
-	b.EdgeToSymbol(RelEmbeds, src, SymbolLabel, "id", "can://app/go/y.go/Missing", nil, "")
+	b.EdgeToSymbol(RelEmbeds, src, SymbolLabel, "id", "can://app/app/go/y.go/Missing", nil, "")
 	rows := b.Finish()
 	if len(rows.Edges) != 0 {
 		t.Errorf("deferred edge to an unemitted target must be dropped; got %d edges", len(rows.Edges))
 	}
 }
 
 func TestRowBuilder_DeferredEdgeKeptWhenTargetEmitted(t *testing.T) {
 	b := NewRowBuilder()
-	src := b.Node([]string{SymbolLabel, LabelType}, "id", "can://app/go/x.go/T", nil, "x.go")
-	target := "can://app/go/y.go/Base"
+	src := b.Node([]string{SymbolLabel, LabelType}, "id", "can://app/app/go/x.go/T", nil, "x.go")
+	target := "can://app/app/go/y.go/Base"
 	b.Node([]string{SymbolLabel, LabelType}, "id", target, nil, "y.go")
 	b.EdgeToSymbol(RelEmbeds, src, SymbolLabel, "id", target, nil, "")
 	rows := b.Finish()
 	if len(rows.Edges) != 1 {
 		t.Fatalf("deferred edge to an emitted target must be kept; got %d edges", len(rows.Edges))
 	}
 	if rows.Edges[0].Type != RelEmbeds || rows.Edges[0].To.Value != target {
 		t.Errorf("resolved edge wrong: %+v", rows.Edges[0])
 	}
 }
@@ -93,52 +93,52 @@ func TestPrune_AllEmptyReturnsNil(t *testing.T) {
 	if prune(Props{"a": nil}) != nil {
 		t.Error("an all-empty bag must prune to nil")
 	}
 	if prune(nil) != nil {
 		t.Error("nil bag must prune to nil")
 	}
 }
 
 func TestApplicationPrefix_RefusesNonBareID(t *testing.T) {
 	cases := map[string]bool{
-		"can://app":           true,  // bare — accepted
-		"can://my-app":        true,  //
-		"":                    false, // empty
-		"can://":              false, // missing app segment
-		"can://app/go/x.go":   false, // too deep (a module id)
-		"can://app/go/x.go/T": false, // deeper still
-		"go/app":              false, // no scheme
-		"can://app/":          false, // trailing empty segment
-		"can://app//":         false, // empty segments
+		"can://app/app":           true,  // bare — accepted
+		"can://my-app/my-app":     true,  //
+		"":                        false, // empty
+		"can://":                  false, // missing app segment
+		"can://app/app/go/x.go":   false, // too deep (a module id)
+		"can://app/app/go/x.go/T": false, // deeper still
+		"go/app":                  false, // no scheme
+		"can://app/app/":          false, // trailing empty segment
+		"can://app/app//":         false, // empty segments
 	}
 	for id, wantOK := range cases {
 		_, ok := applicationPrefix(id)
 		if ok != wantOK {
 			t.Errorf("applicationPrefix(%q) ok=%v, want %v", id, ok, wantOK)
 		}
 	}
 }
 
 func TestDescendantPrefix_AppendsSlash(t *testing.T) {
-	if got := descendantPrefix("can://app"); got != "can://app/" {
-		t.Errorf("descendantPrefix = %q, want can://app/", got)
+	if got := descendantPrefix("can://app/app"); got != "can://app/app/" {
+		t.Errorf("descendantPrefix = %q, want can://app/app/", got)
 	}
 }
 
 func TestFinish_IsOrderStable(t *testing.T) {
 	// Build the SAME logical graph (same nodes, same A→B and B→C edges) but add
 	// nodes and edges in two different INSERTION orders; finish() must sort to
 	// identical ordering both times.
 	ref := func(b *RowBuilder, id string) NodeRef {
 		return b.Node([]string{SymbolLabel, LabelCallable}, "id", id, nil, "")
 	}
-	const A, B, C = "can://app/go/a.go/A", "can://app/go/b.go/B", "can://app/go/c.go/C"
+	const A, B, C = "can://app/app/go/a.go/A", "can://app/app/go/b.go/B", "can://app/app/go/c.go/C"
 
 	build := func(reverse bool) GraphRows {
 		b := NewRowBuilder()
 		if reverse {
 			// Insert nodes C,B,A and the B→C edge before the A→B edge.
 			rc, rb, ra := ref(b, C), ref(b, B), ref(b, A)
 			b.Edge(RelCalls, rb, rc, nil, "")
 			b.Edge(RelCalls, ra, rb, nil, "")
 		} else {
 			ra, rb, rc := ref(b, A), ref(b, B), ref(b, C)
@@ -186,20 +186,47 @@ func nodeValues(g GraphRows) []string {
 }
 func edgeKeys(g GraphRows) []string {
 	out := make([]string, len(g.Edges))
 	for i, e := range g.Edges {
 		out[i] = edgeSortKey(e)
 	}
 	return out
 }
 
 func TestApplicationPrefix_AcceptsBareAppOnly(t *testing.T) {
-	if _, ok := applicationPrefix("can://shop"); !ok {
+	if _, ok := applicationPrefix("can://shop/shop"); !ok {
 		t.Error("bare can://shop should be accepted")
 	}
-	if _, ok := applicationPrefix("can://shop/go/a.go"); ok {
+	if _, ok := applicationPrefix("can://shop/shop/go/a.go"); ok {
 		t.Error("module id should be rejected")
 	}
 	if _, ok := applicationPrefix("can://"); ok {
 		t.Error("can:// should be rejected")
 	}
 }
+
+func TestCanonicalDedup(t *testing.T) {
+	b := NewRowBuilder()
+	a := b.Node([]string{LabelCallable}, "id", "can://team/app/go/a", Props{"kind": "function"}, "")
+	b.Node([]string{SymbolLabel}, "id", a.Value, Props{"kind": "function"}, "")
+	b.Edge("CALLS", a, a, Props{"site": "1"}, "")
+	b.Edge("CALLS", a, a, Props{"site": "1"}, "")
+	b.Edge("CALLS", a, a, Props{"site": "2"}, "")
+	r := b.Finish()
+	if len(r.Nodes) != 1 || len(r.Edges) != 2 {
+		t.Fatalf("nodes %d edges %d", len(r.Nodes), len(r.Edges))
+	}
+}
+
+func TestCanonicalEdgeFactOrder(t *testing.T) {
+	build := func(sites []string) GraphRows {
+		b := NewRowBuilder()
+		n := b.Node([]string{LabelCallable}, "id", "can://team/app/go/a", nil, "")
+		for _, site := range sites {
+			b.Edge(RelCalls, n, n, Props{"site": site}, "")
+		}
+		return b.Finish()
+	}
+	if !reflect.DeepEqual(build([]string{"a", "b"}), build([]string{"b", "a"})) {
+		t.Fatal("site order changes canonical graph")
+	}
+}
diff --git a/internal/neo4j/schema.go b/internal/neo4j/schema.go
index 928e1b4..f9acac0 100644
--- a/internal/neo4j/schema.go
+++ b/internal/neo4j/schema.go
@@ -178,21 +178,21 @@ type RelSpec struct {
 	Deferred bool
 	// Reserved marks an edge declared ahead of the level that fills it: it
 	// emits zero rows. None is Reserved today (the L4 overlay is live).
 	Reserved bool
 }
 
 // Nodes is the full node-label contract, in projection (spine) order.
 var Nodes = []NodeSpec{
 	{
 		Label: LabelApplication, MergeLabel: LabelApplication, Key: "id", CanNode: true,
-		Props: []string{"schema_version", "language", "max_level", "analyzer_name", "analyzer_version", "degraded_json"},
+		Props: []string{"identity_version", "application_name", "identity_namespace", "schema_version", "language", "max_level", "analyzer_name", "analyzer_version", "degraded_json"},
 	},
 	{
 		Label: LabelModule, MergeLabel: LabelModule, Key: "id", CanNode: true,
 		Props: []string{"package", "source", "content_hash", "span_json"},
 	},
 	{
 		Label: LabelType, MergeLabel: SymbolLabel, Key: "id", CanNode: true,
 		// kind ∈ struct|interface|alias|defined (property, decision T1).
 		Props: []string{"kind", "signature", "span_json"},
 	},
diff --git a/internal/options/options.go b/internal/options/options.go
index 01a1af8..13f0af9 100644
--- a/internal/options/options.go
+++ b/internal/options/options.go
@@ -30,23 +30,25 @@ const (
 // AnalysisOptions is the configuration surface passed from the CLI into Analyzer.
 type AnalysisOptions struct {
 	// InputPath is the project root to analyze.
 	InputPath string
 	// OutputDir is where analysis.json is written. Empty = write to stdout.
 	OutputDir string
 	// Format is the serialization format: "json" or "msgpack".
 	Format string
 	// Emit selects the output projection: json (default), neo4j, or schema.
 	Emit EmitTarget
-	// AppName anchors application identity (can://<app-name> and the Neo4j
+	// AppName anchors application identity (can://<namespace>/<app-name> and the Neo4j
 	// :Application node). Defaults to the input directory's base name.
 	AppName string
+	// Namespace is presence-aware: nil defaults to the resolved application name.
+	Namespace *string
 	// AnalysisLevel controls symbol-table-only (1), + call graph (2),
 	// + intraprocedural dataflow (3), or + the interprocedural SDG (4).
 	Level AnalysisLevel
 	// Strict makes the run fail non-zero on any L4 degradation (--strict).
 	Strict bool
 	// LibraryModels is the --library-models JSON file overriding library
 	// stand-in summaries at L4 (sdg.LoadModels). Empty = the defaults.
 	LibraryModels string
 	// AnalyzerVersion is the analyzer's own version, recorded in the v2
 	// manifest's analyzer{} tag. Set by the CLI from its build-stamped value.
diff --git a/internal/schema/v2/ids.go b/internal/schema/v2/ids.go
index 70e6ac5..e2e0788 100644
--- a/internal/schema/v2/ids.go
+++ b/internal/schema/v2/ids.go
@@ -1,48 +1,92 @@
 package v2
 
-import "strings"
+import (
+	"fmt"
+	"strings"
+	"unicode"
+	"unicode/utf8"
+)
 
 // Group A vocabulary: the `can://` durable-id grammar (>= callable) and the
 // `@line:col` ordinal-id grammar (< callable), plus span construction. These
 // helpers are pure so they can be tested in isolation and reused verbatim by
 // the deferred L3/L4 train (which must not re-decide id or span shape).
 //
 // Durable id grammar (the app segment is outermost so a polyglot app shares one
-// `can://<app>` prefix across languages; the language follows it):
+// `can://<namespace>/<app>` prefix across languages; the language follows it):
 //
-//	can://<app>/<lang>/<file>/<type>/<callable-signature>
-//	can://myapp/go/src/util.go/Hasher/Hash(string)uint64
+//	can://<namespace>/<app>/<lang>/<file>/<type>/<callable-signature>
+//	can://myapp/myapp/go/src/util.go/Hasher/Hash(string)uint64
 //
 // External (out-of-project) symbols are language-neutral:
 //
-//	can://<app>/@external/<import-path>/<sig>
+//	can://<namespace>/<app>/@external/<import-path>/<sig>
 //
 // Ordinal id grammar (statements and synthetic vertices, addressed WITHIN their
 // callable):
 //
 //	<callable-id>@<line>:<col>   e.g. …/Hash(string)uint64@15:2
 //	<callable-id>@<tag>          e.g. …/Hash(string)uint64@entry
 //
 // The delimiters `/`, `@`, `:` are fixed by the keystone; do not substitute.
 const (
 	scheme = "can://"
 	// idSep joins containment segments in a durable id.
 	idSep = "/"
 	// ordinalSep separates a callable id from an ordinal (line:col or @tag).
 	ordinalSep = "@"
 )
 
-// AppID builds the application id: can://<app>. The language is not part of it
-// (it follows the app in module ids) so sibling analyzers share the prefix.
-func AppID(app string) string {
-	return scheme + app
+// Identity holds validated raw names and their canonical root.
+type Identity struct {
+	Namespace       string
+	ApplicationName string
+	ApplicationID   string
+}
+
+// ResolveIdentity validates raw names, defaulting an omitted namespace to appName.
+func ResolveIdentity(appName string, namespace *string) (Identity, error) {
+	ns := appName
+	if namespace != nil {
+		ns = *namespace
+	}
+	for _, s := range []string{appName, ns} {
+		if !utf8.ValidString(s) || strings.TrimSpace(s) == "" || s == "." || s == ".." || strings.ContainsAny(s, "/\\") {
+			return Identity{}, fmt.Errorf("invalid application identity segment %q", s)
+		}
+		for _, r := range s {
+			if unicode.IsControl(r) {
+				return Identity{}, fmt.Errorf("control character in identity")
+			}
+		}
+	}
+	return Identity{Namespace: ns, ApplicationName: appName, ApplicationID: AppID(appName, ns)}, nil
+}
+func encodeSegment(s string) string {
+	const hex = "0123456789ABCDEF"
+	var b strings.Builder
+	for _, c := range []byte(s) {
+		if c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || strings.ContainsRune("-._~", rune(c)) {
+			b.WriteByte(c)
+		} else {
+			b.WriteByte('%')
+			b.WriteByte(hex[c>>4])
+			b.WriteByte(hex[c&15])
+		}
+	}
+	return b.String()
+}
+
+// AppID encodes resolved, validated names into a canonical application root.
+func AppID(app, namespace string) string {
+	return scheme + encodeSegment(namespace) + "/" + encodeSegment(app)
 }
 
 // ModuleID builds a module id from the application id and the module's file
 // path relative to the input root (forward-slashed, no leading slash, no "..").
 // The language segment is fixed to the package Language constant so callers
 // cannot drift it.
 func ModuleID(appID, relPath string) string {
 	return appID + idSep + Language + idSep + normalizePath(relPath)
 }
 
diff --git a/internal/schema/v2/ids_test.go b/internal/schema/v2/ids_test.go
index 4b23e72..72e4ee3 100644
--- a/internal/schema/v2/ids_test.go
+++ b/internal/schema/v2/ids_test.go
@@ -1,61 +1,61 @@
 package v2
 
 import "testing"
 
 func TestAppID(t *testing.T) {
-	if got, want := AppID("myapp"), "can://myapp"; got != want {
+	if got, want := AppID("myapp", "myapp"), "can://myapp/myapp"; got != want {
 		t.Errorf("AppID = %q, want %q", got, want)
 	}
 }
 
 func TestDurableIDChain(t *testing.T) {
 	// Reproduces the keystone worked example, segment by segment.
-	app := AppID("myapp")
+	app := AppID("myapp", "myapp")
 	mod := ModuleID(app, "src/util.go")
 	typ := TypeID(mod, "Hasher")
 	call := CallableID(typ, "Hash(string)uint64")
 
 	cases := []struct{ got, want string }{
-		{mod, "can://myapp/go/src/util.go"},
-		{typ, "can://myapp/go/src/util.go/Hasher"},
-		{call, "can://myapp/go/src/util.go/Hasher/Hash(string)uint64"},
+		{mod, "can://myapp/myapp/go/src/util.go"},
+		{typ, "can://myapp/myapp/go/src/util.go/Hasher"},
+		{call, "can://myapp/myapp/go/src/util.go/Hasher/Hash(string)uint64"},
 	}
 	for _, c := range cases {
 		if c.got != c.want {
 			t.Errorf("id = %q, want %q", c.got, c.want)
 		}
 	}
 }
 
 func TestModuleIDNormalizesPath(t *testing.T) {
-	app := AppID("myapp")
+	app := AppID("myapp", "myapp")
 	// Backslashes become forward slashes; a leading slash is trimmed.
-	if got, want := ModuleID(app, "\\pkg\\a.go"), "can://myapp/go/pkg/a.go"; got != want {
+	if got, want := ModuleID(app, "\\pkg\\a.go"), "can://myapp/myapp/go/pkg/a.go"; got != want {
 		t.Errorf("ModuleID = %q, want %q", got, want)
 	}
-	if got, want := ModuleID(app, "/pkg/a.go"), "can://myapp/go/pkg/a.go"; got != want {
+	if got, want := ModuleID(app, "/pkg/a.go"), "can://myapp/myapp/go/pkg/a.go"; got != want {
 		t.Errorf("ModuleID = %q, want %q", got, want)
 	}
 }
 
 func TestModuleLevelFunctionParent(t *testing.T) {
 	// A module-level function hangs off the module id, not a type.
-	mod := ModuleID(AppID("myapp"), "src/util.go")
+	mod := ModuleID(AppID("myapp", "myapp"), "src/util.go")
 	fn := CallableID(mod, "New64()")
-	if want := "can://myapp/go/src/util.go/New64()"; fn != want {
+	if want := "can://myapp/myapp/go/src/util.go/New64()"; fn != want {
 		t.Errorf("CallableID = %q, want %q", fn, want)
 	}
 }
 
 func TestOrdinalAndTagIDs(t *testing.T) {
-	call := "can://myapp/go/src/util.go/Hasher/Hash(string)uint64"
+	call := "can://myapp/myapp/go/src/util.go/Hasher/Hash(string)uint64"
 	if got, want := OrdinalID(call, 15, 2), call+"@15:2"; got != want {
 		t.Errorf("OrdinalID = %q, want %q", got, want)
 	}
 	if got, want := TagID(call, "entry"), call+"@entry"; got != want {
 		t.Errorf("TagID = %q, want %q", got, want)
 	}
 	if got, want := LocalID(16, 2), "16:2"; got != want {
 		t.Errorf("LocalID = %q, want %q", got, want)
 	}
 }
@@ -86,25 +86,25 @@ func TestSpanSliceOutOfRangeIsEmpty(t *testing.T) {
 func TestItoa(t *testing.T) {
 	cases := map[int]string{0: "0", 7: "7", 42: "42", 1000: "1000", -3: "-3"}
 	for in, want := range cases {
 		if got := itoa(in); got != want {
 			t.Errorf("itoa(%d) = %q, want %q", in, got, want)
 		}
 	}
 }
 
 func TestIDs_AppOutermost(t *testing.T) {
-	app := AppID("shop")
+	app := AppID("shop", "shop")
 	cases := []struct{ got, want string }{
-		{app, "can://shop"},
-		{ModuleID(app, "pkg/a.go"), "can://shop/go/pkg/a.go"},
-		{ExternalID(app, "database/sql", "DB.Query"), "can://shop/@external/database/sql/DB.Query"},
+		{app, "can://shop/shop"},
+		{ModuleID(app, "pkg/a.go"), "can://shop/shop/go/pkg/a.go"},
+		{ExternalID(app, "database/sql", "DB.Query"), "can://shop/shop/@external/database/sql/DB.Query"},
 		{GlobalOrdinal("X/F", "@entry"), "X/F@entry"},
 		{GlobalOrdinal("X/F", "12:3"), "X/F@12:3"},
 	}
 	for _, c := range cases {
 		if c.got != c.want {
 			t.Errorf("id = %q, want %q", c.got, c.want)
 		}
 	}
 }
 
diff --git a/internal/schema/v2/namespace_test.go b/internal/schema/v2/namespace_test.go
new file mode 100644
index 0000000..bfcfa7b
--- /dev/null
+++ b/internal/schema/v2/namespace_test.go
@@ -0,0 +1,62 @@
+package v2
+
+import (
+	"encoding/json"
+	"os"
+	"strings"
+	"testing"
+)
+
+func TestResolveIdentityFixtures(t *testing.T) {
+	b, e := os.ReadFile("testdata/namespaces.json")
+	if e != nil {
+		t.Fatal(e)
+	}
+	var f struct {
+		Invalid []struct {
+			Value  string
+			Reason string
+		} `json:"invalid"`
+		Roots []struct {
+			ApplicationName string  `json:"application_name"`
+			Namespace       *string `json:"namespace"`
+			ExpectedRoot    string  `json:"expected_root"`
+		}
+	}
+	if e = json.Unmarshal(b, &f); e != nil {
+		t.Fatal(e)
+	}
+	for _, r := range f.Invalid {
+		if strings.Contains(r.Reason, "surrogate") {
+			continue
+		}
+		if _, err := ResolveIdentity(r.Value, nil); err == nil {
+			t.Errorf("accepted fixture %q (%s)", r.Value, r.Reason)
+		}
+	}
+	for _, r := range f.Roots {
+		i, e := ResolveIdentity(r.ApplicationName, r.Namespace)
+		if e != nil || i.ApplicationID != r.ExpectedRoot {
+			t.Fatalf("%+v: %+v %v", r, i, e)
+		}
+	}
+}
+func TestNamespaceExplicitEmptyRejected(t *testing.T) {
+	for _, s := range []string{"", " ", "\u00a0", "a/b", "a\\b", ".", "..", "a\n", string([]byte{255})} {
+		if _, e := ResolveIdentity("app", &s); e == nil {
+			t.Errorf("accepted %q", s)
+		}
+		if _, e := ResolveIdentity(s, nil); e == nil {
+			t.Errorf("accepted app %q", s)
+		}
+	}
+	s := "AZaz09-._~!()*'"
+	i, e := ResolveIdentity(s, nil)
+	if e != nil || i.ApplicationID != "can://AZaz09-._~%21%28%29%2A%27/AZaz09-._~%21%28%29%2A%27" {
+		t.Fatalf("%+v %v", i, e)
+	}
+	s = "\u00a0x\u00a0"
+	if _, e = ResolveIdentity(s, nil); e != nil {
+		t.Fatal(e)
+	}
+}
diff --git a/internal/schema/v2/schema.go b/internal/schema/v2/schema.go
index 8042056..800c694 100644
--- a/internal/schema/v2/schema.go
+++ b/internal/schema/v2/schema.go
@@ -20,21 +20,21 @@
 //     `callee: null` refinement slot on a call node (null at L1, backfilled at
 //     L2). Absence is the "no fact" encoding — `omitempty` on optional fields.
 //   - open-vocabulary fields (prov, tags) are plain strings.
 package v2
 
 import "encoding/json"
 
 // SchemaVersion is the canonical schema major this package targets.
 const SchemaVersion = "2.0.0"
 
-// Language is the analyzer's language tag in the manifest and `can://<app>/<lang>/…`.
+// Language is the analyzer's language tag in the manifest and `can://<namespace>/<app>/<lang>/…`.
 const Language = "go"
 
 // ─── Positioning ───────────────────────────────────────────────────────────
 
 // Span is the one universal node attribute: where in source the node lives.
 // line:col addresses and displays; bytes slices module.source in O(1). Byte
 // offsets are UTF-8 offsets into module.source (Go source is natively UTF-8).
 type Span struct {
 	// Start is [line, col] of the first byte (1-based line, 1-based col).
 	Start [2]int `json:"start"`
@@ -44,26 +44,27 @@ type Span struct {
 	Bytes [2]int `json:"bytes"`
 }
 
 // ─── Root envelope ───────────────────────────────────────────────────────────
 
 // Analysis is the top-level payload written to analysis.json / stdout. Its
 // siblings of `application` carry the manifest; consumers read `max_level`
 // rather than sniffing for keys. k_limit (the field-path depth bound of the
 // L3 and L4 access paths) is present only at max_level >= 3.
 type Analysis struct {
-	SchemaVersion string      `json:"schema_version"`
-	Language      string      `json:"language"`
-	MaxLevel      int         `json:"max_level"`
-	KLimit        int         `json:"k_limit,omitempty"`
-	Analyzer      AnalyzerTag `json:"analyzer"`
-	Application   Application `json:"application"`
+	IdentityVersion int         `json:"identity_version"`
+	SchemaVersion   string      `json:"schema_version"`
+	Language        string      `json:"language"`
+	MaxLevel        int         `json:"max_level"`
+	KLimit          int         `json:"k_limit,omitempty"`
+	Analyzer        AnalyzerTag `json:"analyzer"`
+	Application     Application `json:"application"`
 	// Degraded records the L4 degradation markers (spec §4.15); absent when
 	// the run degraded nothing and below -a 4.
 	Degraded []Degraded `json:"degraded,omitempty"`
 }
 
 // Degraded is one degradation marker: an L4 step that fell back to a coarser
 // result. Code is an open vocabulary of plain strings (spec §4.15); Detail,
 // Packages and Callables say what was affected.
 type Degraded struct {
 	Code      string   `json:"code"`
@@ -73,31 +74,34 @@ type Degraded struct {
 }
 
 // AnalyzerTag identifies the producing analyzer and version.
 type AnalyzerTag struct {
 	Name    string `json:"name"`
 	Version string `json:"version"`
 }
 
 // Application is the root node of the containment tree.
 type Application struct {
-	// ID is `can://<app>` — the app segment is outermost, so a polyglot
+	IdentityVersion   int    `json:"identity_version"`
+	ApplicationName   string `json:"application_name"`
+	IdentityNamespace string `json:"identity_namespace"`
+	// ID is `can://<namespace>/<app>` — the app segment is outermost, so a polyglot
 	// app shares one prefix across languages. <app> is the --app-name value (default: input dir base name).
 	ID   string `json:"id"`
 	Kind string `json:"kind"` // always "application"
 	// SymbolTable is the L1 named map keyed by relative file path.
 	SymbolTable map[string]Module `json:"symbol_table"`
 	// CallGraph holds the L2 cross-function edges (callable → callable). Empty
 	// at L1.
 	CallGraph []Edge `json:"call_graph"`
 	// ExternalSymbols holds the out-of-project (library) callables the call graph
-	// reaches, keyed by their `can://<app>/@external/<import-path>/<sig>` id.
+	// reaches, keyed by their `can://<namespace>/<app>/@external/<import-path>/<sig>` id.
 	// Absent when the analysis saw no library call.
 	ExternalSymbols map[string]ExternalSymbol `json:"external_symbols,omitempty"`
 	// ParamIn and ParamOut are the L4 interprocedural parameter edges between
 	// global body-node ids. Absent below -a 4.
 	ParamIn  []ParamEdge `json:"param_in,omitempty"`
 	ParamOut []ParamEdge `json:"param_out,omitempty"`
 }
 
 // ParamEdge is an L4 interprocedural parameter edge (call-site actual →
 // callee formal for param_in, callee formal/return → call-site result for
diff --git a/internal/syntactic_analysis/v2emit/determinism_freshbuild_test.go b/internal/syntactic_analysis/v2emit/determinism_freshbuild_test.go
index f89fb6a..b4b7d6a 100644
--- a/internal/syntactic_analysis/v2emit/determinism_freshbuild_test.go
+++ b/internal/syntactic_analysis/v2emit/determinism_freshbuild_test.go
@@ -57,21 +57,21 @@ func chiDir(t *testing.T) string {
 func buildChiL2Fresh(t *testing.T, dir string) *v2.Analysis {
 	t.Helper()
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
-	return Emit(app, "chi", dir, 2, "gate-test", 0, nil, nil)
+	return Emit(app, testIdentity("chi"), dir, 2, "gate-test", 0, nil, nil)
 }
 
 // TestDeterminism_FreshBuildsByteIdentical locks that independent from-disk
 // builds of the chi fixture emit a byte-identical call_graph every time. A
 // regression that reintroduces signature->id collapse (or any map-order leak
 // into the edge set) fails here, in the test suite CI runs — not only in an
 // external CLI diff.
 func TestDeterminism_FreshBuildsByteIdentical(t *testing.T) {
 	dir := chiDir(t)
 
diff --git a/internal/syntactic_analysis/v2emit/determinism_test.go b/internal/syntactic_analysis/v2emit/determinism_test.go
index e87e9cf..b6d2313 100644
--- a/internal/syntactic_analysis/v2emit/determinism_test.go
+++ b/internal/syntactic_analysis/v2emit/determinism_test.go
@@ -39,30 +39,30 @@ func TestDeterminism_CallGraphStableAcrossEmits(t *testing.T) {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges}
 
 	// Emit twice from the SAME model. If the edge order is derived from the
 	// edges slice without a stable sort, repeated marshals still match (same
 	// slice), so to actually exercise order-independence we marshal a shuffled
 	// copy of the edge slice too.
-	first := mustMarshalCallGraph(t, Emit(app, "multipackage", dir, 2, "det-test", 0, nil, nil))
+	first := mustMarshalCallGraph(t, Emit(app, testIdentity("multipackage"), dir, 2, "det-test", 0, nil, nil))
 
 	// Reverse the input edge order and re-emit: a correct emitter sorts, so the
 	// serialized call_graph must be unchanged.
 	rev := make([]schema.GoCallEdge, len(edges))
 	for i, e := range edges {
 		rev[len(edges)-1-i] = e
 	}
 	appRev := &schema.GoApplication{SymbolTable: st, CallGraph: rev}
-	second := mustMarshalCallGraph(t, Emit(appRev, "multipackage", dir, 2, "det-test", 0, nil, nil))
+	second := mustMarshalCallGraph(t, Emit(appRev, testIdentity("multipackage"), dir, 2, "det-test", 0, nil, nil))
 
 	if first != second {
 		t.Errorf("call_graph not order-independent: emitCallGraph must sort edges to a total order\nfirst=%s\nsecond=%s", first, second)
 	}
 }
 
 func mustMarshalCallGraph(t *testing.T, out *v2.Analysis) string {
 	t.Helper()
 	type cgOnly struct {
 		Application struct {
@@ -93,34 +93,34 @@ func TestEncode_ByteIdenticalToMarshal(t *testing.T) {
 			t.Fatal(err)
 		}
 		b := syntactic_analysis.NewSymbolTableBuilder(dir)
 		st, err := b.Build(nil, true)
 		if err != nil {
 			t.Fatalf("%s: symbol table build failed: %v", name, err)
 		}
 		apps := map[int]*schema.GoApplication{1: {SymbolTable: st, CallGraph: []schema.GoCallEdge{}}}
 		check := func(level int, app *schema.GoApplication, l3 map[dataflow.L3Key]dataflow.Result) {
 			t.Run(fmt.Sprintf("%s/a%d", name, level), func(t *testing.T) {
-				tree := Emit(app, name, dir, level, "enc-test", 3, l3, nil)
+				tree := Emit(app, testIdentity(name), dir, level, "enc-test", 3, l3, nil)
 				want, err := json.Marshal(tree)
 				if err != nil {
 					t.Fatal(err)
 				}
 				var enc bytes.Buffer
 				if err := Encode(&enc, tree); err != nil {
 					t.Fatal(err)
 				}
 				if !bytes.Equal(enc.Bytes(), want) {
 					t.Errorf("Encode differs from json.Marshal at byte %d (len %d vs %d)", firstDiff(enc.Bytes(), want), enc.Len(), len(want))
 				}
 				var lazy bytes.Buffer
-				if err := EmitTo(&lazy, app, name, dir, level, "enc-test", 3, l3, nil); err != nil {
+				if err := EmitTo(&lazy, app, testIdentity(name), dir, level, "enc-test", 3, l3, nil); err != nil {
 					t.Fatal(err)
 				}
 				if !bytes.Equal(lazy.Bytes(), want) {
 					t.Errorf("EmitTo differs from json.Marshal(Emit) at byte %d (len %d vs %d)", firstDiff(lazy.Bytes(), want), lazy.Len(), len(want))
 				}
 			})
 		}
 		check(1, apps[1], nil)
 		cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 		edges := cg.Build(st)
@@ -142,21 +142,21 @@ func firstDiff(a, b []byte) int {
 // TestEncode_L4EnvelopeFieldsByteIdentical: the L4 envelope and tree fields
 // (degraded after application, param_in/out inside it, summary, of, receiver,
 // external body) go through the streaming writer's envelope split unchanged.
 func TestEncode_L4EnvelopeFieldsByteIdentical(t *testing.T) {
 	call := "x"
 	a := &v2.Analysis{
 		SchemaVersion: v2.SchemaVersion, Language: v2.Language, MaxLevel: 4, KLimit: 3,
 		Analyzer: v2.AnalyzerTag{Name: "codeanalyzer-go", Version: "t"},
 		Degraded: []v2.Degraded{{Code: "ssa_build", Detail: `has "symbol_table":{} & <x>`, Packages: []string{"p"}, Callables: []string{"c"}}},
 		Application: v2.Application{
-			ID: "can://app", Kind: "application",
+			ID: "can://app/app", Kind: "application",
 			SymbolTable: map[string]v2.Module{
 				"a.go": {ID: "m", Functions: map[string]v2.Callable{"f": {
 					ID: "f", Summary: []v2.SummaryEdge{{Src: "a", Dst: "b"}},
 					Body: map[string]v2.BodyNode{
 						"@fin": {Kind: "formal_in", Of: "p0"},
 						"c1":   {Kind: "call", Callee: &call},
 					},
 				}}},
 			},
 			ExternalSymbols: map[string]v2.ExternalSymbol{"e": {
diff --git a/internal/syntactic_analysis/v2emit/emit.go b/internal/syntactic_analysis/v2emit/emit.go
index 8ff0b1e..3f0279e 100644
--- a/internal/syntactic_analysis/v2emit/emit.go
+++ b/internal/syntactic_analysis/v2emit/emit.go
@@ -12,57 +12,57 @@ import (
 	"slices"
 	"sort"
 	"strings"
 
 	"github.com/codellm-devkit/codeanalyzer-go/internal/dataflow"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/schema"
 	v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 	"github.com/codellm-devkit/codeanalyzer-go/internal/sdg"
 )
 
-// Emit transforms the v1 GoApplication into the v2 Analysis payload. appName is
+// Emit transforms the v1 GoApplication into the v2 Analysis payload. identity is
 // the application anchor (--app-name); projectDir is the absolute input root,
 // used to read each module's source for span slicing. maxLevel records how
 // deeply the tree was populated (1 = symbol table, 2 = + call_graph, 3 = +
 // cfg/cdg/ddg); analyzerVersion is stamped into the manifest's analyzer{} tag.
 //
 // kLimit is the L3 access-path bound (--graph-field-depth), written as the
 // envelope's k_limit at maxLevel >= 3 only. l3 is dataflow.Run's side table,
 // nil below L3; see emit_l3.go for how it merges into each callable. l4 is
 // sdg.Run's result, nil below L4 (and ignored there); see emit_l4.go for how
 // it merges into the tree and mints every L4 id.
 //
 // This is a pure re-serialization: every fact comes from the v1 model and the
 // L3/L4 side tables, except span byte offsets, which are derived from source
 // via lineIndex.
-func Emit(app *schema.GoApplication, appName, projectDir string, maxLevel int, analyzerVersion string, kLimit int, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result) *v2.Analysis {
-	e := newEmitter(app, appName, projectDir, maxLevel, l3, l4)
+func Emit(app *schema.GoApplication, identity v2.Identity, projectDir string, maxLevel int, analyzerVersion string, kLimit int, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result) *v2.Analysis {
+	e := newEmitter(app, identity, projectDir, maxLevel, l3, l4)
 	out := e.envelope(app, maxLevel, analyzerVersion, kLimit)
 	out.Application.SymbolTable = make(map[string]v2.Module, len(app.SymbolTable))
 	for _, relPath := range sortedFileKeys(app.SymbolTable) {
 		out.Application.SymbolTable[relPath] = e.module(relPath, app.SymbolTable[relPath])
 	}
 	late := e.sdg.late()
 	out.Application.ParamIn = collectEdges(late.paramIn)
 	out.Application.ParamOut = collectEdges(late.paramOut)
 	out.Degraded = late.degraded
 	return out
 }
 
 // EmitTo writes the analysis.json bytes of Emit's payload to w — the same bytes
 // json.Marshal(Emit(...)) produces — without building the whole tree: each
 // module is emitted, marshalled and dropped in symbol_table key order, so peak
 // memory is the envelope plus the largest module, not the document. The L4
 // param edges follow the modules (they need every callable's id) and are
 // minted and written one at a time.
-func EmitTo(w io.Writer, app *schema.GoApplication, appName, projectDir string, maxLevel int, analyzerVersion string, kLimit int, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result) error {
-	e := newEmitter(app, appName, projectDir, maxLevel, l3, l4)
+func EmitTo(w io.Writer, app *schema.GoApplication, identity v2.Identity, projectDir string, maxLevel int, analyzerVersion string, kLimit int, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result) error {
+	e := newEmitter(app, identity, projectDir, maxLevel, l3, l4)
 	out := e.envelope(app, maxLevel, analyzerVersion, kLimit)
 	return encode(w, out, func(yield func(string, v2.Module) bool) {
 		for _, relPath := range sortedFileKeys(app.SymbolTable) {
 			if !yield(relPath, e.module(relPath, app.SymbolTable[relPath])) {
 				return
 			}
 		}
 	}, e.sdg.late)
 }
 
@@ -214,47 +214,48 @@ func writeEntry(w io.Writer, key string, m v2.Module, first bool) error {
 // The signature→can:// id index (idx) translates v1 identity (signature
 // strings) into v2 node ids. It is what the L2 refinement uses to backfill
 // body callees and to map call_graph edge endpoints onto real callable ids.
 //
 // srcs holds one lineIndex per source file, read once and shared. A method
 // whose receiver type lives in a different file is nested under that type's
 // module but must have its span computed against ITS OWN file (CLAUDE.md §
 // Schema decisions → callable.source_file); the cache lets emitCallable reach
 // any file's index without re-reading it per callable.
 type emitter struct {
-	appID string
-	idx   sigIndex
-	srcs  *sourceCache
-	flow  l3Overlay
-	sdg   *l4Overlay // nil below L4
+	identity v2.Identity
+	appID    string
+	idx      sigIndex
+	srcs     *sourceCache
+	flow     l3Overlay
+	sdg      *l4Overlay // nil below L4
 }
 
-func newEmitter(app *schema.GoApplication, appName, projectDir string, maxLevel int, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result) *emitter {
-	appID := v2.AppID(appName)
+func newEmitter(app *schema.GoApplication, identity v2.Identity, projectDir string, maxLevel int, l3 map[dataflow.L3Key]dataflow.Result, l4 *sdg.Result) *emitter {
+	appID := identity.ApplicationID
 	idx := buildSigIndex(appID, app.SymbolTable)
 	idx.externals = externalIDs(appID, app.Externals)
 	return &emitter{
-		appID: appID, idx: idx, srcs: newSourceCache(projectDir),
+		identity: identity, appID: appID, idx: idx, srcs: newSourceCache(projectDir),
 		flow: newL3Overlay(maxLevel, l3), sdg: newL4Overlay(maxLevel, l4, idx),
 	}
 }
 
 // envelope is the payload without its symbol_table (nil): the manifest, the
 // call graph and the external symbols.
 func (e *emitter) envelope(app *schema.GoApplication, maxLevel int, analyzerVersion string, kLimit int) *v2.Analysis {
 	out := &v2.Analysis{
-		SchemaVersion: v2.SchemaVersion,
-		Language:      v2.Language,
-		MaxLevel:      maxLevel,
-		Analyzer:      v2.AnalyzerTag{Name: "codeanalyzer-go", Version: analyzerVersion},
+		IdentityVersion: 2, SchemaVersion: v2.SchemaVersion,
+		Language: v2.Language,
+		MaxLevel: maxLevel,
+		Analyzer: v2.AnalyzerTag{Name: "codeanalyzer-go", Version: analyzerVersion},
 		Application: v2.Application{
-			ID:        e.appID,
+			IdentityVersion: 2, ApplicationName: e.identity.ApplicationName, IdentityNamespace: e.identity.Namespace, ID: e.appID,
 			Kind:      "application",
 			CallGraph: emitCallGraph(app.CallGraph, e.idx),
 		},
 	}
 	out.Application.ExternalSymbols = emitExternalSymbols(e.appID, app.Externals, e.sdg.standIns())
 	if e.flow.on {
 		out.KLimit = kLimit
 	}
 	return out
 }
diff --git a/internal/syntactic_analysis/v2emit/emit_l4_test.go b/internal/syntactic_analysis/v2emit/emit_l4_test.go
index cdf0d91..445ac9b 100644
--- a/internal/syntactic_analysis/v2emit/emit_l4_test.go
+++ b/internal/syntactic_analysis/v2emit/emit_l4_test.go
@@ -33,21 +33,21 @@ func TestCompareOrdinal_MatchesMintedIds(t *testing.T) {
 	}
 }
 
 // TestL4Overlay_DuplicateKeyKeepsSmallerID: two callables sharing a target
 // key (declaring file and signature) route its param edges and degraded
 // entries to the lexically smaller id, whichever is applied first —
 // emission walks maps, so last-write-wins would be nondeterministic — and
 // the clash is warned once, naming both ids.
 func TestL4Overlay_DuplicateKeyKeepsSmallerID(t *testing.T) {
 	key := dataflow.L3Key{Path: "a.go", Signature: "example.com/a.F"}
-	small, big := "can://app/go/a.go/example.com/a.F", "can://app/go/b.go/example.com/a.F"
+	small, big := "can://app/app/go/a.go/example.com/a.F", "can://app/app/go/b.go/example.com/a.F"
 	var warned []string
 	prev := warnf
 	warnf = func(format string, args ...any) { warned = append(warned, fmt.Sprintf(format, args...)) }
 	defer func() { warnf = prev }()
 	for _, order := range [][]string{{small, big}, {big, small}} {
 		warned = nil
 		o := newL4Overlay(4, &sdg.Result{}, sigIndex{})
 		for _, id := range order {
 			o.apply(&v2.Callable{ID: id, Body: map[string]v2.BodyNode{}}, key)
 		}
diff --git a/internal/syntactic_analysis/v2emit/emit_test.go b/internal/syntactic_analysis/v2emit/emit_test.go
index 87fe4e2..9bc1dc3 100644
--- a/internal/syntactic_analysis/v2emit/emit_test.go
+++ b/internal/syntactic_analysis/v2emit/emit_test.go
@@ -30,68 +30,68 @@ func buildGreeter(t *testing.T) (*schema.GoApplication, string) {
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	return &schema.GoApplication{SymbolTable: st, CallGraph: []schema.GoCallEdge{}}, dir
 }
 
 func TestEmit_Envelope(t *testing.T) {
 	app, dir := buildGreeter(t)
-	out := Emit(app, "greeter", dir, 1, "test", 0, nil, nil)
+	out := Emit(app, testIdentity("greeter"), dir, 1, "test", 0, nil, nil)
 
 	if out.SchemaVersion != "2.0.0" {
 		t.Errorf("schema_version = %q, want 2.0.0", out.SchemaVersion)
 	}
 	if out.Language != "go" {
 		t.Errorf("language = %q, want go", out.Language)
 	}
 	if out.MaxLevel != 1 {
 		t.Errorf("max_level = %d, want 1", out.MaxLevel)
 	}
-	if out.Application.ID != "can://greeter" {
-		t.Errorf("application.id = %q, want can://greeter", out.Application.ID)
+	if out.Application.ID != "can://greeter/greeter" {
+		t.Errorf("application.id = %q, want can://greeter/greeter", out.Application.ID)
 	}
 	if out.Application.Kind != "application" {
 		t.Errorf("application.kind = %q, want application", out.Application.Kind)
 	}
 	if len(out.Application.SymbolTable) == 0 {
 		t.Fatal("symbol_table is empty")
 	}
 }
 
 func TestEmit_ModuleSourceAndIDs(t *testing.T) {
 	app, dir := buildGreeter(t)
-	out := Emit(app, "greeter", dir, 1, "test", 0, nil, nil)
+	out := Emit(app, testIdentity("greeter"), dir, 1, "test", 0, nil, nil)
 
 	mod, ok := out.Application.SymbolTable["main.go"]
 	if !ok {
 		t.Fatalf("main.go not in symbol_table; keys=%v", keys(out.Application.SymbolTable))
 	}
 	if mod.Kind != "module" {
 		t.Errorf("module.kind = %q, want module", mod.Kind)
 	}
-	if mod.ID != "can://greeter/go/main.go" {
-		t.Errorf("module.id = %q, want can://greeter/go/main.go", mod.ID)
+	if mod.ID != "can://greeter/greeter/go/main.go" {
+		t.Errorf("module.id = %q, want can://greeter/greeter/go/main.go", mod.ID)
 	}
 	if !strings.HasPrefix(mod.Source, "package main") {
 		t.Errorf("module.source should hold the file text; got prefix %q", head(mod.Source, 20))
 	}
 	// The module span slices the whole file.
 	if got := mod.Span.Slice(mod.Source); got != mod.Source {
 		t.Errorf("module span does not cover whole source (%d vs %d bytes)", len(got), len(mod.Source))
 	}
 }
 
 func TestEmit_CallableBodyAndSpanSlice(t *testing.T) {
 	app, dir := buildGreeter(t)
-	out := Emit(app, "greeter", dir, 1, "test", 0, nil, nil)
+	out := Emit(app, testIdentity("greeter"), dir, 1, "test", 0, nil, nil)
 
 	mod := out.Application.SymbolTable["main.go"]
 	var main v2.Callable
 	found := false
 	for _, fn := range mod.Functions {
 		if fn.Signature != "" && strings.HasSuffix(fn.Signature, ".main") {
 			main, found = fn, true
 		}
 	}
 	if !found {
@@ -116,42 +116,42 @@ func TestEmit_CallableBodyAndSpanSlice(t *testing.T) {
 			t.Errorf("body[%s].callee should be null at L1; got %q", local, *node.Callee)
 		}
 		if !strings.Contains(local, ":") {
 			t.Errorf("body key %q should be line:col", local)
 		}
 	}
 }
 
 func TestEmit_CalleeSerializesAsNull(t *testing.T) {
 	app, dir := buildGreeter(t)
-	out := Emit(app, "greeter", dir, 1, "test", 0, nil, nil)
+	out := Emit(app, testIdentity("greeter"), dir, 1, "test", 0, nil, nil)
 	data, err := json.Marshal(out)
 	if err != nil {
 		t.Fatalf("marshal failed: %v", err)
 	}
 	if !strings.Contains(string(data), `"callee":null`) {
 		t.Error("expected at least one call node to serialize callee as null at L1")
 	}
 	// The v1-only keys must be gone.
 	for _, banned := range []string{`"symbol_table"`, `"call_graph"`} {
 		if !strings.Contains(string(data), banned) {
 			t.Errorf("expected v2 payload to contain %s", banned)
 		}
 	}
 	if strings.Contains(string(data), `"is_constructor_call"`) {
 		t.Error("v2 payload should not contain dropped is_constructor_call")
 	}
 }
 
 func TestEmit_TypeKindAndMethods(t *testing.T) {
 	app, dir := buildGreeter(t)
-	out := Emit(app, "greeter", dir, 1, "test", 0, nil, nil)
+	out := Emit(app, testIdentity("greeter"), dir, 1, "test", 0, nil, nil)
 
 	// Find the Greeter type wherever it lives; assert struct kind + methods.
 	var found bool
 	for _, mod := range out.Application.SymbolTable {
 		for name, ty := range mod.Types {
 			if ty.Kind != "struct" && ty.Kind != "interface" {
 				t.Errorf("type %s kind = %q, want struct|interface", name, ty.Kind)
 			}
 			if strings.Contains(ty.ID, "://") == false {
 				t.Errorf("type %s id should be a can:// id; got %q", name, ty.ID)
@@ -176,10 +176,18 @@ func head(s string, n int) string {
 	return s[:n]
 }
 
 func keys[V any](m map[string]V) []string {
 	out := make([]string, 0, len(m))
 	for k := range m {
 		out = append(out, k)
 	}
 	return out
 }
+
+func testIdentity(name string) v2.Identity {
+	i, e := v2.ResolveIdentity(name, nil)
+	if e != nil {
+		panic(e)
+	}
+	return i
+}
diff --git a/internal/syntactic_analysis/v2emit/gate_l2_inits_test.go b/internal/syntactic_analysis/v2emit/gate_l2_inits_test.go
index 287cd81..3953e2a 100644
--- a/internal/syntactic_analysis/v2emit/gate_l2_inits_test.go
+++ b/internal/syntactic_analysis/v2emit/gate_l2_inits_test.go
@@ -30,21 +30,21 @@ func buildDataflowL2Fresh(t *testing.T) *v2.Analysis {
 		t.Fatalf("resolving fixture dir: %v", err)
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
-	return Emit(app, "dataflow", dir, 2, "gate-test", 0, nil, nil)
+	return Emit(app, testIdentity("dataflow"), dir, 2, "gate-test", 0, nil, nil)
 }
 
 // TestGateL2_EveryInitKeepsItsEdges: each file's init has its own edge to the
 // shared in-package callee and to the shared library callee.
 func TestGateL2_EveryInitKeepsItsEdges(t *testing.T) {
 	out := buildDataflowL2Fresh(t)
 	const initSig = "example.com/dataflow/inits.init"
 	setup := functionByName(t, mustModule(t, out, "inits/a.go"), "setup").ID
 	getenv := v2.ExternalID(out.Application.ID, "os", "Getenv")
 
diff --git a/internal/syntactic_analysis/v2emit/gate_l2_test.go b/internal/syntactic_analysis/v2emit/gate_l2_test.go
index 347d3db..d402ed6 100644
--- a/internal/syntactic_analysis/v2emit/gate_l2_test.go
+++ b/internal/syntactic_analysis/v2emit/gate_l2_test.go
@@ -35,21 +35,21 @@ func buildMultipackageL2(t *testing.T) *v2.Analysis {
 	t.Helper()
 	dir := multipackageDir(t)
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st) // mutates st in place: backfills callee_signature
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
-	return Emit(app, "multipackage", dir, 2, "gate-test", 0, nil, nil)
+	return Emit(app, testIdentity("multipackage"), dir, 2, "gate-test", 0, nil, nil)
 }
 
 // allCallableIDs collects every callable/type id in the emitted tree.
 func allCallableIDs(out *v2.Analysis) map[string]bool {
 	ids := map[string]bool{}
 	var walk func(c v2.Callable)
 	walk = func(c v2.Callable) {
 		ids[c.ID] = true
 		for _, inner := range c.Callables {
 			walk(inner)
@@ -103,22 +103,22 @@ func TestGateL2_NoDanglingEndpoints(t *testing.T) {
 	}
 }
 
 // TestGateL2_NamedEdgePresent asserts an EXACT expected edge, so the gate proves
 // correctness, not merely a non-empty graph: Worker.Run calls Worker.execute
 // (the `go w.execute(...)` goroutine), both as can:// ids.
 func TestGateL2_NamedEdgePresent(t *testing.T) {
 	out := buildMultipackageL2(t)
 
 	const (
-		src = "can://multipackage/go/worker/worker.go/example.com/multipackage/worker.Worker/example.com/multipackage/worker.Worker.Run"
-		dst = "can://multipackage/go/worker/worker.go/example.com/multipackage/worker.Worker/example.com/multipackage/worker.Worker.execute"
+		src = "can://multipackage/multipackage/go/worker/worker.go/example.com/multipackage/worker.Worker/example.com/multipackage/worker.Worker.Run"
+		dst = "can://multipackage/multipackage/go/worker/worker.go/example.com/multipackage/worker.Worker/example.com/multipackage/worker.Worker.execute"
 	)
 	found := false
 	for _, e := range out.Application.CallGraph {
 		if e.Src == src && e.Dst == dst {
 			found = true
 			break
 		}
 	}
 	if !found {
 		t.Errorf("expected edge %s -> %s not found in call_graph", src, dst)
@@ -126,22 +126,22 @@ func TestGateL2_NamedEdgePresent(t *testing.T) {
 }
 
 // TestGateL2_CrossPackageEdge locks a specific cross-package edge: main() (in
 // package main, main.go) calls server.New (in package server, server/server.go).
 // Asserting the exact pair proves a resolved cross-module edge, not just that
 // the graph is non-empty.
 func TestGateL2_CrossPackageEdge(t *testing.T) {
 	out := buildMultipackageL2(t)
 
 	const (
-		src = "can://multipackage/go/main.go/example.com/multipackage.main"
-		dst = "can://multipackage/go/server/server.go/example.com/multipackage/server.New"
+		src = "can://multipackage/multipackage/go/main.go/example.com/multipackage.main"
+		dst = "can://multipackage/multipackage/go/server/server.go/example.com/multipackage/server.New"
 	)
 	found := false
 	for _, e := range out.Application.CallGraph {
 		if e.Src == src && e.Dst == dst {
 			found = true
 			break
 		}
 	}
 	if !found {
 		t.Errorf("expected cross-package edge %s -> %s not found", src, dst)
@@ -182,26 +182,26 @@ func TestGateL2_CalleeBackfilled(t *testing.T) {
 // level 2 changes nothing but the callee slot. Every module/type/callable id and
 // span is identical; only body callees may go null -> id.
 func TestGateL2_SupersetOfL1(t *testing.T) {
 	dir := multipackageDir(t)
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	// L1 snapshot BEFORE the resolver mutates call sites.
-	l1 := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: nil}, "multipackage", dir, 1, "gate-test", 0, nil, nil)
+	l1 := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: nil}, testIdentity("multipackage"), dir, 1, "gate-test", 0, nil, nil)
 
 	// Now run the resolver (mutates st) and emit L2.
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
-	l2 := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges}, "multipackage", dir, 2, "gate-test", 0, nil, nil)
+	l2 := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges}, testIdentity("multipackage"), dir, 2, "gate-test", 0, nil, nil)
 
 	if len(l1.Application.SymbolTable) != len(l2.Application.SymbolTable) {
 		t.Fatalf("module count changed L1->L2: %d vs %d",
 			len(l1.Application.SymbolTable), len(l2.Application.SymbolTable))
 	}
 	for rel, m1 := range l1.Application.SymbolTable {
 		m2 := l2.Application.SymbolTable[rel]
 		if m1.ID != m2.ID || m1.Span != m2.Span || m1.Source != m2.Source {
 			t.Errorf("%s: module identity/span/source changed L1->L2", rel)
 		}
@@ -403,21 +403,21 @@ func emitTemp(t *testing.T, src string) *v2.Analysis {
 		t.Fatal(err)
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
-	return Emit(app, "p", dir, 2, "gate-test", 0, nil, nil)
+	return Emit(app, testIdentity("p"), dir, 2, "gate-test", 0, nil, nil)
 }
 
 // TestGateL2_ExternalParamsHaveNoSpan locks that external parameters serialize
 // without a span key (no fabricated location).
 func TestGateL2_ExternalParamsHaveNoSpan(t *testing.T) {
 	out := buildMultipackageL2(t)
 	ext := v2.ExternalID(out.Application.ID, "fmt", "Println")
 	raw, err := json.Marshal(out.Application.ExternalSymbols[ext])
 	if err != nil {
 		t.Fatal(err)
@@ -435,21 +435,21 @@ func TestGateL2_GenericLibraryMethodUsesDeclaredSignature(t *testing.T) {
 	_, thisFile, _, _ := runtime.Caller(0)
 	dir := filepath.Join(filepath.Dir(thisFile), "..", "..", "..", "testdata", "dataflow")
 	for i := 0; i < 6; i++ { // fresh builds: map order varies
 		b := syntactic_analysis.NewSymbolTableBuilder(dir)
 		st, err := b.Build(nil, true)
 		if err != nil {
 			t.Fatalf("build: %v", err)
 		}
 		cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 		edges := cg.Build(st)
-		out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, "dataflow", dir, 2, "gate-test", 0, nil, nil)
+		out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, testIdentity("dataflow"), dir, 2, "gate-test", 0, nil, nil)
 		ext := v2.ExternalID(out.Application.ID, "sync/atomic", "Pointer.Store")
 		sym, ok := out.Application.ExternalSymbols[ext]
 		if !ok {
 			t.Fatalf("missing %s; have %v", ext, out.Application.ExternalSymbols)
 		}
 		if len(sym.Parameters) != 1 || sym.Parameters[0].Type != "*T" {
 			t.Fatalf("Pointer.Store params = %+v, want one param of type *T", sym.Parameters)
 		}
 	}
 }
@@ -459,21 +459,21 @@ func TestGateL2_GenericLibraryMethodUsesDeclaredSignature(t *testing.T) {
 // are never minted as @external symbols named after the project's own module.
 func TestGateL2_IncrementalModeKeepsProjectCalleesInternal(t *testing.T) {
 	dir := multipackageDir(t)
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build([]string{filepath.Join(dir, "main.go")}, true)
 	if err != nil {
 		t.Fatalf("build: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
-	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, "multipackage", dir, 2, "gate-test", 0, nil, nil)
+	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, testIdentity("multipackage"), dir, 2, "gate-test", 0, nil, nil)
 
 	const projectModule = "example.com/multipackage"
 	for id, sym := range out.Application.ExternalSymbols {
 		if sym.Module == projectModule || strings.HasPrefix(sym.Module, projectModule+"/") {
 			t.Errorf("project callee minted as external: %s (module %s)", id, sym.Module)
 		}
 	}
 	if _, ok := out.Application.ExternalSymbols[v2.ExternalID(out.Application.ID, "fmt", "Println")]; !ok {
 		t.Error("fmt.Println should still be external in incremental mode")
 	}
@@ -485,21 +485,21 @@ func TestGateL2_IncrementalModeKeepsProjectCalleesInternal(t *testing.T) {
 func TestGateL2_VendoredCalleeIsExternal(t *testing.T) {
 	_, thisFile, _, _ := runtime.Caller(0)
 	dir := filepath.Join(filepath.Dir(thisFile), "..", "..", "..", "testdata", "dataflow")
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("build: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
-	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, "dataflow", dir, 2, "gate-test", 0, nil, nil)
+	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, testIdentity("dataflow"), dir, 2, "gate-test", 0, nil, nil)
 
 	ext := v2.ExternalID(out.Application.ID, "example.com/vlib", "F")
 	sym, ok := out.Application.ExternalSymbols[ext]
 	if !ok {
 		t.Fatalf("external_symbols missing %s; have %v", ext, out.Application.ExternalSymbols)
 	}
 	if sym.Module != "example.com/vlib" || sym.Signature != "F" {
 		t.Errorf("unexpected symbol %+v", sym)
 	}
 	if !anyCallNodeHasCallee(out, ext) {
@@ -557,21 +557,21 @@ func TestGateL2_LineDirectiveCallsResolve(t *testing.T) {
 func TestGateL2_ExternalUnnamedParamsArePositional(t *testing.T) {
 	_, thisFile, _, _ := runtime.Caller(0)
 	dir := filepath.Join(filepath.Dir(thisFile), "..", "..", "..", "testdata", "dataflow")
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("build: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
-	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, "dataflow", dir, 2, "gate-test", 0, nil, nil)
+	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, testIdentity("dataflow"), dir, 2, "gate-test", 0, nil, nil)
 
 	for sig, want := range map[string][]string{"G": {"_0", "_1"}, "H": {"_0", "n"}} {
 		ext := v2.ExternalID(out.Application.ID, "example.com/vlib", sig)
 		sym, ok := out.Application.ExternalSymbols[ext]
 		if !ok {
 			t.Errorf("external_symbols missing %s", ext)
 			continue
 		}
 		var got []string
 		for _, p := range sym.Parameters {
@@ -586,21 +586,21 @@ func TestGateL2_ExternalUnnamedParamsArePositional(t *testing.T) {
 // emitDirL2 builds dir through the real builder + resolver and emits v2 at L2.
 func emitDirL2(t *testing.T, dir, app string) *v2.Analysis {
 	t.Helper()
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
-	return Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, app, dir, 2, "gate-test", 0, nil, nil)
+	return Emit(&schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}, testIdentity(app), dir, 2, "gate-test", 0, nil, nil)
 }
 
 // assertNoDanglingEdges fails when an edge endpoint is neither a callable id
 // nor an external_symbols key.
 func assertNoDanglingEdges(t *testing.T, out *v2.Analysis) {
 	t.Helper()
 	ids := allCallableIDs(out)
 	for id := range out.Application.ExternalSymbols {
 		ids[id] = true
 	}
diff --git a/internal/syntactic_analysis/v2emit/gate_l3_test.go b/internal/syntactic_analysis/v2emit/gate_l3_test.go
index eaf31f6..a9f17fc 100644
--- a/internal/syntactic_analysis/v2emit/gate_l3_test.go
+++ b/internal/syntactic_analysis/v2emit/gate_l3_test.go
@@ -62,22 +62,22 @@ func buildL3(t *testing.T, name string) *l3Fixture {
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
 	res := dataflow.Run(b.Fset(), b.L3Units(st), 3, 4)
 	fx := &l3Fixture{
 		st:  st,
-		l2:  Emit(app, name, dir, 2, "gate-test", 3, nil, nil),
-		l3:  Emit(app, name, dir, 3, "gate-test", 3, res, nil),
+		l2:  Emit(app, testIdentity(name), dir, 2, "gate-test", 3, nil, nil),
+		l3:  Emit(app, testIdentity(name), dir, 3, "gate-test", 3, res, nil),
 		res: res,
 	}
 	l3Cache[name] = fx
 	return fx
 }
 
 // emitted is one callable of the v2 tree with its v1 source and the file its
 // spans index.
 type emitted struct {
 	v1       schema.GoCallable
diff --git a/internal/syntactic_analysis/v2emit/gate_l4_done_test.go b/internal/syntactic_analysis/v2emit/gate_l4_done_test.go
index d3b4319..6803719 100644
--- a/internal/syntactic_analysis/v2emit/gate_l4_done_test.go
+++ b/internal/syntactic_analysis/v2emit/gate_l4_done_test.go
@@ -113,22 +113,22 @@ func (g *sdgGraph) pathExcept(src, dst string, skip func(from string, h sdgHop)
 // closure's r formal_in reaches the stand-in DB.Query's formal_in of
 // "query", and the path enters sqlRepo.Find through a param_in. Health
 // never queries: from its r, the sink is unreachable.
 func TestGateL4_HTTPToSQLPath(t *testing.T) {
 	fx := buildL4(t, "dataflow/httpsql")
 	a := fx.l4
 	if len(a.Degraded) != 0 {
 		t.Fatalf("httpsql degraded: %+v", a.Degraded)
 	}
 	app := a.Application.ID
-	if app != "can://httpsql" {
-		t.Fatalf("application id %s, want can://httpsql", app)
+	if app != "can://httpsql/httpsql" {
+		t.Fatalf("application id %s, want can://httpsql/httpsql", app)
 	}
 	idx := bodyIndex(a)
 	vertex := func(owner, kind, of string) string {
 		t.Helper()
 		var found []string
 		for id, on := range idx {
 			if on.owner == owner && on.node.Kind == kind && on.node.Of == of {
 				found = append(found, id)
 			}
 		}
@@ -137,21 +137,21 @@ func TestGateL4_HTTPToSQLPath(t *testing.T) {
 		}
 		return found[0]
 	}
 	mod := v2.ModuleID(app, "httpsql.go")
 	pkg := "example.com/dataflow/httpsql."
 	fn := func(name string) string { return v2.CallableID(mod, pkg+name) }
 	closure := func(name string) string { return v2.CallableID(fn(name), pkg+name+".closure_1") }
 	method := func(typ, m string) string { return v2.CallableID(v2.TypeID(mod, pkg+typ), pkg+typ+"."+m) }
 
 	sink := vertex(v2.ExternalID(app, "database/sql", "DB.Query"), "formal_in", "query")
-	if sink != "can://httpsql/@external/database/sql/DB.Query@formal_in:1" {
+	if sink != "can://httpsql/httpsql/@external/database/sql/DB.Query@formal_in:1" {
 		t.Fatalf("sink vertex %s", sink)
 	}
 	find := method("sqlRepo", "Find")
 	g := newSDGGraph(a)
 
 	src := vertex(closure("Handler"), "formal_in", "r")
 	p := g.path(src, sink)
 	if p == nil {
 		t.Fatalf("no path from Handler's r (%s) to %s", src, sink)
 	}
@@ -225,21 +225,21 @@ func buildHTTPSQLWithModels(t *testing.T, models sdg.Models) *v2.Analysis {
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
 	units := b.L3Units(st)
 	res := dataflow.RunWithSideTables(b.Fset(), units, 3, 4)
 	l4 := sdg.Run(sdg.Input{
 		Fset: b.Fset(), Pkgs: b.Pkgs(), ProjectDir: dir, SymbolTable: st,
 		Externals: app.Externals, CallGraph: app.CallGraph,
 		Units: units, L3: res, K: 3, Jobs: 4, Models: models,
 	})
 	l4.ApplyTo(app)
-	return Emit(app, "httpsql", dir, 4, "gate-test", 3, res, &l4)
+	return Emit(app, testIdentity("httpsql"), dir, 4, "gate-test", 3, res, &l4)
 }
 
 // TestGateL4_HTTPToSQLSanitizerIsSDKSemantics pins what L4 does — and
 // does not do — about SanitizedFind's strconv.Atoi [user, 2026-10-27]. L4 is
 // reaching-definitions data flow, not taint: `n, err := strconv.Atoi(id)`
 // does make n (and err) depend on id, and that edge is correct. Treating a
 // call as a sanitizer is the SDK taint analysis's job (callable or
 // variable cuts, including the bypasses below), tracked in
 // codellm-devkit/.github#103.
 //
diff --git a/internal/syntactic_analysis/v2emit/gate_l4_test.go b/internal/syntactic_analysis/v2emit/gate_l4_test.go
index 42b4891..582b2bc 100644
--- a/internal/syntactic_analysis/v2emit/gate_l4_test.go
+++ b/internal/syntactic_analysis/v2emit/gate_l4_test.go
@@ -36,53 +36,62 @@ type l4Fixture struct {
 }
 
 var (
 	l4Mu    sync.Mutex
 	l4Cache = map[string]*l4Fixture{}
 )
 
 // buildL4 runs the -a 4 pipeline over testdata/<name> once and emits both the
 // L3 and the L4 payload from the same resolved symbol table. The app name is
 // name's last element (cango's default: the input directory's base name).
-func buildL4(t *testing.T, name string) *l4Fixture {
+func buildL4(t *testing.T, name string) *l4Fixture { return buildL4Identity(t, name, nil) }
+func buildL4Identity(t *testing.T, name string, identity *v2.Identity) *l4Fixture {
 	t.Helper()
 	l4Mu.Lock()
 	defer l4Mu.Unlock()
-	if fx, ok := l4Cache[name]; ok {
+	key := name
+	if identity != nil {
+		key += "|" + identity.ApplicationID
+	}
+	if fx, ok := l4Cache[key]; ok {
 		return fx
 	}
 	_, thisFile, _, _ := runtime.Caller(0)
 	dir, err := filepath.Abs(filepath.Join(filepath.Dir(thisFile), "..", "..", "..", "testdata", name))
 	if err != nil {
 		t.Fatal(err)
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges, Externals: cg.Externals()}
 	units := b.L3Units(st)
 	res := dataflow.RunWithSideTables(b.Fset(), units, 3, 4)
 	appName := filepath.Base(dir)
-	fx := &l4Fixture{st: st, l3: Emit(app, appName, dir, 3, "gate-test", 3, res, nil), res: res, dir: dir}
+	resolved := testIdentity(appName)
+	if identity != nil {
+		resolved = *identity
+	}
+	fx := &l4Fixture{st: st, l3: Emit(app, resolved, dir, 3, "gate-test", 3, res, nil), res: res, dir: dir}
 	l4 := sdg.Run(sdg.Input{
 		Fset: b.Fset(), Pkgs: b.Pkgs(), ProjectDir: dir, SymbolTable: st,
 		Externals: app.Externals, CallGraph: app.CallGraph,
 		Units: units, L3: res, K: 3, Jobs: 4,
 	})
 	l4.ApplyTo(app)
 	fx.sdg = &l4
-	fx.l4 = Emit(app, appName, dir, 4, "gate-test", 3, res, &l4)
-	l4Cache[name] = fx
+	fx.l4 = Emit(app, resolved, dir, 4, "gate-test", 3, res, &l4)
+	l4Cache[key] = fx
 	return fx
 }
 
 // supersetL4 records where a (-a 3) is not contained in b (-a 4): every object
 // key and value, and every list entry, by position — except the sorted edge
 // lists L4 adds entries into (call_graph gets VTA edges, a callable's ddg
 // gets port edges), where every -a 3 edge must occur unchanged somewhere in
 // the -a 4 list.
 func supersetL4(path string, a, b any, errs *[]string) {
 	if path == "$.application.call_graph" || strings.HasSuffix(path, ".ddg") {
@@ -782,24 +791,24 @@ func buildL4Jobs(t *testing.T, dir, name string, jobs int) []byte {
 	units := b.L3Units(st)
 	res := dataflow.RunWithSideTables(b.Fset(), units, 3, jobs)
 	l4 := sdg.Run(sdg.Input{
 		Fset: b.Fset(), Pkgs: b.Pkgs(), ProjectDir: dir, SymbolTable: st,
 		Externals: app.Externals, CallGraph: app.CallGraph,
 		Units: units, L3: res, K: 3, Jobs: jobs,
 	})
 	l4.ApplyTo(app)
 	dataflow.ReleaseAll(res)
 	var buf bytes.Buffer
-	if err := EmitTo(&buf, app, name, dir, 4, "det", 3, res, &l4); err != nil {
+	if err := EmitTo(&buf, app, testIdentity(name), dir, 4, "det", 3, res, &l4); err != nil {
 		t.Fatal(err)
 	}
-	want, err := json.Marshal(Emit(app, name, dir, 4, "det", 3, res, &l4))
+	want, err := json.Marshal(Emit(app, testIdentity(name), dir, 4, "det", 3, res, &l4))
 	if err != nil {
 		t.Fatal(err)
 	}
 	if !bytes.Equal(buf.Bytes(), want) {
 		t.Fatalf("%s: EmitTo differs from json.Marshal(Emit) at byte %d (len %d vs %d)", name, firstDiff(buf.Bytes(), want), buf.Len(), len(want))
 	}
 	return buf.Bytes()
 }
 
 // TestGateL4_DeterministicAcrossJobs: the -a 4 JSON is byte-identical
@@ -839,21 +848,21 @@ func TestEmitL4_UnresolvedRefIsDroppedAndWarned(t *testing.T) {
 	res.ParamIn = append(slices.Clone(res.ParamIn), sdg.ParamEdge{
 		Src: sdg.Ref{Owner: ghost, Key: "1:1/actual_in:0"},
 		Dst: sdg.Ref{Owner: ghost, Key: "@formal_in:0"},
 		Var: "x",
 	})
 	var warned []string
 	prev := warnf
 	warnf = func(format string, args ...any) { warned = append(warned, fmt.Sprintf(format, args...)) }
 	defer func() { warnf = prev }()
 	app := &schema.GoApplication{SymbolTable: fx.st, Externals: map[string]schema.GoExternalCallee{}}
-	out := Emit(app, "dataflow", fx.dir, 4, "t", 3, fx.res, &res)
+	out := Emit(app, testIdentity("dataflow"), fx.dir, 4, "t", 3, fx.res, &res)
 	for _, e := range out.Application.ParamIn {
 		if strings.Contains(e.Src, "nowhere") || strings.Contains(e.Dst, "nowhere") {
 			t.Errorf("dangling param_in emitted: %+v", e)
 		}
 	}
 	if len(warned) == 0 || !strings.Contains(strings.Join(warned, "\n"), "nowhere.go") {
 		t.Errorf("no warning names the unresolved ref; warned %q", warned)
 	}
 }
 
@@ -913,10 +922,56 @@ func TestSupersetL4_DetectsEveryViolation(t *testing.T) {
 		supersetL4("$", parse(base), parse(c.b), &errs)
 		got := strings.Join(errs, "; ")
 		switch {
 		case c.want == "" && len(errs) > 0:
 			t.Errorf("%s: want no error, got %s", name, got)
 		case c.want != "" && !strings.Contains(got, c.want):
 			t.Errorf("%s: want an error containing %q, got %q", name, c.want, got)
 		}
 	}
 }
+
+func TestNamespaceNestedReferences(t *testing.T) {
+	ns := "team space"
+	identity, err := v2.ResolveIdentity("billing", &ns)
+	if err != nil {
+		t.Fatal(err)
+	}
+	a := buildL4Identity(t, "dataflow/httpsql", &identity).l4
+	b, err := json.Marshal(a)
+	if err != nil {
+		t.Fatal(err)
+	}
+	var raw any
+	if err = json.Unmarshal(b, &raw); err != nil {
+		t.Fatal(err)
+	}
+	count := 0
+	var walk func(any)
+	check := func(s string) {
+		if strings.HasPrefix(s, "can://") {
+			count++
+			if s != identity.ApplicationID && !strings.HasPrefix(s, identity.ApplicationID+"/") {
+				t.Errorf("foreign root: %s", s)
+			}
+		}
+	}
+	walk = func(v any) {
+		switch x := v.(type) {
+		case string:
+			check(x)
+		case map[string]any:
+			for k, v := range x {
+				check(k)
+				walk(v)
+			}
+		case []any:
+			for _, v := range x {
+				walk(v)
+			}
+		}
+	}
+	walk(raw)
+	if count < 20 || len(a.Application.ExternalSymbols) == 0 || len(a.Application.ParamIn) == 0 {
+		t.Fatalf("missing nested coverage: ids=%d externals=%d params=%d", count, len(a.Application.ExternalSymbols), len(a.Application.ParamIn))
+	}
+}
diff --git a/internal/syntactic_analysis/v2emit/gate_test.go b/internal/syntactic_analysis/v2emit/gate_test.go
index 4679a60..41822be 100644
--- a/internal/syntactic_analysis/v2emit/gate_test.go
+++ b/internal/syntactic_analysis/v2emit/gate_test.go
@@ -51,21 +51,21 @@ func multipackageDir(t *testing.T) string {
 // module set is deterministic.
 func buildMultipackageV2(t *testing.T) *v2.Analysis {
 	t.Helper()
 	dir := multipackageDir(t)
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: []schema.GoCallEdge{}}
-	return Emit(app, "multipackage", dir, 1, "gate-test", 0, nil, nil)
+	return Emit(app, testIdentity("multipackage"), dir, 1, "gate-test", 0, nil, nil)
 }
 
 // mustModule fetches a module by relative path or fails.
 func mustModule(t *testing.T, out *v2.Analysis, rel string) v2.Module {
 	t.Helper()
 	mod, ok := out.Application.SymbolTable[rel]
 	if !ok {
 		t.Fatalf("module %q missing; modules=%v", rel, keys(out.Application.SymbolTable))
 	}
 	return mod
@@ -80,21 +80,21 @@ func TestGateL1_ModuleSet(t *testing.T) {
 		"main.go",
 		"server/middleware.go",
 		"server/server.go",
 		"worker/worker.go",
 	}
 	for _, rel := range want {
 		mod := mustModule(t, out, rel)
 		if mod.Kind != "module" {
 			t.Errorf("%s: kind = %q, want module", rel, mod.Kind)
 		}
-		wantID := "can://multipackage/go/" + rel
+		wantID := "can://multipackage/multipackage/go/" + rel
 		if mod.ID != wantID {
 			t.Errorf("%s: id = %q, want %q", rel, mod.ID, wantID)
 		}
 		if mod.Source == "" {
 			t.Errorf("%s: source is empty; every module carries its whole file text", rel)
 		}
 		// The module span must slice back to the whole source (source-once invariant).
 		if got := mod.Span.Slice(mod.Source); got != mod.Source {
 			t.Errorf("%s: module span does not cover whole source (%d vs %d bytes)", rel, len(got), len(mod.Source))
 		}
@@ -294,42 +294,42 @@ func TestGateL1_Envelope(t *testing.T) {
 
 	if out.SchemaVersion != v2.SchemaVersion {
 		t.Errorf("schema_version = %q, want %q", out.SchemaVersion, v2.SchemaVersion)
 	}
 	if out.Language != "go" {
 		t.Errorf("language = %q, want go", out.Language)
 	}
 	if out.MaxLevel != 1 {
 		t.Errorf("max_level = %d, want 1", out.MaxLevel)
 	}
-	if out.Application.ID != "can://multipackage" {
-		t.Errorf("application.id = %q, want can://multipackage", out.Application.ID)
+	if out.Application.ID != "can://multipackage/multipackage" {
+		t.Errorf("application.id = %q, want can://multipackage/multipackage", out.Application.ID)
 	}
 	// L1: no call_graph edges yet.
 	if len(out.Application.CallGraph) != 0 {
 		t.Errorf("L1 call_graph should be empty; got %d edges", len(out.Application.CallGraph))
 	}
 }
 
 // TestGateL1_SupersetOfV1 is the superset gate: every v1 fact must survive into
 // v2 modulo the sanctioned drops. It walks the SAME v1 model the emitter walked
 // and asserts each callable/type/function reappears in v2, and that the
 // sanctioned drops are gone from the serialized payload.
 func TestGateL1_SupersetOfV1(t *testing.T) {
 	dir := multipackageDir(t)
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: []schema.GoCallEdge{}}
-	out := Emit(app, "multipackage", dir, 1, "gate-test", 0, nil, nil)
+	out := Emit(app, testIdentity("multipackage"), dir, 1, "gate-test", 0, nil, nil)
 
 	// Every v1 file, type, method and function reappears in v2.
 	for rel, v1file := range st {
 		mod, ok := out.Application.SymbolTable[rel]
 		if !ok {
 			t.Errorf("v1 file %q dropped from v2 symbol_table", rel)
 			continue
 		}
 		for name := range v1file.Types {
 			if _, ok := mod.Types[name]; !ok {
@@ -380,21 +380,21 @@ func buildDataflowL1V2(t *testing.T) *v2.Analysis {
 	dir, err := filepath.Abs(filepath.Join(filepath.Dir(thisFile), "..", "..", "..", "testdata", "dataflow"))
 	if err != nil {
 		t.Fatalf("resolving fixture dir: %v", err)
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: []schema.GoCallEdge{}}
-	return Emit(app, "dataflow", dir, 1, "gate-test", 0, nil, nil)
+	return Emit(app, testIdentity("dataflow"), dir, 1, "gate-test", 0, nil, nil)
 }
 
 func TestGateL1_TypeKindsAliasAndDefined(t *testing.T) {
 	mod := mustModule(t, buildDataflowL1V2(t), "l1/l1.go")
 	want := map[string]string{"Celsius": "defined", "Alias": "alias", "S": "struct",
 		"Base": "struct", "MyErr": "struct", "I1": "interface", "I2": "interface"}
 	for name, kind := range want {
 		ty, ok := mod.Types[name]
 		if !ok {
 			t.Errorf("type %s missing from l1/l1.go; have %v", name, keys(mod.Types))
@@ -471,21 +471,21 @@ func buildDataflowL2V2(t *testing.T) *v2.Analysis {
 		t.Fatalf("resolving fixture dir: %v", err)
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
 	cg := semantic_analysis.NewCallGraphBuilder(dir, b.Fset(), b.Pkgs())
 	edges := cg.Build(st)
 	app := &schema.GoApplication{SymbolTable: st, CallGraph: edges}
-	return Emit(app, "dataflow", dir, 2, "gate-test", 0, nil, nil)
+	return Emit(app, testIdentity("dataflow"), dir, 2, "gate-test", 0, nil, nil)
 }
 
 // TestGateL2_CoPositionedCallsResolveSeparately: in s.A().B() the outer call
 // (bare key) resolves to B and the inner s.A() (key /2) resolves to A; the call
 // graph has exactly the edges Chain->A and Chain->B.
 func TestGateL2_CoPositionedCallsResolveSeparately(t *testing.T) {
 	out := buildDataflowL2V2(t)
 	mod := mustModule(t, out, "l1/l1.go")
 	chain := functionByName(t, mod, "Chain")
 	s := mod.Types["S"]
@@ -592,21 +592,21 @@ func TestGateL2_GoStatementArgumentCalls(t *testing.T) {
 		if !ok {
 			t.Errorf("GoArgs: no call node %s; have %v", w.key, keys(fn.Body))
 			continue
 		}
 		if n.IsGoroutine != w.goroutine {
 			t.Errorf("GoArgs %s is_goroutine = %v, want %v", w.key, n.IsGoroutine, w.goroutine)
 		}
 		if w.callee == "" {
 			continue
 		}
-		want := "can://dataflow/go/flow/flow.go/" + pkg + w.callee
+		want := "can://dataflow/dataflow/go/flow/flow.go/" + pkg + w.callee
 		if n.Callee == nil || *n.Callee != want {
 			t.Errorf("GoArgs %s callee = %v, want %s", w.key, n.Callee, want)
 		}
 		if !anyEdgeFromTo(out.Application.CallGraph, fn.ID, want) {
 			t.Errorf("no call_graph edge %s -> %s", fn.ID, want)
 		}
 	}
 	if len(fn.Body) != 4 {
 		t.Errorf("GoArgs body has %d nodes, want 4: %v", len(fn.Body), keys(fn.Body))
 	}
@@ -631,21 +631,21 @@ func TestGate_LineDirectiveSpansSliceToText(t *testing.T) {
 	_, thisFile, _, _ := runtime.Caller(0)
 	dir, err := filepath.Abs(filepath.Join(filepath.Dir(thisFile), "..", "..", "..", "testdata", "dataflow"))
 	if err != nil {
 		t.Fatal(err)
 	}
 	b := syntactic_analysis.NewSymbolTableBuilder(dir)
 	st, err := b.Build(nil, true)
 	if err != nil {
 		t.Fatalf("symbol table build failed: %v", err)
 	}
-	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: []schema.GoCallEdge{}}, "dataflow", dir, 1, "gate-test", 0, nil, nil)
+	out := Emit(&schema.GoApplication{SymbolTable: st, CallGraph: []schema.GoCallEdge{}}, testIdentity("dataflow"), dir, 1, "gate-test", 0, nil, nil)
 	const rel = "linedir/linedir.go"
 	mod := mustModule(t, out, rel)
 	calls := 0
 	for sig, fn := range st[rel].Functions {
 		c := mod.Functions[sig]
 		text := c.Span.Slice(mod.Source)
 		if c.Span.Bytes[0] >= c.Span.Bytes[1] || !strings.HasPrefix(text, "func "+fn.Name+"(") {
 			t.Errorf("callable %s: span %v slices to %q, want func %s(…", sig, c.Span, text, fn.Name)
 		}
 		keys := v2.CallBodyKeys(siteStarts(fn.CallSites))
# codeanalyzer-go: e65d73f1ff358dc9f43e21b12b774b4d68e5578c..8fabbf69a11c2c3a338ee60577ca300c52280165
