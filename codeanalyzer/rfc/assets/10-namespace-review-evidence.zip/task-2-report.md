# Task 2 report: Python namespace-qualified identity

Status: implemented, verified within the documented integration gates, committed locally; not pushed.

- Repository: `codeanalyzer-python`, existing branch `feat/add-workspace-root`.
- Base: `94b331e9cb56902420409a3e569e2b1e91608e2d`.
- Commit: `d644a1c84bd6b0ed88548a977a4a169e7d547cf5` — `feat: qualify Python analysis identities by namespace`.
- Working tree after commit: clean.
- Binding requirements: `task-2-brief.md`, `global-constraints.md`, `contract-decisions.md`; shared golden fixture `test/fixtures/identity/namespaces.json`.

## Result and interface audit

`AnalysisOptions.namespace: str | None` and `--namespace` replace the workspace-root setting/flag. Workspace-key prefixing and emission-time map rekeying are removed. Application names default to the resolved input-root basename; an omitted namespace repeats that resolved name. Explicit empty values fail. UTF-8 root text is validated without trimming or Unicode normalization and percent-encoded outside ASCII unreserved characters; invalid fixture cases are rejected.

`application_id(app_name, namespace=None)`, `module_id(app_name, file_key, namespace=None)`, and `artifact_id(app_name, rel_path, namespace=None)` preserve their existing suffix grammars. `assign_ids(app, app_name, namespace=None)` records raw application name/namespace and stamps version 2. Artifacts, external symbols, modules, callables, body nodes, formal/actual parameters, call-graph endpoints and derived edges inherit canonical ownership. `pkg:` identity is unchanged. Source keys and resolved-module references remain application-relative.

The analysis envelope requires integer `identity_version: 2`; raw validation rejects missing/incompatible envelope or application markers (including coercible float/string/bool markers). Existing `schema_version: "2.0.0"` remains. Application model and graph anchor carry `application_name`, `identity_namespace`, and `identity_version`. The schema catalog and checked-in schema snapshot describe these fields.

Cache loading validates the raw marker plus selected application/namespace before reuse. Ownership changes regenerate from source. Neo4j emission rejects an analysis belonging to another requested scope before opening/replacing output, instead of re-keying a tree with stale references. Repeated same-scope Cypher emission is byte-identical.

All raw-app-name graph helper callers propagate namespace, including streaming/nonstreaming Cypher, streaming Bolt, nonstreaming Bolt anchor selection, destructive scope prefixes, and artifact reconciliation. `schema/call_graph_ids.py` was audited and intentionally left unchanged: it accepts no raw application name and remaps endpoints from the already-qualified `sig_to_id` map. No cosmetic propagation change is needed there. The existing canonical-ID node and relationship discriminator behavior remains intact.

## Scoped corrections and retained reconciliation

The expanded L2/L4 source fixture exposed an inherited import-resolver mismatch: real core symbol-table keys are relative, whereas the resolver always applied `relpath(key, absolute_project_root)`. The new test failed because `from helper import identity` did not resolve to `helper.py`. The minimal correction handles both absolute builder keys and existing application-relative keys; absolute-path resolver tests still pass. No broader inference or suffix changes were made. Controller explicitly approved this correction as necessary for the local-reference invariant.

Selected-root artifact reconciliation is retained, including shared-artifact and relationship ownership behavior. Automatic pre-1.5 legacy-root deletion was removed because an ordinary namespaced request must not delete outside its selected namespace/application. The legacy test now asserts those nodes survive. Existing shared Java/TypeScript artifact-retention integration coverage remains present, with ownership expectations updated to the new roots. Controller explicitly approved this scope adaptation.

## TDD evidence

1. Before product edits, replaced `test_workspace_root.py` with `test_namespace.py` using the golden roots/invalid inputs plus analysis/cache/CLI expectations. Ran `.venv/bin/python -m pytest test/test_v2_ids.py test/test_namespace.py -q`: **18 failed, 7 passed, 2 inherited warnings**, 1.58s. Expected failures were missing namespace helper/options interfaces and unknown CLI flag, not imports/dependencies. Tiny-suite coverage was 6.50%, so the repository-wide 40% gate also failed; the red behavior was independently visible in the test failures. Log: `/private/tmp/python-namespace-red.log`.
2. Added emission scope-change rejection and observed **1 failed, 20 passed**, with `DID NOT RAISE ValueError`. Implemented rejection before writing output; subsequent tests passed. Log: `/private/tmp/python-ns-emission-red.log`.
3. Added raw marker integer/legacy-anchor validation and observed **1 failed, 21 passed**, because coercible/noninteger markers were accepted. Implemented raw marker validation; subsequent tests passed. Log: `/private/tmp/python-ns-version-red.log`.
4. Expanded analysis checks through L4, local import joins, parameter IDs and namespace cache changes. Observed **2 failed, 39 passed, 25 skipped**, with missing relative `resolved_module` assertions. Corrected both absolute/relative resolver paths. Focused follow-up: **49 passed, 25 skipped, 42 warnings**, 58.39% coverage, 6.25s. Logs: `/private/tmp/python-ns-final-focused.log`, `/private/tmp/python-ns-final-focused2.log`.

## Final verification

Toolchains/dependencies were already provisioned by the controller; no dependency or lockfile edits were made. Relevant environment for subprocess-based tests:

```sh
source /private/tmp/namespace-toolchains/env.sh
export PATH="$PWD/.venv/bin:$PATH"
export SYSTEM_PYTHON=/private/tmp/namespace-toolchains/python/cpython-3.12.16-macos-aarch64-none/bin/python3
export UV_NO_SYNC=true UV_FROZEN=true
```

- Final broad run, outside sandbox process restrictions:
  `.venv/bin/python -m pytest test -q -k 'not test_cli_call_symbol_table_with_json and not test_flask_level1 and not test_flask_level2 and not test_requests_level1 and not test_requests_level2'`
  **548 passed, 27 skipped, 5 deselected, 167 inherited warnings**, **78.33% coverage**, 150.06s. Exit 0. Log: `/private/tmp/python-ns-all-final.log`.
- Expanded identity/schema/projection verification:
  `.venv/bin/python -m pytest test/test_namespace.py test/test_import_resolver.py test/test_v2_ids.py test/test_v2_schema.py test/test_neo4j_scope.py test/test_neo4j_bolt.py test/test_v2_conformance.py test/test_v2_two_projection_agreement.py test/test_neo4j_schema.py -q`
  **77 passed, 25 skipped, 120 inherited warnings**, **58.72% coverage**, 11.62s. Log: `/private/tmp/python-ns-verification.log`.
- Small CLI fixture suite with the isolated base interpreter: **11 passed, 5 deselected, 2 warnings**, 16.99s. Log: `/private/tmp/python-ns-cli-small-final.log`.
- After regenerating documentation: `.venv/bin/python -m pytest test/test_neo4j_schema.py test/test_namespace.py -q --no-cov`: **30 passed, 42 warnings**, 1.86s. Log: `/private/tmp/python-ns-docs-final.log`.
- `git diff --check`: passed before commit. Commit completed; no push.

The baseline supplied by the controller was 18 passed with 40 pytest_cov/Scalpel AST warnings and 46.86% coverage. Broader runs exercise more existing deprecated AST APIs, yielding 167 warnings. These inherited dependency warnings were recorded, not refactored.

## Full-run attempts and failure diagnosis (no omitted red results)

The required unfiltered `.venv/bin/python -m pytest test -q` was attempted and deliberately bounded at 92.52s: **2 failed, 163 passed, 1 skipped, 23 warnings**, 69.55% coverage, interrupted. The failures were:

- `test_cli.py::test_cli_call_symbol_table_with_json`: Ray/native `sysctl` raised `PermissionError(1, 'Operation not permitted (originated from sysctl() malloc 1/3)')`. Isolated rerun reproduced it. This is a process/sandbox prerequisite, not an identity assertion.
- `test_cli.py::test_flask_level2`: `SystemExit(130)` caused by the intentional full-suite SIGINT bound. It is interrupted/unverified, not a call-count regression.

Log: `/private/tmp/python-ns-full.log`; isolated Ray log: `/private/tmp/python-ns-cli-failure.log`.

A sandboxed non-CLI run completed **525 passed, 10 failed, 27 skipped, 167 warnings**, 106.07s. Every failure was diagnosed:

- `test_decorators_structured.py::{test_class_decorator_is_captured_with_arguments,test_local_and_library_callees_both_resolve}`: library inference returned missing qualified names.
- `test_symbol_table_builder.py::test_call_return_types_reflect_the_call_result`: library inference returned missing builtin return type.
- Four `test_entrypoint_frameworks_integration.py` tests (Flask, FastAPI, Celery, Click) and both `test_entrypoints_e2e.py` tests initially failed because `uv` could not write its default cache under the sandbox. Sourcing the toolchain environment removed the uv-cache failures. The four framework tests then exposed the same sandbox-limited library inference.
- `test_neo4j_schema.py::test_checked_in_schema_matches_catalog`: legitimate expected snapshot update after adding identity fields; refreshed from `build_schema_document()` and subsequent schema tests passed.

Library inference diagnosis used a temporary `git archive` BASE checkout at `/private/tmp/namespace-python-baseline`, the same interpreter/dependencies, and explicit PYTHONPATH. Early baseline comparisons reproduced the three inference failures; one additional relative-project-dir failure resulted from running that baseline test from a different working directory (not a product change). With correct toolchain/process access, the production three inference suites plus framework tests passed **20 passed, 2 warnings**, 9.71s. Log: `/private/tmp/python-ns-unsandbox.log`. These tests also pass in the final broad run. No inference implementation was changed.

A subsequent broad run before supplying `SYSTEM_PYTHON` and before the already-loaded resolver module was refreshed completed **539 passed, 11 failed, 27 skipped, 3 deselected**, 142.76s. Nine CLI failures (`test_single_file`, decorators L1/L2, class hierarchy L1/L2, async L1/L2, Flask L1, requests L1) reported `Could not find a suitable base Python interpreter`; the other two were the new relative-import invariants. Supplying the installed isolated `SYSTEM_PYTHON` resolved the small CLI prerequisites, and the source-relative resolver correction resolved both namespace tests. Final broad verification is green as reported above. Log: `/private/tmp/python-ns-broad-unsandbox.log`.

Another sandbox-limited intermediate wider run completed **528 passed, 2 failed, 27 skipped**, 116.03s; only the same two decorator inference cases failed. Final outside-sandbox verification supersedes it. Log: `/private/tmp/python-ns-wide-final.log`.

## Remaining gates / concerns

- Five heavyweight CLI cases were excluded from final broad verification: Ray/xarray symbol-table CLI, Flask L1/L2, requests L1/L2. The unfiltered attempt is documented above; complete those in a suitably provisioned unrestricted integration environment if required.
- Of the 27 skips, 25 are the explicit `RUN_CONTAINER_TESTS=1` Neo4j Testcontainers gate (Docker/Podman unavailable), including retained shared-artifact reconciliation cases. The other two are pre-existing disabled legacy dataflow-emission coverage and an optional separately-installed Scalpel parity comparison. No container/live graph success is claimed.
- This is a URI-ownership compatibility change. Legacy envelopes/anchors are unsupported and must be regenerated; ordinary emission leaves legacy graph roots untouched. No aliases, migrations, cross-namespace fallback or ID rewriting was introduced.

## Regenerated handoff artifacts

The four JSON levels and graph snapshot were regenerated from the Python source block under `### How the samples were generated` in `docs/handoff/README.md`, using `app_name="sample-app"`, `namespace="sample-app"`, `no_venv=True` and levels 1–4. Analyzer artifact version: **1.6.2**; schema version **2.0.0**; identity version **2**. The source mtime is fixed to zero; only display `file_path`/`path` metadata is sanitized to `/path/to/sample-app`. Canonical IDs and references come from source analysis and are never translated. The README records the updated invocation/contract.

Exact generation command: `PATH="$PWD/.venv/bin:$PATH" .venv/bin/python /private/tmp/regenerate-namespace-python-handoff.py` (script retained locally). Each JSON was parsed by `Analysis.model_validate` and checked by the test conformance validator for its level; temporary machine paths are absent. All five artifacts were regenerated a second time and proved byte-identical. Schema snapshot is directly generated from `build_schema_document()`. Logs: `/private/tmp/python-ns-handoff.log`, `/private/tmp/python-ns-handoff-repeat.log`.

## Committed files

```text
README.md
codeanalyzer/__main__.py
codeanalyzer/artifacts/discovery.py
codeanalyzer/core.py
codeanalyzer/neo4j/bolt.py
codeanalyzer/neo4j/cypher.py
codeanalyzer/neo4j/emit.py
codeanalyzer/neo4j/project.py
codeanalyzer/neo4j/rows.py
codeanalyzer/neo4j/schema.py
codeanalyzer/options/options.py
codeanalyzer/schema/assign_ids.py
codeanalyzer/schema/ids.py
codeanalyzer/schema/py_schema.py
codeanalyzer/syntactic_analysis/import_resolver.py
docs/handoff/README.md
docs/handoff/analysis.l1.json
docs/handoff/analysis.l2.json
docs/handoff/analysis.l3.json
docs/handoff/analysis.l4.json
docs/handoff/graph.cypher
docs/handoff/schema.neo4j.json
test/conftest_v2.py
test/sample_graph_app.py
test/test_artifact_discovery.py
test/test_artifact_models.py
test/test_config_key_models.py
test/test_config_use_dataflow.py
test/test_config_use_literal.py
test/test_dependency_view.py
test/test_entrypoint_bases.py
test/test_namespace.py
test/test_neo4j_artifacts.py
test/test_neo4j_bolt.py
test/test_neo4j_schema.py
test/test_neo4j_scope.py
test/test_neo4j_streamed_nodes.py
test/test_provenance.py
test/test_v2_conformance.py
test/test_v2_ids.py
test/test_v2_l2.py
test/test_v2_l3.py
test/test_v2_l4.py
test/test_v2_schema.py
test/test_v2_two_projection_agreement.py
test/test_workspace_root.py
```
