1f39489 test: bind TypeScript live gates to canonical application roots
 .../typescript/test_typescript_e2e_neo4j_live.py   |  7 ++-
 .../test_typescript_live_identity_contract.py      | 73 ++++++++++++++++++++++
 .../typescript/test_typescript_neo4j_backend.py    |  7 ++-
 3 files changed, 81 insertions(+), 6 deletions(-)
diff --git a/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py b/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py
index 0993543..c4644ea 100644
--- a/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py
+++ b/tests/analysis/typescript/test_typescript_e2e_neo4j_live.py
@@ -39,35 +39,36 @@ from __future__ import annotations
 
 import json
 import logging
 import os
 from typing import Any, Dict, List
 
 import pytest
 
 from cldk import CLDK
 from cldk.analysis.commons.backend_config import Neo4jConnectionConfig
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis.typescript.backend import CALL_GRAPH_NODE_KINDS
 from cldk.analysis.typescript.neo4j.neo4j_backend import TSNeo4jBackend
 from cldk.models.typescript import TSCallable, TSClass, TSEnum, TSInterface, TSTypeAlias
 from cldk.utils.exceptions import GraphSchemaMismatch
 from cldk.utils.exceptions.exceptions import CodeanalyzerExecutionException
 
 logging.getLogger("neo4j").setLevel(logging.ERROR)
 
 NEO4J_URI = os.environ.get("CLDK_TEST_NEO4J_URI")
 NEO4J_USER = os.environ.get("CLDK_TEST_NEO4J_USER", "neo4j")
 NEO4J_PASSWORD = os.environ.get("CLDK_TEST_NEO4J_PASSWORD", "neo4j")
 APP_NAME = os.environ.get("CLDK_TEST_NEO4J_APP", "superset-frontend")
-APP_ID = f"can://{APP_NAME}"
-#: The application scope, spelled here independently of the backend's helper on purpose.
-SCOPE = {"p": f"can://{APP_NAME}/{APP_NAME}/"}
+APP_ID = resolve_identity(APP_NAME, None).application_id
+#: The canonical anchor and descendant scope use the same raw-name encoding contract.
+SCOPE = {"p": f"{APP_ID}/"}
 SCOPED = "(x.id STARTS WITH $p)"
 REQUIRED_RELATIONSHIP_TYPES = {"TS_HAS_MODULE", "TS_HAS_METHOD", "TS_HAS_BODY_NODE", "TS_CALLS"}
 
 
 def _live_application_present() -> bool:
     if not NEO4J_URI:
         return False
     try:
         from neo4j import GraphDatabase
     except ModuleNotFoundError:
diff --git a/tests/analysis/typescript/test_typescript_live_identity_contract.py b/tests/analysis/typescript/test_typescript_live_identity_contract.py
new file mode 100644
index 0000000..01ef0b7
--- /dev/null
+++ b/tests/analysis/typescript/test_typescript_live_identity_contract.py
@@ -0,0 +1,73 @@
+"""Exercise live-suite scope gates offline, even when their modules are skipped."""
+
+import importlib.util
+from pathlib import Path
+from types import SimpleNamespace
+
+import pytest
+
+from cldk.analysis.commons.identity import resolve_identity
+
+
+def _load_live_suite(filename, monkeypatch, *, app_name=None):
+    for name in ["CLDK_TEST_NEO4J_URI", "CLDK_TEST_NEO4J_WRITE_URI"]:
+        monkeypatch.delenv(name, raising=False)
+    if app_name is not None:
+        monkeypatch.setenv("CLDK_TEST_NEO4J_APP", app_name)
+    spec = importlib.util.spec_from_file_location("_offline_" + filename.removesuffix(".py"), Path(__file__).with_name(filename))
+    module = importlib.util.module_from_spec(spec)
+    spec.loader.exec_module(module)
+    monkeypatch.setattr(module, "NEO4J_URI", "bolt://offline-test")
+    return module
+
+
+class Driver:
+    def __init__(self, application_id):
+        self.application_id = application_id
+        self.calls = []
+        self.closed = False
+
+    def verify_connectivity(self):
+        pass
+
+    def session(self):
+        return self
+
+    def __enter__(self):
+        return self
+
+    def __exit__(self, *args):
+        pass
+
+    def run(self, query, **parameters):
+        self.calls.append((query, parameters))
+        return SimpleNamespace(single=lambda: {"c": int(parameters.get("id") == self.application_id)})
+
+    def close(self):
+        self.closed = True
+
+
+@pytest.mark.parametrize("raw_name", ["superset-frontend", "-svc %雪"])
+def test_live_presence_gate_queries_the_encoded_canonical_application(raw_name, monkeypatch):
+    GraphDatabase = pytest.importorskip("neo4j").GraphDatabase
+    module = _load_live_suite("test_typescript_e2e_neo4j_live.py", monkeypatch, app_name=raw_name)
+    expected = resolve_identity(raw_name, None)
+    driver = Driver(expected.application_id)
+    monkeypatch.setattr(GraphDatabase, "driver", lambda *args, **kwargs: driver)
+    assert module._live_application_present()
+    assert driver.calls[0][1] == {"id": expected.application_id}
+    assert module.SCOPE == {"p": expected.application_id + "/"}
+    assert driver.closed
+
+
+def test_live_cleanup_deletes_the_canonical_anchor_and_its_descendants(monkeypatch):
+    GraphDatabase = pytest.importorskip("neo4j").GraphDatabase
+    module = _load_live_suite("test_typescript_neo4j_backend.py", monkeypatch)
+    expected = resolve_identity(module.APP_NAME, None)
+    driver = Driver(expected.application_id)
+    monkeypatch.setattr(GraphDatabase, "driver", lambda *args, **kwargs: driver)
+    module._teardown_application()
+    query, parameters = driver.calls[0]
+    assert "n.id STARTS WITH $p OR n.id = $app_id" in query
+    assert parameters == {"p": expected.application_id + "/", "app_id": expected.application_id}
+    assert driver.closed
diff --git a/tests/analysis/typescript/test_typescript_neo4j_backend.py b/tests/analysis/typescript/test_typescript_neo4j_backend.py
index 621949b..1756c92 100644
--- a/tests/analysis/typescript/test_typescript_neo4j_backend.py
+++ b/tests/analysis/typescript/test_typescript_neo4j_backend.py
@@ -60,34 +60,35 @@ import os
 import shlex
 import subprocess
 import tempfile
 from pathlib import Path
 
 import networkx as nx
 import pytest
 
 from cldk import CLDK
 from cldk.analysis import AnalysisLevel
+from cldk.analysis.commons.identity import resolve_identity
 from cldk.analysis.typescript.neo4j import Neo4jConnectionConfig
 
 logging.getLogger("neo4j").setLevel(logging.ERROR)
 
 NEO4J_URI = os.environ.get("CLDK_TEST_NEO4J_WRITE_URI")
 NEO4J_USER = os.environ.get("CLDK_TEST_NEO4J_WRITE_USER")
 NEO4J_PASSWORD = os.environ.get("CLDK_TEST_NEO4J_WRITE_PASSWORD")
 APP_NAME = "application"
 #: Every node the emitter writes for APP_NAME lives under this one prefix; the teardown deletes
 #: exactly that, plus the application anchor, and nothing else on the server. It was two prefixes
 #: (one per language namespace) while the language was the outermost segment; the application
 #: prefix now covers both, and also the ``@external`` ghosts and artifacts the pair never reached.
-APP_PREFIXES = (f"can://{APP_NAME}/{APP_NAME}/",)
-APP_ID = f"can://{APP_NAME}"
+APP_ID = resolve_identity(APP_NAME, None).application_id
+APP_PREFIXES = (f"{APP_ID}/",)
 
 
 def _neo4j_reachable() -> bool:
     if not (NEO4J_URI and NEO4J_USER and NEO4J_PASSWORD):
         return False
     try:
         from neo4j import GraphDatabase
     except ModuleNotFoundError:
         return False
     try:
@@ -103,21 +104,21 @@ pytestmark = pytest.mark.skipif(
     not _neo4j_reachable(),
     reason=(
         "this module WRITES the graph (it runs codeanalyzer-typescript --emit neo4j and deletes the "
         "application afterwards); set CLDK_TEST_NEO4J_WRITE_URI / _WRITE_USER / _WRITE_PASSWORD to a "
         "disposable server to run it -- there are no defaults"
     ),
 )
 
 
 def _teardown_application() -> None:
-    """Delete the application's own subgraph: every node under its two id prefixes and the
+    """Delete the application's own subgraph: every node under its application prefix and the
     ``:Application`` anchor. The unprefixed nodes the emitter also MERGEs (``Artifact``, ``Package``,
     ``ConfigKey``, ``TSDecorator``) are shared with any other application on the server and are
     left in place."""
     from neo4j import GraphDatabase
 
     driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
     try:
         with driver.session() as session:
             session.run(
                 "MATCH (n) WHERE n.id STARTS WITH $p OR n.id = $app_id DETACH DELETE n",
# python-sdk: 315eeae8e3c9028d1404d2150f00e01e36f6c42b..1f3948976c2d14fb45a7585bcc5b05f07d9b2b15
