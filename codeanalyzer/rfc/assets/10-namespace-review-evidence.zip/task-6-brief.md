### Task 6: SDK configuration, invocation, and scoped resolution

**Files:**
- Create: `python-sdk/cldk/analysis/commons/identity.py` and `python-sdk/tests/analysis/commons/test_identity.py`.
- Modify: `python-sdk/cldk/analysis/commons/{backend_config.py,keys.py}` and `cldk/core.py`.
- Modify each language's existing files: `python-sdk/cldk/analysis/{python,typescript,java,go}/__init__.py`, `backend.py`, `codeanalyzer/codeanalyzer.py`, and `neo4j/neo4j_backend.py`.
- Modify SDK model declarations: `python-sdk/cldk/models/{typescript,java,go}/models.py`; inspect Python's analyzer-model reexports in `cldk/models/python/__init__.py` and update its producer dependency rather than creating incompatible duplicate models.
- Extend: `python-sdk/tests/analysis/commons/test_lifted_helpers.py` and the existing `test_*_neo4j_multi_application_scope.py` in each language's test directory.

**Interfaces:**
- Consumes: Producer contract from Tasks 2–5 and `identity_version: 2`.
- Produces: `ApplicationIdentity`/`resolve_identity` described above; `namespace: str | None` and local `application_name: str | None` on backend configs; bound URI resolution in local and graph backends.
- Extend `resolve_module_key(path: str, keys: Iterable[str], *, application_id: str | None = None, module_ids: Mapping[str, str] | None = None, source_root: str | Path | None = None) -> str`. Keys alone support exact/normalized relative matching only. Full URIs require a matching bound application and module-ID mapping. Absolute paths require an established root. Preserve the existing unchanged-path miss behavior for unknown relative keys so callers retain their existing not-in-graph diagnostics.

- [ ] **Step 1: Write failing identity/config/invocation tests.** Assert fixture roots, graph missing-application rejection, explicit empty-name rejection, and forwarding `--namespace online-boutique --app-name currencyservice` to mocked analyzer commands. Assert the SDK validates returned metadata against the requested scope.
- [ ] **Step 2: Write failing scope/cache tests.** Use two namespaces each containing the same application and two applications with the same `server.js`. Another owner or unsupported language URI must be rejected before normalization. Test prefix neighbors `svc`/`svc-extra`, source-root-bound absolute paths, arbitrary service-prefixed paths, and repeated cache use under changed namespace/application.
- [ ] **Step 3: Verify failure.** Run `uv run --group test pytest tests/analysis/commons/test_identity.py tests/analysis/commons/test_lifted_helpers.py -q`. Failures must expose missing interfaces or ownership behavior, not missing optional analyzer installations.
- [ ] **Step 4: Implement shared identity and thread it through all factories/backends.** Anchor equality uses the complete root; descendant scopes append `/`. Keep JS and TS prefixes separate within their existing facade. Remove fixed slash-position parsing and unrestricted suffix fallback at all `resolve_module_key`/`scope_paths` callers. Resolve scanner paths using existing selected project/source roots; do not add an orchestration API.
- [ ] **Step 5: Reject incompatible persisted data and isolate caches.** Require marker 2 on the selected application/output, verify namespace/application metadata, and perform no writes during graph attachment. Namespace/application participate in cache directory keys or an equivalent validated cache manifest, with mismatch causing regeneration.
- [ ] **Step 6: Verify all language scope suites and SDK suite.** Run `uv run --group test pytest tests/analysis/commons tests/analysis/python/test_neo4j_multi_application_scope.py tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py tests/analysis/java/test_java_neo4j_multi_application_scope.py -q`, then `uv run --group test pytest tests -q`. Add/run equivalent Go multi-application scope coverage rather than assuming it exists. Account explicitly for optional analyzer extras/live tests.
- [ ] **Step 7: Commit.** Use `feat: bind SDK URI resolution to namespace and application`.

