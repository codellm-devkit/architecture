### Task 7: Canonical module indexes, deduplication, and regression

**Files:**
- Create: `python-sdk/tests/analysis/commons/test_module_identity_index.py`.
- Modify: `python-sdk/cldk/analysis/commons/identity.py` and the four `neo4j/neo4j_backend.py` modules from Task 6.
- Extend: `python-sdk/tests/analysis/typescript/test_typescript_neo4j_bulk.py` and the existing local/Neo4j locate tests identified during Task 6.

**Interfaces:**
- Consumes: Canonical IDs and bound resolution from Task 6.
- Add internal `index_module_rows(rows: Iterable[Mapping[str, str]]) -> dict[str, dict[str, str]]`; each row has `module_id` and `file_key`, and results are keyed by canonical module ID. Repeated identical rows collapse; conflicting file keys for one ID raise `ValueError`. Backend-local secondary maps are derived after validating the selected owner/language and retain candidate IDs instead of overwriting one owner.
- Produces: Canonical primary indexes, ID-preserving Cypher projections, and the wrong-service regression test.

- [ ] **Step 1: Write failing index tests with exact assertions.** Given the fixture's currency/payment/currency rows, assert two canonical keys, both file keys equal `server.js`, and the same result after reversing rows. Assert a secondary filename search has two owners. Assert conflicting rows for the same ID are diagnostic rather than last-write-wins.
- [ ] **Step 2: Write a failing functional locate/join regression.** Use two scoped fake-driver applications: currency has no callable at line 28 and `_loadProto` begins at 91; payment has a constructor at lines 24–34. Route currency's scanner position to currency and assert no callable; reversing backend order cannot attach payment's constructor. Assert a finding keyed to currency's canonical module has exactly one module match.
- [ ] **Step 3: Verify failure.** Run `uv run --group test pytest tests/analysis/commons/test_module_identity_index.py tests/analysis/typescript/test_typescript_neo4j_bulk.py -q` before implementing the index changes.
- [ ] **Step 4: Implement ID-preserving row reconstruction.** Project canonical module ID alongside file key before `DISTINCT`; use the common index helper in module loaders. Preserve existing local relative-key APIs only after application ownership is validated. Audit graph node keys and edge identities; do not collapse two call sites sharing endpoint IDs.
- [ ] **Step 5: Verify.** Run the tests above and all existing multi-application/locate suites from Task 6. Add an edge case asserting two real call-site identities survive duplicate-row cleanup. Record the difference between SDK coverage and the still-external integration joins.
- [ ] **Step 6: Commit.** Use `fix: preserve canonical module identity during deduplication`.

