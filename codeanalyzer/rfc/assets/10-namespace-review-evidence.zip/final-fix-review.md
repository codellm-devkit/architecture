# Scoped final fixwave re-review

Reviewed once, against `final-review.md`, `final-fix-report.md`, the complete four-repository `final-fix-review-package.md` BASE/HEAD diffs, `global-constraints.md`, and `contract-decisions.md`. This is a fix-only re-review, not another broad integration review. Product files and Git state were not modified; only this requested artifact was written. No tests were rerun and no subagents were used.

## Per-finding verdicts

| Original finding | Verdict | Spec and quality assessment |
|---|---|---|
| 1. Python persisted selected-anchor validation | **ADDRESSED** | Both streaming and nonstreaming paths call `_validate_stored_identity` before DDL, module-hash reads or writes. The parameterized query selects the exact `PyApplication` canonical root. Existing anchors require an exact Python integer 2 and matching raw application/namespace; absent anchors are permitted. Tests cover missing metadata, float/bool markers and contradictory owners on both paths, assert the selected ID, and allow only the single guard query on rejection. Fresh/matching helper coverage is present. The small shared guard avoids divergent writer rules. |
| 2. Go persisted raw ownership validation | **ADDRESSED** | The exact selected-anchor query now fetches both raw fields. String checks plus `ResolveIdentity` require valid raw names whose canonical root equals the validated incoming `appID`. Encoding is injective over the validated raw UTF-8 names, so this root comparison preserves exact ownership without normalization. `run` returns guard errors before `ensureDDL` or later writes. Tests cover missing/conflicting/wrong-type fields with zero writes, and fresh/matching anchors. Existing strict int64 marker validation remains in place. |
| 3. Strict SDK markers before coercion | **ADDRESSED** | Shared `IdentityVersion` uses a `BeforeValidator` with `type(value) is int` and value 2, before `Literal` conversion, across all five affected Go/TS/Java fields. Complete fresh-model/cache parity tests cover float rejection; field tests also cover bool/string rejection and valid integer acceptance. The producer-owned `PyApplication` now has a before-field validator, and the SDK directly reexports that class; the regression exercises that public reexport. This closes the local Python normalization path as well. |
| 4. Repeated regeneration flags | **ADDRESSED** | Each of the five Python handoff commands retains one app-name/namespace pair. No product behavior changes. |
| 5. Duplicate Python scope setup | **ADDRESSED** | The duplicate import and identity assignment were removed, leaving one initialization. No fixture behavior changes. |
| 6. Delivery wording and provenance | **ADDRESSED** | The SDK body uses a non-closing Related reference to #435 and explicitly leaves downstream joins open. The Go body accurately introduces namespace without claiming an earlier workspace-root option. The verification source table matches the four final fix HEADs and unchanged TS HEAD; it distinguishes Java artifact build source from docs/test HEAD and records the rebuilt Go hash. Prepared PR evidence matches the fix report. Companion Go/SDK links are explicitly pending creation, so they are not represented as delivered links. |
| Java property-refinement triage | **ADDRESSED** | The allowed documentation/test option was taken: class documentation explicitly rejects differing ordinary canonical-node properties and a display-property regression pins it. The diff makes no Java runtime change. The handoff records the stricter contract and its remaining caller risk, without claiming a demonstrated projector regression or a rebuilt artifact. |

Source inspection outside the fix diff was limited to concrete verification risks: Go guard ordering and raw-name encoder semantics, and the SDK's Python class reexport/producer field declaration. The parent `10-namespace-verification.md` and SDD prepared PR bodies were inspected only for fix metadata accuracy.

## New breakage in the fix diff

None established. No additional Important or Minor fix is requested from this scoped pass. The explicit strict Java contract remains a disclosed existing limitation, not newly introduced runtime behavior.

## Evidence and assessment

Reused the supplied RED/GREEN evidence: Python 34 focused passes; Go Neo4j package pass; SDK 142 focused passes and 1 skip; Java 3 contract passes. The final SDK evidence is 1949 passed / 422 skipped, and the rebuilt-native L2 smoke is 20 cases / 60 canonical endpoints. These are recorded implementation results, not independently rerun results from this review.

**Spec compliance: pass for the scoped fixes. Code quality: acceptable for the scoped fixes.** All established final-review findings are addressed; no fix-induced blocker was found. Producer changes can proceed through normal delivery/CI gates. SDK remains Draft and merge/release blocked until compatible published producers, package-workflow pins/lock updates, and installed-package validation. Live Neo4j behavior remains unverified, and private downstream integration adoption remains external under #435. This review does not certify either gate or private end-to-end completion.
