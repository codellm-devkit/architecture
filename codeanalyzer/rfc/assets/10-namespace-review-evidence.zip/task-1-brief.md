### Task 1: Freeze fixtures, tracking, and baseline

**Files:**
- Create: `architecture/codeanalyzer/rfc/assets/10-identity-fixtures.json`.
- Copy fixture bytes into `codeanalyzer-python/test/fixtures/identity/namespaces.json`, `codeanalyzer-typescript/test/fixtures/identity/namespaces.json`, `codeanalyzer-java/src/test/resources/identity/namespaces.json`, `codeanalyzer-go/internal/schema/v2/testdata/namespaces.json`, and `python-sdk/tests/resources/identity/namespaces.json`.
- Read: `architecture/codeanalyzer/rfc/assets/10-module-ownership-issue-draft.md`.

**Interfaces:**
- Consumes: RFC input/default/encoding rules and the current checked-out PR branches.
- Produces: Self-contained golden fixtures and an issue/PR tracking map. Each repo's CI uses its own checked-in fixture copy, never a sibling checkout.

- [ ] **Step 1: Record branch heads and run baseline checks.** Inspect `git status --short --branch` in each repo. Preserve local changes if any. Record baseline failures separately rather than attributing them to this feature. Use existing dependency environments; install only missing project dependencies through the repository's normal workflow.
- [ ] **Step 2: Write golden input/output cases.** JSON contains `roots` (raw application, nullable namespace, expected root), `invalid` inputs, `modules` (namespace/application/language/file-key/expected URI), and `duplicate_module_rows`. Pin at least `inventory/null -> can://inventory/inventory`, `currencyservice/online-boutique -> can://online-boutique/currencyservice`, `a%b/team space -> can://team%20space/a%25b`, and Unicode plus case-distinct cases. Invalid cases include explicit `""`, `" "`, `"a/b"`, `"a\\b"`, `"."`, `".."`, and a control character. In JSON, use escaped surrogate input for Python/Java/TS invalid-input adapters; Go tests exercise invalid UTF-8 separately because Go strings are bytes.
- [ ] **Step 3: Copy and verify fixtures.** Require identical SHA-256 hashes for all six files. The duplicate rows are currency URI, payment URI, currency URI; the expected unique ID count is exactly two.
- [ ] **Step 4: Create tracking issues requested in review.** Check for duplicates in `python-sdk` and each `codeanalyzer-*` repo. Create a public SDK ownership report from the saved draft, and producer issues referencing the existing PRs and namespace contract. Use self-contained public examples, without private tracker links or deployment details. Save exact issue bodies to files and use `gh issue create --body-file`. Link returned issue URLs in this plan/RFC and the eventual PR bodies.
- [ ] **Step 5: Commit fixture copies in each implementation repo.** `git add` only that repo's fixture; commit `test: add namespace identity contract fixtures`. Record heads and baseline test outcomes in this plan.

