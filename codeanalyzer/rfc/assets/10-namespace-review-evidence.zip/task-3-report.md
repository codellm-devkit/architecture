# Task 3 report — TypeScript and JavaScript namespaces

Implemented and committed on existing `feat/add-workspace-root` branch. No push performed.

- Base: `dbb5ccdcad46f5ce9c39e279297cf535579907d0`
- Commit: `f0748dfb52f36ca30b78ad636389058c856bf628`
- Message: `feat: qualify TypeScript analysis identities by namespace`
- Follow-up commit: `fcc9529a932bc40a6be426fb85298237e19ffe65` (`fix: require raw namespace metadata before graph projection`). This closes the default-namespace fallback masking absent raw metadata; a dedicated regression failed before the fix.
- Working tree clean after commit.

## Changes

`--namespace` and `AnalysisOptions.namespace?: string` replace workspace-root. The root is always `can://<encoded namespace>/<encoded application>`, with namespace defaulting to the resolved application name. Names are raw, case sensitive, encoded by UTF-8 with uppercase percent escapes, and validated against empty/whitespace names, controls, separators, dot names, and unpaired surrogates. File keys and signatures remain input relative. Both JavaScript and TypeScript modules retain their language-specific suffixes beneath the same application root.

`applicationIdOf(appName: string, namespace?: string)`, module/artifact helpers with final optional namespace, and `assignIds(app, appName, namespace?)` follow the contract. Every raw-name helper caller propagates namespace. Dependency `declared_in` restamping uses an artifact-reference grammar helper instead of fixed slash slicing. Repeated finalization under a different namespace restamps module/body/artifact/dependency/external IDs.

The existing envelope and application anchor carry integer `identity_version: 2`; the application retains raw `application_name` and `identity_namespace`. Graph projection rejects absent/noninteger/old markers and mismatched raw scope before producing rows. Cache keys include canonical application identity and marker; incompatible cache reads return null without changing cache files. The live Bolt path validates an existing selected application anchor's integer marker and raw names before DDL or graph mutation.

Selected-root artifact reconciliation, sibling claims, existing relationship discrimination and canonical row deduplication remain. Removed the inherited automatic legacy artifact-root cleanup: ordinary operations affect only the selected namespace/application. Legacy outputs require regeneration and explicit retirement.

## Files and invariants audited

Changed CLI/core/options, `schema/{ids,assignIds,emit,schema}.ts`, `utils/cache.ts`, `build/neo4j/{project,rows,schema,bolt}.ts`, README and generated `schema.neo4j.json`. Replaced `test/workspace-root.test.ts` with fixture-driven `test/namespace.test.ts`; updated identity expectations in existing artifact, config, entrypoint, schema and Neo4j tests.

`schema/checker.ts` is a guarded TypeScript compiler symbol accessor, not an output validator, and needs no namespace changes. Canonical-parent forwarding sites (`schema/homing.ts`, `schema/l1Body.ts`, dataflow attachment, config-key and ordinal construction) already derive from canonical parents and were left unchanged. Existing suffix grammar and `pkg:npm` identities are unchanged. Existing edge deduplication retains kind/site discriminators.

No checked-in source-derived example payload needed regeneration. Generated graph schema was regenerated from source, without URI translation, using `bun run gen:schema` (`bun run src/index.ts --emit schema > schema.neo4j.json`); deterministic output was checked again before commit. No timestamps were added to generated output.

## RED / GREEN evidence

All commands executed from `/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-typescript`, after `source /private/tmp/namespace-toolchains/env.sh`.

1. RED: `bun test test/ids.test.ts test/namespace.test.ts` — **15 pass, 20 fail, 53 assertions, 35 tests / 2 files**. New golden-fixture roots, invalid inputs, JavaScript/TypeScript modules and artifact scope failed against the old grammar.
2. GREEN: `bun run typecheck` — exit 0 (`tsc --noEmit`).
3. GREEN: `bun test test/ids.test.ts test/namespace.test.ts test/body-ids.test.ts test/schema-v2.test.ts test/neo4j-prefix-scope.test.ts test/neo4j-artifact-reconcile.test.ts` — **97 pass, 15 skip, 0 fail, 3,359 assertions, 112 tests / 6 files**.
4. GREEN: `bun test` — **399 pass, 23 skip, 0 fail, 16,128 assertions, 422 tests / 44 files**.
5. `bun run gen:schema` — exit 0; generated metadata has integer marker and raw application fields.
6. `bun run src/index.ts --help` — namespace present, workspace-root absent.
7. `git diff --check` — exit 0.
8. Final `git status --short` — empty.

Logs are preserved in `task-3-logs/`: RED, metadata-regression RED (23 pass, 1 fail, 65 assertions / 24 tests), focused GREEN, full GREEN, typecheck and CLI help.

The namespace tests additionally assert `%` escaping, explicit empty namespace rejection, repeated finalization, dependency artifact references, external references, raw metadata, marker rejection, graph raw-scope mismatch, cache namespace mismatch and read-only rejection of legacy/coercible/noninteger markers. Golden fixture assertions explicitly cover both `.js -> javascript` and `.ts -> typescript`.

## Remaining gates / concerns

Docker is unavailable (`command -v docker` returns no path). The 23 skipped tests are existing live/container Bolt and artifact reconciliation gates. `bun run test:container` remains required on a Docker-capable host; live metadata rejection, sibling claim retention, legacy-root noninterference and reconciliation queries could not be exercised against a live server here. There were no failing runnable checks and no sandbox escalation was needed.

Suggested PR description: TypeScript and JavaScript now qualify all application-owned identities with namespace and application name while retaining input-relative keys and language-specific suffixes. Namespace defaults to the application name; version-2 metadata and cache/graph scope checks reject incompatible prior output. Selected-root artifact reconciliation preserves sibling ownership. Validation: typecheck and full Bun suite pass (399 passing, 23 live/container skips); Docker reconciliation gate remains pending.

## Review fix round 1 — explicit empty CLI application name

Reviewed `task-3-review.md` P2 against `FIX_BASE fcc9529a932bc40a6be426fb85298237e19ffe65`. Confirmed `o.appName ? ... : null` incorrectly treated supplied `--app-name ''` as omission. Changed only `src/cli.ts` and `test/namespace.test.ts`: preserve omission with an undefined check, so explicit empty names reach existing identity validation. CLI subprocess regressions cover empty application name with and without explicit namespace, assert no analysis output is written on failure, and verify omitted application name still resolves to input basename with both default and explicit namespace.

Commit: `9658f895e3e75d683a0c00c87069934ddf2966fa` — `fix: reject explicit empty CLI application names`. No push; final repository working tree clean.

Commands ran from `codeanalyzer-typescript` after `source /private/tmp/namespace-toolchains/env.sh`:

- RED: `bun test test/namespace.test.ts` — **26 pass, 2 fail, 75 assertions, 28 tests / 1 file**. Both new explicit-empty CLI cases failed before the fix; omitted-name cases passed.
- GREEN: `bun test test/namespace.test.ts test/input-path.test.ts test/dataflow.test.ts` — **71 pass, 0 fail, 1,752 assertions, 71 tests / 3 files**. Includes namespace, existing CLI input handling and CLI graph/jobs option parsing regressions.
- GREEN: `bun run typecheck` — exit 0 (`tsc --noEmit`).
- `git diff --check` — exit 0.
- `git status --short` after commit — empty.

Logs: `task-3-logs/task3-round1-{red,green,typecheck}.log`. Full suite was not repeated because this review fix only changes CLI flag-presence handling, as instructed. Previously documented Docker/live gates remain pending.
