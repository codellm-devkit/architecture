## Global Constraints

- `application_name = supplied app-name, otherwise basename(selected input root)`.
- `namespace = supplied namespace, otherwise resolved application_name`.
- Both root segments remain present, including `can://inventory/inventory`.
- Keep existing language-specific suffixes and application-relative file keys. Update every embedded application-owned reference; `pkg:` identities are unchanged.
- Root inputs are case-sensitive raw strings. Encode UTF-8 bytes outside ASCII letters/digits/`-._~` with uppercase percent escapes. Reject empty/whitespace-only values, control characters, unpaired surrogates, `/`, `\`, `.` and `..` as whole names. Do not trim or normalize Unicode.
- An ordinary request selects one namespace/application and its existing language view. No namespace-wide fallback, new search API, or unrestricted suffix matching.
- Remove the unmerged PRs' `--workspace-root` option and setting. Preserve their unrelated artifact reconciliation fixes.
- Deduplicate entities by canonical ID. Keep relationship kind and existing site/context discriminators when deduplicating edges.
- Add namespace to cache identity; reject incompatible output read-only. Regenerate outputs and derived references from source; no aliases or in-place ID translation.
- No package-release modeling, suffix redesign, producer lifecycle redesign, or new source-mapping API in this iteration.

