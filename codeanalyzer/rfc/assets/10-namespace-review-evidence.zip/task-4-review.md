# Task 4 review

Reviewed `dcef0a6d..e35d7dca`, the task brief, global constraints, contract decisions, implementation report summary and relevant verification evidence. No suites were rerun; no implementation files were changed.

## Verdicts

- **Spec compliance: changes required.** The namespace/v2 contract is implemented coherently, but the shared writer changes regress explicitly supported legacy-v1 behavior.
- **Code quality: changes required.** The canonical-parent plumbing and validation are clear and reasonably scoped. The destructive-query selection must distinguish legacy-v1 requests from v2 requests instead of applying the v2 root predicate to both.

## Findings

### P2 — Preserve v1 snapshot replacement while removing v2 legacy fallback

`codeanalyzer-java/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java:151` and `:159`.

`writeCypher` is shared by both schema families. When rows come from legacy `GraphProjector`, `applicationIdOf` now synthesizes `can://<name>/<name>`, and `wipe` matches only that canonical id (or its `JCanNode` descendants). Legacy `GraphProjector.java:80` still keys the anchor on `name` and sets no `id`; its compilation units and symbols also lack canonical roots. Consequently a second `--schema v1 --emit neo4j` snapshot performs no wipe of the first v1 graph. Removing a Java file/declaration or an edge leaves its previous graph representation behind after replaying the supposedly full snapshot.

Keep canonical-only selection for v2 rows, but choose an explicit legacy name/containment wipe when the incoming rows are v1. This does not require any v2-to-legacy fallback or automatic legacy retirement.

### P2 — Preserve full-run orphan pruning for v1 Bolt pushes

`codeanalyzer-java/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java:85` (used unconditionally by `Runner.run` at line 328).

The replacement predicate is always `a.id = $appId`, while a v1 push still emits a name-keyed `JApplication` with no id. The fallback `applicationIdOf(rows)` synthesizes a canonical id, so this predicate cannot find that v1 anchor. Deleting a source file and running another full v1 Bolt push now leaves the vanished compilation unit and descendants in the database; the previous guarded name branch pruned them. Select a legacy-only prune query for actual v1 rows and keep this exact canonical predicate for v2 rows.

## Audited invariants and evidence

- Root validation rejects empty/whitespace-only values, controls, invalid surrogates, separators, and whole `.`/`..`; UTF-8 bytes use uppercase escaping with only ASCII unreserved bytes left literal. Omission is distinct from explicit empty.
- Namespace is per instance; app-name option presence is checked per invocation before defaulting from input basename. Modules, artifacts, L2 external targets, config/view ghost references, envelope metadata, and cache settings receive the selected root.
- Marker/raw-name validation precedes Bolt DDL, module-hash reads, and destructive writes. Module hashes select the exact canonical anchor. Reconciliation prefixes select only its artifact subtree; existing sibling-claim/edge retention logic remains intact.
- Canonical node deduplication unions labels and compatible properties and rejects property/key conflicts; canonical edge dedup preserves relationship type and `_k`. Legacy label-scoped row identity remains unchanged.
- Offline snapshot compatibility is evaluated within the stated boundary: incoming metadata is checked through projection; no existing-database guard/APOC is required. Snapshot regeneration may replace shared artifact edges within the selected application, as documented.
- Existing parent-id forwarding builders require no cosmetic namespace arguments. Unchanged `GraphProjector` was inspected specifically to establish the v1-anchor risk above.
- Reported verification: 74 focused tests pass; 635 available full-suite tests pass with 17 skipped; the unfiltered run fails only Docker integration initialization. Live shared-artifact/namespace tests remain unavailable without Docker; this review does not claim they ran.
