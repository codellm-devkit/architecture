
# codeanalyzer-python: 4cd8c1f0c107a1fb23bfe5b26ccf7ae129499a84..94b331e9cb56902420409a3e569e2b1e91608e2d
94b331e test: add namespace identity contract fixtures
 test/fixtures/identity/namespaces.json | 139 +++++++++++++++++++++++++++++++++
 1 file changed, 139 insertions(+)
diff --git a/test/fixtures/identity/namespaces.json b/test/fixtures/identity/namespaces.json
new file mode 100644
index 0000000..8a89219
--- /dev/null
+++ b/test/fixtures/identity/namespaces.json
@@ -0,0 +1,139 @@
+{
+  "identity_version": 2,
+  "roots": [
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "expected_root": "can://inventory/inventory"
+    },
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "expected_root": "can://online-boutique/currencyservice"
+    },
+    {
+      "application_name": "a%b",
+      "namespace": "team space",
+      "expected_root": "can://team%20space/a%25b"
+    },
+    {
+      "application_name": "caf\u00e9",
+      "namespace": "\u56e2\u961f",
+      "expected_root": "can://%E5%9B%A2%E9%98%9F/caf%C3%A9"
+    },
+    {
+      "application_name": "Inventory",
+      "namespace": "Team",
+      "expected_root": "can://Team/Inventory"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": "team",
+      "expected_root": "can://team/inventory"
+    },
+    {
+      "application_name": " cafe\u0301 ",
+      "namespace": "team",
+      "expected_root": "can://team/%20cafe%CC%81%20"
+    }
+  ],
+  "invalid": [
+    {
+      "value": "",
+      "reason": "empty"
+    },
+    {
+      "value": " ",
+      "reason": "whitespace-only"
+    },
+    {
+      "value": "a/b",
+      "reason": "slash"
+    },
+    {
+      "value": "a\\b",
+      "reason": "backslash"
+    },
+    {
+      "value": ".",
+      "reason": "dot"
+    },
+    {
+      "value": "..",
+      "reason": "dot-dot"
+    },
+    {
+      "value": "a\u0001b",
+      "reason": "control"
+    },
+    {
+      "value": "\ud800",
+      "reason": "unpaired-high-surrogate"
+    },
+    {
+      "value": "\udc00",
+      "reason": "unpaired-low-surrogate"
+    }
+  ],
+  "modules": [
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/currencyservice/javascript/server.js"
+    },
+    {
+      "application_name": "paymentservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/paymentservice/javascript/server.js"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "python",
+      "file_key": "src/main.py",
+      "expected_uri": "can://inventory/inventory/python/src/main.py"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "typescript",
+      "file_key": "src/main.ts",
+      "expected_uri": "can://inventory/inventory/typescript/src/main.ts"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "java",
+      "file_key": "src/Main.java",
+      "expected_uri": "can://inventory/inventory/java/src/Main.java"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "go",
+      "file_key": "main.go",
+      "expected_uri": "can://inventory/inventory/go/main.go"
+    }
+  ],
+  "duplicate_module_rows": {
+    "rows": [
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/paymentservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      }
+    ],
+    "expected_unique_id_count": 2
+  }
+}

# codeanalyzer-typescript: b41215f05f54eefe241724009a437b35e490b615..dbb5ccdcad46f5ce9c39e279297cf535579907d0
dbb5ccd test: add namespace identity contract fixtures
 test/fixtures/identity/namespaces.json | 139 +++++++++++++++++++++++++++++++++
 1 file changed, 139 insertions(+)
diff --git a/test/fixtures/identity/namespaces.json b/test/fixtures/identity/namespaces.json
new file mode 100644
index 0000000..8a89219
--- /dev/null
+++ b/test/fixtures/identity/namespaces.json
@@ -0,0 +1,139 @@
+{
+  "identity_version": 2,
+  "roots": [
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "expected_root": "can://inventory/inventory"
+    },
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "expected_root": "can://online-boutique/currencyservice"
+    },
+    {
+      "application_name": "a%b",
+      "namespace": "team space",
+      "expected_root": "can://team%20space/a%25b"
+    },
+    {
+      "application_name": "caf\u00e9",
+      "namespace": "\u56e2\u961f",
+      "expected_root": "can://%E5%9B%A2%E9%98%9F/caf%C3%A9"
+    },
+    {
+      "application_name": "Inventory",
+      "namespace": "Team",
+      "expected_root": "can://Team/Inventory"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": "team",
+      "expected_root": "can://team/inventory"
+    },
+    {
+      "application_name": " cafe\u0301 ",
+      "namespace": "team",
+      "expected_root": "can://team/%20cafe%CC%81%20"
+    }
+  ],
+  "invalid": [
+    {
+      "value": "",
+      "reason": "empty"
+    },
+    {
+      "value": " ",
+      "reason": "whitespace-only"
+    },
+    {
+      "value": "a/b",
+      "reason": "slash"
+    },
+    {
+      "value": "a\\b",
+      "reason": "backslash"
+    },
+    {
+      "value": ".",
+      "reason": "dot"
+    },
+    {
+      "value": "..",
+      "reason": "dot-dot"
+    },
+    {
+      "value": "a\u0001b",
+      "reason": "control"
+    },
+    {
+      "value": "\ud800",
+      "reason": "unpaired-high-surrogate"
+    },
+    {
+      "value": "\udc00",
+      "reason": "unpaired-low-surrogate"
+    }
+  ],
+  "modules": [
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/currencyservice/javascript/server.js"
+    },
+    {
+      "application_name": "paymentservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/paymentservice/javascript/server.js"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "python",
+      "file_key": "src/main.py",
+      "expected_uri": "can://inventory/inventory/python/src/main.py"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "typescript",
+      "file_key": "src/main.ts",
+      "expected_uri": "can://inventory/inventory/typescript/src/main.ts"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "java",
+      "file_key": "src/Main.java",
+      "expected_uri": "can://inventory/inventory/java/src/Main.java"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "go",
+      "file_key": "main.go",
+      "expected_uri": "can://inventory/inventory/go/main.go"
+    }
+  ],
+  "duplicate_module_rows": {
+    "rows": [
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/paymentservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      }
+    ],
+    "expected_unique_id_count": 2
+  }
+}

# codeanalyzer-java: 90a48ca82a3a8011f9d58d9e167e60042df206b5..dcef0a6dcc32dbcb97295eb9de06e7e86b191eda
dcef0a6d test: add namespace identity contract fixtures
 src/test/resources/identity/namespaces.json | 139 ++++++++++++++++++++++++++++
 1 file changed, 139 insertions(+)
diff --git a/src/test/resources/identity/namespaces.json b/src/test/resources/identity/namespaces.json
new file mode 100644
index 00000000..8a892193
--- /dev/null
+++ b/src/test/resources/identity/namespaces.json
@@ -0,0 +1,139 @@
+{
+  "identity_version": 2,
+  "roots": [
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "expected_root": "can://inventory/inventory"
+    },
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "expected_root": "can://online-boutique/currencyservice"
+    },
+    {
+      "application_name": "a%b",
+      "namespace": "team space",
+      "expected_root": "can://team%20space/a%25b"
+    },
+    {
+      "application_name": "caf\u00e9",
+      "namespace": "\u56e2\u961f",
+      "expected_root": "can://%E5%9B%A2%E9%98%9F/caf%C3%A9"
+    },
+    {
+      "application_name": "Inventory",
+      "namespace": "Team",
+      "expected_root": "can://Team/Inventory"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": "team",
+      "expected_root": "can://team/inventory"
+    },
+    {
+      "application_name": " cafe\u0301 ",
+      "namespace": "team",
+      "expected_root": "can://team/%20cafe%CC%81%20"
+    }
+  ],
+  "invalid": [
+    {
+      "value": "",
+      "reason": "empty"
+    },
+    {
+      "value": " ",
+      "reason": "whitespace-only"
+    },
+    {
+      "value": "a/b",
+      "reason": "slash"
+    },
+    {
+      "value": "a\\b",
+      "reason": "backslash"
+    },
+    {
+      "value": ".",
+      "reason": "dot"
+    },
+    {
+      "value": "..",
+      "reason": "dot-dot"
+    },
+    {
+      "value": "a\u0001b",
+      "reason": "control"
+    },
+    {
+      "value": "\ud800",
+      "reason": "unpaired-high-surrogate"
+    },
+    {
+      "value": "\udc00",
+      "reason": "unpaired-low-surrogate"
+    }
+  ],
+  "modules": [
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/currencyservice/javascript/server.js"
+    },
+    {
+      "application_name": "paymentservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/paymentservice/javascript/server.js"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "python",
+      "file_key": "src/main.py",
+      "expected_uri": "can://inventory/inventory/python/src/main.py"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "typescript",
+      "file_key": "src/main.ts",
+      "expected_uri": "can://inventory/inventory/typescript/src/main.ts"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "java",
+      "file_key": "src/Main.java",
+      "expected_uri": "can://inventory/inventory/java/src/Main.java"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "go",
+      "file_key": "main.go",
+      "expected_uri": "can://inventory/inventory/go/main.go"
+    }
+  ],
+  "duplicate_module_rows": {
+    "rows": [
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/paymentservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      }
+    ],
+    "expected_unique_id_count": 2
+  }
+}

# codeanalyzer-go: 25dc74f840360c8b2dbdd299f50b87a630272e6c..e65d73f1ff358dc9f43e21b12b774b4d68e5578c
e65d73f test: add namespace identity contract fixtures
 internal/schema/v2/testdata/namespaces.json | 139 ++++++++++++++++++++++++++++
 1 file changed, 139 insertions(+)
diff --git a/internal/schema/v2/testdata/namespaces.json b/internal/schema/v2/testdata/namespaces.json
new file mode 100644
index 0000000..8a89219
--- /dev/null
+++ b/internal/schema/v2/testdata/namespaces.json
@@ -0,0 +1,139 @@
+{
+  "identity_version": 2,
+  "roots": [
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "expected_root": "can://inventory/inventory"
+    },
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "expected_root": "can://online-boutique/currencyservice"
+    },
+    {
+      "application_name": "a%b",
+      "namespace": "team space",
+      "expected_root": "can://team%20space/a%25b"
+    },
+    {
+      "application_name": "caf\u00e9",
+      "namespace": "\u56e2\u961f",
+      "expected_root": "can://%E5%9B%A2%E9%98%9F/caf%C3%A9"
+    },
+    {
+      "application_name": "Inventory",
+      "namespace": "Team",
+      "expected_root": "can://Team/Inventory"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": "team",
+      "expected_root": "can://team/inventory"
+    },
+    {
+      "application_name": " cafe\u0301 ",
+      "namespace": "team",
+      "expected_root": "can://team/%20cafe%CC%81%20"
+    }
+  ],
+  "invalid": [
+    {
+      "value": "",
+      "reason": "empty"
+    },
+    {
+      "value": " ",
+      "reason": "whitespace-only"
+    },
+    {
+      "value": "a/b",
+      "reason": "slash"
+    },
+    {
+      "value": "a\\b",
+      "reason": "backslash"
+    },
+    {
+      "value": ".",
+      "reason": "dot"
+    },
+    {
+      "value": "..",
+      "reason": "dot-dot"
+    },
+    {
+      "value": "a\u0001b",
+      "reason": "control"
+    },
+    {
+      "value": "\ud800",
+      "reason": "unpaired-high-surrogate"
+    },
+    {
+      "value": "\udc00",
+      "reason": "unpaired-low-surrogate"
+    }
+  ],
+  "modules": [
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/currencyservice/javascript/server.js"
+    },
+    {
+      "application_name": "paymentservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/paymentservice/javascript/server.js"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "python",
+      "file_key": "src/main.py",
+      "expected_uri": "can://inventory/inventory/python/src/main.py"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "typescript",
+      "file_key": "src/main.ts",
+      "expected_uri": "can://inventory/inventory/typescript/src/main.ts"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "java",
+      "file_key": "src/Main.java",
+      "expected_uri": "can://inventory/inventory/java/src/Main.java"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "go",
+      "file_key": "main.go",
+      "expected_uri": "can://inventory/inventory/go/main.go"
+    }
+  ],
+  "duplicate_module_rows": {
+    "rows": [
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/paymentservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      }
+    ],
+    "expected_unique_id_count": 2
+  }
+}

# python-sdk: 1b49043c9d48505bfe92891787b84c7403155cda..7633dd2a61e20a603463946442705db817dbfebe
7633dd2 test: add namespace identity contract fixtures
 tests/resources/identity/namespaces.json | 139 +++++++++++++++++++++++++++++++
 1 file changed, 139 insertions(+)
diff --git a/tests/resources/identity/namespaces.json b/tests/resources/identity/namespaces.json
new file mode 100644
index 0000000..8a89219
--- /dev/null
+++ b/tests/resources/identity/namespaces.json
@@ -0,0 +1,139 @@
+{
+  "identity_version": 2,
+  "roots": [
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "expected_root": "can://inventory/inventory"
+    },
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "expected_root": "can://online-boutique/currencyservice"
+    },
+    {
+      "application_name": "a%b",
+      "namespace": "team space",
+      "expected_root": "can://team%20space/a%25b"
+    },
+    {
+      "application_name": "caf\u00e9",
+      "namespace": "\u56e2\u961f",
+      "expected_root": "can://%E5%9B%A2%E9%98%9F/caf%C3%A9"
+    },
+    {
+      "application_name": "Inventory",
+      "namespace": "Team",
+      "expected_root": "can://Team/Inventory"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": "team",
+      "expected_root": "can://team/inventory"
+    },
+    {
+      "application_name": " cafe\u0301 ",
+      "namespace": "team",
+      "expected_root": "can://team/%20cafe%CC%81%20"
+    }
+  ],
+  "invalid": [
+    {
+      "value": "",
+      "reason": "empty"
+    },
+    {
+      "value": " ",
+      "reason": "whitespace-only"
+    },
+    {
+      "value": "a/b",
+      "reason": "slash"
+    },
+    {
+      "value": "a\\b",
+      "reason": "backslash"
+    },
+    {
+      "value": ".",
+      "reason": "dot"
+    },
+    {
+      "value": "..",
+      "reason": "dot-dot"
+    },
+    {
+      "value": "a\u0001b",
+      "reason": "control"
+    },
+    {
+      "value": "\ud800",
+      "reason": "unpaired-high-surrogate"
+    },
+    {
+      "value": "\udc00",
+      "reason": "unpaired-low-surrogate"
+    }
+  ],
+  "modules": [
+    {
+      "application_name": "currencyservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/currencyservice/javascript/server.js"
+    },
+    {
+      "application_name": "paymentservice",
+      "namespace": "online-boutique",
+      "language": "javascript",
+      "file_key": "server.js",
+      "expected_uri": "can://online-boutique/paymentservice/javascript/server.js"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "python",
+      "file_key": "src/main.py",
+      "expected_uri": "can://inventory/inventory/python/src/main.py"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "typescript",
+      "file_key": "src/main.ts",
+      "expected_uri": "can://inventory/inventory/typescript/src/main.ts"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "java",
+      "file_key": "src/Main.java",
+      "expected_uri": "can://inventory/inventory/java/src/Main.java"
+    },
+    {
+      "application_name": "inventory",
+      "namespace": null,
+      "language": "go",
+      "file_key": "main.go",
+      "expected_uri": "can://inventory/inventory/go/main.go"
+    }
+  ],
+  "duplicate_module_rows": {
+    "rows": [
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/paymentservice/javascript/server.js",
+        "file_key": "server.js"
+      },
+      {
+        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
+        "file_key": "server.js"
+      }
+    ],
+    "expected_unique_id_count": 2
+  }
+}

# Canonical workspace fixture
{
  "identity_version": 2,
  "roots": [
    {
      "application_name": "inventory",
      "namespace": null,
      "expected_root": "can://inventory/inventory"
    },
    {
      "application_name": "currencyservice",
      "namespace": "online-boutique",
      "expected_root": "can://online-boutique/currencyservice"
    },
    {
      "application_name": "a%b",
      "namespace": "team space",
      "expected_root": "can://team%20space/a%25b"
    },
    {
      "application_name": "caf\u00e9",
      "namespace": "\u56e2\u961f",
      "expected_root": "can://%E5%9B%A2%E9%98%9F/caf%C3%A9"
    },
    {
      "application_name": "Inventory",
      "namespace": "Team",
      "expected_root": "can://Team/Inventory"
    },
    {
      "application_name": "inventory",
      "namespace": "team",
      "expected_root": "can://team/inventory"
    },
    {
      "application_name": " cafe\u0301 ",
      "namespace": "team",
      "expected_root": "can://team/%20cafe%CC%81%20"
    }
  ],
  "invalid": [
    {
      "value": "",
      "reason": "empty"
    },
    {
      "value": " ",
      "reason": "whitespace-only"
    },
    {
      "value": "a/b",
      "reason": "slash"
    },
    {
      "value": "a\\b",
      "reason": "backslash"
    },
    {
      "value": ".",
      "reason": "dot"
    },
    {
      "value": "..",
      "reason": "dot-dot"
    },
    {
      "value": "a\u0001b",
      "reason": "control"
    },
    {
      "value": "\ud800",
      "reason": "unpaired-high-surrogate"
    },
    {
      "value": "\udc00",
      "reason": "unpaired-low-surrogate"
    }
  ],
  "modules": [
    {
      "application_name": "currencyservice",
      "namespace": "online-boutique",
      "language": "javascript",
      "file_key": "server.js",
      "expected_uri": "can://online-boutique/currencyservice/javascript/server.js"
    },
    {
      "application_name": "paymentservice",
      "namespace": "online-boutique",
      "language": "javascript",
      "file_key": "server.js",
      "expected_uri": "can://online-boutique/paymentservice/javascript/server.js"
    },
    {
      "application_name": "inventory",
      "namespace": null,
      "language": "python",
      "file_key": "src/main.py",
      "expected_uri": "can://inventory/inventory/python/src/main.py"
    },
    {
      "application_name": "inventory",
      "namespace": null,
      "language": "typescript",
      "file_key": "src/main.ts",
      "expected_uri": "can://inventory/inventory/typescript/src/main.ts"
    },
    {
      "application_name": "inventory",
      "namespace": null,
      "language": "java",
      "file_key": "src/Main.java",
      "expected_uri": "can://inventory/inventory/java/src/Main.java"
    },
    {
      "application_name": "inventory",
      "namespace": null,
      "language": "go",
      "file_key": "main.go",
      "expected_uri": "can://inventory/inventory/go/main.go"
    }
  ],
  "duplicate_module_rows": {
    "rows": [
      {
        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
        "file_key": "server.js"
      },
      {
        "module_id": "can://online-boutique/paymentservice/javascript/server.js",
        "file_key": "server.js"
      },
      {
        "module_id": "can://online-boutique/currencyservice/javascript/server.js",
        "file_key": "server.js"
      }
    ],
    "expected_unique_id_count": 2
  }
}
