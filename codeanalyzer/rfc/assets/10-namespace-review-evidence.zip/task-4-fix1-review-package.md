cbfbd01d fix: preserve explicit legacy Java graph cleanup
 src/main/java/com/ibm/cldk/neo4j/BoltWriter.java     | 19 +++++++++++++++----
 src/main/java/com/ibm/cldk/neo4j/CypherWriter.java   | 20 +++++++++++++++++++-
 .../java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java | 16 ++++++++++++++++
 .../ibm/cldk/neo4j/CypherWriterStreamingTest.java    | 18 ++++++++++++++++++
 4 files changed, 68 insertions(+), 5 deletions(-)
diff --git a/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java b/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java
index 28961b9b..631fc659 100644
--- a/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java
+++ b/src/main/java/com/ibm/cldk/neo4j/BoltWriter.java
@@ -80,20 +80,32 @@ public final class BoltWriter implements BoltSink {
     static final String MODULE_HASHES_V2 = "MATCH (a:JApplication {id: $appId})-[:J_HAS_MODULE]->(c:JModule) "
             + "RETURN c.file_key AS k, c.content_hash AS h";
 
     static final String PRUNE_VANISHED_UNITS_V2 =
             "MATCH (a:JApplication)-[:J_HAS_UNIT|J_HAS_MODULE]->(c) "
                     + "WHERE a.id = $appId "
                     + "AND NOT c.file_key IN $present "
                     + "OPTIONAL MATCH (c)-" + CypherWriter.DESCENDANTS + "->(x) "
                     + "DETACH DELETE x, c RETURN count(c) AS pruned";
 
+    static final String PRUNE_VANISHED_UNITS_V1 =
+            "MATCH (a:JApplication)-[:J_HAS_UNIT]->(c) "
+                    + "WHERE a.id IS NULL AND a.name = $appName "
+                    + "AND NOT c.file_key IN $present "
+                    + "OPTIONAL MATCH (c)-" + CypherWriter.DESCENDANTS + "->(x) "
+                    + "DETACH DELETE x, c RETURN count(c) AS pruned";
+
+    static String orphanPruneQuery(GraphRows rows) {
+        return CypherWriter.legacyApplicationName(rows) != null
+                ? PRUNE_VANISHED_UNITS_V1 : PRUNE_VANISHED_UNITS_V2;
+    }
+
     /**
      * Drop every Java-owned edge on this app's artifacts and config keys so the run rebuilds them:
      * {@code HAS_ARTIFACT} from a {@code :JApplication}, {@code DECLARES_DEPENDENCY}/{@code LOCKS}
      * to {@code pkg:maven/}, and incoming {@code J_} edges ({@code J_USES_CONFIG},
      * {@code J_DISPATCHES_TO}). Not sha-diffed: siblings overwrite the shared {@code sha256}, and a
      * config change alters code edges while every module's hash stays put.
      */
     static final String PURGE_ARTIFACT_EDGES =
             "UNWIND $pres AS pre "
                     + "MATCH (t:" + RowBuilder.CAN_NODE + ") WHERE t.id STARTS WITH pre AND (t:Artifact OR t:ConfigKey) "
@@ -306,31 +318,30 @@ public final class BoltWriter implements BoltSink {
             List<EdgeRow> edges = new ArrayList<>();
             for (EdgeRow e : rows.edges) {
                 String owner = unitOf.get(e.from.value);
                 boolean intoArtifact = e.to.label.equals("Artifact") || e.to.label.equals("ConfigKey");
                 if (owner == null || changed.contains(owner) || (fullRun && intoArtifact)) {
                     edges.add(e);
                 }
             }
             upsertEdges(edges);
 
-            // 6. orphan prune — only safe on a full run. Reaches both generations' per-file nodes
-            // through the shared application anchor, so a v2 push also prunes a prior v1 graph's
-            // units (and other applications in the database are never touched).
+            // 6. Full-run orphan pruning uses the actual incoming schema family. A v1 request
+            // selects only an id-less legacy anchor; v2 selects only its exact canonical anchor.
             if (fullRun) {
                 List<String> present = new ArrayList<>(byUnit.keySet());
                 String appName = appNameOf(rows);
                 String appId = applicationIdOf(rows);
                 // Only Java containment under this exact anchor is traversed. Shared artifacts
                 // are reconciled separately and sibling namespaces are never fallback matches.
                 try (Session s = session()) {
-                    long pruned = s.run(PRUNE_VANISHED_UNITS_V2,
+                    long pruned = s.run(orphanPruneQuery(rows),
                             Values.parameters("present", present, "appId", appId, "appName", appName))
                             .single().get("pruned").asLong(0);
                     Log.info("neo4j(bolt): pruned " + pruned + " vanished unit(s)");
                 }
             } else {
                 Log.info("neo4j(bolt): targeted run — orphan pruning skipped (deleted files not removed)");
             }
         }
 
         /** v2 only: v1 emits no artifacts, so it would release every one. */
diff --git a/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java b/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java
index 88cb359f..2e469aa8 100644
--- a/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java
+++ b/src/main/java/com/ibm/cldk/neo4j/CypherWriter.java
@@ -85,21 +85,22 @@ public final class CypherWriter {
         for (String stmt : Schema.CONSTRAINTS) {
             s.add(stmt + ";");
         }
         for (String stmt : Schema.INDEXES) {
             s.add(stmt + ";");
         }
 
         s.add("");
         s.add("// ── wipe this project's prior subgraph (packages/annotations are shared and survive; "
                 + "artifacts/config keys are inside the app prefix and get rebuilt) ──");
-        s.add(wipe(applicationIdOf(rows, appName)));
+        String legacyName = legacyApplicationName(rows);
+        s.add(legacyName != null ? wipeLegacy(legacyName) : wipe(applicationIdOf(rows, appName)));
 
         s.add("");
         s.add("// ── nodes ──");
         writeNodeStatements(s, rows.nodes);
 
         s.add("");
         s.add("// ── relationships ──");
         writeEdgeStatements(s, rows.edges);
 
         s.add("");
@@ -136,20 +137,37 @@ public final class CypherWriter {
     static String applicationPrefix(String appName) {
         if (appName == null || appName.trim().isEmpty()) {
             throw new IllegalArgumentException(
                     "neo4j: refusing a destructive statement without an application id");
         }
         // The trailing separator is not cosmetic: a bare `STARTS WITH 'can://app'` would also match
         // `can://appX`, a different application.
         return CanId.applicationId(appName) + "/";
     }
 
+    /** Actual name-keyed v1 rows select legacy cleanup; v2 never falls back by display name. */
+    static String legacyApplicationName(GraphRows rows) {
+        for (NodeRow node : rows.nodes) {
+            if (node.labels.contains("JApplication") && "name".equals(node.keyProp)) {
+                return node.value;
+            }
+        }
+        return null;
+    }
+
+    private static String wipeLegacy(String appName) {
+        return "MATCH (a:JApplication) WHERE a.id IS NULL AND a.name = " + cypherValue(appName) + "\n"
+                + "OPTIONAL MATCH (a)-[:J_HAS_UNIT]->(c)\n"
+                + "OPTIONAL MATCH (c)-" + DESCENDANTS + "->(x)\n"
+                + "DETACH DELETE x, c, a;\n";
+    }
+
     /** Canonical roots come from projected rows, preserving the selected namespace. */
     private static String applicationIdOf(GraphRows rows, String appName) {
         for (NodeRow n : rows.nodes) {
             if (n.labels.contains("JApplication") && RowBuilder.isCanId(n.value)) return n.value;
         }
         return CanId.applicationId(appName);
     }
 
     private static String wipe(String applicationId) {
         String appId = cypherValue(applicationId);
diff --git a/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java b/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java
index 107ba941..a331fd6f 100644
--- a/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java
+++ b/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java
@@ -18,20 +18,36 @@ import org.junit.jupiter.api.Test;
  * <p>Scoping on the module's own {@code can://} id fixes both at once, because the id is a path —
  * {@code can://<app>/java/<file>} — so a prefix match is language-, application- and module-scoped
  * simultaneously.
  *
  * <p>Asserted on the statement text rather than through a live database: that path needs Docker and
  * does not run everywhere, while the property that makes the fix correct is entirely in the
  * predicate.
  */
 class BoltWriterPurgeTest {
 
+    @Test
+    void fullRunPruneSelectsActualSchemaFamilyAndProtectsSharedDisplayNames() {
+        var legacy = GraphProjector.project(java.util.Map.of(), null, "shared");
+        String query = BoltWriter.orphanPruneQuery(legacy);
+        assertTrue(query.contains("a.id IS NULL AND a.name = $appName"));
+        assertTrue(query.contains("[:J_HAS_UNIT]"));
+        assertTrue(query.contains("AND NOT c.file_key IN $present"));
+        assertTrue(query.contains("DETACH DELETE x, c"));
+        assertFalse(query.contains("a.id = $appId"));
+        var analysis = com.ibm.cldk.schema.V2Emitter.emit("shared", 1, java.util.Map.of(), null,
+                null, null, null, null, null, null, "team");
+        String canonical = BoltWriter.orphanPruneQuery(V2GraphProjector.project(analysis, "shared"));
+        assertTrue(canonical.contains("a.id = $appId"));
+        assertFalse(canonical.contains("a.name"));
+    }
+
     @Test
     void existingAnchorMustHaveExactMarkerAndRawIdentity() {
         var identity = java.util.Map.<String, Object>of("identity_version", 2,
                 "application_name", "app", "identity_namespace", "team");
         BoltWriter.requireCompatibleApplicationIdentity("can://team/app", identity, identity);
         for (var legacy : java.util.List.of(java.util.Map.<String, Object>of(),
                 java.util.Map.<String, Object>of("identity_version", 2.5, "application_name", "app", "identity_namespace", "team"),
                 java.util.Map.<String, Object>of("identity_version", 1, "application_name", "app", "identity_namespace", "team"),
                 java.util.Map.<String, Object>of("identity_version", 2, "application_name", "app", "identity_namespace", "other"))) {
             org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
diff --git a/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java b/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java
index 326aa544..cbb22946 100644
--- a/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java
+++ b/src/test/java/com/ibm/cldk/neo4j/CypherWriterStreamingTest.java
@@ -54,20 +54,38 @@ class CypherWriterStreamingTest {
             sink.write(cbuf, off, len);
         }
 
         @Override
         public void flush() {}
 
         @Override
         public void close() {}
     }
 
+    @Test
+    void actualV1SnapshotsReplaceOnlyTheNameKeyedLegacyApplication() {
+        GraphRows legacy = GraphProjector.project(Map.of(), null, "shared");
+        String script = CypherWriter.renderCypher(legacy, "shared");
+        assertTrue(script.contains("a.id IS NULL AND a.name = 'shared'"), script);
+        assertTrue(script.contains("OPTIONAL MATCH (a)-[:J_HAS_UNIT]->(c)"), script);
+        assertTrue(script.contains("OPTIONAL MATCH (c)-" + CypherWriter.DESCENDANTS + "->(x)"), script);
+        assertTrue(script.contains("DETACH DELETE x, c, a;"), script);
+        assertFalse(script.contains("STARTS WITH"), "v1 must not sweep a synthesized canonical root");
+        assertTrue(script.indexOf("DETACH DELETE x, c, a;") < script.indexOf("// ── nodes"));
+        var analysis = com.ibm.cldk.schema.V2Emitter.emit("shared", 1, Map.of(), null,
+                null, null, null, null, null, null, "team");
+        String canonical = CypherWriter.renderCypher(V2GraphProjector.project(analysis, "shared"), "shared");
+        assertTrue(canonical.contains("a.id = 'can://team/shared'"));
+        assertFalse(canonical.contains("a.name ="), "the same display name cannot activate v1 cleanup for v2");
+        assertFalse(canonical.contains("can://shared/shared"));
+    }
+
     @Test
     void streamedOutputIsIdenticalToTheRenderedString() throws IOException {
         GraphRows rows = sampleRows(1200); // > 2 batches of 500
         StringWriter w = new StringWriter();
         CypherWriter.writeCypher(w, rows, "app");
         assertEquals(CypherWriter.renderCypher(rows, "app"), w.toString(),
                 "streaming must not change a single byte of the emitted script");
     }
 
     @Test
# codeanalyzer-java: e35d7dcab8c62119a8bdeb4288e9d7cda523fb2e..cbfbd01dd9ed3f5bfca51237487d0273f4eff4ec
