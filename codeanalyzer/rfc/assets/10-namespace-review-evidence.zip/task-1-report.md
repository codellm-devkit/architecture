# Task 1 report

DONE_WITH_CONCERNS. No product code changed; no pushes. All five initial checkouts were clean, and all five were clean after fixture commits. Root architecture/plan artifacts are outside a Git repository.

## Fixtures

Six copies are byte-identical. SHA-256: `6bb6e909079045600ddb06606ca5d9c8f84eb30bf7f5bbc634213c3363a695b0`. Seven root cases cover defaults, percent encoding, Unicode (including decomposed/untrimmed input), and case distinctions; nine invalid values include escaped unpaired high/low surrogates. Go adapters must skip surrogate cases and exercise invalid UTF-8 separately. Six language module examples include Python, JavaScript, TypeScript, Java and Go. Duplicate rows are currency/payment/currency with expected unique count exactly two.

Fixture adapter keys: roots `application_name`, `namespace`, `expected_root`; invalid `value`, `reason`; modules `application_name`, `namespace`, `language`, `file_key`, `expected_uri`; duplicate_module_rows object `rows` (`module_id`, `file_key`) and `expected_unique_id_count`. Controller accepted this interface.

## Changed files

- `architecture/codeanalyzer/rfc/assets/10-identity-fixtures.json`
- `architecture/codeanalyzer/rfc/10-application-identity-namespaces.md` (tracking links)
- `docs/superpowers/plans/2026-10-30-application-identity-namespaces.md` (Task 1 checkboxes and evidence)
- `python-sdk/tests/resources/identity/namespaces.json`
- `codeanalyzer-python/test/fixtures/identity/namespaces.json`
- `codeanalyzer-typescript/test/fixtures/identity/namespaces.json`
- `codeanalyzer-java/src/test/resources/identity/namespaces.json`
- `codeanalyzer-go/internal/schema/v2/testdata/namespaces.json`
- Evidence files alongside this report: `task-1-baseline.json`, `task-1-commits.json`, `issue-bodies/{python-sdk,codeanalyzer-python,codeanalyzer-typescript,codeanalyzer-java,codeanalyzer-go}.md`. Exact issue body files were supplied to `gh issue create --body-file`.

## Tracking

- python-sdk: https://github.com/codellm-devkit/python-sdk/issues/435
- codeanalyzer-python: https://github.com/codellm-devkit/codeanalyzer-python/issues/236
- codeanalyzer-typescript: https://github.com/codellm-devkit/codeanalyzer-typescript/issues/221
- codeanalyzer-java: https://github.com/codellm-devkit/codeanalyzer-java/issues/276
- codeanalyzer-go: https://github.com/codellm-devkit/codeanalyzer-go/issues/40

Producer issues reference existing PRs Python #235, TypeScript/JavaScript #220, Java #275. SDK issue contains the public ownership reproduction and namespace contract. Duplicate checks used `gh issue list -R codellm-devkit/<repo> --search 'namespace OR ownership' --state all --limit 30 --json number,title,url`; no equivalent issue found. SDK #376 is related older single-app URI grammar work, not the two-segment namespace ownership contract. All publications succeeded with automatic approval; none were rejected.

## BASE / HEAD

- python-sdk (feat/application-identity-namespaces): BASE `1b49043c9d48505bfe92891787b84c7403155cda`; HEAD `7633dd2a61e20a603463946442705db817dbfebe`. Commit: `test: add namespace identity contract fixtures`.
- codeanalyzer-python (feat/add-workspace-root): BASE `4cd8c1f0c107a1fb23bfe5b26ccf7ae129499a84`; HEAD `94b331e9cb56902420409a3e569e2b1e91608e2d`. Commit: `test: add namespace identity contract fixtures`.
- codeanalyzer-typescript (feat/add-workspace-root): BASE `b41215f05f54eefe241724009a437b35e490b615`; HEAD `dbb5ccdcad46f5ce9c39e279297cf535579907d0`. Commit: `test: add namespace identity contract fixtures`.
- codeanalyzer-java (feat/add-workspace-root): BASE `90a48ca82a3a8011f9d58d9e167e60042df206b5`; HEAD `dcef0a6dcc32dbcb97295eb9de06e7e86b191eda`. Commit: `test: add namespace identity contract fixtures`.
- codeanalyzer-go (feat/application-identity-namespaces): BASE `25dc74f840360c8b2dbdd299f50b87a630272e6c`; HEAD `e65d73f1ff358dc9f43e21b12b774b4d68e5578c`. Commit: `test: add namespace identity contract fixtures`.

## Baseline checks

- python-sdk: `uv run --group test pytest tests/analysis/commons -q` → exit 127: /bin/sh: uv: command not found
- codeanalyzer-python: `uv run --group test pytest test/test_v2_ids.py -q` → exit 127: /bin/sh: uv: command not found
- codeanalyzer-typescript: `bun test test/ids.test.ts` → exit 127: /bin/sh: bun: command not found
- codeanalyzer-java: `./gradlew test --tests "*CanId*" --offline` → exit 1: The operation couldn’t be completed. Unable to locate a Java Runtime.
- codeanalyzer-go: `go test ./internal/schema/v2` → exit 127: /bin/sh: go: command not found

No dependency downloads were attempted, per controller direction. Python/SDK virtualenvs and TypeScript node_modules were absent. Baseline failures are environment prerequisites, not feature regressions. Java used offline Gradle to prevent dependency downloads.

## Verification

Executed a stdlib Python check against golden root outputs using urllib.parse.quote with safe `-._~`, asserted unique duplicate-row ID count equals two, and compared SHA-256 for all six fixture bytes: PASS. Executed `git -C <repo> diff --check` in all five repos: PASS. Fixture-only commits were inspected through recorded HEAD/status output: all clean. SDK resource ignore rules required `git add -f -- tests/resources/identity/namespaces.json`; only explicitly requested fixture files were staged/committed. No runtime product suite could run.
