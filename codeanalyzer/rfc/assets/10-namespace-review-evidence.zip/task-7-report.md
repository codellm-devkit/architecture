# Task 7: Canonical module indexes and deduplication

Complete on `feat/application-identity-namespaces`, base `1f3948976c2d14fb45a7585bcc5b05f07d9b2b15`.
Commit subject: `fix: preserve canonical module identity during deduplication`.
Implementation SHA: `72f14d7d9a6997019ff4ac079838505631df7540`. This report is local and ignored under the existing `.superpowers` policy; the commit contains the eight implementation/test files listed below.

## Work and reused partial implementation

Resumed the interrupted worker's uncommitted changes without resetting or redoing Task 6. Preserved its common index/scoped-key helpers, all four backend loader changes, initial index tests, TS conflicting-row test and currency/payment regression. Inspected and extended these changes with secondary owner/language/ambiguity checks, scanner canonical-module joining and routing, and two call-site retention coverage.

`index_module_rows` returns canonical-ID keys, collapses repeated identical projections and raises a diagnostic ValueError for conflicting file keys. `scoped_module_keys` validates the selected application and language before deriving the existing relative-key API; secondary candidates retain canonical IDs and ambiguous filenames raise instead of overwriting. All four graph loaders retain canonical primary indexes. Existing projections already carry module IDs alongside names/file keys (or inside full properties); no filename-only DISTINCT projection remains in these loaders.

Currency's `server.js` has `_loadProto` at lines 91–110 and no callable at line 28; payment's constructor spans lines 24–34. Both backend orders now exercise an exact canonical-module finding join, select one scoped backend, return no currency callable at 28, retain currency's callable at 91, and return payment's constructor only from payment.

Audited graph node/edge reconstruction: no new relationship deduplication was introduced. Existing call-site body-node IDs and relationship-specific projection fields remain intact. The bulk regression cleans duplicate module rows, then retains two distinct call sites at lines 28 and 31 to the same target. Existing call graphs deliberately aggregate endpoint pairs with weight/provenance; this task does not redesign them or invent context fields absent from the SDK models. Existing edge kind/var/provenance and site-containing canonical endpoints are unchanged.

## RED and GREEN evidence

All pytest commands below were run after `source /private/tmp/namespace-toolchains/sdk-env.sh`, using `.venv/bin/python` directly. No `uv run`, stale published producer reinstallation, corpus regeneration, Docker or graph writes.

1. Baseline replay: temporarily restored **all five implementation files** from HEAD in a Python try/finally, ran `.venv/bin/python -m pytest tests/analysis/commons/test_module_identity_index.py tests/analysis/typescript/test_typescript_neo4j_bulk.py --no-cov -q`, then restored the uncommitted implementation. **3 failed, 14 passed (1.40 s)**: absent index helper (two assertions) and loader failed to reject conflicting rows. Log `/private/tmp/task7-red.log`. An earlier incomplete baseline replay hit collection imports; the complete replay supersedes it.
2. Functional mutation RED: temporarily replaced canonical primary indexing with filename collapse followed by rekeying retained rows to their canonical IDs, ran `.venv/bin/python -m pytest tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py -k currency_scanner --no-cov -q`, then restored implementation in finally. **1 failed, 1 passed, 139 deselected (1.34 s)**: reverse order lost currency's canonical finding match. Log `/private/tmp/task7-functional-red.log`. The Task 6 bound locate behavior already passes against baseline; this mutation proves the new canonical-join regression detects filename deduplication without claiming a historical locate failure.
3. Broad relevant GREEN: `.venv/bin/python -m pytest tests/analysis/commons tests/analysis/go/test_go_neo4j_multi_application_scope.py tests/analysis/java/test_java_neo4j_multi_application_scope.py tests/analysis/python/test_neo4j_multi_application_scope.py tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py tests/analysis/typescript/test_typescript_neo4j_bulk.py tests/analysis/python/test_locate.py tests/analysis/java/test_java_addressing.py tests/analysis/java/test_java_addressing_rules.py tests/analysis/typescript/test_typescript_addressing.py --no-cov -q` — **596 passed, 2 skipped (10.23 s)**. Log `/private/tmp/task7-green.log`.
4. Final restored focused GREEN: `.venv/bin/python -m pytest tests/analysis/commons/test_module_identity_index.py tests/analysis/typescript/test_typescript_neo4j_bulk.py tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py --no-cov -q` — **163 passed (3.84 s)**. Log `/private/tmp/task7-focused-green.log`.
5. `git diff --check` — clean.

A full SDK run was started, then explicitly interrupted at the controller's request to defer combined verification until Task 8: 105 passed before KeyboardInterrupt, not a full-suite success claim. Log `/private/tmp/task7-full-green.log`.

## Exact changed files

- `cldk/analysis/commons/identity.py`
- `cldk/analysis/go/neo4j/neo4j_backend.py`
- `cldk/analysis/java/neo4j/neo4j_backend.py`
- `cldk/analysis/python/neo4j/neo4j_backend.py`
- `cldk/analysis/typescript/neo4j/neo4j_backend.py`
- `tests/analysis/commons/test_module_identity_index.py` (new)
- `tests/analysis/typescript/test_typescript_neo4j_bulk.py`
- `tests/analysis/typescript/test_typescript_neo4j_multi_application_scope.py`
- `.superpowers/sdd/2026-10-30-application-identity-namespaces/task-7-report.md` (new)

## Limits and concerns

Fake-driver SDK scope, reconstruction and canonical joins are covered; private scanner ingestion/integration joins and live Neo4j remain external coverage, not claimed here. Source-derived native producer checks from Task 6 were reused, not rerun or regenerated. The same reviewed local toolchain/provenance caveat remains: published dependency pins lag those artifacts. No producer release pins changed, no agents/reviewers spawned and no push performed.
