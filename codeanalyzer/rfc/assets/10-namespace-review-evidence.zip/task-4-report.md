# Task 4 — Java namespace identity

Implemented and committed on existing `feat/add-workspace-root` (no push).

- Base: `dcef0a6dcc32dbcb97295eb9de06e7e86b191eda`
- Commit: `e35d7dca` — `feat: qualify Java analysis identities by namespace`
- Repository: `/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java`
- Toolchain: Temurin 17.0.21, Gradle 8.9, isolated user home from `/private/tmp/namespace-toolchains/env.sh`.

## Result and contract audit

CLI `--namespace` replaces the unmerged `--workspace-root` option. Explicit empty app/namespace values fail; omitted app-name uses input basename, omitted namespace uses resolved app-name. App-name flag presence is checked per invocation to prevent the existing static app-name field leaking a prior invocation into default resolution. Namespace itself is an instance field.

`CanId.applicationId(appName, namespace)` validates raw names, preserves case/Unicode spelling, percent-encodes UTF-8 bytes with uppercase escapes, and always emits both root segments. Equivalent namespace overloads exist for artifact and external helpers. Tests consume the shared roots/invalid-name fixture and duplicate-module fixture; punctuation `!'()*~`, non-ASCII whitespace, unpaired UTF-16 surrogates, supplementary Unicode, and repeated default roots are covered.

Application-relative file keys and Java symbol/body suffixes remain unchanged. L1 extraction receives a canonical parent root. L2 external targets, config-read ghosts, and view-dispatch ghosts receive that same root via explicit canonical-parent entry points. Artifact/config/dependency references are rebuilt from source in the selected namespace. Package URLs remain unchanged. There is no mutable global namespace or string-based translation of old IDs.

Analysis envelopes carry required `identity_version: 2`; application JSON nodes retain raw `application_name` and `identity_namespace`. Graph anchors retain all three. No runtime defaults synthesize persisted identity metadata: `Analysis.identityVersion` is nullable, raw application fields are nullable, and graph projection rejects missing/inconsistent marker/root/raw names. Published JSON validator requires marker and raw fields, and root/reference regexes accept both ownership segments. `schema_version` remains `2.0.0`. `schema.neo4j.json` was regenerated from `V2SchemaCatalog` using `./gradlew run --args='--emit schema -o .'`.

The incremental L1 cache includes the canonical namespace/application root in its settings identity and a required marker. A missing-marker cache is ignored without modifying the persisted input. The CLI namespace-change regression reuses the same input/cache and checks every emitted canonical value/map key, module/type/callable/body/external/artifact references, and projected graph endpoints under the second root.

Bolt checks incoming metadata and the exact selected existing anchor's integer marker/raw names before DDL or writes. Incremental module hashes now traverse the exact selected anchor, preventing same-file content in another namespace from suppressing module insertion. Orphan pruning and artifact reconciliation use the selected root only. Name-based legacy fallback, legacy artifact-prefix cleanup, and global orphan-symbol deletion are removed. Shared-artifact retention logic remains intact. Existing live coverage for sibling markers, unmarked sibling inventory, config-key retention, config-only edits, manifest/lock changes, and idempotent pushes is retained; workspace-only cases now cover namespace separation/application-relative keys and explicit legacy retirement.

`RowBuilder` deduplicates canonical entities and edge endpoints by ID, unions labels, rejects conflicting canonical properties/key semantics, and retains relationship kind and `_k` site/context discriminators. Legacy v1 node/endpoint keys retain their prior label scope. No conflicting canonical records were encountered in the available full suite.

Inventory exceptions: `GraphProjector.java` remains unchanged because it is the legacy v1 projector, whose public APIs and FQN suffixes require no namespace input; explicit schema-v1 namespace requests are rejected before extraction. Existing canonical-parent builders such as `L1BuildContext`, type/callable/body builders and SDG passes forward their parent root unchanged and therefore needed no mechanical namespace parameters.

Offline Cypher generation validates incoming model metadata through `V2GraphProjector` and obtains its scope from the projected canonical anchor. It does not inspect an existing database or introduce speculative Cypher error guards/APOC. Snapshot execution belongs to explicit regeneration; existing-database compatibility is checked by the connected Bolt path. Snapshot artifact rebuilding retains its documented existing behavior, including replacing shared-artifact edges within the selected application; incremental Bolt remains the path preserving sibling claims/edges.

## Verification

All Gradle commands first source `/private/tmp/namespace-toolchains/env.sh`.

| Gate | Outcome |
| --- | --- |
| Golden-root/API RED | Expected compile failure: missing two-argument applicationId overload. |
| Graph-marker/prune RED | 18 tests, 2 expected failures: missing-marker projection accepted and legacy name fallback. |
| Namespace incremental-hash RED | Expected compile failure for absent selected-anchor query constant. |
| Repeated-invocation defaults RED | Expected failure: prior static app-name leaked into omitted app-name. |
| Existing-anchor RED | Expected compile failure for absent shared validator. |
| Fractional marker RED | 7 tests, 1 expected failure: fractional marker was truncated/accepted. |
| Canonical dedup/conflict RED | 2 tests, 2 expected failures. |
| Focused requested classes + cache + canonical dedup | All 74 tests pass in final full-suite XML (40 CLI, 10 CanId, 13 V2Json, 7 BoltWriterPurge, 2 L1Cache, 2 CanonicalIdentityRows). |
| Unfiltered `./gradlew test --console=plain` | 636 tests, 1 failure, 17 skipped. Only failure: `CodeAnalyzerIntegrationTest.initializationError`, no valid Docker environment. |
| `./gradlew test -I /private/tmp/task4-no-docker.gradle --console=plain` | BUILD SUCCESSFUL; 635 tests, 0 failures, 17 skipped. External init script excludes only `**/CodeAnalyzerIntegrationTest.class`; no repository gate weakened. |
| Bounded real-world gate | `./gradlew realWorldConformanceTest --tests com.ibm.cldk.schema.L1ConformanceGateTest --console=plain` under 90-second process timeout: BUILD SUCCESSFUL, both methods skipped because application git submodules are absent. No real-world execution claimed. |
| Live namespace/shared-artifact Neo4j tests | Retained/adapted, unavailable here: RUN_CONTAINER_TESTS unset and no Docker runtime. |
| `git diff --check` | Clean. |

The initial sandboxed Gradle attempt failed with `java.net.SocketException: Operation not permitted`; Gradle daemon sockets require escalated execution in this environment. Separate escalated Gradle calls worked.

Automatic approval review rejected a combined escalated edit/run command because it proposed broad regex rewrites across every Java test and truncating the workspace-only test section. That command did not execute. The safe alternative used narrow, reviewed fixture expectation updates and adapted each existing workspace CLI case while retaining its assertions, then ran Gradle separately. No rejected operation was bypassed and no user approval remained necessary. The superseded draft design document was replaced with the accepted namespace contract.

## Exact captured logs

The logs below are verbatim from `/private/tmp`; individual paths remain available in this session. Intermediate failed full runs identified stale fixture metadata/expectations, which were repaired without weakening schema validation. The final unfiltered failure is solely the unavailable Docker initialization gate.

### Root/API RED

`/private/tmp/task4-red.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE

> Task :compileTestJava FAILED
/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/src/test/java/com/ibm/cldk/schema/CanIdTest.java:23: error: method applicationId in class CanId cannot be applied to given types;
            assertEquals(r.get("expected_root").getAsString(), CanId.applicationId(r.get("application_name").getAsString(), ns));
                                                                    ^
  required: String
  found: String,String
  reason: actual and formal argument lists differ in length
/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/src/test/java/com/ibm/cldk/schema/CanIdTest.java:28: error: method applicationId in class CanId cannot be applied to given types;
            org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class, () -> CanId.applicationId("app", value));
                                                                                                     ^
  required: String
  found: String,String
  reason: actual and formal argument lists differ in length
/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/src/test/java/com/ibm/cldk/schema/CanIdTest.java:30: error: method applicationId in class CanId cannot be applied to given types;
        assertEquals("can://team/%21%27%28%29%2A~", CanId.applicationId("!'()*~", "team"));
                                                         ^
  required: String
  found: String,String
  reason: actual and formal argument lists differ in length
/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/src/test/java/com/ibm/cldk/schema/CanIdTest.java:34: error: method applicationId in class CanId cannot be applied to given types;
        assertEquals("can://team/%F0%9F%98%80", CanId.applicationId("😀", "team"));
                                                     ^
  required: String
  found: String,String
  reason: actual and formal argument lists differ in length
4 errors

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':compileTestJava'.
> Compilation failed; see the compiler error output for details.

* Try:
> Run with --info option to get more log output.
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 1s
7 actionable tasks: 3 executed, 4 up-to-date
```

### Graph compatibility RED

`/private/tmp/task4-graph-red.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply

> Task :compileJava
Note: ReflectConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/reflect-config.json
Note: ResourceConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/resource-config.json
Note: ProxyConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/proxy-config.json
Note: Some input files use unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details.

> Task :processResources UP-TO-DATE
> Task :classes
> Task :jar
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava
> Task :processTestResources UP-TO-DATE
> Task :testClasses

> Task :test FAILED

BoltWriterPurgeTest > orphanPruneNeverFallsBackToLegacyName() FAILED
    org.opentest4j.AssertionFailedError at BoltWriterPurgeTest.java:69

V2JsonTest > identityMetadataIsRequiredAndNotDefaultedWhenReadingOldPayloads() FAILED
    org.opentest4j.AssertionFailedError at V2JsonTest.java:58

18 tests completed, 2 failed

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':test'.
> There were failing tests. See the report at: file:///Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/build/reports/tests/test/index.html

* Try:
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 3s
9 actionable tasks: 6 executed, 3 up-to-date
```

### Invocation default RED

`/private/tmp/task4-default-red.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava
> Task :processTestResources UP-TO-DATE
> Task :testClasses

> Task :test FAILED

CodeAnalyzerV2CliTest > omittedIdentityFlagsDoNotReusePreviousInvocation(Path) FAILED
    org.opentest4j.AssertionFailedError at CodeAnalyzerV2CliTest.java:919

1 test completed, 1 failed

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':test'.
> There were failing tests. See the report at: file:///Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/build/reports/tests/test/index.html

* Try:
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 2s
9 actionable tasks: 4 executed, 5 up-to-date
```

### Fractional marker RED

`/private/tmp/task4-integer-red.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava
> Task :processTestResources UP-TO-DATE
> Task :testClasses

> Task :test FAILED

BoltWriterPurgeTest > existingAnchorMustHaveExactMarkerAndRawIdentity() FAILED
    org.opentest4j.AssertionFailedError at BoltWriterPurgeTest.java:37

7 tests completed, 1 failed

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':test'.
> There were failing tests. See the report at: file:///Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/build/reports/tests/test/index.html

* Try:
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 1s
9 actionable tasks: 4 executed, 5 up-to-date
```

### Canonical dedup RED

`/private/tmp/task4-dedup-red.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava
> Task :processTestResources UP-TO-DATE
> Task :testClasses

> Task :test FAILED

CanonicalIdentityRowsTest > conflictingCanonicalEntityPropertiesAreRejected() FAILED
    org.opentest4j.AssertionFailedError at CanonicalIdentityRowsTest.java:18

CanonicalIdentityRowsTest > canonicalIdsDeduplicateAcrossLabelsWithoutCollapsingEdgeKindsOrSites() FAILED
    org.opentest4j.AssertionFailedError at CanonicalIdentityRowsTest.java:43

2 tests completed, 2 failed

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':test'.
> There were failing tests. See the report at: file:///Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/build/reports/tests/test/index.html

* Try:
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 1s
9 actionable tasks: 4 executed, 5 up-to-date
```

### Canonical dedup GREEN

`/private/tmp/task4-dedup-green.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply

> Task :compileJava
Note: ReflectConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/reflect-config.json
Note: ResourceConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/resource-config.json
Note: ProxyConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/proxy-config.json
Note: Some input files use unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details.

> Task :processResources UP-TO-DATE
> Task :classes
> Task :jar
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava UP-TO-DATE
> Task :processTestResources UP-TO-DATE
> Task :testClasses UP-TO-DATE
> Task :test

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD SUCCESSFUL in 3s
9 actionable tasks: 5 executed, 4 up-to-date
```

### Focused GREEN

`/private/tmp/task4-focused-final.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply
> Task :compileJava
Note: ReflectConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/reflect-config.json
Note: ResourceConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/resource-config.json
Note: ProxyConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/proxy-config.json
Note: Some input files use unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details.

> Task :processResources UP-TO-DATE
> Task :classes
> Task :jar
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava UP-TO-DATE
> Task :processTestResources UP-TO-DATE
> Task :testClasses UP-TO-DATE
> Task :test

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD SUCCESSFUL in 7m 37s
9 actionable tasks: 5 executed, 4 up-to-date
```

### Final unfiltered full suite

`/private/tmp/task4-full-final.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava UP-TO-DATE
> Task :spotlessJavaApply UP-TO-DATE
> Task :spotlessApply UP-TO-DATE
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava UP-TO-DATE
> Task :processTestResources UP-TO-DATE
> Task :testClasses UP-TO-DATE

> Task :test

CodeAnalyzerIntegrationTest > initializationError FAILED
    java.lang.IllegalStateException at DockerClientProviderStrategy.java:274

636 tests completed, 1 failed, 17 skipped

> Task :test FAILED

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':test'.
> There were failing tests. See the report at: file:///Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/build/reports/tests/test/index.html

* Try:
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 11s
9 actionable tasks: 1 executed, 8 up-to-date
```

### Final available full suite

`/private/tmp/task4-no-docker-final.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava UP-TO-DATE
> Task :spotlessJavaApply UP-TO-DATE
> Task :spotlessApply UP-TO-DATE
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava UP-TO-DATE
> Task :processTestResources UP-TO-DATE
> Task :testClasses UP-TO-DATE
> Task :test

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD SUCCESSFUL in 3s
9 actionable tasks: 1 executed, 8 up-to-date
```

### Bounded real-world gate

`/private/tmp/task4-realworld.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava UP-TO-DATE
> Task :spotlessJavaApply UP-TO-DATE
> Task :spotlessApply UP-TO-DATE
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava UP-TO-DATE
> Task :processTestResources UP-TO-DATE
> Task :testClasses UP-TO-DATE

> Task :realWorldConformanceTest

L1ConformanceGateTest > springPetclinicResolvesFrameworkAnnotationsAndEntrypoints() SKIPPED

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD SUCCESSFUL in 826ms
9 actionable tasks: 1 executed, 8 up-to-date
```

## Round 1 review fixes — explicit legacy v1 cleanup

Fix base: `e35d7dcab8c62119a8bdeb4288e9d7cda523fb2e`.
Fix commit: `cbfbd01dd9ed3f5bfca51237487d0273f4eff4ec` — `fix: preserve explicit legacy Java graph cleanup` (no push).

Both P2 findings were verified against `GraphProjector`: actual v1 anchors are name-keyed and have no canonical id, so the prior canonical-only shared-writer cleanup could not reach them. This was a regression in supported explicit v1 requests, not an authorized removal of legacy-v1 behavior.

The snapshot writer now selects a dedicated legacy containment wipe only when incoming rows contain an actual name-keyed `JApplication`. Its database predicate requires `a.id IS NULL AND a.name = <selected-name>`, traverses `J_HAS_UNIT` and Java containment, and deletes the previous units/declarations/edges/anchor before new node statements. It does not synthesize or sweep a canonical prefix for v1.

Full-run Bolt pruning uses the same incoming-row schema-family selection. V1 uses the id-less/name-matching anchor, `J_HAS_UNIT`, and the existing `present` file-key set; v2 retains the exact `a.id = $appId` query. No v2-to-v1 fallback or automatic legacy migration was introduced. A namespaced v2 anchor with the same display name has a non-null id and cannot match either legacy predicate.

Targeted regressions use real legacy `GraphProjector` output and real `V2Emitter`/`V2GraphProjector` output with a shared display name. They verify snapshot replacement ordering and containment deletion, full-run vanished-unit query selection, the id-less guard protecting v2 anchors, and v2's continued refusal to select any name predicate. These are generated-query and selector tests; live query execution remains unavailable without Docker. Whole-suite repetition was intentionally omitted for this narrowly scoped reviewed fix, as requested; the prior full-suite results above remain the baseline evidence.

Exact RED/GREEN command (after sourcing `/private/tmp/namespace-toolchains/env.sh`):

```sh
./gradlew test --tests com.ibm.cldk.neo4j.CypherWriterStreamingTest --tests com.ibm.cldk.neo4j.BoltWriterPurgeTest --console=plain
```

The initial API RED failed compilation because `orphanPruneQuery` was absent. After exposing the existing unchanged v2 query via that selector, behavioral RED ran all 16 targeted tests and failed exactly the two new v1 regressions. GREEN passed all 16 tests. `git diff --check` was clean and the Java working tree is clean after the fix commit.

### Round 1 Initial API RED

`/private/tmp/task4-review-red.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply
> Task :compileJava UP-TO-DATE
> Task :processResources UP-TO-DATE
> Task :classes UP-TO-DATE
> Task :jar UP-TO-DATE
> Task :compileTestKotlin NO-SOURCE

> Task :compileTestJava FAILED
/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java:31: error: cannot find symbol
        String query = BoltWriter.orphanPruneQuery(legacy);
                                 ^
  symbol:   method orphanPruneQuery(GraphRows)
  location: class BoltWriter
/Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/src/test/java/com/ibm/cldk/neo4j/BoltWriterPurgeTest.java:39: error: cannot find symbol
        String canonical = BoltWriter.orphanPruneQuery(V2GraphProjector.project(analysis, "shared"));
                                     ^
  symbol:   method orphanPruneQuery(GraphRows)
  location: class BoltWriter
2 errors

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':compileTestJava'.
> Compilation failed; see the compiler error output for details.

* Try:
> Run with --info option to get more log output.
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 1s
7 actionable tasks: 3 executed, 4 up-to-date
```

### Round 1 Behavioral RED

`/private/tmp/task4-review-red-behavior.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply

> Task :compileJava
Note: ReflectConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/reflect-config.json
Note: ResourceConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/resource-config.json
Note: ProxyConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/proxy-config.json
Note: Some input files use unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details.

> Task :processResources UP-TO-DATE
> Task :classes
> Task :jar
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava
> Task :processTestResources UP-TO-DATE
> Task :testClasses

> Task :test FAILED

BoltWriterPurgeTest > fullRunPruneSelectsActualSchemaFamilyAndProtectsSharedDisplayNames() FAILED
    org.opentest4j.AssertionFailedError at BoltWriterPurgeTest.java:32

CypherWriterStreamingTest > actualV1SnapshotsReplaceOnlyTheNameKeyedLegacyApplication() FAILED
    org.opentest4j.AssertionFailedError at CypherWriterStreamingTest.java:68

16 tests completed, 2 failed

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':test'.
> There were failing tests. See the report at: file:///Users/rkrsn/workspace/codellm-devkit/codeanalyzer-java/build/reports/tests/test/index.html

* Try:
> Run with --scan to get full insights.

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD FAILED in 3s
9 actionable tasks: 6 executed, 3 up-to-date
```

### Round 1 GREEN

`/private/tmp/task4-review-green.log`

```text
> Task :checkKotlinGradlePluginConfigurationErrors SKIPPED
> Task :compileKotlin NO-SOURCE
> Task :spotlessInternalRegisterDependencies UP-TO-DATE
> Task :spotlessJava
> Task :spotlessJavaApply
> Task :spotlessApply

> Task :compileJava
Note: ReflectConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/reflect-config.json
Note: ResourceConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/resource-config.json
Note: ProxyConfigGen writing to: CLASS_OUTPUT/META-INF/native-image/picocli-generated/proxy-config.json
Note: Some input files use unchecked or unsafe operations.
Note: Recompile with -Xlint:unchecked for details.

> Task :processResources UP-TO-DATE
> Task :classes
> Task :jar
> Task :compileTestKotlin NO-SOURCE
> Task :compileTestJava
> Task :processTestResources UP-TO-DATE
> Task :testClasses
> Task :test

Deprecated Gradle features were used in this build, making it incompatible with Gradle 9.0.

You can use '--warning-mode all' to show the individual deprecation warnings and determine if they come from your own scripts or plugins.

For more on this, please refer to https://docs.gradle.org/8.9/userguide/command_line_interface.html#sec:command_line_warnings in the Gradle documentation.

BUILD SUCCESSFUL in 3s
9 actionable tasks: 6 executed, 3 up-to-date
```
