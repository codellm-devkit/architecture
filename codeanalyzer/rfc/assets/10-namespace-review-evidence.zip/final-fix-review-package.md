b659966 Guard stored application identity before Bolt mutations
 codeanalyzer/neo4j/bolt.py        | 34 +++++++++++++++++++++++++-----
 codeanalyzer/schema/py_schema.py  | 10 ++++++++-
 docs/handoff/README.md            | 10 ++++-----
 test/test_neo4j_bolt_streaming.py | 44 +++++++++++++++++++++++++++++++++++++++
 4 files changed, 87 insertions(+), 11 deletions(-)
diff --git a/codeanalyzer/neo4j/bolt.py b/codeanalyzer/neo4j/bolt.py
index 0a69569..571b007 100644
--- a/codeanalyzer/neo4j/bolt.py
+++ b/codeanalyzer/neo4j/bolt.py
@@ -271,20 +271,40 @@ class _EdgeBatches(RowBuilder):
 
     def _flush(self):
         _upsert_edges(self._session, self._neo4j, self._pending)
         self._pending, self._waiting = [], set()
 
     def finish(self):
         self._flush()
         return GraphRows([], [])
 
 
+def _validate_stored_identity(session, app_name, namespace):
+    """Read the selected anchor before schema or graph mutations; absence is fresh."""
+    from codeanalyzer.schema.ids import application_id
+
+    app_id = application_id(app_name, namespace)
+    record = session.run(
+        "MATCH (a:PyApplication {id: $id}) RETURN properties(a) AS identity",
+        id=app_id,
+    ).single()
+    if record is None:
+        return
+    metadata = record["identity"]
+    expected_namespace = app_name if namespace is None else namespace
+    if (type(metadata.get("identity_version")) is not int
+            or metadata.get("identity_version") != 2
+            or metadata.get("application_name") != app_name
+            or metadata.get("identity_namespace") != expected_namespace):
+        raise ValueError("Stored application identity is missing or incompatible")
+
+
 def bolt_writer_streaming(app, app_name, sig_to_id, analyzer, cfg: BoltConfig, full_run: bool,
                           eager: bool = False, namespace: str | None = None) -> None:
     """:func:`bolt_writer` without materializing :class:`GraphRows`: the projection
     runs twice (nodes, then relationships) and is written in bounded batches."""
     try:
         import neo4j  # noqa: WPS433 (lazy, optional dependency)
     except ImportError as exc:  # pragma: no cover - exercised only without the extra
         raise RuntimeError(
             "The 'neo4j' driver is required for a live Bolt push. "
             "Install it with: pip install 'codeanalyzer-python[neo4j]'"
@@ -294,20 +314,21 @@ def bolt_writer_streaming(app, app_name, sig_to_id, analyzer, cfg: BoltConfig, f
     app_prefix = application_prefix(app_name, namespace)
     driver = neo4j.GraphDatabase.driver(cfg.uri, auth=(cfg.user, cfg.password))
 
     session_kwargs = {"database": cfg.database} if cfg.database else {}
 
     def session():
         return driver.session(**session_kwargs)
 
     try:
         with session() as s:
+            _validate_stored_identity(s, app_name, namespace)
             for stmt in CONSTRAINTS + INDEXES:
                 s.run(stmt).consume()
             db_hash = {rec["k"]: rec["h"] for rec in s.run(
                 f"MATCH (m:PyModule:{CAN_NODE}) WHERE m.id STARTS WITH $app "
                 "RETURN m.id AS k, m.content_hash AS h", app=app_prefix,
             )}
         changed = {key for key, mod in app.symbol_table.items()
                    if mod.id not in db_hash or mod.content_hash is None
                    or mod.content_hash != db_hash[mod.id]}
         logger.info(f"neo4j(bolt): {len(app.symbol_table)} modules ({len(changed)} changed)")
@@ -343,42 +364,45 @@ def bolt_writer(rows: GraphRows, cfg: BoltConfig, full_run: bool, eager: bool =
             "Install it with: pip install 'codeanalyzer-python[neo4j]'"
         ) from exc
 
     driver = neo4j.GraphDatabase.driver(cfg.uri, auth=(cfg.user, cfg.password))
     session_kwargs = {"database": cfg.database} if cfg.database else {}
 
     def session():
         return driver.session(**session_kwargs)
 
     try:
-        # 1. schema (DDL runs in its own autocommit transactions).
-        with session() as s:
-            for stmt in [*CONSTRAINTS, *INDEXES]:
-                s.run(stmt)
-
         # The application anchor. Every destructive statement below is scoped to
         # ``can://<app>/``; an empty application is refused up front rather than
         # becoming ``STARTS WITH ''`` (every node in the database). The root row is
         # keyed on its ``can://`` id now, so the name comes off its props — reading
         # ``n.value`` here would build ``can://can://<app>/``.
         app_name = next(
             (
                 n.props.get("name")
                 for n in rows.nodes
                 if n.labels and n.labels[0] == "PyApplication"
             ),
             None,
         )
         namespace = next((n.props.get("identity_namespace") for n in rows.nodes
                           if n.labels and n.labels[0] == "PyApplication"), None)
         app_prefix = application_prefix(app_name, namespace)
 
+        with session() as s:
+            _validate_stored_identity(s, app_name, namespace)
+
+        # 1. schema (DDL runs in its own autocommit transactions).
+        with session() as s:
+            for stmt in [*CONSTRAINTS, *INDEXES]:
+                s.run(stmt)
+
         # Partition nodes by owning module (an in-memory field, never emitted, #173);
         # shared nodes have none.
         by_module: Dict[str, List[NodeRow]] = {}
         shared: List[NodeRow] = []
         module_of: Dict[str, str] = {}  # node value → owning module
         for n in rows.nodes:
             if n.module is not None:
                 by_module.setdefault(n.module, []).append(n)
                 module_of[n.value] = n.module
             else:
diff --git a/codeanalyzer/schema/py_schema.py b/codeanalyzer/schema/py_schema.py
index 4ab5702..2f16a13 100644
--- a/codeanalyzer/schema/py_schema.py
+++ b/codeanalyzer/schema/py_schema.py
@@ -17,21 +17,21 @@
 """Python schema models module.
 
 This module defines the data models used to represent Python code structures
 for static analysis purposes.
 """
 from __future__ import annotations
 from pathlib import Path
 import dataclasses as _dataclasses
 from dataclasses import dataclass, field as _dc_field
 from typing import Any, Dict, List, Optional, Tuple
-from pydantic import BaseModel, model_validator
+from pydantic import BaseModel, field_validator, model_validator
 from typing_extensions import Literal
 
 
 def builder(cls):
     """
     Decorator that generates a builder class for a Pydantic models defined below.
 
     It creates methods like:
         - <fieldname>(value)
         - build() to instantiate the model
@@ -649,20 +649,28 @@ class PyApplication(BaseModel):
     repository: Optional[PyRepositoryInfo] = None
     # Interprocedural parameter-passing edges (formal↔actual); populated at L4.
     param_in: List[ParamEdge] = []
     param_out: List[ParamEdge] = []
     # config_use (#162): PY_USES_CONFIG edges + first-class unresolved reads.
     # Literal tier from L2; dataflow tiers widen the set at L3/L4 (additive).
     config_uses: List[PyConfigUseEdge] = []
     config_reads_unresolved: List[PyConfigRead] = []
 
 
+    @field_validator("identity_version", mode="before")
+    @classmethod
+    def validate_identity_version(cls, value):
+        if type(value) is not int or value != 2:
+            raise ValueError("application identity_version must be integer 2")
+        return value
+
+
 @builder
 class Analysis(BaseModel):
     """v2 payload root: envelope + the application tree node. ``k_limit`` is an
     L3+ envelope key (None below the dataflow levels; exclude_none drops it)."""
     schema_version: str = "2.0.0"
     identity_version: Literal[2]
     language: str = "python"
     max_level: int = 1
     k_limit: Optional[int] = None
     analyzer: PyAnalyzerInfo = PyAnalyzerInfo()
diff --git a/docs/handoff/README.md b/docs/handoff/README.md
index 242482f..423fb23 100644
--- a/docs/handoff/README.md
+++ b/docs/handoff/README.md
@@ -130,25 +130,25 @@ class Service(BaseService):
 def build(x):
     y = x
     return y
 
 def run(flag):
     svc = Service()
     return svc.announce(flag)
 ```
 
 ```
-python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app -a 1 -o <tmp> --no-venv   # → analysis.l1.json
-python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app -a 2 -o <tmp> --no-venv   # → analysis.l2.json
-python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app -a 3 -o <tmp> --no-venv   # → analysis.l3.json
-python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app -a 4 -o <tmp> --no-venv   # → analysis.l4.json
-python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app --app-name sample-app --namespace sample-app --emit neo4j -o <tmp> --no-venv   # → graph.cypher
+python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app -a 1 -o <tmp> --no-venv   # → analysis.l1.json
+python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app -a 2 -o <tmp> --no-venv   # → analysis.l2.json
+python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app -a 3 -o <tmp> --no-venv   # → analysis.l3.json
+python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app -a 4 -o <tmp> --no-venv   # → analysis.l4.json
+python -m codeanalyzer -i <sample> --app-name sample-app --namespace sample-app --emit neo4j -o <tmp> --no-venv   # → graph.cypher
 python -m codeanalyzer --emit schema -o <tmp>                # → schema.json
 ```
 
 In `analysis.l4.json`, the interprocedural flow to verify:
 `Service.announce` calls `build(flag)` → an `actual_in`/`actual_out` pair at the
 callsite, a `summary` edge over `build`'s pass-through, `param_in`/`param_out`
 edges bridging actual ⇄ `build`'s formals, and a `prov:["points-to"]` `ddg` edge
 in `run` from the `Service()` construction to the `svc.announce` use.
 
 ## Follow-up: the SDK model revision consumes this bundle
diff --git a/test/test_neo4j_bolt_streaming.py b/test/test_neo4j_bolt_streaming.py
index b4876e1..7b865b7 100644
--- a/test/test_neo4j_bolt_streaming.py
+++ b/test/test_neo4j_bolt_streaming.py
@@ -19,10 +19,54 @@ def test_batches_do_not_retain_the_graph(monkeypatch):
             nodes.node(["PyBodyNode"], "id", f"{prefix}python/m.py/f()@{i}:0", {"kind": "statement"})
             edges.edge("PY_DDG", NodeRef("PyBodyNode", "id", f"{prefix}s{i}"),
                        NodeRef("PyBodyNode", "id", f"{prefix}t{i}"), {"var": "x"}, key="x|ssa")
         nodes.finish()
         edges.finish()
         _, peak = tracemalloc.get_traced_memory()
     finally:
         tracemalloc.stop()
     assert sum(sizes) == 100_000 and max(sizes) <= bolt.BATCH
     assert peak < 4 * 1024 * 1024, f"streaming retained {peak} bytes for 100k rows"
+
+
+import sys
+from types import SimpleNamespace
+import pytest
+from codeanalyzer.neo4j.rows import GraphRows, NodeRow
+
+
+@pytest.mark.parametrize("streaming", [False, True])
+@pytest.mark.parametrize("metadata", [
+    {}, {"identity_version": 2, "application_name": "app"},
+    {"identity_version": 2, "identity_namespace": "team"},
+    {"identity_version": 2.0, "application_name": "app", "identity_namespace": "team"},
+    {"identity_version": True, "application_name": "app", "identity_namespace": "team"},
+    {"identity_version": 2, "application_name": "other", "identity_namespace": "team"},
+    {"identity_version": 2, "application_name": "app", "identity_namespace": "other"},
+])
+def test_stored_identity_rejected_before_any_write(monkeypatch, streaming, metadata):
+    queries = []
+    class Session:
+        def __enter__(self): return self
+        def __exit__(self, *args): pass
+        def run(self, query, **params):
+            queries.append(query)
+            assert query.startswith("MATCH (a:PyApplication"), "write or unrelated read before identity guard"
+            assert params == {"id": "can://team/app"}
+            return SimpleNamespace(single=lambda: {"identity": metadata})
+    driver = SimpleNamespace(session=lambda **kw: Session(), close=lambda: None)
+    monkeypatch.setitem(sys.modules, "neo4j", SimpleNamespace(GraphDatabase=SimpleNamespace(driver=lambda *a, **kw: driver)))
+    cfg = bolt.BoltConfig("bolt://unused", "user", "password")
+    with pytest.raises(ValueError, match="identity"):
+        if streaming:
+            bolt.bolt_writer_streaming(SimpleNamespace(symbol_table={}), "app", {}, None, cfg, True, namespace="team")
+        else:
+            rows = GraphRows([NodeRow(["PyApplication"], "id", "can://team/app", {"name": "app", "identity_namespace": "team"})], [])
+            bolt.bolt_writer(rows, cfg, True)
+    assert len(queries) == 1
+
+
+def test_stored_identity_allows_fresh_or_matching_anchor():
+    for metadata in [None, {"identity_version": 2, "application_name": "app", "identity_namespace": "team"}]:
+        result = None if metadata is None else {"identity": metadata}
+        session = SimpleNamespace(run=lambda *args, **kwargs: SimpleNamespace(single=lambda: result))
+        bolt._validate_stored_identity(session, "app", "team")
89b95237 Document strict canonical node property conflict contract
 src/main/java/com/ibm/cldk/neo4j/RowBuilder.java                | 4 +++-
 src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java | 9 +++++++++
 2 files changed, 12 insertions(+), 1 deletion(-)
diff --git a/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java b/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java
index e11e9242..92d0eeae 100644
--- a/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java
+++ b/src/main/java/com/ibm/cldk/neo4j/RowBuilder.java
@@ -21,21 +21,23 @@ import java.util.LinkedHashMap;
 import java.util.List;
 import java.util.Map;
 import java.util.Set;
 
 /**
  * Accumulates nodes/edges with {@code MERGE} semantics in memory, so the same node touched many
  * times (a hot annotation, a canonical package) collapses to one row, and cross-reference edges to
  * a target that never materialized are dropped (the "edge-only-when-resolved" rule).
  *
  * <p>This is the in-memory analog of {@code MERGE (n:Label {key}) SET n += props}: re-seeing the
- * same (mergeLabel, value) merges props (last write wins) and unions labels.
+ * same canonical ID merges compatible properties and unions labels. A differing value for any
+ * existing node property, including an ordinary display property, is rejected rather than refined.
+ * Noncanonical rows retain their label/key identity.
  */
 public final class RowBuilder {
 
     /** key: {@code labels[0] + " " + value}. */
     private final Map<String, NodeRow> nodes = new LinkedHashMap<>();
     private final List<EdgeRow> edges = new ArrayList<>();
     /** Edges gated against node existence at {@link #finish()}. */
     private final List<EdgeRow> deferred = new ArrayList<>();
     /** Every node value seen, for resolved-gating. */
     private final Set<String> keys = new HashSet<>();
diff --git a/src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java b/src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java
index 2ee7b680..4b130388 100644
--- a/src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java
+++ b/src/test/java/com/ibm/cldk/neo4j/CanonicalIdentityRowsTest.java
@@ -12,20 +12,29 @@ import org.junit.jupiter.api.Test;
 class CanonicalIdentityRowsTest {
     @Test
     void conflictingCanonicalEntityPropertiesAreRejected() {
         RowBuilder builder = new RowBuilder();
         String id = "can://team/app/java/Foo.java/Foo";
         builder.node(List.of("JSymbol"), "id", id, Map.of("kind", "class"));
         org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
                 () -> builder.node(List.of("JType"), "id", id, Map.of("kind", "method")));
     }
 
+    @Test
+    void ordinaryCanonicalDisplayPropertyRefinementIsRejected() {
+        RowBuilder builder = new RowBuilder();
+        String id = "can://team/app/java/Foo.java/Foo";
+        builder.node(List.of("JSymbol"), "id", id, Map.of("name", "Foo"));
+        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
+                () -> builder.node(List.of("JSymbol"), "id", id, Map.of("name", "refined Foo")));
+    }
+
     @Test
     void canonicalIdsDeduplicateAcrossLabelsWithoutCollapsingEdgeKindsOrSites() throws Exception {
         var fixture = JsonParser.parseReader(new InputStreamReader(
                 getClass().getResourceAsStream("/identity/namespaces.json"), StandardCharsets.UTF_8))
                 .getAsJsonObject().getAsJsonObject("duplicate_module_rows");
         RowBuilder builder = new RowBuilder();
         GraphRows.NodeRef first = null;
         GraphRows.NodeRef second = null;
         for (var row : fixture.getAsJsonArray("rows")) {
             String id = row.getAsJsonObject().get("module_id").getAsString();
f66a589 Reject contradictory stored application owners before graph writes
 internal/neo4j/bolt.go              | 12 +++++++-
 internal/neo4j/bolt_session_test.go | 60 +++++++++++++++++++++++++++++++++----
 2 files changed, 66 insertions(+), 6 deletions(-)
diff --git a/internal/neo4j/bolt.go b/internal/neo4j/bolt.go
index baaf0e2..da5b001 100644
--- a/internal/neo4j/bolt.go
+++ b/internal/neo4j/bolt.go
@@ -1,15 +1,16 @@
 package neo4j
 
 import (
 	"context"
 	"fmt"
+	v2 "github.com/codellm-devkit/codeanalyzer-go/internal/schema/v2"
 	"sort"
 
 	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
 )
 
 // Milestone M5: the incremental Bolt writer. It pushes a GraphRows bag into a
 // live Neo4j over Bolt, updating ONLY what changed, with the module subgraph as
 // the unit of idempotent replacement. The neo4j driver is pure Go, so a
 // CGO_ENABLED=0 static build still links; it is only exercised when EmitNeo4j
 // runs with a --neo4j-uri, never on the JSON path.
@@ -202,30 +203,39 @@ func (w *boltWriter) ensureDDL() error {
 //     so the push fails safe.
 //
 // No stored application (first push) forces nothing beyond the normal
 // upsert, nor does a stored level at or above this push's.
 func (w *boltWriter) storedAppStale() (bool, error) {
 	var stored string
 	var storedLevel int64
 	haveLevel, badLevel := false, false
 	err := w.read(func(tx neo4j.ManagedTransaction) error {
 		res, err := tx.Run(w.ctx,
-			"MATCH (a:GoApplication {id: $id}) RETURN a.schema_version AS v, a.max_level AS l, a.identity_version AS iv",
+			"MATCH (a:GoApplication {id: $id}) RETURN a.schema_version AS v, a.max_level AS l, a.identity_version AS iv, a.application_name AS an, a.identity_namespace AS ns",
 			map[string]any{"id": w.appID})
 		if err != nil {
 			return err
 		}
 		if res.Next(w.ctx) {
 			iv, _ := res.Record().Get("iv")
 			if n, ok := iv.(int64); !ok || n != 2 {
 				return fmt.Errorf("incompatible stored identity_version: %v", iv)
 			}
+			nameValue, _ := res.Record().Get("an")
+			namespaceValue, _ := res.Record().Get("ns")
+			name, nameOK := nameValue.(string)
+			namespace, namespaceOK := namespaceValue.(string)
+			identity, identityErr := v2.ResolveIdentity(name, &namespace)
+			if !nameOK || !namespaceOK || identityErr != nil || identity.ApplicationID != w.appID {
+				return fmt.Errorf("incompatible stored application identity metadata")
+			}
+
 			if v, ok := res.Record().Get("v"); ok && v != nil {
 				stored, _ = v.(string)
 			}
 			if l, ok := res.Record().Get("l"); ok && l != nil {
 				storedLevel, haveLevel = l.(int64)
 				badLevel = !haveLevel
 			}
 		}
 		return res.Err()
 	})
diff --git a/internal/neo4j/bolt_session_test.go b/internal/neo4j/bolt_session_test.go
index db37f0c..545d35d 100644
--- a/internal/neo4j/bolt_session_test.go
+++ b/internal/neo4j/bolt_session_test.go
@@ -1,14 +1,15 @@
 package neo4j
 
 import (
 	"context"
+	"net/url"
 	"reflect"
 	"strings"
 	"testing"
 
 	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
 )
 
 // recordingSession is a DB-free SessionWithContext: it records which path a
 // statement takes (implicit Run vs an explicit ExecuteWrite transaction).
 // Methods it does not override panic through the nil embedded interface.
@@ -78,24 +79,29 @@ func TestEagerPurge_OnlyOnFullRun(t *testing.T) {
 // answer the stored-application gate with SchemaVersion and level (when
 // non-zero; else no stored level) and the content_hash diff with
 // hashes[module id] (an unchanged module when it equals the local hash);
 // every write statement is recorded with its parameters.
 type fakeDB struct {
 	neo4j.SessionWithContext
 	hashes map[string]string
 	level  int64
 	// rawLevel, when non-nil, is the stored max_level returned verbatim
 	// (any type), overriding level.
-	missingIdentity bool
-	rawIdentity     any
-	rawLevel        any
-	writes          []fakeStmt
+	missingIdentity  bool
+	missingAnchor    bool
+	missingName      bool
+	missingNamespace bool
+	rawIdentity      any
+	rawName          any
+	rawNamespace     any
+	rawLevel         any
+	writes           []fakeStmt
 }
 
 type fakeStmt struct {
 	q      string
 	params map[string]any
 }
 
 type fakeTx struct {
 	neo4j.ManagedTransaction
 	db *fakeDB
@@ -110,35 +116,55 @@ func (s *fakeDB) ExecuteWrite(ctx context.Context, work neo4j.ManagedTransaction
 	return work(fakeTx{db: s})
 }
 
 func (s *fakeDB) ExecuteRead(ctx context.Context, work neo4j.ManagedTransactionWork, _ ...func(*neo4j.TransactionConfig)) (any, error) {
 	return work(fakeTx{db: s})
 }
 
 func (tx fakeTx) Run(_ context.Context, q string, params map[string]any) (neo4j.ResultWithContext, error) {
 	switch {
 	case strings.Contains(q, "a.schema_version"):
+		if tx.db.missingAnchor {
+			return &fakeResult{}, nil
+		}
 		var lvl any
 		if tx.db.level != 0 {
 			lvl = tx.db.level
 		}
 		if tx.db.rawLevel != nil {
 			lvl = tx.db.rawLevel
 		}
 		identity := any(int64(2))
 		if tx.db.missingIdentity {
 			identity = nil
 		}
 		if tx.db.rawIdentity != nil {
 			identity = tx.db.rawIdentity
 		}
-		return &fakeResult{rec: &neo4j.Record{Keys: []string{"v", "l", "iv"}, Values: []any{SchemaVersion, lvl, identity}}}, nil
+		parts := strings.Split(strings.TrimPrefix(params["id"].(string), "can://"), "/")
+		ns, _ := url.PathUnescape(parts[0])
+		name, _ := url.PathUnescape(parts[1])
+		var rawName any = name
+		var rawNamespace any = ns
+		if tx.db.missingName {
+			rawName = nil
+		}
+		if tx.db.missingNamespace {
+			rawNamespace = nil
+		}
+		if tx.db.rawName != nil {
+			rawName = tx.db.rawName
+		}
+		if tx.db.rawNamespace != nil {
+			rawNamespace = tx.db.rawNamespace
+		}
+		return &fakeResult{rec: &neo4j.Record{Keys: []string{"v", "l", "iv", "an", "ns"}, Values: []any{SchemaVersion, lvl, identity, rawName, rawNamespace}}}, nil
 	case strings.Contains(q, "m.content_hash"):
 		h, ok := tx.db.hashes[params["id"].(string)]
 		if !ok {
 			return &fakeResult{}, nil
 		}
 		return &fakeResult{rec: &neo4j.Record{Keys: []string{"h"}, Values: []any{h}}}, nil
 	}
 	tx.db.writes = append(tx.db.writes, fakeStmt{q, params})
 	return &fakeResult{}, nil
 }
@@ -477,10 +503,34 @@ func TestWritersPreserveDistinctEdgeFacts(t *testing.T) {
 						}
 					}
 				}
 				if scripts[0] != scripts[1] || !reflect.DeepEqual(batches[0], batches[1]) {
 					t.Fatal("input order changes writer identities")
 				}
 			})
 		}
 	}
 }
+
+func TestStoredOwnerMismatchReadOnly(t *testing.T) {
+	for _, db := range []*fakeDB{{missingName: true}, {missingNamespace: true}, {rawName: "other"}, {rawNamespace: "other"}, {rawName: 42}, {rawNamespace: 42}} {
+		w := &boltWriter{ctx: context.Background(), session: db, appID: "can://team/app"}
+		if err := w.run(); err == nil {
+			t.Fatal("accepted contradictory stored owner")
+		}
+		if len(db.writes) != 0 {
+			t.Fatal("wrote before rejecting stored owner")
+		}
+	}
+}
+
+func TestStoredOwnerAllowsFreshAndMatchingAnchor(t *testing.T) {
+	for _, db := range []*fakeDB{{missingAnchor: true}, {}} {
+		w := &boltWriter{ctx: context.Background(), session: db, appID: "can://team/app"}
+		if _, err := w.storedAppStale(); err != nil {
+			t.Fatal(err)
+		}
+		if len(db.writes) != 0 {
+			t.Fatal("identity probe mutated graph")
+		}
+	}
+}
d2256fb Validate integer identity markers before model coercion
 cldk/models/go/models.py                           |  6 ++-
 cldk/models/identity.py                            | 14 ++++++
 cldk/models/java/models.py                         |  4 +-
 cldk/models/typescript/models.py                   |  6 ++-
 tests/analysis/commons/test_identity.py            | 50 ++++++++++++++++++++++
 .../python/test_neo4j_multi_application_scope.py   |  3 --
 6 files changed, 75 insertions(+), 8 deletions(-)
diff --git a/cldk/models/go/models.py b/cldk/models/go/models.py
index 86dacde..de6e915 100644
--- a/cldk/models/go/models.py
+++ b/cldk/models/go/models.py
@@ -40,20 +40,22 @@ consumable without an SDK edit, at the cost of the drift detector — an unmodel
 rather than failing loudly. :class:`_NullSafeBase` coerces a JSON ``null`` collection to its empty
 default **before** validation: Go's zero-value idiom marshals a ``nil`` slice/map to ``null``, and
 although ``cango`` emits ``[]``/``{}`` today, this keeps the SDK robust to a future emitter that
 does not.
 """
 
 from __future__ import annotations
 
 from typing import Dict, List, Optional, Tuple
 
+from cldk.models.identity import IdentityVersion
+
 from pydantic import BaseModel, ConfigDict, model_validator
 from typing_extensions import Literal
 
 
 class _Base(BaseModel):
     #: ``ignore``, not ``forbid`` (per TypeScript #386): an additive analyzer release is consumable
     #: without an SDK edit. The cost is the drift detector — a field the SDK does not model is
     #: dropped silently rather than refusing to parse; a declared field is the only way a value is
     #: reachable.
     model_config = ConfigDict(extra="ignore")
@@ -231,36 +233,36 @@ class GoModule(_NullSafeBase):
 # Application + envelope
 # ----------------------------------------------------------------------------------------------
 
 
 class GoApplication(_NullSafeBase):
     """The application root: the containment tree (``symbol_table``) plus the one app-scope overlay
     the analyzer emits at L2 (``call_graph``)."""
 
     application_name: str
     identity_namespace: str
-    identity_version: Literal[2]
+    identity_version: IdentityVersion
     id: str
     kind: Literal["application"] = "application"
     symbol_table: Dict[str, GoModule]
     call_graph: List[GoCallGraphEdge] = []
 
 
 class GoAnalyzer(_Base):
     name: str
     version: str
 
 
 class GoAnalysis(_Base):
     """The envelope ``analysis.json`` IS."""
 
-    identity_version: Literal[2]
+    identity_version: IdentityVersion
     schema_version: str
     language: str
     max_level: int
     k_limit: Optional[int] = None  # L3+ (absent at L1/L2)
     analyzer: GoAnalyzer
     application: GoApplication
 
 
 # Resolve the forward reference in the self-recursive callable.
 GoCallable.model_rebuild()
diff --git a/cldk/models/identity.py b/cldk/models/identity.py
new file mode 100644
index 0000000..dbddde7
--- /dev/null
+++ b/cldk/models/identity.py
@@ -0,0 +1,14 @@
+"""Strict wire marker shared by SDK-owned analysis models."""
+
+from typing import Annotated, Literal
+
+from pydantic import BeforeValidator
+
+
+def _require_integer_version(value):
+    if type(value) is not int or value != 2:
+        raise ValueError("identity_version must be the integer 2")
+    return value
+
+
+IdentityVersion = Annotated[Literal[2], BeforeValidator(_require_integer_version)]
diff --git a/cldk/models/java/models.py b/cldk/models/java/models.py
index a4382fa..97dcb5b 100644
--- a/cldk/models/java/models.py
+++ b/cldk/models/java/models.py
@@ -37,20 +37,22 @@ carry (CRUD) is an empty list, and the facade raises for it (J-4).
 that gives up is the drift detector — an unmodelled field is dropped silently, so a field the SDK does
 not declare is unreachable rather than an error. The projections in ``projections.py`` keep
 ``extra="forbid"``, because they are constructed by this SDK and never validated from the wire, so
 there strictness guards our own typos rather than the analyzer's additions.
 """
 
 from __future__ import annotations
 
 from typing import Any, Dict, List, Optional, Tuple, Union
 
+from cldk.models.identity import IdentityVersion
+
 from pydantic import BaseModel, ConfigDict, Field, PrivateAttr
 from typing_extensions import Literal
 
 from cldk.models.java.enums import CRUDOperationType, CRUDQueryType
 
 
 class _Base(BaseModel):
     #: ``ignore``, not ``forbid`` (#386). An additive analyzer release used to fail the whole payload
     #: rather than the one field it added: codeanalyzer-java 3.1.2's ``var`` on ``param_in``/
     #: ``param_out`` produced 2515 validation errors on daytrader8 until ``JParamEdge`` declared it,
@@ -943,21 +945,21 @@ class JApplication(_Base):
 
 
 class JAnalyzer(_Base):
     name: str
     version: str
 
 
 class JAnalysis(_Base):
     """The envelope ``analysis.json`` IS."""
 
-    identity_version: Literal[2]
+    identity_version: IdentityVersion
     schema_version: str
     language: str
     max_level: int
     k_limit: Optional[int] = None  # not emitted by 3.0.1 at any level
     analyzer: JAnalyzer
     application: JApplication
 
 
 # ----------------------------------------------------------------------------------------------
 # Call-graph node payload built by the backends (not on the wire)
diff --git a/cldk/models/typescript/models.py b/cldk/models/typescript/models.py
index 33144b9..8c8893d 100644
--- a/cldk/models/typescript/models.py
+++ b/cldk/models/typescript/models.py
@@ -34,20 +34,22 @@ the fact in another shape (``start_line`` over ``span``, ``code`` over ``source`
 ``extra="ignore"`` since #386: an additive analyzer release is consumable without an SDK edit, at the
 cost of the drift detector — an unmodelled field is dropped silently rather than failing
 loudly. The fields the next analyzer release (1.3.0) is known to add are already declared
 ``Optional`` so that pin bump changes no model.
 """
 
 from __future__ import annotations
 
 from typing import Any, Dict, Iterator, List, Optional, Tuple, Union
 
+from cldk.models.identity import IdentityVersion
+
 from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, model_validator
 from typing_extensions import Annotated, Literal
 
 
 class _Base(BaseModel):
     #: ``ignore``, not ``forbid`` (#386). An additive analyzer release used to fail the whole payload
     #: rather than the one field it added: codeanalyzer-java 3.1.2's ``var`` on ``param_in``/
     #: ``param_out`` produced 2515 validation errors on daytrader8 until ``JParamEdge`` declared it,
     #: for a change that was backward compatible by construction. Uptake should not require an SDK
     #: edit before anything parses.
@@ -730,21 +732,21 @@ class TSConfigRead(_Base):
     reason: str  # non-literal | undefined-key
     prov: List[str] = []
 
 
 class TSApplication(_Base):
     """The application root: the containment tree plus the app-scope overlays."""
 
     name: Optional[str] = None
     application_name: str
     identity_namespace: str
-    identity_version: Literal[2]
+    identity_version: IdentityVersion
     id: str
     kind: Literal["application"] = "application"
     symbol_table: Dict[str, TSModule]
     call_graph: List[TSCallGraphEdge] = []
     param_in: List[TSParamEdge] = []
     param_out: List[TSParamEdge] = []
     artifacts: Dict[str, TSArtifact] = {}
     dependencies: List[TSDependency] = []
     unresolved_imports: List[TSImportBinding] = []
     config_uses: List[TSConfigUse] = []
@@ -755,21 +757,21 @@ class TSApplication(_Base):
 
 
 class TSAnalyzer(_Base):
     name: str
     version: str
 
 
 class TSAnalysis(_Base):
     """The envelope ``analysis.json`` IS."""
 
-    identity_version: Literal[2]
+    identity_version: IdentityVersion
     schema_version: str
     language: str
     max_level: int
     k_limit: Optional[int] = None  # L3+
     analyzer: TSAnalyzer
     application: TSApplication
 
 
 # ----------------------------------------------------------------------------------------------
 # 1.x compatibility — names kept importable; the wire no longer carries these shapes
diff --git a/tests/analysis/commons/test_identity.py b/tests/analysis/commons/test_identity.py
index ec2b3dc..af5cda9 100644
--- a/tests/analysis/commons/test_identity.py
+++ b/tests/analysis/commons/test_identity.py
@@ -230,10 +230,60 @@ def test_changed_namespace_regenerates_a_shared_local_cache(tmp_path, monkeypatc
             application=dict(identity_version=2, id=bound.application_id, application_name="svc", identity_namespace=namespace, symbol_table={}),
         )
         (output / "analysis.json").write_text(json.dumps(raw))
 
     monkeypatch.setattr(TSCodeanalyzer, "_get_codeanalyzer_exec", lambda self: ["producer"])
     monkeypatch.setattr("cldk.analysis.typescript.codeanalyzer.codeanalyzer.subprocess.run", producer)
     for namespace in ["one", "two", "two"]:
         analyzer = TSCodeanalyzer(tmp_path, output, "symbol_table", False, None, application_name="svc", namespace=namespace)
         assert analyzer.application.identity_namespace == namespace
     assert calls == ["one", "two"]
+
+
+@pytest.mark.parametrize("model_path,model_name", [
+    ("go", "GoAnalysis"), ("go", "GoApplication"),
+    ("typescript", "TSAnalysis"), ("typescript", "TSApplication"),
+    ("java", "JAnalysis"),
+])
+@pytest.mark.parametrize("marker", [2.0, True, "2"])
+def test_fresh_models_reject_noninteger_identity_marker(model_path, model_name, marker):
+    import importlib
+    from pydantic import TypeAdapter, ValidationError
+    model = getattr(importlib.import_module(f"cldk.models.{model_path}.models"), model_name)
+    annotation = model.model_fields["identity_version"].annotation
+    metadata = model.model_fields["identity_version"].metadata
+    from typing import Annotated
+    adapter = TypeAdapter(Annotated[annotation, *metadata] if metadata else annotation)
+    with pytest.raises(ValidationError):
+        adapter.validate_python(marker)
+    assert adapter.validate_python(2) == 2
+
+@pytest.mark.parametrize("language,model_name", [("go", "GoAnalysis"), ("typescript", "TSAnalysis"), ("java", "JAnalysis"), ("python", "Analysis")])
+@pytest.mark.parametrize("location", ["envelope", "application"])
+def test_fresh_model_and_cache_both_reject_float_marker(language, model_name, location, tmp_path):
+    import importlib
+    import json
+    from pydantic import ValidationError
+    if language == "java" and location == "application":
+        pytest.skip("Java stores its marker in the envelope")
+    model = (getattr(importlib.import_module(f"cldk.models.{language}.models"), model_name)
+             if language != "python" else importlib.import_module("codeanalyzer.schema").Analysis)
+    app = dict(identity_version=2, id="can://team/svc", application_name="svc", identity_namespace="team", symbol_table={})
+    payload = dict(identity_version=2, schema_version="2.0.0", language=language, max_level=1,
+                   analyzer=dict(name=language, version="local"), application=app)
+    model.model_validate(payload)
+    if location == "envelope":
+        payload["identity_version"] = 2.0
+    else:
+        payload["application"]["identity_version"] = 2.0
+    with pytest.raises(ValidationError, match="identity_version"):
+        model.model_validate(payload)
+    path = tmp_path / "analysis.json"
+    path.write_text(json.dumps(payload))
+    assert not identity.cache_matches(path, identity.resolve_identity("svc", "team"))
+
+
+def test_python_reexport_rejects_float_before_local_model_normalization():
+    from cldk.models.python import PyApplication
+    from pydantic import ValidationError
+    with pytest.raises(ValidationError, match="identity_version"):
+        PyApplication(symbol_table={}, identity_version=2.0)
diff --git a/tests/analysis/python/test_neo4j_multi_application_scope.py b/tests/analysis/python/test_neo4j_multi_application_scope.py
index 60d7d41..8a2c9ad 100644
--- a/tests/analysis/python/test_neo4j_multi_application_scope.py
+++ b/tests/analysis/python/test_neo4j_multi_application_scope.py
@@ -255,23 +255,20 @@ def _two_app_backend(record: List[str] | None = None) -> PyNeo4jBackend:
     """A backend scoped to application A over a fake driver holding A and B."""
 
     def run(query: str, **params: Any) -> List[Dict[str, Any]]:
         if record is not None:
             record.append(query)
         return _fake_two_app_cypher(query, **params)
 
     backend = object.__new__(PyNeo4jBackend)
     from cldk.analysis.commons.identity import resolve_identity
 
-    backend.identity = resolve_identity(APP_A, None)
-    from cldk.analysis.commons.identity import resolve_identity
-
     backend.identity = resolve_identity(APP_A, None)
     backend.application_name = APP_A
     backend._database = None
     backend._driver = None
     backend._session_obj = None
     backend._modules = [APP_A_MODULE, SHARED_MODULE]
     backend._module_ids = {key: backend.identity.application_id + "/python/" + key for key in backend._modules}
     backend._call_graph = None
     backend._run = run
     return backend

# codeanalyzer-python: d644a1c84bd6b0ed88548a977a4a169e7d547cf5..b6599662ee17947bedc4231fa1b0875c2d172999

# codeanalyzer-java: cbfbd01dd9ed3f5bfca51237487d0273f4eff4ec..89b95237ee2623dfdf84ddd6e71f07ab2472699b

# codeanalyzer-go: 4e1fb80e099a82b9f21c1cf749d43cd749eba251..f66a589c1e2f4dc0ed373f4811a0dbe8f22b3d13

# python-sdk: 54b044fe27c52f9a3efe6bf2bd6ce51fa7c8be98..d2256fb728f19bb456d1226a1ba1d5ff4afe19a8
