# SDD ledger — plan: /Users/rkrsn/workspace/codellm-devkit/docs/superpowers/plans/2026-10-30-application-identity-namespaces.md

Execution selected: subagent-driven (Plannotator review answer). User explicitly requests continuous execution without repeated proceed prompts.

Workspace: parent is a non-Git workspace; SDD scratch is in python-sdk, on a dedicated feature branch. Existing producer PR branches are preserved. Go/SDK companion branches created.

## Preflight

| Tasks | Shared interface / internal check | Finding / ruling |
|---|---|---|
| Task 1 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| Task 2 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| Task 3 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| Task 4 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| Task 5 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| Task 6 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| Task 7 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| Task 8 internal | Test, interface, file and verification steps checked | Consistent; execution must report environment failures separately. |
| 1 -> 2 | Golden root fixtures | Same input/default/encoding and version contract. |
| 1 -> 3 | Golden root fixtures | Same input/default/encoding and version contract. |
| 1 -> 4 | Golden root fixtures | Same input/default/encoding and version contract. |
| 1 -> 5 | Golden root fixtures | Same input/default/encoding and version contract. |
| 1 -> 6 | Golden root fixtures | Same input/default/encoding and version contract. |
| 2 <-> 3 | Producer wire identity | Same two-segment root and identity_version 2; separate repositories. |
| 2 <-> 4 | Producer wire identity | Same two-segment root and identity_version 2; separate repositories. |
| 2 <-> 5 | Producer wire identity | Same two-segment root and identity_version 2; separate repositories. |
| 3 <-> 4 | Producer wire identity | Same two-segment root and identity_version 2; separate repositories. |
| 3 <-> 5 | Producer wire identity | Same two-segment root and identity_version 2; separate repositories. |
| 4 <-> 5 | Producer wire identity | Same two-segment root and identity_version 2; separate repositories. |
| 2 -> 6 | CLI, metadata, emitted references | SDK consumes exact marker and explicit identity fields. |
| 3 -> 6 | CLI, metadata, emitted references | SDK consumes exact marker and explicit identity fields. |
| 4 -> 6 | CLI, metadata, emitted references | SDK consumes exact marker and explicit identity fields. |
| 5 -> 6 | CLI, metadata, emitted references | SDK consumes exact marker and explicit identity fields. |
| 6 -> 7 | identity.py and four Neo4j backends | Run sequentially; Task 7 extends Task 6 rather than replacing it. |
| 1, 2, 3, 4, 5, 6, 7 -> 8 | Fixtures, tracking, artifacts and PRs | Delivery follows verified coordinated behavior. |

Ruling: The workspace parent cannot host Git-native SDD artifacts; use the SDK's ignored SDD directory with the absolute workspace plan path — preserves one ledger without initializing a repository.
Ruling: Product code uses dedicated existing PR/feature branches in the supplied checkouts — user requested repurposing these branches; no main-branch implementation.
Ruling: The selected plan's identity_version 2 is the ownership-contract marker; schema_version stays 2.0.0. No suffix redesign.
Ruling: Public issue creation and PR updates are authorized by the user's Plannotator feedback (“Please create issue in python-sdk and in the codeanalyzer-* repos ... Make the change, and create/update PRs.”). Do not publish private links/details, force-push, merge, or release.
Ruling: Integration repositories are absent. Complete available producers and SDK, and track/report the private join/index adoption separately.

## Tasks

Task 1: active; implementer /root/namespace_task1. BASE hashes in task-1-bases.json.
Tasks 2–8: pending.

Task 1: implementer reported DONE_WITH_CONCERNS; missing runtime baseline prerequisites are recorded. Controller provisioned isolated Python/Go/Bun/Java runtimes; dependency setup in progress. Review dispatched against task-1-review-package.md.

Task 1: complete (SDK 1b49043..7633dd2; Python 4cd8c1f..94b331e; TS b41215f..dbb5ccd; Java 90a48ca..dcef0a6d; Go 25dc74f..e65d73f; review clean). Tracking: SDK #435, Python #236, TS #221, Java #276, Go #40.
Task 2: preparing Python implementer; BASE 94b331e9cb56902420409a3e569e2b1e91608e2d.

Task 2: active; implementer /root/namespace_task2. Python baseline 18 passed (40 existing dependency warnings). Isolated toolchains in /private/tmp/namespace-toolchains/env.sh.
Baseline TS identity/body/prefix suites: 25 passed, 0 failed; Go schema/v2: passed. Java identity baseline and SDK focused baseline running.
Ruling: Remove Python PR legacy can://artifact/<app>/ automatic cleanup while retaining selected-root artifact reconciliation — legacy retirement belongs to explicit regeneration, avoiding cross-namespace deletion.

Baseline Java CanIdTest: Gradle BUILD SUCCESSFUL, 46s (existing compiler/deprecation notes); SDK commons + Python/TS/Java scope suites: 354 passed, 2 skipped, 7.11s. Gradle baseline runs spotlessApply automatically; inspect its formatting-only mutations before Task 4.

Bookkeeping: replaced stale RFC pending-publication references with actual SDK issue #435; public tracker links are now canonical.

Ruling: Producer/SDK file inventories are audit targets: do not create cosmetic changes in files that already consume canonical parent IDs correctly. Report any listed file left unchanged with the verified forwarding invariant. This follows the narrow RFC and avoids gratuitous edits; missing necessary propagation remains a defect.

Ruling: Permit a minimal Python import-resolver key-form correction exposed by the namespace emission fixture — input-relative keys are required by the RFC, and emitted resolved_module references must stay coherent. Cover both pre-existing absolute-key and relative-key forms; no inference/suffix redesign. Cost if wrong: local import-edge regression caught by dedicated RED/GREEN tests and task review.

Task 2 checkpoint: focused 77 passed/25 container skips; small CLI 11 passed after base-interpreter environment correction. Final broad run excludes five heavyweight Ray/whole-application tests, retained as explicit gates. Source-regenerate checked-in Python handoff analysis/graph examples to current marker/root where bounded; do not translate IDs.

Task 2: implementation commit d644a1c84bd6b0ed88548a977a4a169e7d547cf5. Review active: /root/namespace_review2, package task-2-review-package.md. Broad548 passed/27 skipped/5 heavyweight deselected; focus77 passed/25 container skips. Working tree clean; no push. Report includes full RED/GREEN and documented prerequisite/interrupted runs.

Task 2: complete (94b331e..d644a1c, spec and quality review approved; nonblocking docs nit deferred to final review).
Task 2: minor (deferred): docs/handoff/README.md lines140–144 repeat app-name/namespace pair three times. Remove duplicate pairs in final review fix wave; no behavioral issue.
Task 3: preparing implementer; BASE dbb5ccdcad46f5ce9c39e279297cf535579907d0.

Task 3: active; implementer /root/namespace_task3; BASE dbb5ccdcad46f5ce9c39e279297cf535579907d0. Toolchain/env and TS baseline supplied.

Final-review focus: exact unreserved encoding parity (especially !, apostrophe, parentheses, *, ~) across Python/JS/Java/Go. Golden fixture includes percent/space/Unicode/case, but final cross-producer smoke should include these punctuation inputs as an additional encoding boundary.

Task 3: reviewer found P2 CLI explicit-empty app-name normalized to omission. Fix round1/5 active with original implementer; FIX_BASE fcc9529a932bc40a6be426fb85298237e19ffe65. Require CLI RED/GREEN with/without namespace and omitted-name fallback. No other blocking findings.

Task 3: fix round1/5 (1 addressed,0 open — explicit empty CLI app-name; commits fcc9529..9658f89). Scoped re-review approved.
Task 3: complete (dbb5ccd..9658f89, review clean). Full pre-fix suite399passed/23container skips; CLI fix focused71passed/typecheckpass.
Task 4: preparing implementer; BASE dcef0a6dcc32dbcb97295eb9de06e7e86b191eda.

Task 4: active; implementer /root/namespace_task4. Dedicated PR branch, isolated Java/Gradle environment and baseline evidence supplied.

Ruling: Offline Cypher export validates incoming scope/marker before producing output, but must not invent unvalidated failure-expression guards for an existing DB. Connected Bolt/SDK/loader validates existing anchors; offline snapshot execution is explicit regeneration. No APOC or speculative divide-by-zero mechanism.
Named cross-task risk checked: TS Bolt integer marker encoding. Existing driverProps converts integer-valued numbers with neo4j.int, and anchor compatibility uses neo4j.isInt; no finding.

Task 4: implementation commit e35d7dcab8c62119a8bdeb4288e9d7cda523fb2e, clean. Review /root/namespace_review4 active against task-4-review-package.md. Available full635 tests/17skips; unfiltered636tests/1Dockerinitfail/17skips. Focus74pass. LiveNeo4j and realworld-submodule gates unavailable.
SDK handoff detail: required identity_version2 is on envelope and graph anchor. Check actual app JSON layouts per producer; do not assume every producer repeats marker on application JSON if its existing envelope carries it. Validate raw app-name/namespace + canonical ID regardless.

Task 4: fix round1/5 active, original implementer. P2s: shared Cypher/Bolt writers lost ordinary v1 replacement/pruning after v2 fallback removal. FIX_BASE e35d7dcab8c62119a8bdeb4288e9d7cda523fb2e. Explicit actual-v1 branch must retain legacy behavior and exclude canonical v2 anchors with same display name; no v2-to-name fallback. Require targeted RED/GREEN for both directions.

Task 4: fix round1/5 (2 addressed,0 open — v1 snapshot and full Bolt cleanup; commits e35d7dca..cbfbd01). Scoped re-review approved.
Task 4: complete (dcef0a6d..cbfbd01, review clean). Full available635tests/17skips beforefix; targetedv1/v2fix16passed. LiveDocker/realworldsubmodule gates remain.
Task 5: preparing implementer; BASE e65d73f1ff358dc9f43e21b12b774b4d68e5578c.
Ruling: Go Emit/EmitTo replace existing appName string parameter with named v2.Identity, preserving every trailing argument type/order. Identity is resolved once before emission; no positional insertion of namespace among existing strings.

Task 5 rulings: RenderCypher returns (string,error) through internal callers/EmitNeo4j, with invalid input rejected before filesystem creation/truncation; no panic or empty-success result. Existing ordinary RowBuilder property last-write-wins is retained: property refinement is not an identity collision. Canonical-ID keys and label union required; identity/ownership mismatches fail at validated write/read boundaries. Earlier generic-conflict phrasing was overbroad, not a new reconciliation feature requirement. Task7 module-index contradictory file-key diagnostic remains explicit.
Final-review focus: Java added broad canonical property-conflict rejection; examine whether this changes any expected ordinary refinement semantics beyond identity checks. Go retains its explicitly tested last-write merge policy.

Local artifacts prepared for SDK verification (not published): reviewed TS dist/cants and Java3.3.4 wheel staged entirely under /private/tmp. Source commits/paths/SHA256 in local-artifacts.json. SDK currently still has old released producer installs; Task6 should replace with local artifacts for verification and not fabricate release pins.

Task 5: fix round1/5 active original implementer; FIX_BASE8fabbf69a11c2c3a338ee60577ca300c52280165. P2 direct WriteOutput prevalidation, and persistence collapse of retained site/context facts. Ruling: shared deterministic private relationship fact discriminator may be added to this unreleased breaking graph contract, preserving original _k and public URI suffixes; must work identically in Cypher/Bolt with schema documentation.

Task 5: fix round1/5 (2 addressed,0 open — direct output prevalidation and persisted edge facts; commits8fabbf6..f62c3ec). Scoped re-review approved.
Task 5: complete (e65d73f..f62c3ec, review clean). FullGo passed beforefix; focusedcore/Neo4j175passevents afterfix.
User steering: incorporated SaurabhSinha origin/main fd96329 (PR#37), sibling-file same-position regression test only, via normal merge. New GoHEAD 4e1fb80e099a82b9f21c1cf749d43cd749eba251; merge clean; TestCallGraph_SamePositionInSiblingFiles passes. No forcepush.
Task 6: preparing SDK implementer; BASE7633dd2a61e20a603463946442705db817dbfebe.

Task 6: active; implementer /root/namespace_task6, BASE7633dd2a61e20a603463946442705db817dbfebe. SDK .venv now uses reviewed local Pythoneditable+Javawheel and existing TS/Go native overrides in /private/tmp/namespace-toolchains/sdk-env.sh; artifacts at sourceSHAs local-artifacts.json. SDK handoff constraints include keyword-only new config fields/reused-config defaults/normalized root/marker layout/raw argv boundary.

Task 6 checkpoint: helpers/factories and all backend bindings implemented; focused379pass2skip, corpus regeneration underway. Real localPython owner root passes. Go key reconstruction corrected (retained go/ segment from positional grammar). SourceZIP regeneration succeeds GoLitestream55modules3082calls, JavaDaytraderL1/L4 138modules1391calls1609param_in, TSall4levels. Older tests/corpora are being upgraded explicitly from source.
Ruling: permit explicit GoType kind literal defined (and necessary declared fields) to consume actual current reviewed Go output, with focused regression; not arbitrary string/Any or type API redesign. Minimal compatibility for currentGo adoption.

Task 6 prerequisites: isolated official SHA512-verified Maven3.9.16 added to /private/tmp toolchain env; JAVA_HOME17.0.21 and MAVEN_OPTS temp repository. Compiled Java regeneration now succeeds: pruned4file L4 reproduces247calls/258param_in/320points-to; WALAsemanticDDG118callables. Earlier engine-free outputs superseded, originalsemanticassertions restored. Tracked gzip snapshots regenerated withmtime0; sourcegenerator/provenance added by implementer.
Ruling: minimal PyCallsite dataclass compatibility uses dataclasses.replace rather than obsolete model_copy; optional TSApplication.name models real producer display field for lossless roundtrip. No broad type looseness.

Task 6: implemented 315eeae8e3c9028d1404d2150f00e01e36f6c42b; task review pending. Final SDK1913pass421skip20warnings85.09%coverage71.18s using CLDK_SKIP_JAVA_E2E; actual compiled native Java and all4customnamespace checks passed separately. No push.

Task6review active /root/namespace_review6; full8MBpackage plus493KBsource package excludes only minified generated native JSON diff bodies (full preserved). Remote PR check: George3PRs remain open unchanged titles; no Go companion yet. SDK open PR439 bumps Go0.1.0rc1to0.2.0 (unrelated branch), preserve and cross-check packaging during Task8; do not merge it implicitly.

Task6review: specissues/qualityneedsfixes, Important staleTS live gate/cleanup APP_ID. Fixround1 active originalimplementer BASE315eeae. Minor(deferred finalwave): strictfloat2.0 marker coercion before validate_identity; duplicatePython scopefixture setup. Ruling: brief file list followed actual facade ownership rather than no-op __init__/abstractbackend edits; reviewer verified sole direct abstractcaller Java is wired, no demonstrated missing API. Live Neo4j remains explicitly unavailable, cannotverify item accounted.

Task8 preparation note: final fix wave must triage SDK strict integer marker2.0 acceptance (Minor but spec consistency), duplicatePythonfixtureidentitysetup, PythonhandoffREADME repeatedflags, Java broad ordinarycanonicalproperty-conflict behavior. Final delivery checks precede pushes; push/update authorized by prior explicituserinstruction.

Task 6: fix round1/5 (1addressed0open — liveTSgate/cleanuproots;315eeae..1f39489). Scopedreviewclean.
Task 6: complete (7633dd2..1f39489, review clean;2minorsdeferredfinalwave).
Task 7: starting BASE1f3948976c2d14fb45a7585bcc5b05f07d9b2b15.

Task7implementation complete72f14d7d9a6997019ff4ac079838505631df7540; 596pass2skiprelevant,163focusedpass, REDhelper/loader+canonicalfilenamejoinmutationverified. /root/namespace_review7 active.

Task 7: complete (1f39489..72f14d7, review clean). Task8verification/docs preparation next; combinedfinalreview and PRdelivery remain.

Task8verification/docs prepared54b044f;1926pass421skip10warnings85.33%cov98.15s,20nativeL2cases60endpointrefs. Allfixture/nativehashesmatch,diffchecksall5clean. Finalcombinedreview before PRmutations. Ruling: Task8 includes independent whole-branch review/delivery as its own step4, so final review serves that planned review gate and judges Task8handoff; no duplicate documentation-onlyreviewseat. Cost ifwrong: documentationgaps may need follow-up if broadreviewmissesthem.

Final combined review active /root/namespace_final_review gpt6astra. PreliminaryImportant: Python Bolt stream/nonstream noexistinganchor guard beforeDDL/upsert; Goexistinganchor guard markeronlydoesnotverifyrawowner. Singlefixwavependingcompletefindinglist. NoPRmutationsyet.

Finalsinglefixwave active /root/namespace_final_fix (gpt6.1sol), bases final-review-manifest. ConfirmedPython/Go existinganchor guarddefects + SDKfloatmarker/coercion and duplicatefixture/docs minors; finalreportpending reviewer. Workerinspectsconfirmedareas while reviewerfinishes, no duplicatereview/implementation. Mustreadfinalreportbeforefinalizingwave.

Finalreviewreport saved:2Important Pythonstoredanchorvalidation/Goownerfields, SDKfloatmarker + repeateddocsflags/fixture + deliverywording minors. Javaordinaryrefinement no demonstratedproductiontrigger. Ruling: retain strictJavaordinarypropertyconflictrejection thisiteration and document/test strictercontract rather than speculativebehaviorchange; costifwrong: externalbuilderrefinement callers mayneedtargetedfollowup. Declinedjudgments: privateintegration joins absent; liveDB/runtime/productionrollbackunavailable; futurepackage/search/suffix/lifecyclefeaturesoutofscope; unmodifiedgeneratedcorpuswholeaudit not repeated. All retain explicit limits, nohiddenclaims.

Finalsinglefixwave complete and scopedreviewclean:all6findings+JavatriageADDRESSED,nofixbreakage. SDKd2256fb/Pythonb659966/Gof66a589/Javadocstest89b95237/TSunchanged.1949SDKpass422skip85.34%75.22runnerexit0;20nativecases60endpointsverifiedfromlogs. NativeJavaL2tinyprojectsdeclared-edgefallbackwarnsGradlecmdnull; verif/bodyexplicitlydiscloses, separatecompiledWALAprovedTask6. Finishingbranch workflow usespriorauthorizedpush/createPRchoice, no newconfirmation.

Task 8: complete — finalreview+singlefixwave+scopedrereviewclean;all5normalpushesverified;GeorgePR235/220/275updatedinplace;GoPR41open;SDKPR440Draft. Titles/bodiescrosslinked/actualheadSHAsverified;SDK435editedwithremainingintegration/live/releaseobligations, remainsopen. No forcepush/merge/release/private-repochanges. FourHTTPSgitpushes initiallylackedcredentialhelper; percommandexistingghcredentialhelper succeeded, no globalconfigmutation.

Delivery independently verified viaGitHubAPI:all5OPEN/main/headSHAequalslocalHEAD; SDKonlyDraft; all5bodiescrosslinkGo41/SDK440;no privatehostlinks; SDK435OPENwithremainingwork. FinalparentRFC/plan/veriflinkedallPRs. ArchiveallplanworkspaceevidencebeforeSDDcleanup, preserveproductcheckouts/branches.
