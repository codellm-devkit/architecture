# Task8 delivery context

Required: read task-8-brief.md first; global-constraints and ledger bind implementation.

- User explicitly authorized creating all5issues, making changes, creating/updatingPRs in Plannotator. No new proceed approval needed. No forcepush, merge, release, productiondataregeneration, or private-repochanges.
- ExistingPRs to reuse: Python235, TS220, Java275, all feat/add-workspace-root. Go+SDK companion branch feat/application-identity-namespaces. Tracking issues SDK435/Py236/TS221/Java276/Go40.
- Independent final combined review should happen before actual pushes/PRupdates. Prepare verification/docs and exact PRbody files; root will deliver after review. PRbody must not expose private issue links/details.
- SDK dependency pins remain previouspublished versions: reviewedlocalproducerartifacts only, no fabricated releasepins. SDKPR must be Draft with precise producerreleaseblocking note. Separate open SDKPR439 updates Go0.1.0rc1->0.2.0, preserve it; not namespace-ready release.
- Source /private/tmp/namespace-toolchains/sdk-env.sh, use SDK.venv/bin/python (NOT uv run). Toolchain has Maven3.9.16 now for Java, notDocker. local-artifacts.json records nativepaths/sourceSHAs/hashes. Pythoninstallededitable reviewedsource. Donot claim nativeversionlabels are newlypublished artifacts.
- RFC bottom currently has stale Task1 baseline-unavailable claims; replace with final evidence. Openquestion marker decision now resolved integeridentity_version2 envelope/anchor, raw names onapp; schema_version stays2.0.0. Update references and externalintegration status.
- Tests were already run perproducer/report; do not rerun allproducerfullsuites without newchanges. Task8 smoke should test exactcurrentnativeartifacts appownedreferences/endpoints/SDKIDs, explicit anddefaultroot, rawencoding, samefilename services. LiveNeo4j unavailable; recordfake-drivercoverage, no livepass.
- All6fixture copies must have same hash6bb6e909079045600ddb06606ca5d9c8f84eb30bf7f5bbc634213c3363a695b0. git diff --check all5repos.
- Finalwave deferred findings are ledger: PythonhandoffREADMEduplicatedflags; SDKstrictfloat2.0markercoercion; duplicatePythontestidentitysetup; inspect Javaordinarypropertyconflictrejection vs refinement semantics. Task8 should not silentlydiscard or duplicatefinalreviewwork.
- Parent workspace noGit; architectureRFC/plan/verificationfiles stay local reviewable, not pretendcommitted. SDK canhostcheckedinverification utility/docs ifhelpful.
- User will clone OnlineBoutique and projectallserviceoutputs intooneNeo4j then runSDK script; provideactualusableAPIs/commands/servicebindings; labeluser-run notalreadyperformed. No need entireBoutiquedownload now.
- Finalhandoff includes exhaustive ledger Ruling entries (in order) with costifwrong in verificationannex; no need exposetransientSDDscratchasonlyrecord.
