# Task 3 review

Scope: `codeanalyzer-typescript`, base `dbb5ccd` through `fcc9529` (both implementation commits), against task-3-brief.md, global-constraints.md and contract-decisions.md. Read-only code review; no Git mutations or reported suite reruns.

## Findings

### P2 — Explicit empty CLI application name bypasses identity validation

Location: `codeanalyzer-typescript/src/cli.ts:149`.

`appName: o.appName ? String(o.appName) : null` turns an explicitly supplied empty string into omission. Thus `--app-name ''` resolves to the input directory basename in `analyze()` and succeeds, although the binding root-input contract rejects empty supplied application names. Supplying `--namespace team` does not prevent this: the analyzer writes the basename application under that namespace instead of rejecting the invalid request. The raw-name helper correctly rejects empty strings, but this CLI normalization prevents it from receiving the invalid value.

Preserve flag presence as done for namespace, using an undefined check instead of a truthiness check. Add a CLI-level regression covering explicit empty application name, with and without namespace, and keep omitted application-name fallback covered. This is an existing parsing expression that the new identity contract requires changing; it is not a suffix or ownership redesign.

## Spec compliance verdict

Changes requested for the empty CLI application-name case above. The remaining reviewed contract is implemented: two encoded root segments; raw case-sensitive names without trimming/Unicode normalization; strict unreserved UTF-8 encoding including punctuation and percent; rejected separators, controls and malformed surrogates; namespace-aware cache selection; required identity marker and raw metadata before projection; existing selected Bolt-anchor compatibility checked before DDL or destructive work; input-relative keys and unchanged language/body/artifact/pkg suffix grammar. JavaScript module language selection remains explicit.

Repeated finalization rebuilds IDs from signatures/canonical parent IDs and recovers dependency artifact suffixes without fixed slash slicing. Existing homing derives external and synthesized IDs from the canonical application parent. The checker inventory entry is a compiler-symbol helper and does not call for cosmetic edits. Legacy-root cleanup removal matches the regeneration boundary.

## Code quality verdict

Changes requested for the same P2 correctness issue; otherwise acceptable. The implementation is focused, preserves canonical-parent forwarding, and adds useful fixture and repeated-finalization tests. Selected-root artifact cleanup uses slash-terminated scope, retains sibling claim checks, and no longer reaches legacy roots. Existing relationship discriminants and projection mechanics are preserved. No separate maintainability blocker was identified.

## Validation and limits

Accepted the implementer's recorded RED/GREEN evidence, typecheck, generated-schema regeneration and full suite result (399 passing, 23 container/live skips); did not rerun those suites as instructed. Inspected the primary diff and implementation files; outside-diff inspection was limited to the concrete canonical-parent/repeated-finalization risk in homing. The CLI finding follows directly from the parser's truthiness conversion and the core's nullish fallback. Live Neo4j metadata rejection and reconciliation remain unverified on a Docker-capable server; this is a pending execution gate, not evidence of a code defect.
