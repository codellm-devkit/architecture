# Task 5 — Go namespace producer

Status: implementation complete and verified. Branch `feat/application-identity-namespaces`, base `e65d73f1ff358dc9f43e21b12b774b4d68e5578c`. Commit `8fabbf69a11c2c3a338ee60577ca300c52280165` — `feat: qualify Go analysis identities by namespace` (34 files changed).

## Implementation

- Added presence-aware `AnalysisOptions.Namespace *string`, CLI `--namespace`, validated `ResolveIdentity`, and `Identity` fields Namespace/ApplicationName/ApplicationID. Omitted app resolves the normalized absolute input basename; explicit empty app or namespace fails before analysis. Omitted namespace equals resolved app name. Strict UTF-8 byte percent encoding preserves raw names and case without normalization.
- `AppID(appName, namespace string)` receives validated raw names. `Emit` and `EmitTo` replace their former appName argument with named `v2.Identity`; trailing parameter order is unchanged. All production/test callers were migrated, including core streaming, graph CLI, dataflow and metamorphic harnesses.
- Envelope and existing application carry integer `identity_version: 2`; app carries raw `application_name`/`identity_namespace`. Existing schema version, language view, relative file keys and language-specific suffixes remain intact.
- Graph rows preserve canonical IDs. Canonical-ID node dedup unions labels and retains existing last-write-wins property refinement. Exact relationship facts dedup on canonical endpoints, relationship kind, existing key and full properties, retaining site/context differences; stable ordering includes property JSON. Deferred references recognize every unioned label.
- `RenderCypher` now returns `(string, error)`. Incoming root marker, raw names and canonical root agreement are validated; facade checks both envelope/application markers before touching output. Bolt validates incoming rows before connecting, and rejects missing/noninteger/non-v2 stored selected-anchor markers before DDL or writes.
- Programmatic `Analyzer.Analyze` rejects invalid identity before dependency materialization or debug cache writes.
- Cache directories include a SHA-256 of canonical root under the existing configured cache root. Existing source/options mechanisms remain inside that directory. The cached v1 debug payload has no reader and is never translated or treated as canonical input.
- README documents namespace CLI/defaults, encoded roots, migration by regeneration and markers; illustrative examples reflect the canonical root. No checked-in generated analysis/graph/schema artifacts exist to regenerate. Graph schema vocabulary source now declares the application metadata.

## Audit

`ids.go`, emitter signature index, L3/L4 overlays, external symbol builders and graph projector all derive module/body/external/degraded/parameter references from the selected canonical root or canonical parent. `emit_l3.go`/`emit_l4.go` required no production changes because they already consume canonical parents. Artifact/Package/ConfigKey in Go are graph vocabulary declarations only: no local artifact/config producer exists in this branch, so no speculative emitter or ID grammar was introduced. `pkg:` identities are unaffected. No workspace-root option or global mutable namespace was present or introduced.

## RED evidence

All commands source `/private/tmp/namespace-toolchains/env.sh` (Go 1.26.10, isolated GOPATH/GOCACHE).

1. `go test ./internal/schema/v2 ./cmd/codeanalyzer`: schema tests failed because `ResolveIdentity` did not exist. CLI dependency fetching initially failed due sandbox DNS; authorized escalated `go mod download` populated dependencies.
2. `go test ./internal/neo4j -run TestCanonicalDedup`: failed `nodes 2 edges 3`, expected canonical one node/two distinct site facts.
3. `go test ./internal/neo4j -run TestIncompatibleIdentityReadOnly`: failed accepting v1 and recording writes before compatibility gate.
4. `go test ./internal/neo4j -run TestCypherRejectsInvalidIdentity`: failed missing error-return API (assignment mismatch).
5. `go test ./internal/neo4j -run TestEmitNeo4jInvalidIdentityLeavesOutput`: failed accepting app marker mismatch; protected existing file regression.
6. `go test ./cmd/codeanalyzer -run TestNamespaceDefaultUsesNormalizedInput`: failed rejecting literal `.` for omitted app on `--input .`.
7. `go test ./internal/neo4j -run TestCanonicalEdgeFactOrder`: failed stable site ordering when source order reversed.
8. `go test ./internal/core -run TestAnalyzeInvalidNamespaceReadOnly`: failed accepting explicit empty namespace through the programmatic API before early validation.

Additional CLI explicit scope, custom-namespace L4 recursive reference traversal, cache-isolation and malformed-marker cases broaden regression coverage. The shared fixture invalid surrogate JSON cases cannot survive Go JSON decoding, so those entries are skipped explicitly and invalid UTF-8 is supplied directly. Exact ASCII unreserved punctuation and Unicode whitespace/raw-name cases are tested.

## GREEN evidence

- Focused schema/CLI/core/Neo4j suite passed.
- Targeted canonical dedup, incompatible/missing stored marker, protected output, normalized input and site-order regressions passed after fixes.
- Final full `go test -json ./...`: **655 passing test/subtest events, 13 passing tested packages, 3 packages without tests, zero failures**. Log `/private/tmp/go-release.jsonl`. Earlier full verification also passed 653 events before the final CLI/site-order regressions.
- Required `go test ./internal/schema/v2 ./internal/syntactic_analysis/v2emit ./internal/neo4j ./cmd/codeanalyzer`: all four packages passed (`/private/tmp/go-required.log`).
- Bare `go test ./...` passed across all 13 tested packages (`/private/tmp/go-bare.log`). After the final early-core-validation addition, bare `go test ./...` passed again across all 13 tested packages (including core 12.150s and SDG 56.225s); final whole-suite confirmation is `/private/tmp/go-last.log`.
- `gofmt` applied to every changed Go file; `git diff --check` passed.

Initial full-suite failures were resolved: three cache tests needed scoped cache paths; `TestGateL4_HTTPToSQLPath` still expected legacy httpsql roots; and the existing last-write-wins test exposed an overly broad temporary conflict panic, which was removed per controller ruling. No known unresolved test failures.

## Controller rulings

Internal RenderCypher may gain an error return, with errors propagated before output mutation. Existing property refinements remain last-write-wins; identity metadata mismatches reject at validation boundaries, without generic property-conflict panics. These decisions avoid changing producer reconciliation semantics.

## Limitations

Docker is unavailable (`command -v docker` fails); live `neo4j_it` gates were not run. DB-free recording-session tests cover compatibility-before-write ordering. The suite emits existing fixture warnings for intentionally unresolved `example.com/vlib`, ill-typed packages, and documented L4 degradation; these are not test failures. No push performed.

## Files

```text
 M README.md
 M cmd/codeanalyzer/main.go
 M cmd/codeanalyzer/main_test.go
 M internal/core/analyzer.go
 M internal/core/analyzer_test.go
 M internal/dataflow/run_test.go
 M internal/metamorphic/run.go
 M internal/neo4j/bolt.go
 M internal/neo4j/bolt_session_test.go
 M internal/neo4j/bolt_test.go
 M internal/neo4j/cypher.go
 M internal/neo4j/cypher_test.go
 M internal/neo4j/emit.go
 M internal/neo4j/project.go
 M internal/neo4j/project_test.go
 M internal/neo4j/rows.go
 M internal/neo4j/rows_test.go
 M internal/neo4j/schema.go
 M internal/options/options.go
 M internal/schema/v2/ids.go
 M internal/schema/v2/ids_test.go
 M internal/schema/v2/schema.go
 M internal/syntactic_analysis/v2emit/determinism_freshbuild_test.go
 M internal/syntactic_analysis/v2emit/determinism_test.go
 M internal/syntactic_analysis/v2emit/emit.go
 M internal/syntactic_analysis/v2emit/emit_l4_test.go
 M internal/syntactic_analysis/v2emit/emit_test.go
 M internal/syntactic_analysis/v2emit/gate_l2_inits_test.go
 M internal/syntactic_analysis/v2emit/gate_l2_test.go
 M internal/syntactic_analysis/v2emit/gate_l3_test.go
 M internal/syntactic_analysis/v2emit/gate_l4_done_test.go
 M internal/syntactic_analysis/v2emit/gate_l4_test.go
 M internal/syntactic_analysis/v2emit/gate_test.go
?? internal/schema/v2/namespace_test.go
```

## Review fix round 1

Base: `8fabbf69a11c2c3a338ee60577ca300c52280165`.
Commit: `f62c3ec5df679858add19694c3c37d88c8037e30` — `fix: validate output scope and preserve graph edge facts`.

Addressed both P2 findings in task-5-review.md:

1. Direct `core.WriteOutput` validates identity before EnsureDir/createTemp or any output filesystem work. Regression covers a missing nested destination (parent remains empty) and an existing protected analysis.json (contents and directory entries unchanged).
2. Snapshot and Bolt MERGE now include private `_fact`, derived by one shared deterministic SHA-256 helper over canonical JSON of existing pruned fact properties. The original explicit `_k` remains unchanged and participates independently. The graph vocabulary declares `RelationshipFactProperty`, and `--emit schema` exposes `relationship_fact_property`; README documents it. No URI suffix or identity-version change. Writer tests cover keyed and unkeyed equal-endpoint/type facts with different sites and with equal sites/different contexts, preserve original keys, compare rendered and recorded batch identity, and assert identical results after reversing input.

RED:
- `go test ./internal/core ./internal/neo4j -run 'TestWriteOutputInvalidIdentityPreservesFilesystem|TestWritersPreserveDistinctEdgeFacts'`: failed as intended; missing destination was created and both writers omitted a fact discriminator in MERGE. Log `/private/tmp/go-review-red.log`.
- `go test ./internal/neo4j -run TestSchemaDeclaresRelationshipFactIdentity`: failed because schema document lacked the private identity-property declaration.

GREEN:
- Targeted regressions passed after implementation (`/private/tmp/go-review-green.log`).
- `go test -json ./internal/core ./internal/neo4j`: **175 test/subtest pass events, 2 passing packages, zero failures** (`/private/tmp/go-review-focused.jsonl`). Includes existing invalid identity/output/stored-marker tests, preserving validation-before-file/connection/DDL boundaries.
- Changed Go files formatted; `git diff --check` passed. Worktree clean after commit. No full-suite rerun, per controller's focused verification scope. No push or subagents. Docker remains unavailable, so live Neo4j tests remain unrun.
