import json,logging,os,subprocess
from pathlib import Path
from neo4j import GraphDatabase
from cldk import CLDK
from cldk.analysis.commons.backend_config import Neo4jConnectionConfig
logging.getLogger('neo4j').setLevel(logging.ERROR)
work=Path('/private/tmp/online-boutique-namespace-check');root=Path('/Users/rkrsn/workspace/codellm-devkit');uri='bolt://127.0.0.1:17687'
with GraphDatabase.driver(uri,auth=('neo4j','neo4j')) as d:
 with d.session(database='neo4j') as s:
  def scopes():
   roots=[r['id'] for r in s.run('MATCH (a) WHERE a.identity_version=2 RETURN a.id AS id')]
   return {a:dict(s.run('MATCH (n) WHERE n.id=$root OR n.id STARTS WITH $prefix OPTIONAL MATCH (n)-[r]->() RETURN count(DISTINCT n) AS nodes,count(r) AS edges',root=a,prefix=a+'/').single()) for a in roots}
  before=scopes()
  for ns,expected in [(None,'can://currencyservice/currencyservice'),('namespace-verification-control','can://namespace-verification-control/currencyservice')]:
   a=CLDK.typescript(backend=Neo4jConnectionConfig(uri=uri,database='neo4j',application_name='currencyservice',namespace=ns))
   view=a.get_application_view();assert view.id==expected
   assert {m.id for m in view.symbol_table.values()}=={expected+'/javascript/server.js',expected+'/javascript/client.js'}
   try:a.locate('can://online-boutique/currencyservice/javascript/server.js',28)
   except ValueError:pass
   else:raise AssertionError('foreign namespace URI accepted')
  with (work/'currency-reconciliation.log').open('w') as out:
   cmd=[str(root/'codeanalyzer-typescript/dist/cants'),'-i',str(root/'online-boutique/src/currencyservice'),'-o',str(work/'output/currencyservice'),'--app-name','currencyservice','--namespace','online-boutique','--emit','neo4j','--eager','--neo4j-uri',uri,'--neo4j-database','neo4j']
   subprocess.run(cmd,env=os.environ.copy(),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=120)
  after=scopes();selected='can://online-boutique/currencyservice'
  assert {k:v for k,v in before.items() if k!=selected}=={k:v for k,v in after.items() if k!=selected},(before,after)
  assert len(after)==13
  nodes=[r.data() for r in s.run("MATCH (n:TSBodyNode) WHERE n.id STARTS WITH $prefix AND n.kind='call' AND n.start_line IN [28,29] RETURN n.id AS id,n.start_line AS line,n.callee AS callee",prefix='can://online-boutique/paymentservice/javascript/server.js/HipsterShopServer/constructor')]
  # Each loadProto call retains its own position-bearing canonical body node.
  load=[r for r in nodes if r['callee']=='can://online-boutique/paymentservice/javascript/server.js/HipsterShopServer/loadProto']
  assert len({r['id'] for r in load})==2 and {r['line'] for r in load}=={28,29},nodes
  result={'default_repeated_root':'pass','same_application_other_namespace':'pass','foreign_namespace_uri_rejected':'pass','other_12_scopes_unchanged_after_eager_regeneration':'pass','distinct_real_callsites':load,'scopes':after}
  (work/'control-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
