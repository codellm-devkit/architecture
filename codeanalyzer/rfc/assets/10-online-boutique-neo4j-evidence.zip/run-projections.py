from pathlib import Path
import subprocess,time,json,os,signal
root=Path('/Users/rkrsn/workspace/codellm-devkit');work=Path('/private/tmp/online-boutique-namespace-check')
services=[('currencyservice','javascript'),('paymentservice','javascript'),('checkoutservice','go'),('frontend','go'),('productcatalogservice','go'),('shippingservice','go'),('emailservice','python'),('loadgenerator','python'),('recommendationservice','python'),('shoppingassistantservice','python'),('adservice','java')]
rows=[]
for service,language in services:
 source=root/'online-boutique/src'/service
 if language=='javascript':cmd=[str(root/'codeanalyzer-typescript/dist/cants')]
 elif language=='go':cmd=['/private/tmp/namespace-toolchains/cango']
 elif language=='python':cmd=[str(root/'python-sdk/.venv/bin/canpy'),'--no-ray']
 else:cmd=[os.environ['JAVA_HOME']+'/bin/java','-Xmx2g','-jar',str(root/'codeanalyzer-java/build/libs/codeanalyzer-3.3.4.jar'),'-f',str(source)]
 cmd+=['-i',str(source),'-o',str(work/'output'/service),'--namespace','online-boutique','--app-name',service,'--emit','neo4j','--neo4j-uri',os.environ['NEO4J_URI'],'--neo4j-database','neo4j']
 start=time.monotonic();print('START',service,language,flush=True)
 with (work/f'{service}.log').open('w') as log:
  proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,cwd=root,env=os.environ.copy(),start_new_session=True)
  try:code=proc.wait(timeout=600)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGTERM);code=124
 row=dict(service=service,language=language,exit=code,seconds=round(time.monotonic()-start,2),command=cmd)
 rows.append(row);(work/'projection-results.json').write_text(json.dumps(rows,indent=2)+'\n');print('RESULT',json.dumps({k:v for k,v in row.items() if k!='command'}),flush=True)
print('DONE',len(rows),flush=True)
